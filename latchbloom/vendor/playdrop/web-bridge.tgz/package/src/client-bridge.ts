import {
  BridgeEnvelope,
  BridgeEvent,
  BridgeMessageHandler,
  BridgeTransport,
  ClientBridgeOptions,
  LoadingState,
  LogEntry,
} from './types.js';

const DEFAULT_MAX_QUEUE = 32;
const CLIENT_BRIDGE_DEBUG = true;

function debugClientBridge(...args: unknown[]): void {
  if (!CLIENT_BRIDGE_DEBUG) {
    return;
  }
  try {
    console.debug('[web-bridge][client]', ...args);
  } catch {
    // avoid propagating console failures into bridge flow
  }
}

function createIframeClientTransport(parentOrigin: string | undefined, win?: Window): BridgeTransport {
  const runtimeWindow = win ?? (typeof window !== 'undefined' ? window : undefined);
  if (!runtimeWindow) {
    throw new Error('[web-bridge] iframe client transport requires a window');
  }
  const parentWindow = runtimeWindow.parent;

  if (!parentWindow || parentWindow === runtimeWindow) {
    throw new Error('[web-bridge] parent window unavailable for iframe client transport');
  }

  const listeners = new Set<(envelope: BridgeEnvelope) => void>();

  const onMessage = (event: MessageEvent) => {
    if (event.source !== parentWindow) {
      return;
    }
    if (parentOrigin && parentOrigin !== '*' && event.origin !== parentOrigin) {
      return;
    }
    const envelope = event.data;
    if (!envelope || typeof envelope !== 'object') {
      return;
    }
    listeners.forEach((listener) => {
      try {
        listener(envelope as BridgeEnvelope);
      } catch {
        // ignore listener error
      }
    });
  };

  runtimeWindow.addEventListener('message', onMessage);

  return {
    send(envelope: BridgeEnvelope): void {
      parentWindow.postMessage(envelope, parentOrigin ?? '*');
    },
    subscribe(handler: (envelope: BridgeEnvelope) => void): () => void {
      listeners.add(handler);
      return () => listeners.delete(handler);
    },
    close(): void {
      listeners.clear();
      runtimeWindow.removeEventListener('message', onMessage);
    },
  };
}

function createNativeTransport(options: ClientBridgeOptions): BridgeTransport {
  const runtimeWindow = options.window ?? (typeof window !== 'undefined' ? window : undefined);
  if (!runtimeWindow) {
    throw new Error('[web-bridge] native client transport requires a window');
  }

  const handlerName = options.nativeHandlerName ?? 'playdropNativeBridge';
  const callbackName = options.nativeCallbackName ?? '__playdropNativeBridge__';

  const listeners = new Set<(envelope: BridgeEnvelope) => void>();

  const namespace = (runtimeWindow as any)[callbackName] ?? {};
  const previous = typeof namespace.receiveMessage === 'function' ? namespace.receiveMessage : null;
  namespace.receiveMessage = (message: BridgeEnvelope) => {
    if (previous) {
      try {
        previous(message);
      } catch {
        // ignore
      }
    }
    listeners.forEach((listener) => {
      try {
        listener(message);
      } catch {
        // ignore
      }
    });
  };
  (runtimeWindow as any)[callbackName] = namespace;

  function postMessage(envelope: BridgeEnvelope) {
    const iosBridge = (runtimeWindow as any).webkit?.messageHandlers?.[handlerName];
    if (iosBridge && typeof iosBridge.postMessage === 'function') {
      iosBridge.postMessage(envelope);
      return;
    }

    const androidBridge = (runtimeWindow as any)[handlerName];
    if (androidBridge && typeof androidBridge.postMessage === 'function') {
      androidBridge.postMessage(envelope);
      return;
    }
    if (typeof androidBridge === 'function') {
      androidBridge(envelope);
      return;
    }

    console.warn('[web-bridge] native handler not available, message dropped');
  }

  return {
    send: postMessage,
    subscribe(handler: (envelope: BridgeEnvelope) => void): () => void {
      listeners.add(handler);
      return () => listeners.delete(handler);
    },
  };
}

export class ClientBridge {
  private readonly transport: BridgeTransport;
  private readonly handlers = new Map<string, Set<BridgeMessageHandler>>();
  private readonly maxQueue: number;
  private ready = false;
  private queue: BridgeEnvelope[] = [];
  private unsubscribe?: () => void;

  constructor(options: ClientBridgeOptions = {}) {
    this.maxQueue = options.maxQueue ?? DEFAULT_MAX_QUEUE;

    if (options.transport) {
      this.transport = options.transport;
    } else if (options.mode === 'native') {
      this.transport = createNativeTransport(options);
    } else {
      this.transport = createIframeClientTransport(options.parentOrigin, options.window);
    }

    this.unsubscribe = this.transport.subscribe((envelope) => this.handleIncoming(envelope));
  }

  on<T = unknown>(type: string, handler: BridgeMessageHandler<T>): () => void {
    if (!this.handlers.has(type)) {
      this.handlers.set(type, new Set());
    }
    const bucket = this.handlers.get(type)!;
    bucket.add(handler as BridgeMessageHandler);
    return () => {
      bucket.delete(handler as BridgeMessageHandler);
      if (bucket.size === 0) {
        this.handlers.delete(type);
      }
    };
  }

  send<T = unknown>(type: string, payload?: T): void {
    const envelope: BridgeEnvelope = { type, payload };
    debugClientBridge('send', envelope, { ready: this.ready });
    if (this.ready) {
      this.transport.send(envelope);
      return;
    }
    this.enqueue(envelope);
  }

  sendInit(): void {
    const envelope: BridgeEnvelope = { type: BridgeEvent.ClientInit };
    debugClientBridge('send', envelope, { immediate: true });
    this.transport.send(envelope);
  }

  sendLoading(state: LoadingState): void {
    this.send(BridgeEvent.ClientLoading, state);
  }

  sendLog(entry: LogEntry): void {
    this.send(BridgeEvent.ClientLog, entry);
  }

  destroy(): void {
    this.handlers.clear();
    this.queue = [];
    this.unsubscribe?.();
    this.transport.close?.();
  }

  private handleIncoming(envelope: BridgeEnvelope): void {
    debugClientBridge('received', envelope);
    const type = envelope?.type;
    if (typeof type !== 'string' || type.length === 0) {
      return;
    }

    if (!this.ready && (type === BridgeEvent.HostInit || type === BridgeEvent.HostStart)) {
      this.ready = true;
      this.flushQueue();
    }

    const bucket = this.handlers.get(type);
    if (!bucket || bucket.size === 0) {
      return;
    }

    bucket.forEach((handler) => {
      try {
        handler(envelope.payload, envelope);
      } catch {
        // ignore handler error
      }
    });
  }

  private enqueue(envelope: BridgeEnvelope): void {
    debugClientBridge('queueing', envelope, { queueLength: this.queue.length });
    this.queue.push(envelope);
    if (this.queue.length > this.maxQueue) {
      this.queue.splice(0, this.queue.length - this.maxQueue);
    }
  }

  private flushQueue(): void {
    if (!this.queue.length) {
      return;
    }
    const pending = this.queue;
    this.queue = [];
    debugClientBridge('flushing queued envelopes', { count: pending.length });
    for (const envelope of pending) {
      this.transport.send(envelope);
    }
  }
}

export function createClientBridge(options?: ClientBridgeOptions): ClientBridge {
  return new ClientBridge(options);
}
