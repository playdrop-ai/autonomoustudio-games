export type Deployment = 'dev' | 'live';
export type Platform = 'web' | 'native';
export type HostRuntime = 'web' | 'native';
export type HostChannel = 'local' | 'dev' | 'prod';
export type DeviceCategory = 'desktop' | 'tablet' | 'phone';
export type DeviceOrientation = 'portrait' | 'landscape';

export type LoadingState =
  | { status: 'loading'; message?: string; progress?: number }
  | { status: 'ready' }
  | { status: 'error'; message?: string };

export type LogSeverity = 'debug' | 'info' | 'warn' | 'error';

export interface LogEntry {
  severity: LogSeverity;
  message: string;
  payload?: unknown;
}

export interface HostInfo {
  deployment: Deployment;
  platform: Platform;
  sdkVersion: string;
  runtime: HostRuntime;
  appVersion: string;
  channel: HostChannel;
  apiServerUrl?: string;
  realtimeServerUrl?: string;
  assetsServerUrl?: string;
  webAppUrl?: string;
  localAssetStoreUrl?: string | null;
}

export interface DeviceInfo {
  category: DeviceCategory;
  orientation: DeviceOrientation;
  inputs: {
    keyboard: boolean;
    mouse: boolean;
    touch: boolean;
  };
}

export interface SessionInfo {
  mode: 'dev' | 'play';
  authToken: string;
}

export interface MeInfo {
  username: string | null;
  selectedProfileAssetRef: string | null;
}

import type { AppSurface } from '@playdrop/types';

export interface AppInfo {
  id: number | null;
  name: string;
  creatorUsername: string;
  displayName: string | null;
  description: string | null;
  emoji: string | null;
  color: string | null;
  type: string | null;
  surfaceTargets: AppSurface[];
  /** Semantic version string (e.g., "1.2.3") for multiplayer room isolation */
  version: string | null;
}

export interface HostInitPayload {
  host: HostInfo;
  device: DeviceInfo;
  session: SessionInfo;
  me: MeInfo;
  app: AppInfo;
  services: {
    apiBaseUrl: string;
    realtimeWebsocketUrl: string;
    assetsBaseUrl: string;
    webAppUrl: string;
    localAssetStoreUrl?: string;
  };
}

export interface BridgeEnvelope<T = unknown> {
  type: string;
  payload?: T;
}

export const BridgeEvent = {
  ClientInit: 'client:init',
  HostInit: 'host:init',
  HostStart: 'host:start',
  ClientLoading: 'client:loading',
  ClientLog: 'client:log',
  ClientShopPurchase: 'client:shop:purchase',
  HostShopPurchaseResult: 'host:shop:purchase-result',
} as const;

export type BridgeEventName = (typeof BridgeEvent)[keyof typeof BridgeEvent];

export type BridgeMessageHandler<T = unknown> = (payload: T, envelope: BridgeEnvelope<T>) => void;

export interface BridgeTransport {
  send(envelope: BridgeEnvelope): void;
  subscribe(handler: (envelope: BridgeEnvelope) => void): () => void;
  close?(): void;
}

export interface HostBridgeOptions {
  transport?: BridgeTransport;
  iframe?: { contentWindow: Window | null } | null;
  targetOrigin?: string;
  hostWindow?: Window;
  maxQueue?: number;
}

export interface ClientBridgeOptions {
  transport?: BridgeTransport;
  mode?: 'iframe' | 'native';
  parentOrigin?: string;
  window?: Window;
  nativeHandlerName?: string;
  nativeCallbackName?: string;
  maxQueue?: number;
}
