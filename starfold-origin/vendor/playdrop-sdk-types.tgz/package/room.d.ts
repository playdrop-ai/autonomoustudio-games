import type { AppData, Room } from './types.js';
export declare function joinRoom(): Promise<Room>;
export declare function createRoom(config?: Record<string, string | number | boolean>): Promise<Room>;
export declare function joinRoomById(roomId: number): Promise<Room>;
export declare function joinOrCreateRoom(config?: Record<string, string | number | boolean>): Promise<Room>;
export declare function getActiveRoom(): Room | null;
export declare function applySelfAppDataSnapshotToActiveRoom(snapshot: AppData | null): void;
export declare function __resetRoomStateForTests(): void;
