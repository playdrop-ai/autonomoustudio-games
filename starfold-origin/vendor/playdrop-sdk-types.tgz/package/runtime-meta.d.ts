export interface RuntimeSdkMeta {
    version: string;
    build: number;
}
export declare function readRuntimeSdkMeta(): RuntimeSdkMeta;
