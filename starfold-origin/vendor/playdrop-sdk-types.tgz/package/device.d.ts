import type { ControllerAvailability, DeviceAPI, DeviceCategory, DeviceControllerState, DeviceGamepad, DeviceInputs, DeviceOrientation } from './types.js';
interface DeviceState {
    category: DeviceCategory;
    orientation: DeviceOrientation;
    inputs: DeviceInputs;
    controller: DeviceControllerState;
}
export declare function setDeviceInfo(info: DeviceState): void;
export declare function setControllerState(state: {
    availability: ControllerAvailability;
    gamepads: DeviceGamepad[];
}): void;
export declare const device: DeviceAPI;
export {};
