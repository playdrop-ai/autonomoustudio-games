import { createApiClient } from '@playdrop/api-client';
import { type ClientBridge } from '@playdrop/web-bridge';
import type { AchievementsAPI, LeaderboardsAPI } from './types.js';
export declare const achievements: AchievementsAPI;
export declare const leaderboards: LeaderboardsAPI;
export declare const __test__: {
    setApiClientFactory(fn: typeof createApiClient): void;
    setBridgeResolver(fn: () => ClientBridge | null): void;
    resetApiClientFactory(): void;
    resetBridgeResolver(): void;
    resetState(): void;
};
