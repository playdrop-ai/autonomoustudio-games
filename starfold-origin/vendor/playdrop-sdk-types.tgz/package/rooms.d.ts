import type { RoomsAPI } from './types.js';
export declare const rooms: RoomsAPI;
