import { type ClientBridge } from '@playdrop/web-bridge';
import type { AdsAPI } from './types.js';
export declare const ads: AdsAPI;
export declare function resetAdsState(): void;
export declare const __test__: {
    setBridgeResolver(fn: () => ClientBridge | null): void;
    resetBridgeResolver(): void;
    resetState(): void;
};
