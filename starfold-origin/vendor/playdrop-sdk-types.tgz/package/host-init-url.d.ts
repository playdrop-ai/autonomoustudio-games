export declare function normalizeRequiredUrl(raw: unknown, label: string): string;
export declare function normalizeRequiredRealtimeServerUrl(raw: unknown): string;
