import type { HostAPI, HostPhase, HostAudioPolicyReason, HostPauseReason, SessionMode } from './types.js';
export declare function resetHostStateForTests(): void;
export declare function setSessionMode(mode: SessionMode): void;
export declare function setHostPhase(nextPhase: HostPhase): void;
export declare function applyHostPause(reason: HostPauseReason): void;
export declare function applyHostResume(reason: HostPauseReason): void;
export declare function setAudioPolicy(enabled: boolean, reason: HostAudioPolicyReason): void;
export declare const host: HostAPI;
