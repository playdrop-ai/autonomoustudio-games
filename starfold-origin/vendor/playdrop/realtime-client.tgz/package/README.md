# @playdrop/realtime-client

Typed WebSocket client for the realtime server protocol used by the web app and SDK.

## Responsibilities
- Manages the WebSocket lifecycle (connect, authenticate, reconnect with backoff, teardown) against the realtime service.
- Tracks in-flight requests, correlates acknowledgements, and exposes callbacks for room events, app login, and user data updates.
- Emits connection quality metrics (latency, jitter, clock offset) via the bundled `TelemetryTracker`.
- Redacts sensitive payload fields (e.g. tokens) before logging debug output when realtime debugging is enabled.

## Usage
```ts
import { RealtimeClient } from '@playdrop/realtime-client';

const client = new RealtimeClient({ url: 'ws://localhost:3000', appId: 42 });
client.onStateChange((state) => console.log('state', state));
client.connect('Bearer …');
```

## Configuration
- Accepts explicit `url`, `reconnect`, custom `WebSocketImpl`, and optional pre-allocated `TelemetryTracker` instances.
- Supports dynamic app context updates via `setAppContext()`.

## Implementation Notes
- Protocol enums and frame types are pulled from `@playdrop/types/realtime`, ensuring contract consistency with the server.
- Pending requests expire after `DEFAULT_REQUEST_TIMEOUT_MS`; timeouts reject Promises so callers can handle back-pressure.
- Room broadcasts automatically propagate to listeners without requiring manual ack management.

## Related Workspaces
- Wrapped by `@playdrop/sdk` and the web app’s runtime manager; also useful for integration tests or custom tooling.
