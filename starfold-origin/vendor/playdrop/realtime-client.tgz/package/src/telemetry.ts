/**
 * Connection telemetry tracker.
 * Computes latency/jitter from ping/pong samples.
 */

const OFFSET_SMOOTHING = 0.2;
const JITTER_ALPHA = 0.3;

export interface PingSample {
  roundTripMs: number;
  offsetMs: number;
}

export interface TelemetrySnapshot {
  latencyMs: number;
  jitterMs: number;
  clockOffsetMs: number;
}

export class TelemetryTracker {
  private lastRoundTrip = 0;
  private snapshot: TelemetrySnapshot = {
    latencyMs: 0,
    jitterMs: 0,
    clockOffsetMs: 0,
  };

  recordSample(sample: PingSample): void {
    if (!Number.isFinite(sample.roundTripMs)) {
      return;
    }
    const roundTrip = Math.max(0, sample.roundTripMs);
    if (this.lastRoundTrip === 0) {
      this.lastRoundTrip = roundTrip;
      this.snapshot.latencyMs = roundTrip;
      this.snapshot.jitterMs = roundTrip;
    } else {
      const jitterSample = Math.abs(roundTrip - this.lastRoundTrip);
      this.snapshot.jitterMs = this.snapshot.jitterMs + (jitterSample - this.snapshot.jitterMs) * JITTER_ALPHA;
      this.lastRoundTrip = roundTrip;
      this.snapshot.latencyMs = roundTrip;
    }
    if (Number.isFinite(sample.offsetMs)) {
      this.snapshot.clockOffsetMs = this.snapshot.clockOffsetMs + (sample.offsetMs - this.snapshot.clockOffsetMs) * OFFSET_SMOOTHING;
    }
  }

  getSnapshot(): TelemetrySnapshot {
    return { ...this.snapshot };
  }

  reset(): void {
    this.lastRoundTrip = 0;
    this.snapshot = {
      latencyMs: 0,
      jitterMs: 0,
      clockOffsetMs: 0,
    };
  }
}