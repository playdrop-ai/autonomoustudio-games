// Export the main client
export { RealtimeClient } from './client.js';
export type {
  RealtimeState,
  ConnectionQuality,
  RealtimeClientListeners,
  RealtimeClientConfig,
  AuthAckPayload,
} from './client.js';

// Export telemetry utilities
export { TelemetryTracker } from './telemetry.js';
export type {
  PingSample,
  TelemetrySnapshot,
} from './telemetry.js';

// Re-export realtime protocol types for convenience
export type {
  ClientFrame,
  ServerFrame,
  ClientOpcode,
  ServerOpcode,
  ErrorCode,
  ConnectionContext,
  RoomState,
  // Individual frame types
  AuthRequest,
  AuthAck,
  TimePingRequest,
  TimePongResponse,
  SetSelectedAvatarRequest,
  SetSelectedAvatarAck,
  AppLoginRequest,
  AppLoginResponse,
  UserAppDataOverrideRequest,
  UserAppDataOverrideAck,
  JoinRoomRequest,
  JoinRoomAck,
  RoomDataOverrideRequest,
  RoomDataOverrideAck,
  RoomLeaveRequest,
  RoomLeaveAck,
  RoomEventJsonSendRequest,
  RoomEventJsonAck,
  RoomEventJsonBroadcast,
  RoomEventBinarySendRequest,
  RoomEventBinaryAck,
  RoomEventBinaryBroadcast,
  RoomMemberSnapshot,
  ServerError,
} from '@playdrop/types/realtime';