import {
  ClientOpcode,
  ServerOpcode,
  type AuthAck,
  type ServerError,
  type TimePongResponse,
  type RoomEventBinarySendRequest,
  type RoomEventBinaryAck,
  type RoomEventBinaryBroadcast,
  type AppLoginResponse,
  type UserAppDataOverrideAck,
  type JoinRoomAck,
  type RoomDataOverrideAck,
  type RoomLeaveAck,
  type RoomEventJsonAck,
  type RoomEventJsonBroadcast,
  type RoomDataOverrideBroadcast,
  type RoomLeaveBroadcast,
  type JoinRoomBroadcast,
  type SetSelectedAvatarAck,
  type UserAppDataOverrideBroadcast,
} from '@playdrop/types/realtime';
import { TelemetryTracker, type PingSample, type TelemetrySnapshot } from './telemetry.js';

const REALTIME_DEBUG = true;

function debugRealtime(...args: unknown[]): void {
  if (!REALTIME_DEBUG) {
    return;
  }
  try {
    console.debug('[realtime-client]', ...args);
  } catch {
    // ignore logger failures to keep realtime flow intact
  }
}

function sanitizeFrame(frame: unknown): unknown {
  if (!frame || typeof frame !== 'object') {
    return frame;
  }
  if (Array.isArray(frame)) {
    return frame.map((entry) => sanitizeFrame(entry));
  }
  const source = frame as Record<string, unknown>;
  const result: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(source)) {
    if (key === 'token') {
      result[key] = '[redacted]';
      continue;
    }
    result[key] = sanitizeFrame(value);
  }
  return result;
}

const DEFAULT_REQUEST_TIMEOUT_MS = 3000;

interface PendingRequest {
  resolve: (value: unknown) => void;
  reject: (reason: unknown) => void;
  timeout: ReturnType<typeof setTimeout>;
}

export type RealtimeState =
  | 'disconnected'
  | 'connecting'
  | 'connected'
  | 'authenticating'
  | 'authenticated';

export interface ConnectionQuality {
  latencyMs: number;
  jitterMs: number;
  clockOffsetMs: number;
}

export interface RealtimeClientListeners {
  onStateChange?(state: RealtimeState): void;
  onAuthAck?(payload: AuthAckPayload): void;
  onError?(error: unknown): void;
  onMessage?(frame: unknown): void;
  onConnectionQuality?(update: ConnectionQuality): void;
  // High-level event listeners
  onRoomEventJsonBroadcast?(event: RoomEventJsonBroadcast): void;
  onRoomEventBinaryBroadcast?(event: RoomEventBinaryBroadcast): void;
  onRoomDataUpdate?(update: RoomDataOverrideBroadcast): void;
  onRoomSnapshot?(snapshot: JoinRoomBroadcast): void;
  onRoomLeaveBroadcast?(payload: RoomLeaveBroadcast): void;
  onAppLoginResponse?(response: AppLoginResponse): void;
  onUserAppDataOverrideAck?(response: UserAppDataOverrideAck): void;
  onUserAppDataOverrideBroadcast?(response: UserAppDataOverrideBroadcast): void;
  onJoinRoomAck?(response: JoinRoomAck): void;
  onRoomDataOverrideAck?(response: RoomDataOverrideAck): void;
  onRoomLeaveAck?(response: RoomLeaveAck): void;
  onRoomEventJsonAck?(response: RoomEventJsonAck): void;
}

export interface RealtimeClientConfig {
  url?: string;
  reconnect?: boolean;
  telemetry?: TelemetryTracker;
  WebSocketImpl?: typeof WebSocket;
  appId?: number;
}

export interface AuthAckPayload {
  userId: number;
  username: string;
  selectedAvatarId: number;
  raw: any;
}

const DEFAULT_RECONNECT = true;
const MAX_BACKOFF_MS = 10_000;
const PING_INTERVAL_MS = 1_000;

export class RealtimeClient {
  private ws: WebSocket | null = null;
  private state: RealtimeState = 'disconnected';
  private listeners: RealtimeClientListeners = {};
  private seq = 0;
  private token: string | null = null;
  private shouldReconnect: boolean;
  private reconnectPreference: boolean;
  private reconnectTimer: ReturnType<typeof setTimeout> | null = null;
  private reconnectAttempts = 0;
  private readonly explicitUrl?: string;
  private pingTimer: ReturnType<typeof setInterval> | null = null;
  private pendingPing: { seq: number; t0: number } | null = null;
  private telemetry: TelemetryTracker;
  private WebSocketConstructor: typeof WebSocket;
  private appId: number | null;
  private readonly pending = new Map<number, PendingRequest>();
  private authContext: { userId: number; username: string; selectedAvatarId: number } | null = null;

  constructor(config: RealtimeClientConfig = {}) {
    this.reconnectPreference = config.reconnect ?? DEFAULT_RECONNECT;
    this.shouldReconnect = this.reconnectPreference;
    this.explicitUrl = config.url;
    this.telemetry = config.telemetry ?? new TelemetryTracker();
    this.WebSocketConstructor = config.WebSocketImpl ?? (typeof WebSocket !== 'undefined' ? WebSocket : null as any);
    this.appId = typeof config.appId === 'number' && Number.isFinite(config.appId) ? config.appId : null;

    if (!this.WebSocketConstructor) {
      throw new Error('WebSocket implementation not available');
    }

    debugRealtime('constructed', {
      explicitUrl: this.explicitUrl,
      reconnect: this.reconnectPreference,
      appId: this.appId,
    });
  }

  setAppContext(appId: number | null): void {
    this.appId = typeof appId === 'number' && Number.isFinite(appId) ? appId : null;
    debugRealtime('app context updated', { appId: this.appId });
  }

  private allocateSeq(): number {
    return ++this.seq;
  }

  private resolvePending(ack: number | undefined, payload: unknown): boolean {
    if (typeof ack !== 'number' || !Number.isFinite(ack)) {
      return false;
    }
    const pending = this.pending.get(ack);
    if (!pending) {
      return false;
    }
    this.pending.delete(ack);
    pending.resolve(payload);
    return true;
  }

  private rejectPending(ack: number | undefined, error: unknown): boolean {
    if (typeof ack !== 'number' || !Number.isFinite(ack)) {
      return false;
    }
    const pending = this.pending.get(ack);
    if (!pending) {
      return false;
    }
    this.pending.delete(ack);
    pending.reject(error);
    return true;
  }

  protected getRequestTimeout(): number {
    return DEFAULT_REQUEST_TIMEOUT_MS;
  }

  private rejectAllPending(error: unknown): void {
    if (!this.pending.size) {
      return;
    }
    for (const [, pending] of this.pending) {
      clearTimeout(pending.timeout);
      pending.reject(error);
    }
    this.pending.clear();
  }

  private sendRequest<T>(
    buildFrame: (seq: number) => Record<string, unknown>,
    transform: (payload: any) => T
  ): Promise<T> {
    const seq = this.allocateSeq();
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        this.pending.delete(seq);
        reject(new Error('realtime_request_timeout'));
      }, this.getRequestTimeout());

      const pending: PendingRequest = {
        timeout,
        resolve: (payload) => {
          clearTimeout(timeout);
          try {
            resolve(transform(payload));
          } catch (error) {
            reject(error);
          }
        },
        reject: (error) => {
          clearTimeout(timeout);
          reject(error);
        },
      };

      this.pending.set(seq, pending);

      try {
        const frame = buildFrame(seq);
        this.send(frame);
      } catch (error) {
        clearTimeout(timeout);
        this.pending.delete(seq);
        reject(error);
      }
    });
  }

  private requireAppId(explicit?: number): number {
    const resolved = typeof explicit === 'number' && Number.isFinite(explicit)
      ? explicit
      : this.appId;
    if (typeof resolved !== 'number' || !Number.isFinite(resolved)) {
      throw new Error('realtime_app_id_missing');
    }
    return resolved;
  }

  setListeners(listeners: RealtimeClientListeners): void {
    this.listeners = listeners;
  }

  getState(): RealtimeState {
    return this.state;
  }

  connect(token: string): void {
    this.token = token;
    this.shouldReconnect = this.reconnectPreference;
    this.clearReconnectTimer();
    debugRealtime('connect requested', { hasToken: Boolean(token) });
    this.openSocket();
  }

  disconnect(): void {
    this.shouldReconnect = false;
    this.clearReconnectTimer();
    this.stopPingLoop();
    debugRealtime('disconnect requested');
    if (this.ws) {
      try {
        this.ws.close();
      } catch (error) {
        debugRealtime('ignored websocket close failure', { error });
      }
    }
    this.ws = null;
    this.rejectAllPending(new Error('realtime_connection_closed'));
    this.updateState('disconnected');
    this.authContext = null;
  }

  send(frame: unknown): void {
    if (!this.ws || this.ws.readyState !== this.WebSocketConstructor.OPEN) {
      this.emitError(new Error('socket_not_open'));
      return;
    }
    try {
      debugRealtime('send frame', sanitizeFrame(frame));
      if (typeof frame === 'string') {
        this.ws.send(frame);
      } else if (this.isBinaryRoomEvent(frame)) {
        const payload = this.encodeBinaryFrame(frame);
        this.ws.send(payload);
      } else {
        this.ws.send(JSON.stringify(frame));
      }
    } catch (error) {
      this.emitError(error);
    }
  }

  private isBinaryRoomEvent(frame: unknown): frame is RoomEventBinarySendRequest {
    return (
      frame != null &&
      typeof frame === 'object' &&
      'opcode' in frame &&
      frame.opcode === ClientOpcode.RoomEventBinary &&
      'payload' in frame &&
      frame.payload instanceof Float64Array
    );
  }

  private encodeBinaryFrame(frame: RoomEventBinarySendRequest): ArrayBuffer {
    // Binary frame format: [opcode, seq, roomId, ts, eventCode, payloadLength, payload...]
    const view = new DataView(new ArrayBuffer(48 + frame.payload.length * 8));
    let offset = 0;

    view.setFloat64(offset, frame.opcode, true); offset += 8;
    view.setFloat64(offset, frame.seq, true); offset += 8;
    view.setFloat64(offset, frame.roomId, true); offset += 8;
    view.setFloat64(offset, frame.ts, true); offset += 8;
    view.setFloat64(offset, frame.eventCode, true); offset += 8;
    view.setFloat64(offset, frame.payload.length, true); offset += 8;

    const payloadView = new Float64Array(view.buffer, offset);
    payloadView.set(frame.payload);

    return view.buffer;
  }

  updateSelectedAvatar(avatarId: number): void {
    if (!Number.isFinite(avatarId) || avatarId <= 0) {
      console.warn('[RealtimeClient] ignoring invalid avatar id', avatarId);
      return;
    }
    if (!this.ws || this.ws.readyState !== this.WebSocketConstructor.OPEN) {
      console.warn('[RealtimeClient] cannot send SetSelectedAvatar; socket not open');
      return;
    }
    const payload = {
      opcode: ClientOpcode.SetSelectedAvatar,
      seq: ++this.seq,
      avatarId,
    };
    try {
      this.ws.send(JSON.stringify(payload));
    } catch (error) {
      this.emitError(error);
    }
  }

  private openSocket(): void {
    if (!this.token) {
      return;
    }
    if (this.ws && (this.ws.readyState === this.WebSocketConstructor.OPEN || this.ws.readyState === this.WebSocketConstructor.CONNECTING)) {
      return;
    }

    const url = this.resolveRealtimeUrl();
    if (!url) {
      debugRealtime('openSocket aborted: unable to resolve URL');
      this.emitError(new Error('Unable to resolve realtime WebSocket URL'));
      return;
    }

    try {
      debugRealtime('opening websocket', { url });
      this.ws = new this.WebSocketConstructor(url);
      if ('binaryType' in this.ws) {
        try {
          (this.ws as WebSocket).binaryType = 'arraybuffer';
        } catch (error) {
          debugRealtime('failed to set websocket binaryType', { error });
        }
      }
    } catch (error) {
      debugRealtime('failed to construct websocket', { error });
      this.emitError(error);
      this.scheduleReconnect();
      return;
    }

    this.updateState('connecting');

    this.ws.onopen = () => {
      debugRealtime('websocket open');
      this.reconnectAttempts = 0;
      this.sendAuth();
    };

    this.ws.onmessage = (event) => {
      debugRealtime('websocket message received', { type: typeof event.data });
      this.handleMessage(event.data);
    };

    this.ws.onerror = (event) => {
      debugRealtime('websocket error', event);
      this.emitError(event);
    };

    this.ws.onclose = () => {
      debugRealtime('websocket closed');
      this.updateState('disconnected');
      this.ws = null;
      this.rejectAllPending(new Error('realtime_connection_closed'));
      if (this.shouldReconnect) {
        this.scheduleReconnect();
      }
    };
  }

  private sendAuth(): void {
    if (!this.ws || this.ws.readyState !== this.WebSocketConstructor.OPEN || !this.token) {
      return;
    }
    this.updateState('authenticating');
    const payload = {
      opcode: ClientOpcode.Auth,
      seq: ++this.seq,
      token: this.token,
    };
    debugRealtime('sending auth frame', { seq: payload.seq });
    try {
      this.ws.send(JSON.stringify(payload));
    } catch (error) {
      this.emitError(error);
    }
  }

  private handleMessage(raw: any): void {
    let parsed: any;

    debugRealtime('handleMessage received', {
      isArrayBuffer: raw instanceof ArrayBuffer,
      isView: ArrayBuffer.isView(raw),
      isString: typeof raw === 'string',
    });

    if (raw instanceof ArrayBuffer || ArrayBuffer.isView(raw)) {
      parsed = this.parseBinaryFrame(raw);
      if (!parsed) return;
    } else if (typeof raw === 'string') {
      try {
        parsed = JSON.parse(raw);
      } catch (error) {
        debugRealtime('failed to parse JSON frame', { error });
        this.emitError(error);
        return;
      }
    } else if (typeof Blob !== 'undefined' && raw instanceof Blob) {
      raw.arrayBuffer().then((buffer) => {
        const parsedFrame = this.parseBinaryFrame(buffer);
        if (parsedFrame) {
          debugRealtime('parsed blob frame', sanitizeFrame(parsedFrame));
          this.processParsedFrame(parsedFrame);
        }
      }).catch((error) => this.emitError(error));
      return;
    } else {
      return;
    }

    debugRealtime('parsed frame', sanitizeFrame(parsed));
    this.processParsedFrame(parsed);
  }

  private processParsedFrame(parsed: any): void {
    const opcode = Number(parsed?.opcode);
    if (Number.isNaN(opcode)) {
      return;
    }

    debugRealtime('process frame', { opcode, frame: sanitizeFrame(parsed) });

    if (opcode === ServerOpcode.AuthAck) {
      this.updateState('authenticated');
      const payload: AuthAckPayload = {
        userId: Number(parsed.userId) || 0,
        username: String(parsed.username ?? ''),
        selectedAvatarId: Number(parsed.selectedAvatarId) || 0,
        raw: parsed,
      };
      this.authContext = {
        userId: payload.userId,
        username: payload.username,
        selectedAvatarId: payload.selectedAvatarId,
      };
      this.startPingLoop();
      this.listeners.onAuthAck?.(payload);
      return;
    }
    if (opcode === ServerOpcode.TimePong) {
      this.handleTimePong(parsed as TimePongResponse);
      return;
    }
    if (opcode === ServerOpcode.Error) {
      const errorFrame = parsed as ServerError;
      const handled = this.rejectPending(errorFrame.ack, errorFrame);
      if (!handled) {
        debugRealtime('unmatched error frame', { ack: errorFrame.ack });
        if (!Number.isFinite(errorFrame.ack) || errorFrame.ack === 0) {
          this.rejectAllPending(errorFrame);
        }
      }
      this.emitError(errorFrame);
      return;
    }
    if (opcode === ServerOpcode.SetSelectedAvatarAck) {
      const payload = parsed as SetSelectedAvatarAck;
      this.resolvePending(payload.ack, payload);
      return;
    }
    if (opcode === ServerOpcode.AppLoginAck) {
      const payload = parsed as AppLoginResponse;
      this.resolvePending(payload.ack, payload);
      this.listeners.onAppLoginResponse?.(payload);
      return;
    }
    if (opcode === ServerOpcode.UserAppDataOverrideAck) {
      const payload = parsed as UserAppDataOverrideAck;
      this.resolvePending(payload.ack, payload);
      this.listeners.onUserAppDataOverrideAck?.(payload);
      return;
    }
    if (opcode === ServerOpcode.UserAppDataOverrideBroadcast) {
      const payload = parsed as UserAppDataOverrideBroadcast;
      this.listeners.onUserAppDataOverrideBroadcast?.(payload);
      return;
    }
    if (opcode === ServerOpcode.JoinRoomAck) {
      const payload = parsed as JoinRoomAck;
      this.resolvePending(payload.ack, payload);
      this.listeners.onJoinRoomAck?.(payload);
      return;
    }
    if (opcode === ServerOpcode.RoomDataOverrideAck) {
      const payload = parsed as RoomDataOverrideAck;
      this.resolvePending(payload.ack, payload);
      this.listeners.onRoomDataOverrideAck?.(payload);
      return;
    }
    if (opcode === ServerOpcode.RoomLeaveAck) {
      const payload = parsed as RoomLeaveAck;
      this.resolvePending(payload.ack, payload);
      this.listeners.onRoomLeaveAck?.(payload);
      return;
    }
    if (opcode === ServerOpcode.RoomEventJsonAck) {
      const payload = parsed as RoomEventJsonAck;
      this.resolvePending(payload.ack, payload);
      this.listeners.onRoomEventJsonAck?.(payload);
      return;
    }
    if (opcode === ServerOpcode.RoomEventBinaryAck) {
      const payload = parsed as RoomEventBinaryAck;
      this.resolvePending(payload.ack, payload);
      return;
    }
    if (opcode === ServerOpcode.RoomEventBinaryBroadcast) {
      const payload = parsed as RoomEventBinaryBroadcast;
      this.listeners.onRoomEventBinaryBroadcast?.(payload);
      return;
    }
    if (opcode === ServerOpcode.RoomEventJsonBroadcast) {
      const payload = parsed as RoomEventJsonBroadcast;
      this.listeners.onRoomEventJsonBroadcast?.(payload);
      return;
    }
    if (opcode === ServerOpcode.RoomDataUpdate) {
      const payload = parsed as RoomDataOverrideBroadcast;
      this.listeners.onRoomDataUpdate?.(payload);
      return;
    }
    if (opcode === ServerOpcode.RoomSnapshot) {
      const payload = parsed as JoinRoomBroadcast;
      this.listeners.onRoomSnapshot?.(payload);
      return;
    }
    if (opcode === ServerOpcode.RoomLeaveBroadcast) {
      const payload = parsed as RoomLeaveBroadcast;
      this.listeners.onRoomLeaveBroadcast?.(payload);
      return;
    }
    this.listeners.onMessage?.(parsed);
  }

  private parseBinaryFrame(raw: ArrayBuffer | ArrayBufferView): RoomEventBinaryAck | RoomEventBinaryBroadcast | null {
    try {
      const view = this.toDataView(raw);
      if (view.byteLength < 8) {
        return null;
      }

      const opcode = view.getFloat64(0, true);

      if (opcode === ServerOpcode.RoomEventBinaryAck) {
        if (view.byteLength < 40) {
          return null;
        }
        return {
          opcode: ServerOpcode.RoomEventBinaryAck,
          ack: view.getFloat64(8, true),
          roomId: view.getFloat64(16, true),
          seq: view.getFloat64(24, true),
          ts_arrival: view.getFloat64(32, true),
        };
      }

      if (opcode === ServerOpcode.RoomEventBinaryBroadcast) {
        if (view.byteLength < 64) {
          return null;
        }
        const roomId = view.getFloat64(8, true);
        const userId = view.getFloat64(16, true);
        const seq = view.getFloat64(24, true);
        const ts = view.getFloat64(32, true);
        const ts_arrival = view.getFloat64(40, true);
        const eventCode = view.getFloat64(48, true);
        const length = view.getFloat64(56, true);
        if (!Number.isFinite(length) || length < 0) {
          return null;
        }
        const payloadLength = Math.trunc(length);
        const payloadBytes = payloadLength * 8;
        if (view.byteLength - 64 < payloadBytes) {
          return null;
        }
        const payload = new Float64Array(payloadLength);
        for (let i = 0; i < payloadLength; i += 1) {
          payload[i] = view.getFloat64(64 + i * 8, true);
        }
        return {
          opcode: ServerOpcode.RoomEventBinaryBroadcast,
          roomId,
          userId,
          seq,
          ts,
          ts_arrival,
          eventCode,
          payload,
        };
      }

      return null;
    } catch (error) {
      this.emitError(error);
      return null;
    }
  }

  private toDataView(raw: ArrayBuffer | ArrayBufferView): DataView {
    if (raw instanceof ArrayBuffer) {
      return new DataView(raw);
    }
    if (ArrayBuffer.isView(raw)) {
      return new DataView(raw.buffer, raw.byteOffset, raw.byteLength);
    }
    throw new TypeError('Unsupported binary frame type');
  }

  private emitError(error: unknown): void {
    debugRealtime('error emitted', error);
    this.listeners.onError?.(error);
  }

  private updateState(next: RealtimeState): void {
    if (this.state === next) {
      return;
    }
    debugRealtime('state transition', { previous: this.state, next });
    this.state = next;
    this.listeners.onStateChange?.(next);
    if (next === 'disconnected' || next === 'connecting' || next === 'authenticating') {
      this.stopPingLoop();
    }
  }

  private scheduleReconnect(): void {
    if (!this.shouldReconnect || !this.token) {
      return;
    }
    this.clearReconnectTimer();
    this.reconnectAttempts += 1;
    const backoff = Math.min(1000 * 2 ** (this.reconnectAttempts - 1), MAX_BACKOFF_MS);
    debugRealtime('scheduling reconnect', { attempts: this.reconnectAttempts, backoff });
    this.reconnectTimer = setTimeout(() => {
      this.openSocket();
    }, backoff);
  }

  private clearReconnectTimer(): void {
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
      debugRealtime('cleared reconnect timer');
    }
  }

  private resolveRealtimeUrl(): string | null {
    if (this.explicitUrl) {
      return this.explicitUrl;
    }
    if (typeof window === 'undefined') {
      return null;
    }
    const { protocol, hostname } = window.location;
    const wsProtocol = protocol === 'https:' ? 'wss:' : 'ws:';

    let host: string;
    if (hostname.includes('www.') && hostname.includes('.')) {
      host = `play.${hostname.replace('www.', '')}`;
    } else if (hostname === 'play.local' || hostname === 'www.localhost') {
      host = hostname.includes('localhost') ? 'play.localhost' : 'play.local';
    } else if (hostname === 'localhost' || hostname === '127.0.0.1') {
      host = `${hostname}:3000`;
    } else if (hostname.includes(':')) {
      host = hostname;
    } else {
      host = `${hostname}:3000`;
    }

    return `${wsProtocol}//${host}/ws`;
  }

  private startPingLoop(): void {
    if (this.pingTimer || !this.ws || this.ws.readyState !== this.WebSocketConstructor.OPEN) {
      return;
    }
    this.sendTimePing();
    this.pingTimer = setInterval(() => this.sendTimePing(), PING_INTERVAL_MS);
  }

  private stopPingLoop(): void {
    if (this.pingTimer) {
      clearInterval(this.pingTimer);
      this.pingTimer = null;
    }
    this.pendingPing = null;
    this.telemetry.reset();
  }

  private sendTimePing(): void {
    if (!this.ws || this.ws.readyState !== this.WebSocketConstructor.OPEN) {
      return;
    }
    const payload = {
      opcode: ClientOpcode.TimePing,
      seq: ++this.seq,
      t0ClientMs: Date.now(),
    };
    this.pendingPing = { seq: payload.seq, t0: payload.t0ClientMs };
    debugRealtime('sending time ping', { seq: payload.seq });
    try {
      this.ws.send(JSON.stringify(payload));
    } catch (error) {
      this.emitError(error);
    }
  }

  private handleTimePong(payload: TimePongResponse): void {
    if (!this.pendingPing) {
      return;
    }
    const ack = payload.ack;
    if (!Number.isFinite(ack) || ack !== this.pendingPing.seq) {
      return;
    }
    debugRealtime('time pong received', { ack });
    const t1 = payload.t1ServerMs;
    const t2 = payload.t2ServerMs;
    if (!Number.isFinite(t1) || !Number.isFinite(t2)) {
      return;
    }
    const t0 = this.pendingPing.t0;
    const t3 = Date.now();
    const roundTrip = Math.max(0, t3 - t0);
    const offset = ((t1 - t0) + (t2 - t3)) / 2;
    const sample: PingSample = {
      roundTripMs: roundTrip,
      offsetMs: offset,
    };
    this.telemetry.recordSample(sample);
    this.pendingPing = null;
    const snapshot = this.telemetry.getSnapshot();
    this.listeners.onConnectionQuality?.({
      latencyMs: snapshot.latencyMs,
      jitterMs: snapshot.jitterMs,
      clockOffsetMs: snapshot.clockOffsetMs,
    });
  }

  // High-level API methods for SDK integration
  getServerTime(): number {
    const snapshot = this.telemetry.getSnapshot();
    return Date.now() + snapshot.clockOffsetMs;
  }

  getRenderTime(): number {
    return Date.now();
  }

  getAuthContext(): { userId: number; username: string; selectedAvatarId: number } | null {
    if (!this.authContext) {
      return null;
    }
    return { ...this.authContext };
  }

  // Event emitter interface for high-level events
  on(event: string, listener: (...args: any[]) => void): void {
    debugRealtime('register listener', { event });
    const wrapStateListener = (predicate: (state: RealtimeState) => boolean) => {
      const previous = this.listeners.onStateChange;
      this.listeners.onStateChange = (state) => {
        try {
          previous?.(state);
        } catch (error) {
          this.emitError(error);
        }
        if (predicate(state)) {
          try {
            listener();
          } catch (error) {
            this.emitError(error);
          }
        }
      };
    };

    if (event === 'connect') {
      wrapStateListener((state) => state === 'authenticated');
      return;
    }

    if (event === 'disconnect') {
      wrapStateListener((state) => state === 'disconnected');
      return;
    }

    if (event === 'error') {
      const previous = this.listeners.onError;
      this.listeners.onError = (error) => {
        previous?.(error);
        listener(error);
      };
      return;
    }

    if (event === 'quality') {
      const previous = this.listeners.onConnectionQuality;
      this.listeners.onConnectionQuality = (update) => {
        previous?.(update);
        listener(update);
      };
      return;
    }

    if (event === 'roomEventJsonBroadcast') {
      const previous = this.listeners.onRoomEventJsonBroadcast;
      this.listeners.onRoomEventJsonBroadcast = (payload) => {
        previous?.(payload);
        listener(payload);
      };
      return;
    }

    if (event === 'roomDataUpdate') {
      const previous = this.listeners.onRoomDataUpdate;
      this.listeners.onRoomDataUpdate = (payload) => {
        previous?.(payload);
        listener(payload);
      };
      return;
    }

    if (event === 'roomEventBinaryBroadcast') {
      const previous = this.listeners.onRoomEventBinaryBroadcast;
      this.listeners.onRoomEventBinaryBroadcast = (payload) => {
        previous?.(payload);
        listener(payload);
      };
      return;
    }

    if (event === 'roomSnapshot') {
      const previous = this.listeners.onRoomSnapshot;
      this.listeners.onRoomSnapshot = (payload) => {
        previous?.(payload);
        listener(payload);
      };
      return;
    }

    if (event === 'roomLeaveBroadcast') {
      const previous = this.listeners.onRoomLeaveBroadcast;
      this.listeners.onRoomLeaveBroadcast = (payload) => {
        previous?.(payload);
        listener(payload);
      };
      return;
    }

    if (event === 'appLoginResponse') {
      this.listeners.onAppLoginResponse = listener;
      return;
    }

    if (event === 'userAppDataOverrideAck') {
      this.listeners.onUserAppDataOverrideAck = listener;
      return;
    }

    if (event === 'userAppDataOverrideBroadcast') {
      const previous = this.listeners.onUserAppDataOverrideBroadcast;
      this.listeners.onUserAppDataOverrideBroadcast = (payload) => {
        previous?.(payload);
        listener(payload);
      };
      return;
    }

    if (event === 'joinRoomAck') {
      this.listeners.onJoinRoomAck = listener;
      return;
    }

    if (event === 'roomDataOverrideAck') {
      this.listeners.onRoomDataOverrideAck = listener;
      return;
    }

    if (event === 'roomLeaveAck') {
      this.listeners.onRoomLeaveAck = listener;
      return;
    }

    if (event === 'roomEventJsonAck') {
      this.listeners.onRoomEventJsonAck = listener;
    }
  }

  // App login
  async appLogin(options: { appId?: number; timestamp?: number; appVersion?: string } = {}): Promise<AppLoginResponse> {
    const appId = this.requireAppId(options.appId);
    const ts = typeof options.timestamp === 'number' ? options.timestamp : Date.now();
    const appVersion = typeof options.appVersion === 'string' ? options.appVersion : undefined;
    return this.sendRequest<AppLoginResponse>(
      (seq) => ({
        opcode: ClientOpcode.AppLogin,
        seq,
        appId,
        ts,
        ...(appVersion ? { appVersion } : {}),
      }),
      (payload) => payload as AppLoginResponse,
    );
  }

  // Update user app data
  async updateUserAppData(
    data: Record<string, any>,
    options: { appId?: number; timestamp?: number } = {}
  ): Promise<UserAppDataOverrideAck> {
    const appId = this.requireAppId(options.appId);
    const ts = typeof options.timestamp === 'number' ? options.timestamp : Date.now();
    return this.sendRequest<UserAppDataOverrideAck>(
      (seq) => ({
        opcode: ClientOpcode.UserAppDataOverride,
        seq,
        appId,
        appData: data,
        ts,
      }),
      (payload) => payload as UserAppDataOverrideAck,
    );
  }

  // Join room
  async joinRoom(options: { appId?: number; timestamp?: number; appVersion?: string } = {}): Promise<JoinRoomAck> {
    const appId = this.requireAppId(options.appId);
    const ts = typeof options.timestamp === 'number' ? options.timestamp : Date.now();
    const appVersion = typeof options.appVersion === 'string' ? options.appVersion : undefined;
    return this.sendRequest<JoinRoomAck>(
      (seq) => ({
        opcode: ClientOpcode.JoinRoom,
        seq,
        appId,
        ts,
        ...(appVersion ? { appVersion } : {}),
      }),
      (payload) => payload as JoinRoomAck,
    );
  }

  // Update room data
  async updateRoomData(
    roomId: number,
    data: Record<string, any>,
    options: { appId?: number; timestamp?: number } = {}
  ): Promise<RoomDataOverrideAck> {
    const appId = this.requireAppId(options.appId);
    const ts = typeof options.timestamp === 'number' ? options.timestamp : Date.now();
    return this.sendRequest<RoomDataOverrideAck>(
      (seq) => ({
        opcode: ClientOpcode.RoomDataOverride,
        seq,
        roomId,
        roomData: data,
        ts,
        appId,
      }),
      (payload) => payload as RoomDataOverrideAck,
    );
  }

  // Leave room
  async leaveRoom(
    roomId: number,
    options: { appId?: number; timestamp?: number } = {}
  ): Promise<RoomLeaveAck> {
    const appId = this.requireAppId(options.appId);
    const ts = typeof options.timestamp === 'number' ? options.timestamp : Date.now();
    return this.sendRequest<RoomLeaveAck>(
      (seq) => ({
        opcode: ClientOpcode.RoomLeave,
        seq,
        roomId,
        ts,
        appId,
      }),
      (payload) => payload as RoomLeaveAck,
    );
  }

  // Send room event
  async sendRoomEventJson(
    roomId: number,
    type: string,
    payload: Record<string, any>,
    options: { appId?: number; timestamp?: number } = {}
  ): Promise<RoomEventJsonAck> {
    const appId = this.requireAppId(options.appId);
    const ts = typeof options.timestamp === 'number' ? options.timestamp : Date.now();
    return this.sendRequest<RoomEventJsonAck>(
      (seq) => ({
        opcode: ClientOpcode.RoomEventJson,
        seq,
        roomId,
        ts,
        eventType: type,
        payload,
        appId,
      }),
      (ack) => ack as RoomEventJsonAck,
    );
  }

  async sendRoomEventBinary(
    roomId: number,
    eventCode: number,
    payload: Float64Array,
    options: { appId?: number; timestamp?: number } = {}
  ): Promise<RoomEventBinaryAck> {
    this.requireAppId(options.appId);
    const ts = typeof options.timestamp === 'number' ? options.timestamp : Date.now();
    const normalizedPayload = payload instanceof Float64Array ? payload : new Float64Array(payload);
    return this.sendRequest<RoomEventBinaryAck>(
      (seq) => ({
        opcode: ClientOpcode.RoomEventBinary,
        seq,
        roomId,
        ts,
        eventCode,
        payload: normalizedPayload,
      }),
      (ack) => ack as RoomEventBinaryAck,
    );
  }
}
