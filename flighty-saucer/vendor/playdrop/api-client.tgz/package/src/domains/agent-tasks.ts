import { AGENT_TASK_KIND_VALUES } from '@playdrop/types';
import type {
  AdminAgentTaskDetailResponse,
  AdminAgentTaskTranscriptResponse,
  AdminAgentTasksResponse,
  AdminAgentWorkersStatusResponse,
  AgentExecutionTarget,
  AgentTaskCreatorFeedbackStatus,
  AgentTaskAvailabilityResponse,
  AgentTaskAttachmentUploadResponse,
  AgentTaskDetailResponse,
  AgentTaskEventsResponse,
  AgentTaskKind,
  AgentTaskNewGameSuggestionsResponse,
  AgentTaskStatus,
  AgentTasksResponse,
  AppAgentTaskResponse,
  CancelAgentTaskResponse,
  ClearAgentTaskResponse,
  CreateAppAgentTaskRequest,
  CreateAppAgentTaskResponse,
  CreateGameEvalAgentTaskRequest,
  CreateGameEvalAgentTaskResponse,
  CreateNewGameAgentTaskRequest,
  CreateNewGameAgentTaskResponse,
  CreateRemixGameAgentTaskRequest,
  CreateRemixGameAgentTaskResponse,
  CreatorGameCreatorFeedbackStatusResponse,
  CreatorGamesListResponse,
  CreatorGameShareResponse,
  CreatorGameStatusResponse,
  CreatorGameVersionsResponse,
  MeAgentWorkersResponse,
  RegisterAgentBundleRequest,
  RegisterAgentBundleResponse,
  RetryAgentTaskResponse,
  WorkerClaimAgentTaskRequest,
  WorkerClaimAgentTaskResponse,
  WorkerClaimAgentTaskSlugRequest,
  WorkerClaimAgentTaskSlugResponse,
  WorkerCompleteAgentTaskRequest,
  WorkerCreateAgentTaskEventRequest,
  WorkerCreateAgentTaskEventResponse,
  WorkerCreateAgentTaskTranscriptChunkRequest,
  WorkerCreateAgentTaskTranscriptChunkResponse,
  WorkerFailAgentTaskRequest,
  WorkerAgentTaskAttemptUnavailableRequest,
  WorkerAgentTaskAttemptUnavailableResponse,
  WorkerHeartbeatAgentTaskRequest,
  WorkerHeartbeatAgentTaskResponse,
  WorkerRecordAgentTaskRunTelemetryRequest,
  WorkerRecordAgentTaskRunTelemetryResponse,
  WorkerPresenceRequest,
  WorkerPresenceResponse,
  WorkerUpdateIntentRequest,
  WorkerUpdateIntentResponse,
  WorkerSubmitAgentTaskEvalRequest,
  WorkerSubmitAgentTaskEvalResponse,
  WorkerSubmitAgentTaskReviewRequest,
  WorkerSubmitAgentTaskReviewResponse,
} from '@playdrop/types';
import { buildBrowserCredentialsInit } from '../core/request.js';

type ApiResponseLike<T> = {
  status: number;
  body: T;
  headers: Headers;
};

type RequestExecutor = <T>(input: {
  method: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
  path: string;
  body?: unknown;
  headers?: Record<string, string>;
  signal?: AbortSignal;
}) => Promise<ApiResponseLike<T>>;

type ErrorHandler = (response: ApiResponseLike<unknown>, defaultMessage: string) => never;
type ParseResponseBody = <T>(response: Response) => Promise<T>;

export type ListAgentTasksOptions = {
  status?: AgentTaskStatus;
  kind?: AgentTaskKind;
  target?: AgentExecutionTarget;
  limit?: number;
  offset?: number;
};

export type AdminAgentTaskTranscriptOptions = {
  afterSequence?: number;
  limit?: number;
};

export type ListCreatorGamesOptions = {
  limit?: number;
  offset?: number;
};

function normalizeAgentTaskId(taskId: number): number {
  if (!Number.isInteger(taskId) || taskId <= 0) {
    throw new Error('invalid_agent_task_id');
  }
  return taskId;
}

function normalizeAgentTaskKind(value: AgentTaskKind): AgentTaskKind {
  if (!AGENT_TASK_KIND_VALUES.includes(value)) {
    throw new Error('invalid_agent_task_kind');
  }
  return value;
}

function normalizeAppName(value: string): string {
  const normalized = typeof value === 'string' ? value.trim() : '';
  if (!normalized) {
    throw new Error('invalid_app_name');
  }
  return normalized;
}

function buildAgentTaskListQuery(options: ListAgentTasksOptions): string {
  const params = new URLSearchParams();
  if (typeof options.status === 'string' && options.status.trim()) {
    params.set('status', options.status.trim());
  }
  if (typeof options.kind === 'string' && options.kind.trim()) {
    params.set('kind', options.kind.trim());
  }
  if (typeof options.target === 'string' && options.target.trim()) {
    params.set('target', options.target.trim());
  }
  if (typeof options.limit === 'number' && Number.isFinite(options.limit)) {
    params.set('limit', String(options.limit));
  }
  if (typeof options.offset === 'number' && Number.isFinite(options.offset)) {
    params.set('offset', String(options.offset));
  }
  return params.toString();
}

function buildCreatorGamesQuery(options: ListCreatorGamesOptions): string {
  const params = new URLSearchParams();
  if (typeof options.limit === 'number' && Number.isFinite(options.limit)) {
    params.set('limit', String(options.limit));
  }
  if (typeof options.offset === 'number' && Number.isFinite(options.offset)) {
    params.set('offset', String(options.offset));
  }
  return params.toString();
}

function normalizeCreatorGameRef(value: string): string {
  const normalized = typeof value === 'string' ? value.trim() : '';
  if (!normalized) {
    throw new Error('invalid_creator_game_ref');
  }
  return normalized;
}

async function buildAuthorizedHeaders(
  getClientHeaders: () => Record<string, string>,
  resolveToken: () => Promise<string | null>,
): Promise<Headers> {
  const headers = new Headers();
  for (const [key, value] of Object.entries(getClientHeaders())) {
    if (key.toLowerCase() === 'content-type') {
      continue;
    }
    headers.set(key, value);
  }
  headers.set('accept', 'application/json');
  const token = await resolveToken();
  if (token) {
    headers.set('authorization', `Bearer ${token}`);
  }
  return headers;
}

function resolveAttachmentFilename(file: Blob, filename?: string): string {
  const explicit = typeof filename === 'string' ? filename.trim() : '';
  if (explicit) {
    return explicit;
  }
  const namedFile = file as Blob & { name?: unknown };
  return typeof namedFile.name === 'string' && namedFile.name.trim()
    ? namedFile.name.trim()
    : 'attachment';
}

export function buildAgentTasksApiClientMethods(input: {
  request: RequestExecutor;
  handleApiError: ErrorHandler;
  fetchImpl: typeof fetch;
  includeBrowserCredentials: boolean;
  resolveBaseUrl: () => string;
  resolveUrl: (base: string, path: string) => string;
  parseResponseBody: ParseResponseBody;
  resolveToken: () => Promise<string | null>;
  getClientHeaders: () => Record<string, string>;
}) {
  const {
    request,
    handleApiError,
    fetchImpl,
    includeBrowserCredentials,
    resolveBaseUrl,
    resolveUrl,
    parseResponseBody,
    resolveToken,
    getClientHeaders,
  } = input;

  return {
    async uploadAgentTaskAttachment(
      file: Blob,
      description?: string,
      filename?: string,
    ): Promise<AgentTaskAttachmentUploadResponse> {
      const form = new FormData();
      form.set('file', file, resolveAttachmentFilename(file, filename));
      const normalizedDescription = typeof description === 'string' ? description.trim() : '';
      if (normalizedDescription) {
        form.set('description', normalizedDescription);
      }
      const response = await fetchImpl(resolveUrl(resolveBaseUrl(), '/me/agent-attachments'), {
        method: 'POST',
        headers: await buildAuthorizedHeaders(getClientHeaders, resolveToken),
        body: form,
        ...buildBrowserCredentialsInit(includeBrowserCredentials),
      });
      const body = await parseResponseBody<AgentTaskAttachmentUploadResponse>(response);
      const result = { status: response.status, body, headers: response.headers };
      if (response.status !== 201 && response.status !== 200) {
        handleApiError(result, 'upload_agent_task_attachment');
      }
      return body;
    },

    async createNewGameAgentTask(
      body: CreateNewGameAgentTaskRequest,
    ): Promise<CreateNewGameAgentTaskResponse> {
      const response = await request<CreateNewGameAgentTaskResponse>({
        method: 'POST',
        path: '/me/agent-tasks',
        body,
      });
      if (response.status !== 201 && response.status !== 200) {
        handleApiError(response, 'create_new_game_agent_task');
      }
      return response.body;
    },

    async createRemixGameAgentTask(
      body: CreateRemixGameAgentTaskRequest,
    ): Promise<CreateRemixGameAgentTaskResponse> {
      const response = await request<CreateRemixGameAgentTaskResponse>({
        method: 'POST',
        path: '/me/agent-tasks/remix-game',
        body,
      });
      if (response.status !== 201 && response.status !== 200) {
        handleApiError(response, 'create_remix_game_agent_task');
      }
      return response.body;
    },

    async createGameEvalAgentTask(
      body: CreateGameEvalAgentTaskRequest,
    ): Promise<CreateGameEvalAgentTaskResponse> {
      const response = await request<CreateGameEvalAgentTaskResponse>({
        method: 'POST',
        path: '/me/agent-tasks/game-eval',
        body,
      });
      if (response.status !== 201 && response.status !== 200) {
        handleApiError(response, 'create_game_eval_agent_task');
      }
      return response.body;
    },

    async createAppAgentTask(
      appName: string,
      body: CreateAppAgentTaskRequest,
    ): Promise<CreateAppAgentTaskResponse> {
      const name = normalizeAppName(appName);
      const response = await request<CreateAppAgentTaskResponse>({
        method: 'POST',
        path: `/me/games/${encodeURIComponent(name)}/agent-tasks`,
        body,
      });
      if (response.status !== 201 && response.status !== 200) {
        handleApiError(response, 'create_app_agent_task');
      }
      return response.body;
    },

    async getAppAgentTask(appName: string): Promise<AppAgentTaskResponse> {
      const name = normalizeAppName(appName);
      const response = await request<AppAgentTaskResponse>({
        method: 'GET',
        path: `/me/games/${encodeURIComponent(name)}/agent-tasks`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'get_app_agent_task');
      }
      return response.body;
    },

    async getAppAgentTaskAvailability(appName: string): Promise<AgentTaskAvailabilityResponse> {
      const name = normalizeAppName(appName);
      const response = await request<AgentTaskAvailabilityResponse>({
        method: 'GET',
        path: `/me/games/${encodeURIComponent(name)}/agent-tasks/availability`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'get_app_agent_task_availability');
      }
      return response.body;
    },

    async getAgentTaskAvailability(kind: AgentTaskKind): Promise<AgentTaskAvailabilityResponse> {
      const normalizedKind = normalizeAgentTaskKind(kind);
      const params = new URLSearchParams();
      params.set('kind', normalizedKind);
      const response = await request<AgentTaskAvailabilityResponse>({
        method: 'GET',
        path: `/me/agent-tasks/availability?${params.toString()}`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'get_agent_task_availability');
      }
      return response.body;
    },

    async listNewGameSuggestions(): Promise<AgentTaskNewGameSuggestionsResponse> {
      const response = await request<AgentTaskNewGameSuggestionsResponse>({
        method: 'GET',
        path: '/agent-tasks/new-game-suggestions',
      });
      if (response.status !== 200) {
        handleApiError(response, 'list_new_game_suggestions');
      }
      return response.body;
    },

    async listAgentTasks(options: ListAgentTasksOptions = {}): Promise<AgentTasksResponse> {
      const query = buildAgentTaskListQuery(options);
      const response = await request<AgentTasksResponse>({
        method: 'GET',
        path: '/me/agent-tasks' + (query ? `?${query}` : ''),
      });
      if (response.status !== 200) {
        handleApiError(response, 'list_agent_tasks');
      }
      return response.body;
    },

    async listCreatorGames(options: ListCreatorGamesOptions = {}): Promise<CreatorGamesListResponse> {
      const query = buildCreatorGamesQuery(options);
      const response = await request<CreatorGamesListResponse>({
        method: 'GET',
        path: '/me/creator-games' + (query ? `?${query}` : ''),
      });
      if (response.status !== 200) {
        handleApiError(response, 'list_creator_games');
      }
      return response.body;
    },

    async getCreatorGameStatus(gameRef: string): Promise<CreatorGameStatusResponse> {
      const normalizedRef = normalizeCreatorGameRef(gameRef);
      const response = await request<CreatorGameStatusResponse>({
        method: 'GET',
        path: `/me/creator-games/${encodeURIComponent(normalizedRef)}/status`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'get_creator_game_status');
      }
      return response.body;
    },

    async recordCreatorGameShare(gameRef: string): Promise<CreatorGameShareResponse> {
      const normalizedRef = normalizeCreatorGameRef(gameRef);
      const response = await request<CreatorGameShareResponse>({
        method: 'POST',
        path: `/me/creator-games/${encodeURIComponent(normalizedRef)}/share`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'record_creator_game_share');
      }
      return response.body;
    },

    async updateCreatorGameFeedbackStatus(
      gameRef: string,
      appVersionId: number,
      creatorFeedbackStatus: AgentTaskCreatorFeedbackStatus,
    ): Promise<CreatorGameCreatorFeedbackStatusResponse> {
      const normalizedRef = normalizeCreatorGameRef(gameRef);
      if (!Number.isInteger(appVersionId) || appVersionId <= 0) {
        throw new Error('invalid_app_version_id');
      }
      const response = await request<CreatorGameCreatorFeedbackStatusResponse>({
        method: 'POST',
        path: `/me/creator-games/${encodeURIComponent(normalizedRef)}/creator-feedback-status`,
        body: { appVersionId, creatorFeedbackStatus },
      });
      if (response.status !== 200) {
        handleApiError(response, 'update_creator_game_feedback_status');
      }
      return response.body;
    },

    async listCreatorGameVersions(gameRef: string): Promise<CreatorGameVersionsResponse> {
      const normalizedRef = normalizeCreatorGameRef(gameRef);
      const response = await request<CreatorGameVersionsResponse>({
        method: 'GET',
        path: `/me/creator-games/${encodeURIComponent(normalizedRef)}/versions`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'list_creator_game_versions');
      }
      return response.body;
    },

    async getAgentTask(taskId: number): Promise<AgentTaskDetailResponse> {
      const id = normalizeAgentTaskId(taskId);
      const response = await request<AgentTaskDetailResponse>({
        method: 'GET',
        path: `/me/agent-tasks/${id}`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'get_agent_task');
      }
      return response.body;
    },

    async listAgentTaskEvents(taskId: number): Promise<AgentTaskEventsResponse> {
      const id = normalizeAgentTaskId(taskId);
      const response = await request<AgentTaskEventsResponse>({
        method: 'GET',
        path: `/me/agent-tasks/${id}/events`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'list_agent_task_events');
      }
      return response.body;
    },

    async cancelAgentTask(taskId: number): Promise<CancelAgentTaskResponse> {
      const id = normalizeAgentTaskId(taskId);
      const response = await request<CancelAgentTaskResponse>({
        method: 'POST',
        path: `/me/agent-tasks/${id}/cancel`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'cancel_agent_task');
      }
      return response.body;
    },

    async clearAgentTask(taskId: number): Promise<ClearAgentTaskResponse> {
      const id = normalizeAgentTaskId(taskId);
      const response = await request<ClearAgentTaskResponse>({
        method: 'DELETE',
        path: `/me/agent-tasks/${id}`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'clear_agent_task');
      }
      return response.body;
    },

    async retryAgentTask(taskId: number): Promise<RetryAgentTaskResponse> {
      const id = normalizeAgentTaskId(taskId);
      const response = await request<RetryAgentTaskResponse>({
        method: 'POST',
        path: `/me/agent-tasks/${id}/retry`,
        body: {},
      });
      if (response.status !== 201 && response.status !== 200) {
        handleApiError(response, 'retry_agent_task');
      }
      return response.body;
    },

    async listMyAgentWorkers(): Promise<MeAgentWorkersResponse> {
      const response = await request<MeAgentWorkersResponse>({
        method: 'GET',
        path: '/me/agent-workers',
      });
      if (response.status !== 200) {
        handleApiError(response, 'list_my_agent_workers');
      }
      return response.body;
    },

    async registerAgentBundle(body: RegisterAgentBundleRequest): Promise<RegisterAgentBundleResponse> {
      const response = await request<RegisterAgentBundleResponse>({
        method: 'POST',
        path: '/me/agent-bundles',
        body,
      });
      if (response.status !== 200 && response.status !== 201) {
        handleApiError(response, 'register_agent_bundle');
      }
      return response.body;
    },

    async workerPresence(body: WorkerPresenceRequest): Promise<WorkerPresenceResponse> {
      const response = await request<WorkerPresenceResponse>({
        method: 'POST',
        path: '/worker/presence',
        body,
      });
      if (response.status !== 200) {
        handleApiError(response, 'worker_presence');
      }
      return response.body;
    },

    async workerClaimAgentTask(body: WorkerClaimAgentTaskRequest): Promise<WorkerClaimAgentTaskResponse> {
      const response = await request<WorkerClaimAgentTaskResponse>({
        method: 'POST',
        path: '/worker/tasks/claim',
        body,
      });
      if (response.status !== 200) {
        handleApiError(response, 'worker_claim_agent_task');
      }
      return response.body;
    },

    async workerClaimAgentTaskSlug(
      taskId: number,
      body: WorkerClaimAgentTaskSlugRequest,
    ): Promise<WorkerClaimAgentTaskSlugResponse> {
      const id = normalizeAgentTaskId(taskId);
      const response = await request<WorkerClaimAgentTaskSlugResponse>({
        method: 'POST',
        path: `/worker/tasks/${id}/claim-slug`,
        body,
      });
      if (response.status !== 200) {
        handleApiError(response, 'worker_claim_agent_task_slug');
      }
      return response.body;
    },

    async workerCreateUpdateIntent(body: WorkerUpdateIntentRequest): Promise<WorkerUpdateIntentResponse> {
      const response = await request<WorkerUpdateIntentResponse>({
        method: 'POST',
        path: '/worker/update-intents',
        body,
      });
      if (response.status !== 200) {
        handleApiError(response, 'worker_create_update_intent');
      }
      return response.body;
    },

    async workerRecordAgentTaskAttemptUnavailable(
      taskId: number,
      body: WorkerAgentTaskAttemptUnavailableRequest,
    ): Promise<WorkerAgentTaskAttemptUnavailableResponse> {
      const id = normalizeAgentTaskId(taskId);
      const response = await request<WorkerAgentTaskAttemptUnavailableResponse>({
        method: 'POST',
        path: `/worker/tasks/${id}/attempt-unavailable`,
        body,
      });
      if (response.status !== 200 && response.status !== 201) {
        handleApiError(response, 'worker_record_agent_task_attempt_unavailable');
      }
      return response.body;
    },

    async workerHeartbeatAgentTask(
      taskId: number,
      body: WorkerHeartbeatAgentTaskRequest,
    ): Promise<WorkerHeartbeatAgentTaskResponse> {
      const id = normalizeAgentTaskId(taskId);
      const response = await request<WorkerHeartbeatAgentTaskResponse>({
        method: 'POST',
        path: `/worker/tasks/${id}/heartbeat`,
        body,
      });
      if (response.status !== 200) {
        handleApiError(response, 'worker_heartbeat_agent_task');
      }
      return response.body;
    },

    async workerCreateAgentTaskEvent(
      taskId: number,
      body: WorkerCreateAgentTaskEventRequest,
    ): Promise<WorkerCreateAgentTaskEventResponse> {
      const id = normalizeAgentTaskId(taskId);
      const response = await request<WorkerCreateAgentTaskEventResponse>({
        method: 'POST',
        path: `/worker/tasks/${id}/events`,
        body,
      });
      if (response.status !== 201) {
        handleApiError(response, 'worker_create_agent_task_event');
      }
      return response.body;
    },

    async workerAppendAgentTaskTranscriptChunks(
      taskId: number,
      body: WorkerCreateAgentTaskTranscriptChunkRequest,
    ): Promise<WorkerCreateAgentTaskTranscriptChunkResponse> {
      const id = normalizeAgentTaskId(taskId);
      const response = await request<WorkerCreateAgentTaskTranscriptChunkResponse>({
        method: 'POST',
        path: `/worker/tasks/${id}/transcript-chunks`,
        body,
      });
      if (response.status !== 201) {
        handleApiError(response, 'worker_append_agent_task_transcript_chunks');
      }
      return response.body;
    },

    async workerRecordAgentTaskRunTelemetry(
      taskId: number,
      body: WorkerRecordAgentTaskRunTelemetryRequest,
    ): Promise<WorkerRecordAgentTaskRunTelemetryResponse> {
      const id = normalizeAgentTaskId(taskId);
      const response = await request<WorkerRecordAgentTaskRunTelemetryResponse>({
        method: 'POST',
        path: `/worker/tasks/${id}/run-telemetry`,
        body,
      });
      if (response.status !== 200) {
        handleApiError(response, 'worker_record_agent_task_run_telemetry');
      }
      return response.body;
    },

    async workerCompleteAgentTask(
      taskId: number,
      body: WorkerCompleteAgentTaskRequest,
    ): Promise<AgentTaskDetailResponse> {
      const id = normalizeAgentTaskId(taskId);
      const response = await request<AgentTaskDetailResponse>({
        method: 'POST',
        path: `/worker/tasks/${id}/complete`,
        body,
      });
      if (response.status !== 200) {
        handleApiError(response, 'worker_complete_agent_task');
      }
      return response.body;
    },

    async workerSubmitAgentTaskReview(
      taskId: number,
      body: WorkerSubmitAgentTaskReviewRequest,
    ): Promise<WorkerSubmitAgentTaskReviewResponse> {
      const id = normalizeAgentTaskId(taskId);
      const response = await request<WorkerSubmitAgentTaskReviewResponse>({
        method: 'POST',
        path: `/worker/tasks/${id}/review-result`,
        body,
      });
      if (response.status !== 200) {
        handleApiError(response, 'worker_submit_agent_task_review');
      }
      return response.body;
    },

    async workerSubmitAgentTaskEval(
      taskId: number,
      body: WorkerSubmitAgentTaskEvalRequest,
    ): Promise<WorkerSubmitAgentTaskEvalResponse> {
      const id = normalizeAgentTaskId(taskId);
      const response = await request<WorkerSubmitAgentTaskEvalResponse>({
        method: 'POST',
        path: `/worker/tasks/${id}/eval-result`,
        body,
      });
      if (response.status !== 200) {
        handleApiError(response, 'worker_submit_agent_task_eval');
      }
      return response.body;
    },

    async workerFailAgentTask(
      taskId: number,
      body: WorkerFailAgentTaskRequest,
    ): Promise<AgentTaskDetailResponse> {
      const id = normalizeAgentTaskId(taskId);
      const response = await request<AgentTaskDetailResponse>({
        method: 'POST',
        path: `/worker/tasks/${id}/fail`,
        body,
      });
      if (response.status !== 200) {
        handleApiError(response, 'worker_fail_agent_task');
      }
      return response.body;
    },

    async adminListAgentTasks(options: ListAgentTasksOptions = {}): Promise<AdminAgentTasksResponse> {
      const query = buildAgentTaskListQuery(options);
      const response = await request<AdminAgentTasksResponse>({
        method: 'GET',
        path: '/admin/agent-tasks' + (query ? `?${query}` : ''),
      });
      if (response.status !== 200) {
        handleApiError(response, 'admin_list_agent_tasks');
      }
      return response.body;
    },

    async adminGetAgentTask(taskId: number): Promise<AdminAgentTaskDetailResponse> {
      const id = normalizeAgentTaskId(taskId);
      const response = await request<AdminAgentTaskDetailResponse>({
        method: 'GET',
        path: `/admin/agent-tasks/${id}`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'admin_get_agent_task');
      }
      return response.body;
    },

    async adminGetAgentTaskTranscript(
      taskId: number,
      options: AdminAgentTaskTranscriptOptions = {},
    ): Promise<AdminAgentTaskTranscriptResponse> {
      const id = normalizeAgentTaskId(taskId);
      const params = new URLSearchParams();
      if (typeof options.afterSequence === 'number' && Number.isFinite(options.afterSequence)) {
        params.set('afterSequence', String(options.afterSequence));
      }
      if (typeof options.limit === 'number' && Number.isFinite(options.limit)) {
        params.set('limit', String(options.limit));
      }
      const query = params.toString();
      const response = await request<AdminAgentTaskTranscriptResponse>({
        method: 'GET',
        path: `/admin/agent-tasks/${id}/transcript` + (query ? `?${query}` : ''),
      });
      if (response.status !== 200) {
        handleApiError(response, 'admin_get_agent_task_transcript');
      }
      return response.body;
    },

    async adminGetAgentWorkersStatus(): Promise<AdminAgentWorkersStatusResponse> {
      const response = await request<AdminAgentWorkersStatusResponse>({
        method: 'GET',
        path: '/admin/agent-workers/status',
      });
      if (response.status !== 200) {
        handleApiError(response, 'admin_get_agent_workers_status');
      }
      return response.body;
    },
  };
}
