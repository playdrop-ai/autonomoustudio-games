import type {
  AdminTagGroupResponse,
  AdminTagGroupsResponse,
  AdminTagResponse,
  CreateTagGroupRequest,
  CreateTagRequest,
  SavedItemKind,
  TagDirectoryResponse,
  TagDetailResponse,
  TagGroupDetailResponse,
  TagListResponse,
  TagGroupSort,
  UpdateTagGroupRequest,
  UpdateTagRequest,
} from '@playdrop/types';

type ApiResponseLike<T> = {
  status: number;
  body: T;
  headers: Headers;
};

type RequestExecutor = <T>(input: {
  method: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
  path: string;
  body?: unknown;
  headers?: Record<string, string>;
  signal?: AbortSignal;
}) => Promise<ApiResponseLike<T>>;

type ErrorHandler = (response: ApiResponseLike<unknown>, defaultMessage: string) => never;

export function buildTagsApiClientMethods(input: {
  request: RequestExecutor;
  handleApiError: ErrorHandler;
  normalizePositiveIntegerInput: (value: number, errorCode: string) => number;
}) {
  const {
    request,
    handleApiError,
    normalizePositiveIntegerInput,
  } = input;

  return {
    async fetchTagDirectory(options: {
      limit?: number;
      offset?: number;
      tagLimit?: number;
    } = {}): Promise<TagDirectoryResponse> {
      const params = new URLSearchParams();
      if (typeof options.limit === 'number') {
        params.set('limit', String(normalizePositiveIntegerInput(options.limit, 'invalid_tags_limit')));
      }
      if (typeof options.offset === 'number') {
        params.set('offset', String(normalizePositiveIntegerInput(options.offset, 'invalid_tags_offset')));
      }
      if (typeof options.tagLimit === 'number') {
        params.set('tagLimit', String(normalizePositiveIntegerInput(options.tagLimit, 'invalid_tags_limit')));
      }
      const query = params.toString();
      const response = await request<TagDirectoryResponse>({
        method: 'GET',
        path: `/tags/directory${query ? `?${query}` : ''}`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'fetch_tag_directory');
      }
      return response.body;
    },

    async fetchTags(options: {
      targetKind?: SavedItemKind;
      groupSlug?: string;
      limit?: number;
      offset?: number;
    } = {}): Promise<TagListResponse> {
      const params = new URLSearchParams();
      if (typeof options.targetKind === 'string' && options.targetKind.trim().length > 0) {
        params.set('targetKind', options.targetKind.trim());
      }
      if (typeof options.groupSlug === 'string' && options.groupSlug.trim().length > 0) {
        params.set('groupSlug', options.groupSlug.trim());
      }
      if (typeof options.limit === 'number') {
        params.set('limit', String(normalizePositiveIntegerInput(options.limit, 'invalid_tags_limit')));
      }
      if (typeof options.offset === 'number') {
        params.set('offset', String(normalizePositiveIntegerInput(options.offset, 'invalid_tags_offset')));
      }
      const query = params.toString();
      const response = await request<TagListResponse>({
        method: 'GET',
        path: `/tags${query ? `?${query}` : ''}`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'fetch_tags');
      }
      return response.body;
    },

    async fetchTag(groupSlug: string, tagSlug: string): Promise<TagDetailResponse> {
      const normalizedGroupSlug = typeof groupSlug === 'string' ? groupSlug.trim() : '';
      const normalizedTagSlug = typeof tagSlug === 'string' ? tagSlug.trim() : '';
      if (!normalizedGroupSlug || !normalizedTagSlug) {
        throw new Error('invalid_tag_ref');
      }
      const response = await request<TagDetailResponse>({
        method: 'GET',
        path: `/tags/${encodeURIComponent(normalizedGroupSlug)}/${encodeURIComponent(normalizedTagSlug)}`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'fetch_tag');
      }
      return response.body;
    },

    async fetchTagGroup(
      groupSlug: string,
      options: {
        targetKind?: SavedItemKind;
        appType?: string;
        sort?: TagGroupSort;
        limit?: number;
        offset?: number;
      } = {},
    ): Promise<TagGroupDetailResponse> {
      const normalizedGroupSlug = typeof groupSlug === 'string' ? groupSlug.trim() : '';
      if (!normalizedGroupSlug) {
        throw new Error('invalid_tag_group_slug');
      }
      const params = new URLSearchParams();
      if (typeof options.targetKind === 'string' && options.targetKind.trim().length > 0) {
        params.set('targetKind', options.targetKind.trim());
      }
      if (typeof options.appType === 'string' && options.appType.trim().length > 0) {
        params.set('appType', options.appType.trim());
      }
      if (typeof options.sort === 'string' && options.sort.trim().length > 0) {
        params.set('sort', options.sort.trim());
      }
      if (typeof options.limit === 'number') {
        params.set('limit', String(normalizePositiveIntegerInput(options.limit, 'invalid_tags_limit')));
      }
      if (typeof options.offset === 'number') {
        params.set('offset', String(normalizePositiveIntegerInput(options.offset, 'invalid_tags_offset')));
      }
      const query = params.toString();
      const response = await request<TagGroupDetailResponse>({
        method: 'GET',
        path: `/tags/${encodeURIComponent(normalizedGroupSlug)}${query ? `?${query}` : ''}`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'fetch_tag_group');
      }
      return response.body;
    },

    async fetchAdminTagGroups(): Promise<AdminTagGroupsResponse> {
      const response = await request<AdminTagGroupsResponse>({
        method: 'GET',
        path: '/admin/tag-groups',
      });
      if (response.status !== 200) {
        handleApiError(response, 'fetch_admin_tag_groups');
      }
      return response.body;
    },

    async createAdminTagGroup(requestBody: CreateTagGroupRequest): Promise<AdminTagGroupResponse> {
      const response = await request<AdminTagGroupResponse>({
        method: 'POST',
        path: '/admin/tag-groups',
        body: requestBody,
      });
      if (response.status !== 201) {
        handleApiError(response, 'create_admin_tag_group');
      }
      return response.body;
    },

    async updateAdminTagGroup(groupSlug: string, requestBody: UpdateTagGroupRequest): Promise<AdminTagGroupResponse> {
      const normalizedGroupSlug = typeof groupSlug === 'string' ? groupSlug.trim() : '';
      if (!normalizedGroupSlug) {
        throw new Error('invalid_tag_group_slug');
      }
      const response = await request<AdminTagGroupResponse>({
        method: 'PATCH',
        path: `/admin/tag-groups/${encodeURIComponent(normalizedGroupSlug)}`,
        body: requestBody,
      });
      if (response.status !== 200) {
        handleApiError(response, 'update_admin_tag_group');
      }
      return response.body;
    },

    async createAdminTag(groupSlug: string, requestBody: CreateTagRequest): Promise<AdminTagResponse> {
      const normalizedGroupSlug = typeof groupSlug === 'string' ? groupSlug.trim() : '';
      if (!normalizedGroupSlug) {
        throw new Error('invalid_tag_group_slug');
      }
      const response = await request<AdminTagResponse>({
        method: 'POST',
        path: `/admin/tag-groups/${encodeURIComponent(normalizedGroupSlug)}/tags`,
        body: requestBody,
      });
      if (response.status !== 201) {
        handleApiError(response, 'create_admin_tag');
      }
      return response.body;
    },

    async updateAdminTag(
      groupSlug: string,
      tagSlug: string,
      requestBody: UpdateTagRequest,
    ): Promise<AdminTagResponse> {
      const normalizedGroupSlug = typeof groupSlug === 'string' ? groupSlug.trim() : '';
      const normalizedTagSlug = typeof tagSlug === 'string' ? tagSlug.trim() : '';
      if (!normalizedGroupSlug || !normalizedTagSlug) {
        throw new Error('invalid_tag_ref');
      }
      const response = await request<AdminTagResponse>({
        method: 'PATCH',
        path: `/admin/tags/${encodeURIComponent(normalizedGroupSlug)}/${encodeURIComponent(normalizedTagSlug)}`,
        body: requestBody,
      });
      if (response.status !== 200) {
        handleApiError(response, 'update_admin_tag');
      }
      return response.body;
    },
  };
}
