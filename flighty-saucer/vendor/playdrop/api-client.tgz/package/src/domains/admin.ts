import type {
  AdminAppPlayerMetaResponse,
  AdminAppPlayerMetaUserResponse,
  AdminAppsListResponse,
  AdminAppVersionReviewsListResponse,
  AdminCreatorEngagementExecutionsResponse,
  AdminCreatorEngagementRulePreviewRequest,
  AdminCreatorEngagementRulePreviewResponse,
  AdminCreatorEngagementRulesResponse,
  AdminCreatorEngagementUserResponse,
  AdminCreditTransactionsResponse,
  AdminEnqueueNextAppVersionReviewTaskResponse,
  AdminGameCollectionCandidatesResponse,
  AdminGameCollectionResponse,
  AdminGameCollectionsResponse,
  AdminMutateAchievementStateRequest,
  AdminMutateAchievementStateResponse,
  AdminMutateLeaderboardScoreRequest,
  AdminMutateLeaderboardScoreResponse,
  AdminPaymentDetailResponse,
  AdminPaymentsListResponse,
  AdminPlatformAnalyticsRequest,
  AdminPlatformAnalyticsResponse,
  AdminRefundPaymentRequest,
  AdminRetirePlayerMetaDefinitionResponse,
  AdminUpdateAppRequest,
  AdminUpdateAppResponse,
  AdminUpdateAppVersionReviewRequest,
  AdminUpdateAppVersionReviewResponse,
  AdminUserResponse,
  AiGenerationDetailResponse,
  AiGenerationsResponse,
  AppVersionVisibility,
  BatchCreateUsersResponse,
  CreateAdminGameCollectionRequest,
  CreateUserRequest,
  CreateUserResponse,
  CreatorEngagementRuleExecutionStatus,
  CreditPackResponse,
  CreditPacksResponse,
  DeleteAdminGameCollectionResponse,
  DeleteAdminUserResponse,
  DeleteAppResponse,
  PaymentProvider,
  PaymentStatus,
  ReviewState,
  UpdateAdminGameCollectionGamesRequest,
  UpdateAdminGameCollectionRequest,
  UpdateAdminUserRequest,
  UsersListResponse,
} from '@playdrop/types';
import { buildBrowserCredentialsInit } from '../core/request.js';

type ApiResponseLike<T> = {
  status: number;
  body: T;
  headers: Headers;
};

type RequestExecutor = <T>(input: {
  method: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
  path: string;
  body?: unknown;
  headers?: Record<string, string>;
  signal?: AbortSignal;
}) => Promise<ApiResponseLike<T>>;

type ErrorHandler = (response: ApiResponseLike<unknown>, defaultMessage: string) => never;
type ParseResponseBody = <T>(response: Response) => Promise<T>;

type FetchAdminPaymentsOptions = {
  provider?: PaymentProvider;
  status?: PaymentStatus | PaymentStatus[];
  userId?: number;
  creditPackSku?: string;
  from?: string | Date;
  to?: string | Date;
  limit?: number;
  offset?: number;
};

type FetchAdminAppVersionReviewsOptions = {
  state?: ReviewState;
  visibility?: AppVersionVisibility;
  limit?: number;
  offset?: number;
};

type FetchAdminPlatformAnalyticsOptions = AdminPlatformAnalyticsRequest;

function isUtcDateString(value: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) {
    return false;
  }
  const parsed = new Date(`${value}T00:00:00.000Z`);
  return !Number.isNaN(parsed.getTime()) && parsed.toISOString().slice(0, 10) === value;
}

function buildAdminPlatformAnalyticsQueryString(options?: FetchAdminPlatformAnalyticsOptions): string {
  const hasDays = options?.days !== undefined;
  const fromDateUtc = options?.fromDateUtc;
  const toDateUtc = options?.toDateUtc;
  const hasFromDate = fromDateUtc !== undefined;
  const hasToDate = toDateUtc !== undefined;
  if (hasDays && (hasFromDate || hasToDate)) {
    throw new Error('invalid_admin_platform_analytics_options');
  }
  if (hasFromDate !== hasToDate) {
    throw new Error('invalid_admin_platform_analytics_options');
  }
  if (hasFromDate && hasToDate) {
    if (
      typeof fromDateUtc !== 'string'
      || typeof toDateUtc !== 'string'
      || !isUtcDateString(fromDateUtc)
      || !isUtcDateString(toDateUtc)
    ) {
      throw new Error('invalid_admin_platform_analytics_options');
    }
  }

  const params = new URLSearchParams();
  if (hasDays) {
    params.set('days', String(options.days));
  }
  if (hasFromDate && hasToDate) {
    params.set('fromDateUtc', fromDateUtc);
    params.set('toDateUtc', toDateUtc);
  }
  return params.toString();
}

function buildAdminPaymentsQueryString(options?: FetchAdminPaymentsOptions): string {
  const params = new URLSearchParams();
  if (options?.provider) {
    params.set('provider', options.provider);
  }
  if (options?.status) {
    const statuses = Array.isArray(options.status) ? options.status : [options.status];
    params.set('status', statuses.join(','));
  }
  if (typeof options?.userId === 'number') {
    params.set('userId', String(options.userId));
  }
  if (options?.creditPackSku) {
    params.set('creditPackSku', options.creditPackSku);
  }
  if (options?.from) {
    params.set('from', options.from instanceof Date ? options.from.toISOString() : options.from);
  }
  if (options?.to) {
    params.set('to', options.to instanceof Date ? options.to.toISOString() : options.to);
  }
  if (typeof options?.limit === 'number') {
    params.set('limit', String(options.limit));
  }
  if (typeof options?.offset === 'number') {
    params.set('offset', String(options.offset));
  }
  return params.toString();
}

function buildAdminAppVersionReviewsQueryString(options?: FetchAdminAppVersionReviewsOptions): string {
  const params = new URLSearchParams();
  if (options?.state) {
    params.set('state', options.state);
  }
  if (options?.visibility) {
    params.set('visibility', options.visibility);
  }
  if (typeof options?.limit === 'number') {
    params.set('limit', String(options.limit));
  }
  if (typeof options?.offset === 'number') {
    params.set('offset', String(options.offset));
  }
  return params.toString();
}

async function buildAuthorizedHeaders(
  getClientHeaders: () => Record<string, string>,
  resolveToken: () => Promise<string | null>,
): Promise<Headers> {
  const headers = new Headers();
  for (const [key, value] of Object.entries(getClientHeaders())) {
    headers.set(key, value);
  }
  const token = await resolveToken();
  if (token) {
    headers.set('authorization', `Bearer ${token}`);
  }
  return headers;
}


export function buildAdminApiClientMethods(input: {
  request: RequestExecutor;
  handleApiError: ErrorHandler;
  fetchImpl: typeof fetch;
  includeBrowserCredentials: boolean;
  resolveBaseUrl: () => string;
  resolveUrl: (base: string, path: string) => string;
  parseResponseBody: ParseResponseBody;
  resolveToken: () => Promise<string | null>;
  getClientHeaders: () => Record<string, string>;
}) {
  const {
    request,
    handleApiError,
    fetchImpl,
    includeBrowserCredentials,
    resolveBaseUrl,
    resolveUrl,
    parseResponseBody,
    resolveToken,
    getClientHeaders,
  } = input;

  return {
    async fetchUsers(): Promise<UsersListResponse> {
      const response = await request<UsersListResponse>({
        method: 'GET',
        path: '/admin/users',
      });

      if (response.status !== 200) {
        handleApiError(response, 'fetch_users');
      }

      return response.body;
    },

    async createUser(userRequest: CreateUserRequest): Promise<CreateUserResponse> {
      const response = await request<CreateUserResponse>({
        method: 'POST',
        path: '/admin/users',
        body: userRequest,
      });

      if (response.status !== 201 && response.status !== 200) {
        handleApiError(response, 'create_user');
      }

      return response.body;
    },

    async batchCreateUsersFromCsv(formData: FormData): Promise<BatchCreateUsersResponse> {
      const base = resolveBaseUrl();
      const headers = new Headers();

      for (const [key, value] of Object.entries(getClientHeaders())) {
        headers.set(key, value);
      }

      const token = await resolveToken();
      if (token) {
        headers.set('authorization', `Bearer ${token}`);
      }

      const path = '/admin/users/batch-create';
      const response = await fetchImpl(resolveUrl(base, path), {
        method: 'POST',
        headers,
        body: formData,
        ...buildBrowserCredentialsInit(includeBrowserCredentials),
      });

      const parsed = await parseResponseBody<BatchCreateUsersResponse>(response);
      const apiResponse = { status: response.status, body: parsed, headers: response.headers };

      if (response.status !== 200 && response.status !== 201) {
        handleApiError(apiResponse, 'batch_create_users');
      }

      return parsed;
    },

    async fetchAdminUser(userId: number): Promise<AdminUserResponse> {
      const response = await request<AdminUserResponse>({
        method: 'GET',
        path: `/admin/users/${encodeURIComponent(String(userId))}`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'fetch_admin_user');
      }

      return response.body;
    },

    async updateAdminUser(userId: number, updateRequest: UpdateAdminUserRequest): Promise<AdminUserResponse> {
      const response = await request<AdminUserResponse>({
        method: 'PATCH',
        path: `/admin/users/${encodeURIComponent(String(userId))}`,
        body: updateRequest,
      });

      if (response.status !== 200) {
        handleApiError(response, 'update_admin_user');
      }

      return response.body;
    },

    async deleteAdminUser(userId: number): Promise<DeleteAdminUserResponse> {
      const response = await request<DeleteAdminUserResponse>({
        method: 'DELETE',
        path: `/admin/users/${encodeURIComponent(String(userId))}`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'delete_admin_user');
      }

      return response.body;
    },

    async fetchAdminApps(): Promise<AdminAppsListResponse> {
      const response = await request<AdminAppsListResponse>({
        method: 'GET',
        path: '/admin/apps',
      });

      if (response.status !== 200) {
        handleApiError(response, 'fetch_admin_apps');
      }

      return response.body;
    },

    async fetchAdminPlatformAnalytics(
      options?: FetchAdminPlatformAnalyticsOptions,
    ): Promise<AdminPlatformAnalyticsResponse> {
      const query = buildAdminPlatformAnalyticsQueryString(options);
      const response = await request<AdminPlatformAnalyticsResponse>({
        method: 'GET',
        path: query ? `/admin/analytics/platform?${query}` : '/admin/analytics/platform',
      });

      if (response.status !== 200) {
        handleApiError(response, 'fetch_admin_platform_analytics');
      }

      return response.body;
    },

    async updateAdminApp(id: number, updateRequest: AdminUpdateAppRequest): Promise<AdminUpdateAppResponse> {
      const response = await request<AdminUpdateAppResponse>({
        method: 'PATCH',
        path: `/admin/apps/${encodeURIComponent(String(id))}`,
        body: updateRequest,
      });

      if (response.status !== 200) {
        handleApiError(response, 'update_admin_app');
      }

      return response.body;
    },

    async deleteAdminApp(id: number): Promise<DeleteAppResponse> {
      const response = await request<DeleteAppResponse>({
        method: 'DELETE',
        path: `/admin/apps/${encodeURIComponent(String(id))}`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'delete_admin_app');
      }

      return response.body;
    },

    async fetchAdminGameCollections(): Promise<AdminGameCollectionsResponse> {
      const response = await request<AdminGameCollectionsResponse>({
        method: 'GET',
        path: '/admin/game-collections',
      });

      if (response.status !== 200) {
        handleApiError(response, 'fetch_admin_game_collections');
      }

      return response.body;
    },

    async createAdminGameCollection(
      requestBody: CreateAdminGameCollectionRequest,
    ): Promise<AdminGameCollectionResponse> {
      const response = await request<AdminGameCollectionResponse>({
        method: 'POST',
        path: '/admin/game-collections',
        body: requestBody,
      });

      if (response.status !== 201 && response.status !== 200) {
        handleApiError(response, 'create_admin_game_collection');
      }

      return response.body;
    },

    async fetchAdminGameCollection(id: number): Promise<AdminGameCollectionResponse> {
      const response = await request<AdminGameCollectionResponse>({
        method: 'GET',
        path: `/admin/game-collections/${encodeURIComponent(String(id))}`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'fetch_admin_game_collection');
      }

      return response.body;
    },

    async updateAdminGameCollection(
      id: number,
      requestBody: UpdateAdminGameCollectionRequest,
    ): Promise<AdminGameCollectionResponse> {
      const response = await request<AdminGameCollectionResponse>({
        method: 'PATCH',
        path: `/admin/game-collections/${encodeURIComponent(String(id))}`,
        body: requestBody,
      });

      if (response.status !== 200) {
        handleApiError(response, 'update_admin_game_collection');
      }

      return response.body;
    },

    async replaceAdminGameCollectionGames(
      id: number,
      requestBody: UpdateAdminGameCollectionGamesRequest,
    ): Promise<AdminGameCollectionResponse> {
      const response = await request<AdminGameCollectionResponse>({
        method: 'PUT',
        path: `/admin/game-collections/${encodeURIComponent(String(id))}/games`,
        body: requestBody,
      });

      if (response.status !== 200) {
        handleApiError(response, 'replace_admin_game_collection_games');
      }

      return response.body;
    },

    async searchAdminGameCollectionCandidates(
      options: {
        q: string;
        limit?: number;
      },
    ): Promise<AdminGameCollectionCandidatesResponse> {
      const params = new URLSearchParams();
      params.set('q', options.q);
      if (typeof options.limit === 'number') {
        params.set('limit', String(options.limit));
      }
      const response = await request<AdminGameCollectionCandidatesResponse>({
        method: 'GET',
        path: `/admin/game-collections/candidates?${params.toString()}`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'search_admin_game_collection_candidates');
      }

      return response.body;
    },

    async uploadAdminGameCollectionIcon(
      id: number,
      formData: FormData,
    ): Promise<AdminGameCollectionResponse> {
      const base = resolveBaseUrl();
      const headers = await buildAuthorizedHeaders(getClientHeaders, resolveToken);
      const path = `/admin/game-collections/${encodeURIComponent(String(id))}/icon`;
      const response = await fetchImpl(resolveUrl(base, path), {
        method: 'POST',
        headers,
        body: formData,
        ...buildBrowserCredentialsInit(includeBrowserCredentials),
      });

      const parsed = await parseResponseBody<AdminGameCollectionResponse>(response);
      const apiResponse = { status: response.status, body: parsed, headers: response.headers };

      if (response.status !== 200) {
        handleApiError(apiResponse, 'upload_admin_game_collection_icon');
      }

      return parsed;
    },

    async deleteAdminGameCollection(id: number): Promise<DeleteAdminGameCollectionResponse> {
      const response = await request<DeleteAdminGameCollectionResponse>({
        method: 'DELETE',
        path: `/admin/game-collections/${encodeURIComponent(String(id))}`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'delete_admin_game_collection');
      }

      return response.body;
    },

    async fetchAdminAppVersionReviews(
      options?: FetchAdminAppVersionReviewsOptions,
    ): Promise<AdminAppVersionReviewsListResponse> {
      const query = buildAdminAppVersionReviewsQueryString(options);
      const response = await request<AdminAppVersionReviewsListResponse>({
        method: 'GET',
        path: '/admin/app-version-reviews' + (query ? `?${query}` : ''),
      });

      if (response.status !== 200) {
        handleApiError(response, 'fetch_admin_app_version_reviews');
      }

      return response.body;
    },

    async enqueueNextAdminAppVersionReviewTask(): Promise<AdminEnqueueNextAppVersionReviewTaskResponse> {
      const response = await request<AdminEnqueueNextAppVersionReviewTaskResponse>({
        method: 'POST',
        path: '/admin/app-version-reviews/enqueue-next-task',
      });

      if (response.status !== 200) {
        handleApiError(response, 'enqueue_next_admin_app_version_review_task');
      }

      return response.body;
    },

    async updateAdminAppVersionReview(
      versionId: number,
      requestBody: AdminUpdateAppVersionReviewRequest,
    ): Promise<AdminUpdateAppVersionReviewResponse> {
      const response = await request<AdminUpdateAppVersionReviewResponse>({
        method: 'PATCH',
        path: `/admin/app-version-reviews/${encodeURIComponent(String(versionId))}`,
        body: requestBody,
      });

      if (response.status !== 200) {
        handleApiError(response, 'update_admin_app_version_review');
      }

      return response.body;
    },

    async fetchAdminAppPlayerMeta(appId: number): Promise<AdminAppPlayerMetaResponse> {
      const response = await request<AdminAppPlayerMetaResponse>({
        method: 'GET',
        path: `/admin/apps/${encodeURIComponent(String(appId))}/player-meta`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'fetch_admin_app_player_meta');
      }

      return response.body;
    },

    async fetchAdminAppPlayerMetaUser(appId: number, userId: number): Promise<AdminAppPlayerMetaUserResponse> {
      const response = await request<AdminAppPlayerMetaUserResponse>({
        method: 'GET',
        path: `/admin/apps/${encodeURIComponent(String(appId))}/player-meta/users/${encodeURIComponent(String(userId))}`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'fetch_admin_app_player_meta_user');
      }

      return response.body;
    },

    async retireAdminAchievement(appId: number, key: string): Promise<AdminRetirePlayerMetaDefinitionResponse> {
      const response = await request<AdminRetirePlayerMetaDefinitionResponse>({
        method: 'POST',
        path: `/admin/apps/${encodeURIComponent(String(appId))}/player-meta/achievements/${encodeURIComponent(key)}/retire`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'retire_admin_achievement');
      }

      return response.body;
    },

    async retireAdminLeaderboard(appId: number, key: string): Promise<AdminRetirePlayerMetaDefinitionResponse> {
      const response = await request<AdminRetirePlayerMetaDefinitionResponse>({
        method: 'POST',
        path: `/admin/apps/${encodeURIComponent(String(appId))}/player-meta/leaderboards/${encodeURIComponent(key)}/retire`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'retire_admin_leaderboard');
      }

      return response.body;
    },

    async mutateAdminAchievementState(
      appId: number,
      userId: number,
      key: string,
      body: AdminMutateAchievementStateRequest,
    ): Promise<AdminMutateAchievementStateResponse> {
      const response = await request<AdminMutateAchievementStateResponse>({
        method: 'POST',
        path: `/admin/apps/${encodeURIComponent(String(appId))}/player-meta/users/${encodeURIComponent(String(userId))}/achievements/${encodeURIComponent(key)}`,
        body,
      });

      if (response.status !== 200) {
        handleApiError(response, 'mutate_admin_achievement_state');
      }

      return response.body;
    },

    async mutateAdminLeaderboardScore(
      appId: number,
      userId: number,
      key: string,
      body: AdminMutateLeaderboardScoreRequest,
    ): Promise<AdminMutateLeaderboardScoreResponse> {
      const response = await request<AdminMutateLeaderboardScoreResponse>({
        method: 'POST',
        path: `/admin/apps/${encodeURIComponent(String(appId))}/player-meta/users/${encodeURIComponent(String(userId))}/leaderboards/${encodeURIComponent(key)}`,
        body,
      });

      if (response.status !== 200) {
        handleApiError(response, 'mutate_admin_leaderboard_score');
      }

      return response.body;
    },

    async fetchAdminCreditPacks(): Promise<CreditPacksResponse> {
      const response = await request<CreditPacksResponse>({
        method: 'GET',
        path: '/admin/credit-packs',
      });
      if (response.status !== 200) {
        handleApiError(response, 'fetch_admin_credit_packs');
      }
      return response.body;
    },

    async createAdminCreditPack(body: { sku: string; displayName: string; amount: number; costCents: number }): Promise<CreditPackResponse> {
      const response = await request<CreditPackResponse>({
        method: 'POST',
        path: '/admin/credit-packs',
        body,
      });
      if (response.status !== 201) {
        handleApiError(response, 'create_admin_credit_pack');
      }
      return response.body;
    },

    async updateAdminCreditPack(
      sku: string,
      body: { displayName?: string; amount?: number; costCents?: number },
    ): Promise<CreditPackResponse> {
      const response = await request<CreditPackResponse>({
        method: 'PATCH',
        path: `/admin/credit-packs/${encodeURIComponent(sku)}`,
        body,
      });
      if (response.status !== 200) {
        handleApiError(response, 'update_admin_credit_pack');
      }
      return response.body;
    },

    async deleteAdminCreditPack(sku: string): Promise<{ success: boolean }> {
      const response = await request<{ success: boolean }>({
        method: 'DELETE',
        path: `/admin/credit-packs/${encodeURIComponent(sku)}`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'delete_admin_credit_pack');
      }
      return response.body;
    },

    async syncAdminCreditPacksStripe(): Promise<CreditPacksResponse> {
      const response = await request<CreditPacksResponse>({
        method: 'POST',
        path: '/admin/credit-packs/sync-stripe',
      });
      if (response.status !== 200) {
        handleApiError(response, 'sync_admin_credit_packs_stripe');
      }
      return response.body;
    },

    async fetchAdminPayments(options?: FetchAdminPaymentsOptions): Promise<AdminPaymentsListResponse> {
      const query = buildAdminPaymentsQueryString(options);
      const path = query ? `/admin/payments?${query}` : '/admin/payments';
      const response = await request<AdminPaymentsListResponse>({
        method: 'GET',
        path,
      });
      if (response.status !== 200) {
        handleApiError(response, 'fetch_admin_payments');
      }
      return response.body;
    },

    async fetchAdminPayment(paymentId: number): Promise<AdminPaymentDetailResponse> {
      const response = await request<AdminPaymentDetailResponse>({
        method: 'GET',
        path: `/admin/payments/${encodeURIComponent(String(paymentId))}`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'fetch_admin_payment');
      }
      return response.body;
    },

    async refundAdminPayment(paymentId: number, body: AdminRefundPaymentRequest): Promise<AdminPaymentDetailResponse> {
      const response = await request<AdminPaymentDetailResponse>({
        method: 'POST',
        path: `/admin/payments/${encodeURIComponent(String(paymentId))}/refund`,
        body,
      });
      if (response.status !== 200) {
        handleApiError(response, 'refund_admin_payment');
      }
      return response.body;
    },

    async reconcileAdminPayment(paymentId: number): Promise<AdminPaymentDetailResponse> {
      const response = await request<AdminPaymentDetailResponse>({
        method: 'POST',
        path: `/admin/payments/${encodeURIComponent(String(paymentId))}/reconcile`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'reconcile_admin_payment');
      }
      return response.body;
    },

    async fetchAdminCreditTransactions(options?: { limit?: number; offset?: number }): Promise<AdminCreditTransactionsResponse> {
      const params = new URLSearchParams();
      if (options?.limit !== undefined) {
        params.set('limit', String(options.limit));
      }
      if (options?.offset !== undefined) {
        params.set('offset', String(options.offset));
      }
      const query = params.toString();
      const path = query ? `/admin/credit-transactions?${query}` : '/admin/credit-transactions';
      const response = await request<AdminCreditTransactionsResponse>({
        method: 'GET',
        path,
      });
      if (response.status !== 200) {
        handleApiError(response, 'fetch_admin_credit_transactions');
      }
      return response.body;
    },

    async fetchAdminAiGenerations(options?: { limit?: number; offset?: number }): Promise<AiGenerationsResponse> {
      const params = new URLSearchParams();
      if (options?.limit !== undefined) {
        params.set('limit', String(options.limit));
      }
      if (options?.offset !== undefined) {
        params.set('offset', String(options.offset));
      }
      const query = params.toString();
      const path = query ? `/admin/ai-generations?${query}` : '/admin/ai-generations';
      const response = await request<AiGenerationsResponse>({
        method: 'GET',
        path,
      });
      if (response.status !== 200) {
        handleApiError(response, 'fetch_admin_ai_generations');
      }
      return response.body;
    },

    async fetchAdminAiGeneration(id: string): Promise<AiGenerationDetailResponse> {
      const response = await request<AiGenerationDetailResponse>({
        method: 'GET',
        path: `/admin/ai-generations/${id}`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'fetch_admin_ai_generation');
      }
      return response.body;
    },

    async fetchAdminCommunicationsRules(): Promise<AdminCreatorEngagementRulesResponse> {
      const response = await request<AdminCreatorEngagementRulesResponse>({
        method: 'GET',
        path: '/admin/communications/rules',
      });
      if (response.status !== 200) {
        handleApiError(response, 'fetch_admin_communications_rules');
      }
      return response.body;
    },

    async fetchAdminCommunicationsExecutions(options: {
      limit?: number;
      offset?: number;
      status?: CreatorEngagementRuleExecutionStatus;
      ruleId?: string;
      userId?: number;
    } = {}): Promise<AdminCreatorEngagementExecutionsResponse> {
      const params = new URLSearchParams();
      if (options.limit !== undefined) {
        params.set('limit', String(options.limit));
      }
      if (options.offset !== undefined) {
        params.set('offset', String(options.offset));
      }
      if (options.status) {
        params.set('status', options.status);
      }
      if (options.ruleId) {
        params.set('ruleId', options.ruleId);
      }
      if (options.userId !== undefined) {
        params.set('userId', String(options.userId));
      }
      const query = params.toString();
      const response = await request<AdminCreatorEngagementExecutionsResponse>({
        method: 'GET',
        path: `/admin/communications/executions${query ? `?${query}` : ''}`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'fetch_admin_communications_executions');
      }
      return response.body;
    },

    async fetchAdminCommunicationsUser(userId: number): Promise<AdminCreatorEngagementUserResponse> {
      const response = await request<AdminCreatorEngagementUserResponse>({
        method: 'GET',
        path: `/admin/communications/users/${encodeURIComponent(String(userId))}`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'fetch_admin_communications_user');
      }
      return response.body;
    },

    async previewAdminCommunicationsRule(
      ruleId: string,
      body: AdminCreatorEngagementRulePreviewRequest,
    ): Promise<AdminCreatorEngagementRulePreviewResponse> {
      const response = await request<AdminCreatorEngagementRulePreviewResponse>({
        method: 'POST',
        path: `/admin/communications/rules/${encodeURIComponent(ruleId)}/preview`,
        body,
      });
      if (response.status !== 200) {
        handleApiError(response, 'preview_admin_communications_rule');
      }
      return response.body;
    },

    async updateAdminCommunicationsRuleAction(
      ruleId: string,
      actionId: string,
      body: { enabled: boolean },
    ): Promise<AdminCreatorEngagementRulesResponse['rules'][number]> {
      const response = await request<AdminCreatorEngagementRulesResponse['rules'][number]>({
        method: 'PATCH',
        path: `/admin/communications/rules/${encodeURIComponent(ruleId)}/actions/${encodeURIComponent(actionId)}`,
        body,
      });
      if (response.status !== 200) {
        handleApiError(response, 'update_admin_communications_rule_action');
      }
      return response.body;
    },

  };
}
