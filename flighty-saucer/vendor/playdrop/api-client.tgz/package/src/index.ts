export { createApiClient } from './client.js';
export type {
  ApiClient,
  ApiClientConfig,
  ApiRequest,
  ApiResponse,
  UploadAppSessionFileOptions,
  UploadAppSessionOwnedAssetOptions,
  UploadAssetPackSessionAssetOptions,
  UploadAssetPackSessionMediaOptions,
  UploadAssetVersionOptions
} from './client.js';
export type { AdminAgentTaskTranscriptOptions, ListAgentTasksOptions, ListCreatorGamesOptions } from './domains/agent-tasks.js';

import type {
  AdminCreatorEngagementRulePreviewRequest,
  AdminGameCollectionCandidatesResponse,
  AdminGameCollectionResponse,
  AdminGameCollectionsResponse,
  AdminMutateAchievementStateRequest,
  AdminMutateLeaderboardScoreRequest,
  AgentTaskAttachmentUploadResponse,
  AgentTaskCreatorFeedbackStatus,
  AgentTaskKind,
  AgentTaskNewGameSuggestionsResponse,
  ApiKeyLoginRequest,
  AppBrowseRequest,
  AppDetailRequest,
  AppDetailResponse,
  AppleLinkRequest,
  AppleNativeChallengeResponse,
  AppleOAuthHandoffExchangeRequest,
  AppleOAuthLinkStartRequest,
  ApplePendingSignupResponse,
  ApplePushDeviceRequest,
  AppleSignInRequest,
  AppLogEntryRequest,
  AppMoreCollectionKey,
  AppMoreCollectionPage,
  AppMoreCollectionRequest,
  AppMoreCollectionsRequest,
  AppMoreCollectionsResponse,
  AppResponse,
  AppSurface,
  AppType,
  AppVersionVisibility,
  AssetBrowseKind,
  AssetCategory,
  AssetListSort,
  AssetPackListSort,
  AssetPackResponse,
  AssetResponse,
  AssetSpecResponse,
  AssetSummaryResponse,
  BoostPurchaseRequest,
  BoostReportQuery,
  ChangePasswordRequest,
  ClaimFreeCreditRewardResponse,
  ClearAgentTaskResponse,
  CliLoginApproveRequest,
  CliLoginPollRequest,
  CliWebLaunchStartRequest,
  CompleteAppleSignupRequest,
  CompleteGoogleSignupRequest,
  CompleteXSignupRequest,
  ContentLicense,
  CreateAdminGameCollectionRequest,
  CreateAppAgentTaskRequest,
  CreateCommentReportRequest,
  CreateCliApiTokenRequest,
  CreateContentCommentRequest,
  CreateContentReportRequest,
  CreateCreatorReportRequest,
  CreateNewGameAgentTaskRequest,
  CreateRemixGameAgentTaskRequest,
  CreatorAppsBrowseRequest,
  CreatorBlockMutationResponse,
  CreatorEngagementRuleExecutionStatus,
  CreatorFollowMutationResponse,
  DeleteMyAccountRequest,
  DislikedItemMutationResponse,
  FeedbackCategory,
  FeedbackClient,
  FeedbackStatus,
  FetchHomeOptions,
  FirebasePushDeviceRequest,
  FollowingFeedSection,
  FollowingSort,
  FreeCreditsResponse,
  GoogleAppleLinkRequest,
  GoogleAppleSignInRequest,
  GoogleOneTapExchangeRequest,
  IapPurchaseRequest,
  IapReceiptListParams,
  InvitePreviewResponse,
  LibraryCategory,
  LibrarySort,
  LikedItemMutationResponse,
  ModerationReportResponse,
  NativeOAuthHandoffExchangeRequest,
  NativeOAuthLinkStartRequest,
  MyInviteCodeResponse,
  NotificationStatus,
  PublicEmailPreferencesUpdateRequest,
  ResolveRuntimeAssetsRequest,
  RetryAgentTaskResponse,
  RegisterAgentBundleRequest,
  ReviewState,
  SavedItemKind,
  SearchRequest,
  SearchSuggestRequest,
  SetProfileAssetRequest,
  SubmitFeedbackRequest,
  TrackEngagementEventRequest,
  TrackEngagementEventResponse,
  UpdateAdminFeedbackRequest,
  UpdateAdminGameCollectionGamesRequest,
  UpdateAdminGameCollectionRequest,
  UpdateAssetPackRequest,
  UpdateAssetPackVersionRequest,
  UpdateAssetRequest,
  UpdateAssetVersionRequest,
  UpdateProfileRequest,
  UpdateUserCommunicationPreferencesRequest,
  UpsertWebPushSubscriptionRequest,
  WorkerAgentTaskAttemptUnavailableRequest,
  WorkerClaimAgentTaskRequest,
  WorkerClaimAgentTaskSlugRequest,
  WorkerCompleteAgentTaskRequest,
  WorkerCreateAgentTaskEventRequest,
  WorkerCreateAgentTaskTranscriptChunkRequest,
  WorkerFailAgentTaskRequest,
  WorkerHeartbeatAgentTaskRequest,
  WorkerPresenceRequest,
  WorkerRecordAgentTaskRunTelemetryRequest,
  WorkerSubmitAgentTaskReviewRequest,
  WorkerUpdateIntentRequest
} from '@playdrop/types';
import { ApiError, UnsupportedClientError } from '@playdrop/types';
import type { ApiClient } from './client.js';
import { createApiClient } from './client.js';
import { buildBrowserCredentialsInit } from './core/request.js';
import type { AdminAgentTaskTranscriptOptions, ListAgentTasksOptions, ListCreatorGamesOptions } from './domains/agent-tasks.js';

const CLIENT_HEADER_NAMES = {
  client: 'x-playdrop-client',
  clientVersion: 'x-playdrop-client-version',
  clientBuild: 'x-playdrop-client-build',
  platform: 'x-playdrop-platform',
  platformVersion: 'x-playdrop-platform-version',
} as const;

const ENGAGEMENT_HEADER_NAMES = {
  anonymousId: 'x-playdrop-anon-id',
  sessionId: 'x-playdrop-session-id',
} as const;
const AUTH_MODE_HEADER_NAME = 'x-playdrop-auth-mode';
const COOKIE_AUTH_MODE = 'cookie';

let defaultClient: ApiClient | null = null;

type PlatformInfo = {
  name: string;
  version: string;
};

type ClientInfo = {
  version: string;
  build: string;
};

const runtimeState: {
  platform: PlatformInfo | null;
  client: ClientInfo | null;
} = {
  platform: null,
  client: null,
};

const WEB_ANONYMOUS_ID_STORAGE_KEY = 'playdrop.anonymousId';
const WEB_SESSION_ID_STORAGE_KEY = 'playdrop.sessionId';

function generateUuid(): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID();
  }
  return `${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function readOrCreateStorageValue(storage: Storage, key: string): string {
  const existing = storage.getItem(key)?.trim();
  if (existing) {
    return existing;
  }
  const generated = generateUuid();
  storage.setItem(key, generated);
  return generated;
}

function getBrowserEngagementHeaders(): Record<string, string> {
  if (typeof window === 'undefined') {
    return {};
  }
  const anonymousId = readOrCreateStorageValue(window.localStorage, WEB_ANONYMOUS_ID_STORAGE_KEY);
  const sessionId = readOrCreateStorageValue(window.sessionStorage, WEB_SESSION_ID_STORAGE_KEY);
  return {
    [ENGAGEMENT_HEADER_NAMES.anonymousId]: anonymousId,
    [ENGAGEMENT_HEADER_NAMES.sessionId]: sessionId,
  };
}

function getDefaultClient(): ApiClient {
  if (!defaultClient) {
    defaultClient = createApiClient({
      clientHeaders: (): Record<string, string> => {
        const state = getRuntimeState();
        if (!state.platform || !state.client) {
          return {};
        }

        return {
          [CLIENT_HEADER_NAMES.client]: 'web',
          [CLIENT_HEADER_NAMES.clientVersion]: state.client.version,
          [CLIENT_HEADER_NAMES.clientBuild]: state.client.build,
          [CLIENT_HEADER_NAMES.platform]: state.platform.name,
          [CLIENT_HEADER_NAMES.platformVersion]: state.platform.version,
          [AUTH_MODE_HEADER_NAME]: COOKIE_AUTH_MODE,
          ...getBrowserEngagementHeaders(),
        };
      },
    });
  }
  return defaultClient;
}

export async function apiFetch(path: string, init: RequestInit = {}) {
  const state = getRuntimeState();
  if (!state.platform || !state.client) {
    throw new Error(
      'apiFetch called before client runtime was configured. Call ensureWebClientRuntimeConfigured() or use createApiClient().',
    );
  }

  const clientHeaders: Record<string, string> = {
    [CLIENT_HEADER_NAMES.client]: 'web',
    [CLIENT_HEADER_NAMES.clientVersion]: state.client.version,
    [CLIENT_HEADER_NAMES.clientBuild]: state.client.build,
    [CLIENT_HEADER_NAMES.platform]: state.platform.name,
    [CLIENT_HEADER_NAMES.platformVersion]: state.platform.version,
    [AUTH_MODE_HEADER_NAME]: COOKIE_AUTH_MODE,
    ...getBrowserEngagementHeaders(),
  };

  return await fetch(path, {
    ...init,
    ...buildBrowserCredentialsInit(true),
    headers: {
      'Content-Type': 'application/json',
      ...clientHeaders,
      ...init.headers,
    },
  });
}

export async function attemptMe() {
  try {
    const client = getDefaultClient();
    return await client.me();
  } catch (error) {
    if (error instanceof UnsupportedClientError) {
      throw error;
    }
    if (error instanceof ApiError) {
      if (error.status === 401) {
        return null;
      }
      throw error;
    }
    throw error instanceof Error ? error : new Error(String(error));
  }
}

export async function login(username: string, password: string) {
  return await getDefaultClient().login({ username, password });
}

export async function register(username: string, password: string, displayName: string, inviteCode?: string) {
  return await getDefaultClient().register({
    username,
    password,
    displayName,
    ...(inviteCode ? { inviteCode } : {}),
  });
}

export async function fetchStarterProfileAssets() {
  return await getDefaultClient().fetchStarterProfileAssets();
}

export async function loginWithApiKey(request: ApiKeyLoginRequest) {
  return await getDefaultClient().loginWithApiKey(request);
}

export async function startCliLogin() {
  return await getDefaultClient().startCliLogin();
}

export async function pollCliLogin(request: CliLoginPollRequest) {
  return await getDefaultClient().pollCliLogin(request);
}

export async function fetchCliLoginStatus(requestId: string) {
  return await getDefaultClient().fetchCliLoginStatus(requestId);
}

export async function approveCliLogin(request: CliLoginApproveRequest) {
  return await getDefaultClient().approveCliLogin(request);
}

export async function startCliWebLaunch(request: CliWebLaunchStartRequest) {
  return await getDefaultClient().startCliWebLaunch(request);
}

export async function logout() {
  return await getDefaultClient().logout();
}

export async function updateProfile(request: UpdateProfileRequest) {
  return await getDefaultClient().updateProfile(request);
}

export async function changePassword(newPassword: string, currentPassword?: string) {
  const request: ChangePasswordRequest = {
    newPassword,
    ...(currentPassword ? { currentPassword } : {}),
  };
  return await getDefaultClient().changePassword(request);
}

export async function exportPrivacyData() {
  return await getDefaultClient().exportPrivacyData();
}

export async function deleteAccount(request: DeleteMyAccountRequest) {
  return await getDefaultClient().deleteAccount(request);
}

export async function unlinkX() {
  return await getDefaultClient().unlinkX();
}

export async function unlinkGoogle() {
  return await getDefaultClient().unlinkGoogle();
}

export async function unlinkApple() {
  return await getDefaultClient().unlinkApple();
}

export async function createAppleOAuthLinkStart(request: AppleOAuthLinkStartRequest) {
  return await getDefaultClient().createAppleOAuthLinkStart(request);
}

export async function createNativeOAuthLinkStart(request: NativeOAuthLinkStartRequest) {
  return await getDefaultClient().createNativeOAuthLinkStart(request);
}

export async function createAppleNativeChallenge(): Promise<AppleNativeChallengeResponse> {
  return await getDefaultClient().createAppleNativeChallenge();
}

export async function exchangeAppleOAuthHandoff(request: AppleOAuthHandoffExchangeRequest) {
  return await getDefaultClient().exchangeAppleOAuthHandoff(request);
}

export async function exchangeNativeOAuthHandoff(request: NativeOAuthHandoffExchangeRequest) {
  return await getDefaultClient().exchangeNativeOAuthHandoff(request);
}

export async function signInWithApple(request: AppleSignInRequest) {
  return await getDefaultClient().signInWithApple(request);
}

export async function linkApple(request: AppleLinkRequest) {
  return await getDefaultClient().linkApple(request);
}

export async function signInWithGoogleApple(request: GoogleAppleSignInRequest) {
  return await getDefaultClient().signInWithGoogleApple(request);
}

export async function linkGoogleApple(request: GoogleAppleLinkRequest) {
  return await getDefaultClient().linkGoogleApple(request);
}

export async function fetchGooglePendingSignup(token: string) {
  return await getDefaultClient().fetchGooglePendingSignup(token);
}

export async function fetchApplePendingSignup(token: string): Promise<ApplePendingSignupResponse> {
  return await getDefaultClient().fetchApplePendingSignup(token);
}

export async function fetchXPendingSignup(token: string) {
  return await getDefaultClient().fetchXPendingSignup(token);
}

export async function fetchPublicFreeCredits(): Promise<FreeCreditsResponse> {
  return await getDefaultClient().fetchPublicFreeCredits();
}

export async function fetchFreeCredits(): Promise<FreeCreditsResponse> {
  return await getDefaultClient().fetchFreeCredits();
}

export async function claimFreeCreditReward(rewardId: number): Promise<ClaimFreeCreditRewardResponse> {
  return await getDefaultClient().claimFreeCreditReward(rewardId);
}

export async function fetchInvitePreview(inviteCode: string): Promise<InvitePreviewResponse> {
  return await getDefaultClient().fetchInvitePreview(inviteCode);
}

export async function fetchMyInviteCode(): Promise<MyInviteCodeResponse> {
  return await getDefaultClient().fetchMyInviteCode();
}

export async function submitMyInviteCode(inviteCode: string): Promise<MyInviteCodeResponse> {
  return await getDefaultClient().submitMyInviteCode(inviteCode);
}

export async function uploadAgentTaskAttachment(
  file: Blob,
  description?: string,
  filename?: string,
): Promise<AgentTaskAttachmentUploadResponse> {
  return await getDefaultClient().uploadAgentTaskAttachment(file, description, filename);
}

export async function createNewGameAgentTask(body: CreateNewGameAgentTaskRequest) {
  return await getDefaultClient().createNewGameAgentTask(body);
}

export async function createRemixGameAgentTask(body: CreateRemixGameAgentTaskRequest) {
  return await getDefaultClient().createRemixGameAgentTask(body);
}

export async function createAppAgentTask(appName: string, body: CreateAppAgentTaskRequest) {
  return await getDefaultClient().createAppAgentTask(appName, body);
}

export async function getAppAgentTask(appName: string) {
  return await getDefaultClient().getAppAgentTask(appName);
}

export async function getAppAgentTaskAvailability(appName: string) {
  return await getDefaultClient().getAppAgentTaskAvailability(appName);
}

export async function getAgentTaskAvailability(kind: AgentTaskKind) {
  return await getDefaultClient().getAgentTaskAvailability(kind);
}

export async function listNewGameSuggestions(): Promise<AgentTaskNewGameSuggestionsResponse> {
  return await getDefaultClient().listNewGameSuggestions();
}

export async function listAgentTasks(options?: ListAgentTasksOptions) {
  return await getDefaultClient().listAgentTasks(options);
}

export async function listCreatorGames(options?: ListCreatorGamesOptions) {
  return await getDefaultClient().listCreatorGames(options);
}

export async function getCreatorGameStatus(gameRef: string) {
  return await getDefaultClient().getCreatorGameStatus(gameRef);
}

export async function recordCreatorGameShare(gameRef: string) {
  return await getDefaultClient().recordCreatorGameShare(gameRef);
}

export async function updateCreatorGameFeedbackStatus(
  gameRef: string,
  appVersionId: number,
  creatorFeedbackStatus: AgentTaskCreatorFeedbackStatus,
) {
  return await getDefaultClient().updateCreatorGameFeedbackStatus(gameRef, appVersionId, creatorFeedbackStatus);
}

export async function listCreatorGameVersions(gameRef: string) {
  return await getDefaultClient().listCreatorGameVersions(gameRef);
}

export async function getAgentTask(taskId: number) {
  return await getDefaultClient().getAgentTask(taskId);
}

export async function listAgentTaskEvents(taskId: number) {
  return await getDefaultClient().listAgentTaskEvents(taskId);
}

export async function cancelAgentTask(taskId: number) {
  return await getDefaultClient().cancelAgentTask(taskId);
}

export async function clearAgentTask(taskId: number): Promise<ClearAgentTaskResponse> {
  return await getDefaultClient().clearAgentTask(taskId);
}

export async function retryAgentTask(taskId: number): Promise<RetryAgentTaskResponse> {
  return await getDefaultClient().retryAgentTask(taskId);
}

export async function listMyAgentWorkers() {
  return await getDefaultClient().listMyAgentWorkers();
}

export async function registerAgentBundle(body: RegisterAgentBundleRequest) {
  return await getDefaultClient().registerAgentBundle(body);
}

export async function workerPresence(body: WorkerPresenceRequest) {
  return await getDefaultClient().workerPresence(body);
}

export async function workerClaimAgentTask(body: WorkerClaimAgentTaskRequest) {
  return await getDefaultClient().workerClaimAgentTask(body);
}

export async function workerClaimAgentTaskSlug(taskId: number, body: WorkerClaimAgentTaskSlugRequest) {
  return await getDefaultClient().workerClaimAgentTaskSlug(taskId, body);
}

export async function workerCreateUpdateIntent(body: WorkerUpdateIntentRequest) {
  return await getDefaultClient().workerCreateUpdateIntent(body);
}

export async function workerRecordAgentTaskAttemptUnavailable(
  taskId: number,
  body: WorkerAgentTaskAttemptUnavailableRequest,
) {
  return await getDefaultClient().workerRecordAgentTaskAttemptUnavailable(taskId, body);
}

export async function workerHeartbeatAgentTask(taskId: number, body: WorkerHeartbeatAgentTaskRequest) {
  return await getDefaultClient().workerHeartbeatAgentTask(taskId, body);
}

export async function workerCreateAgentTaskEvent(taskId: number, body: WorkerCreateAgentTaskEventRequest) {
  return await getDefaultClient().workerCreateAgentTaskEvent(taskId, body);
}

export async function workerAppendAgentTaskTranscriptChunks(
  taskId: number,
  body: WorkerCreateAgentTaskTranscriptChunkRequest,
) {
  return await getDefaultClient().workerAppendAgentTaskTranscriptChunks(taskId, body);
}

export async function workerRecordAgentTaskRunTelemetry(
  taskId: number,
  body: WorkerRecordAgentTaskRunTelemetryRequest,
) {
  return await getDefaultClient().workerRecordAgentTaskRunTelemetry(taskId, body);
}

export async function workerCompleteAgentTask(taskId: number, body: WorkerCompleteAgentTaskRequest) {
  return await getDefaultClient().workerCompleteAgentTask(taskId, body);
}

export async function workerSubmitAgentTaskReview(taskId: number, body: WorkerSubmitAgentTaskReviewRequest) {
  return await getDefaultClient().workerSubmitAgentTaskReview(taskId, body);
}

export async function workerFailAgentTask(taskId: number, body: WorkerFailAgentTaskRequest) {
  return await getDefaultClient().workerFailAgentTask(taskId, body);
}

export async function adminListAgentTasks(options?: ListAgentTasksOptions) {
  return await getDefaultClient().adminListAgentTasks(options);
}

export async function adminGetAgentTask(taskId: number) {
  return await getDefaultClient().adminGetAgentTask(taskId);
}

export async function adminGetAgentTaskTranscript(taskId: number, options?: AdminAgentTaskTranscriptOptions) {
  return await getDefaultClient().adminGetAgentTaskTranscript(taskId, options);
}

export async function adminGetAgentWorkersStatus() {
  return await getDefaultClient().adminGetAgentWorkersStatus();
}

export async function checkUsernameAvailable(username: string) {
  return await getDefaultClient().checkUsernameAvailable(username);
}

export async function completeGoogleSignup(request: CompleteGoogleSignupRequest) {
  return await getDefaultClient().completeGoogleSignup(request);
}

export async function completeXSignup(request: CompleteXSignupRequest) {
  return await getDefaultClient().completeXSignup(request);
}

export async function completeAppleSignup(request: CompleteAppleSignupRequest) {
  return await getDefaultClient().completeAppleSignup(request);
}

export async function exchangeGoogleOneTapCredential(request: GoogleOneTapExchangeRequest) {
  return await getDefaultClient().exchangeGoogleOneTapCredential(request);
}

export async function fetchCliApiKeyStatus() {
  return await getDefaultClient().fetchCliApiKeyStatus();
}

export async function createCliApiKey() {
  return await getDefaultClient().createCliApiKey();
}

export async function listCliApiTokens() {
  return await getDefaultClient().listCliApiTokens();
}

export async function createCliApiToken(request: CreateCliApiTokenRequest) {
  return await getDefaultClient().createCliApiToken(request);
}

export async function rotateCliApiToken(tokenId: number) {
  return await getDefaultClient().rotateCliApiToken(tokenId);
}

export async function deleteCliApiToken(tokenId: number) {
  return await getDefaultClient().deleteCliApiToken(tokenId);
}

export async function fetchTagDirectory(options?: {
  limit?: number;
  offset?: number;
  tagLimit?: number;
}) {
  return await getDefaultClient().fetchTagDirectory(options);
}

export async function fetchTags(options?: {
  targetKind?: SavedItemKind;
  groupSlug?: string;
  limit?: number;
  offset?: number;
}) {
  const response = await getDefaultClient().fetchTags(options);
  return response.groups;
}

export async function fetchTag(groupSlug: string, tagSlug: string) {
  const response = await getDefaultClient().fetchTag(groupSlug, tagSlug);
  return response.tag;
}

export async function fetchTagGroup(
  groupSlug: string,
  options: {
    targetKind?: SavedItemKind;
    appType?: string;
    sort?: "alpha" | "popularity";
    limit?: number;
    offset?: number;
  } = {},
) {
  return await getDefaultClient().fetchTagGroup(groupSlug, options);
}

export async function fetchApps(options: AppBrowseRequest = {}) {
  const response = await getDefaultClient().fetchApps(options);
  return response.apps;
}

export async function fetchAppsPage(options: AppBrowseRequest = {}) {
  return await getDefaultClient().fetchApps(options);
}

export async function fetchAppsByType(
  type: AppType,
  options: AppBrowseRequest = {},
) {
  const response = await getDefaultClient().fetchAppsByType(type, options);
  return response.apps;
}

export async function fetchAppsByTypePage(
  type: AppType,
  options: AppBrowseRequest = {},
) {
  return await getDefaultClient().fetchAppsByType(type, options);
}

export async function fetchHomeGamesCollectionPage(
  collectionId: string,
  options: Pick<AppBrowseRequest, 'limit' | 'offset' | 'auth' | 'controller' | 'controllerCompatible' | 'surface'> = {},
) {
  return await getDefaultClient().fetchHomeGamesCollectionPage(collectionId, options);
}

export async function fetchAppsByCreator(
  creatorUsername: string,
  options: CreatorAppsBrowseRequest = {},
) {
  const response = await getDefaultClient().fetchAppsByCreator(creatorUsername, options);
  return response.apps;
}

export async function fetchAppsByCreatorPage(
  creatorUsername: string,
  options: CreatorAppsBrowseRequest = {},
) {
  return await getDefaultClient().fetchAppsByCreator(creatorUsername, options);
}

export async function fetchMyApps(options: { limit?: number; offset?: number; type?: AppType } = {}) {
  const response = await getDefaultClient().fetchMyApps(options);
  return response.apps;
}

export async function fetchMyAppsPage(options: { limit?: number; offset?: number; type?: AppType } = {}) {
  return await getDefaultClient().fetchMyApps(options);
}

export async function fetchUserById(userId: number) {
  const response = await getDefaultClient().fetchUserById(userId);
  return response.user;
}

export async function fetchUserByUsername(username: string) {
  const response = await getDefaultClient().fetchUserByUsername(username);
  return response.user;
}

export async function fetchAppBySlug(
  creatorUsername: string,
  appName: string,
  options: AppDetailRequest = {},
) {
  const response = await getDefaultClient().fetchAppBySlug(creatorUsername, appName, options);
  return response.app;
}

export async function fetchAppRelated(creatorUsername: string, appName: string) {
  return await getDefaultClient().fetchAppRelated(creatorUsername, appName);
}

export async function fetchAppMoreCollections(
  creatorUsername: string,
  appName: string,
  options: AppMoreCollectionsRequest = {},
): Promise<AppMoreCollectionsResponse> {
  return await getDefaultClient().fetchAppMoreCollections(creatorUsername, appName, options);
}

export async function fetchAppMoreCollectionPage(
  creatorUsername: string,
  appName: string,
  collectionKey: AppMoreCollectionKey,
  options: AppMoreCollectionRequest = {},
): Promise<AppMoreCollectionPage> {
  return await getDefaultClient().fetchAppMoreCollectionPage(creatorUsername, appName, collectionKey, options);
}

export async function requestAppAccessToken(appId: number) {
  return await getDefaultClient().requestAppAccessToken(appId);
}

export async function requestDevAppAccessToken(appId: number, slot: number) {
  return await getDefaultClient().requestDevAppAccessToken(appId, slot);
}

export async function resetDevPlayer(appId: number, slot: number) {
  return await getDefaultClient().resetDevPlayer(appId, slot);
}

export async function resetAllDevPlayers(appId: number) {
  return await getDefaultClient().resetAllDevPlayers(appId);
}

export async function sendAppLog(appId: number, entry: AppLogEntryRequest) {
  return await getDefaultClient().sendAppLog(appId, entry);
}

export async function listAchievements(
  appId: number,
  options: { includeHiddenDefinitions?: boolean; includeRetired?: boolean } = {},
) {
  return await getDefaultClient().listAchievements(appId, options);
}

export async function getAchievement(
  appId: number,
  key: string,
  options: { includeHiddenDefinitions?: boolean; includeRetired?: boolean } = {},
) {
  return await getDefaultClient().getAchievement(appId, key, options);
}

export async function unlockAchievement(appId: number, key: string) {
  return await getDefaultClient().unlockAchievement(appId, key);
}

export async function setAchievementProgressAtLeast(
  appId: number,
  key: string,
  progress: number,
) {
  return await getDefaultClient().setAchievementProgressAtLeast(appId, key, { progress });
}

export async function listLeaderboards(appId: number, options: { includeRetired?: boolean } = {}) {
  return await getDefaultClient().listLeaderboards(appId, options);
}

export async function getLeaderboard(
  appId: number,
  key: string,
  options: { top?: number; aroundMe?: number; includeRetired?: boolean } = {},
) {
  return await getDefaultClient().getLeaderboard(appId, key, options);
}

export async function submitLeaderboardScore(appId: number, key: string, score: number) {
  return await getDefaultClient().submitLeaderboardScore(appId, key, { score });
}

export async function fetchMyAchievements() {
  return await getDefaultClient().fetchMyAchievements();
}

export async function fetchMyLeaderboards() {
  return await getDefaultClient().fetchMyLeaderboards();
}

export async function fetchOwnedProfileAssets() {
  const response = await getDefaultClient().fetchOwnedProfileAssets();
  return response.assets;
}

export async function saveItem(kind: SavedItemKind, creatorUsername: string, itemName: string) {
  return await getDefaultClient().saveItem(kind, creatorUsername, itemName);
}

export async function unsaveItem(kind: SavedItemKind, creatorUsername: string, itemName: string) {
  return await getDefaultClient().unsaveItem(kind, creatorUsername, itemName);
}

export async function likeItem(kind: SavedItemKind, creatorUsername: string, itemName: string): Promise<LikedItemMutationResponse> {
  return await getDefaultClient().likeItem(kind, creatorUsername, itemName);
}

export async function unlikeItem(kind: SavedItemKind, creatorUsername: string, itemName: string): Promise<LikedItemMutationResponse> {
  return await getDefaultClient().unlikeItem(kind, creatorUsername, itemName);
}

export async function dislikeItem(kind: SavedItemKind, creatorUsername: string, itemName: string): Promise<DislikedItemMutationResponse> {
  return await getDefaultClient().dislikeItem(kind, creatorUsername, itemName);
}

export async function undislikeItem(kind: SavedItemKind, creatorUsername: string, itemName: string): Promise<DislikedItemMutationResponse> {
  return await getDefaultClient().undislikeItem(kind, creatorUsername, itemName);
}

export async function reportContent(
  kind: SavedItemKind,
  creatorUsername: string,
  itemName: string,
  request: CreateContentReportRequest,
): Promise<ModerationReportResponse> {
  return await getDefaultClient().reportContent(kind, creatorUsername, itemName, request);
}

export async function fetchContentComments(kind: SavedItemKind, creatorUsername: string, itemName: string) {
  return await getDefaultClient().fetchContentComments(kind, creatorUsername, itemName);
}

export async function createContentComment(
  kind: SavedItemKind,
  creatorUsername: string,
  itemName: string,
  request: CreateContentCommentRequest,
) {
  return await getDefaultClient().createContentComment(kind, creatorUsername, itemName, request);
}

export async function likeContentComment(commentId: number): Promise<LikedItemMutationResponse> {
  return await getDefaultClient().likeContentComment(commentId);
}

export async function unlikeContentComment(commentId: number): Promise<LikedItemMutationResponse> {
  return await getDefaultClient().unlikeContentComment(commentId);
}

export async function dislikeContentComment(commentId: number): Promise<DislikedItemMutationResponse> {
  return await getDefaultClient().dislikeContentComment(commentId);
}

export async function undislikeContentComment(commentId: number): Promise<DislikedItemMutationResponse> {
  return await getDefaultClient().undislikeContentComment(commentId);
}

export async function reportComment(
  commentId: number,
  request: CreateCommentReportRequest,
): Promise<ModerationReportResponse> {
  return await getDefaultClient().reportComment(commentId, request);
}

export async function deleteContentComment(commentId: number) {
  return await getDefaultClient().deleteContentComment(commentId);
}

export async function trackEngagementEvent(request: TrackEngagementEventRequest): Promise<TrackEngagementEventResponse> {
  return await getDefaultClient().trackEngagementEvent(request);
}

export async function fetchLibrary(options: { category?: LibraryCategory; sort?: LibrarySort } = {}) {
  return await getDefaultClient().fetchLibrary(options);
}

export async function followCreator(creatorUsername: string): Promise<CreatorFollowMutationResponse> {
  return await getDefaultClient().followCreator(creatorUsername);
}

export async function unfollowCreator(creatorUsername: string): Promise<CreatorFollowMutationResponse> {
  return await getDefaultClient().unfollowCreator(creatorUsername);
}

export async function reportCreator(
  creatorUsername: string,
  request: CreateCreatorReportRequest,
): Promise<ModerationReportResponse> {
  return await getDefaultClient().reportCreator(creatorUsername, request);
}

export async function blockCreator(creatorUsername: string): Promise<CreatorBlockMutationResponse> {
  return await getDefaultClient().blockCreator(creatorUsername);
}

export async function unblockCreator(creatorUsername: string): Promise<CreatorBlockMutationResponse> {
  return await getDefaultClient().unblockCreator(creatorUsername);
}

export async function fetchFollowingCreators(options: { sort?: FollowingSort } = {}) {
  return await getDefaultClient().fetchFollowingCreators(options);
}

export async function fetchFollowingFeed(options: { section: FollowingFeedSection; limit?: number }) {
  return await getDefaultClient().fetchFollowingFeed(options);
}

export async function fetchNotifications(options: { status?: NotificationStatus; limit?: number; offset?: number } = {}) {
  return await getDefaultClient().fetchNotifications(options);
}

export async function markNotificationRead(notificationId: number) {
  return await getDefaultClient().markNotificationRead(notificationId);
}

export async function markAllNotificationsRead() {
  return await getDefaultClient().markAllNotificationsRead();
}

export async function fetchEmailPreferences() {
  return await getDefaultClient().fetchEmailPreferences();
}

export async function updateEmailPreferences(request: UpdateUserCommunicationPreferencesRequest) {
  return await getDefaultClient().updateEmailPreferences(request);
}

export async function fetchPublicEmailPreferences(token: string) {
  return await getDefaultClient().fetchPublicEmailPreferences(token);
}

export async function updatePublicEmailPreferences(token: string, request: PublicEmailPreferencesUpdateRequest) {
  return await getDefaultClient().updatePublicEmailPreferences(token, request);
}

export async function unsubscribeEmailPreferences(token: string) {
  return await getDefaultClient().unsubscribeEmailPreferences(token);
}

export async function fetchWebPushConfig() {
  return await getDefaultClient().fetchWebPushConfig();
}

export async function fetchWebPushSubscriptionStatus(request: UpsertWebPushSubscriptionRequest) {
  return await getDefaultClient().fetchWebPushSubscriptionStatus(request);
}

export async function upsertWebPushSubscription(request: UpsertWebPushSubscriptionRequest) {
  return await getDefaultClient().upsertWebPushSubscription(request);
}

export async function deleteWebPushSubscription(request: UpsertWebPushSubscriptionRequest) {
  return await getDefaultClient().deleteWebPushSubscription(request);
}

export async function fetchApplePushDeviceStatus(request: ApplePushDeviceRequest) {
  return await getDefaultClient().fetchApplePushDeviceStatus(request);
}

export async function upsertApplePushDevice(request: ApplePushDeviceRequest) {
  return await getDefaultClient().upsertApplePushDevice(request);
}

export async function deleteApplePushDevice(request: ApplePushDeviceRequest) {
  return await getDefaultClient().deleteApplePushDevice(request);
}

export async function fetchFirebasePushDeviceStatus(request: FirebasePushDeviceRequest) {
  return await getDefaultClient().fetchFirebasePushDeviceStatus(request);
}

export async function upsertFirebasePushDevice(request: FirebasePushDeviceRequest) {
  return await getDefaultClient().upsertFirebasePushDevice(request);
}

export async function deleteFirebasePushDevice(request: FirebasePushDeviceRequest) {
  return await getDefaultClient().deleteFirebasePushDevice(request);
}

export async function search(request: SearchRequest) {
  return await getDefaultClient().search(request);
}

export async function suggestSearch(request: SearchSuggestRequest) {
  return await getDefaultClient().suggestSearch(request);
}

export async function setSelectedProfileAsset(assetRef: string) {
  const request: SetProfileAssetRequest = { assetRef };
  return await getDefaultClient().setSelectedProfileAsset(request);
}

export async function fetchHome(options?: FetchHomeOptions) {
  return await getDefaultClient().fetchHome(options);
}

export async function fetchShop() {
  return await getDefaultClient().fetchCreditShop();
}

export async function fetchPublicShop() {
  return await getDefaultClient().fetchPublicCreditShop();
}

export async function createCreditPackCheckoutSession(
  sku: string,
  request?: { nextPath?: string },
) {
  return await getDefaultClient().createCreditPackCheckoutSession(sku, request);
}

export async function fetchCreditPackCheckoutStatus(sessionId: string) {
  return await getDefaultClient().fetchCreditPackCheckoutStatus(sessionId);
}

export async function fulfillAppleCreditPackPurchase(request: {
  productId: string;
  transactionId: string;
  signedTransactionInfo: string;
}) {
  return await getDefaultClient().fulfillAppleCreditPackPurchase(request);
}

export async function fulfillGoogleCreditPackPurchase(request: {
  productId: string;
  purchaseToken: string;
}) {
  return await getDefaultClient().fulfillGoogleCreditPackPurchase(request);
}

export async function purchaseAsset(assetRef: string) {
  return await getDefaultClient().purchaseAsset({ type: 'asset', assetRef });
}

export async function purchaseIap(request: IapPurchaseRequest) {
  return await getDefaultClient().purchaseIap(request);
}

export async function purchaseDevIap(appId: number, slot: number, request: IapPurchaseRequest) {
  return await getDefaultClient().purchaseDevIap(appId, slot, request);
}

export async function fetchIapReceipts(params?: IapReceiptListParams) {
  return await getDefaultClient().fetchIapReceipts(params);
}

export async function cancelIapReceipt(receiptId: number) {
  return await getDefaultClient().cancelIapReceipt(receiptId);
}

export async function fetchAppIapReceipts(params?: Omit<IapReceiptListParams, 'appId'>) {
  return await getDefaultClient().fetchAppIapReceipts(params);
}

export async function consumeAppIapReceipt(receiptId: number) {
  return await getDefaultClient().consumeAppIapReceipt(receiptId);
}

export async function grantAppIapReceipt(receiptId: number) {
  return await getDefaultClient().grantAppIapReceipt(receiptId);
}

export async function cancelAppIapReceipt(receiptId: number) {
  return await getDefaultClient().cancelAppIapReceipt(receiptId);
}

export async function fetchCreditTransactions(options?: { limit?: number; offset?: number }) {
  return await getDefaultClient().fetchCreditTransactions(options);
}

export async function submitFeedback(request: SubmitFeedbackRequest) {
  return await getDefaultClient().submitFeedback(request);
}

export async function listFeedback(options?: { limit?: number; offset?: number; client?: FeedbackClient; category?: FeedbackCategory; userId?: number }) {
  return await getDefaultClient().listFeedback(options);
}

export async function fetchAdminFeedback(options?: {
  limit?: number;
  offset?: number;
  client?: FeedbackClient;
  category?: FeedbackCategory;
  status?: FeedbackStatus;
  userId?: number;
}) {
  return await getDefaultClient().fetchAdminFeedback(options);
}

export async function fetchAdminFeedbackEntry(id: number) {
  return await getDefaultClient().fetchAdminFeedbackEntry(id);
}

export async function updateAdminFeedback(id: number, request: UpdateAdminFeedbackRequest) {
  return await getDefaultClient().updateAdminFeedback(id, request);
}

export async function deleteAdminFeedback(id: number) {
  return await getDefaultClient().deleteAdminFeedback(id);
}

export async function fetchBoostBalance() {
  return await getDefaultClient().fetchBoostBalance();
}

export async function purchaseBoostPack(request: BoostPurchaseRequest) {
  return await getDefaultClient().purchaseBoostPack(request);
}

export async function activateAppBoost(appId: number, units = 1) {
  return await getDefaultClient().activateAppBoost(appId, { units });
}

export async function fetchAppBoostStatus(appId: number) {
  return await getDefaultClient().fetchAppBoostStatus(appId);
}

export async function fetchAppBoostHistory(appId: number, options?: { limit?: number }) {
  return await getDefaultClient().fetchAppBoostHistory(appId, options);
}

export async function fetchAppBoostReport(appId: number, options?: BoostReportQuery) {
  return await getDefaultClient().fetchAppBoostReport(appId, options);
}

export async function fetchCreatorEarnings(options?: { days?: number; appId?: number }) {
  return await getDefaultClient().fetchCreatorEarnings(options);
}

export async function loadInterstitialAd(sourceAppId: number, viewerSurface: AppSurface) {
  return await getDefaultClient().loadInterstitialAd({ sourceAppId, viewerSurface });
}

export async function showInterstitialAd(reservationId: string, viewedMs: number) {
  return await getDefaultClient().showInterstitialAd({ reservationId, viewedMs });
}

export async function loadDevInterstitialAd(appId: number, slot: number, viewerSurface: AppSurface) {
  return await getDefaultClient().loadDevInterstitialAd(appId, slot, { viewerSurface });
}

export async function showDevInterstitialAd(appId: number, slot: number, reservationId: string, viewedMs: number) {
  return await getDefaultClient().showDevInterstitialAd(appId, slot, { reservationId, viewedMs });
}

export async function loadRewardedAd(sourceAppId: number, viewerSurface: AppSurface) {
  return await getDefaultClient().loadRewardedAd({ sourceAppId, viewerSurface });
}

export async function showRewardedAd(reservationId: string, viewedMs: number) {
  return await getDefaultClient().showRewardedAd({ reservationId, viewedMs });
}

export async function loadDevRewardedAd(appId: number, slot: number, viewerSurface: AppSurface) {
  return await getDefaultClient().loadDevRewardedAd(appId, slot, { viewerSurface });
}

export async function showDevRewardedAd(appId: number, slot: number, reservationId: string, viewedMs: number) {
  return await getDefaultClient().showDevRewardedAd(appId, slot, { reservationId, viewedMs });
}

export async function fetchAiGeneration(id: string) {
  return await getDefaultClient().fetchAiGeneration(id);
}

export async function fetchAdminAiGeneration(id: string) {
  return await getDefaultClient().fetchAdminAiGeneration(id);
}

export async function fetchAdminCommunicationsRules() {
  return await getDefaultClient().fetchAdminCommunicationsRules();
}

export async function fetchAdminCommunicationsExecutions(options?: {
  limit?: number;
  offset?: number;
  status?: CreatorEngagementRuleExecutionStatus;
  ruleId?: string;
  userId?: number;
}) {
  return await getDefaultClient().fetchAdminCommunicationsExecutions(options);
}

export async function fetchAdminCommunicationsUser(userId: number) {
  return await getDefaultClient().fetchAdminCommunicationsUser(userId);
}

export async function previewAdminCommunicationsRule(
  ruleId: string,
  request: AdminCreatorEngagementRulePreviewRequest,
) {
  return await getDefaultClient().previewAdminCommunicationsRule(ruleId, request);
}

export async function updateAdminCommunicationsRuleAction(
  ruleId: string,
  actionId: string,
  request: { enabled: boolean },
) {
  return await getDefaultClient().updateAdminCommunicationsRuleAction(ruleId, actionId, request);
}

export async function listAssetCategories() {
  const response = await getDefaultClient().listAssetCategories();
  return response.categories;
}

export async function listAssets(
  options: {
    limit?: number;
    offset?: number;
    category?: AssetCategory;
    subcategory?: string;
    kind?: AssetBrowseKind;
    assetSpec?: string;
    assetSpecOwner?: string;
    assetSpecName?: string;
    sort?: AssetListSort;
    tags?: string[];
  } = {},
) {
  const response = await getDefaultClient().listAssets(options);
  return response.assets;
}

export async function fetchAssetBySlug(creatorUsername: string, assetName: string) {
  const response = await getDefaultClient().fetchAssetBySlug(creatorUsername, assetName);
  return response.asset;
}

export async function fetchAssetRelated(creatorUsername: string, assetName: string) {
  return await getDefaultClient().fetchAssetRelated(creatorUsername, assetName);
}

export async function listAssetVersions(
  creatorUsername: string,
  assetName: string,
  options: { limit?: number; offset?: number } = {},
) {
  const response = await getDefaultClient().listAssetVersions(creatorUsername, assetName, options);
  return response.versions;
}

export async function listAssetsForCreator(
  creatorUsername: string,
  options: {
    limit?: number;
    offset?: number;
    category?: AssetCategory;
    subcategory?: string;
    kind?: AssetBrowseKind;
    assetSpec?: string;
    assetSpecOwner?: string;
    assetSpecName?: string;
    sort?: AssetListSort;
    tags?: string[];
  } = {},
) {
  const response = await getDefaultClient().listAssetsForCreator(creatorUsername, options);
  return response.assets;
}

export async function listAssetsForCreatorPage(
  creatorUsername: string,
  options: {
    limit?: number;
    offset?: number;
    category?: AssetCategory;
    subcategory?: string;
    kind?: AssetBrowseKind;
    assetSpec?: string;
    assetSpecOwner?: string;
    assetSpecName?: string;
    sort?: AssetListSort;
    tags?: string[];
  } = {},
) {
  return await getDefaultClient().listAssetsForCreator(creatorUsername, options);
}

export async function updateAsset(
  creatorUsername: string,
  name: string,
  request: UpdateAssetRequest,
) {
  return await getDefaultClient().updateAsset(creatorUsername, name, request);
}

export async function updateAssetVersion(
  creatorUsername: string,
  name: string,
  revision: string | number,
  request: UpdateAssetVersionRequest,
) {
  return await getDefaultClient().updateAssetVersion(creatorUsername, name, revision, request);
}

export async function deleteAssetVersion(
  creatorUsername: string,
  name: string,
  revision: string | number,
) {
  return await getDefaultClient().deleteAssetVersion(creatorUsername, name, revision);
}

export async function deleteAsset(creatorUsername: string, name: string) {
  return await getDefaultClient().deleteAsset(creatorUsername, name);
}

export async function downloadAssetFile(
  creatorUsername: string,
  assetName: string,
  revision: string | number,
  options: { role?: string } = {},
) {
  return await getDefaultClient().downloadAssetFile(creatorUsername, assetName, revision, options);
}

export async function downloadAssetSource(
  creatorUsername: string,
  assetName: string,
  revision: string | number,
) {
  return await getDefaultClient().downloadAssetSource(creatorUsername, assetName, revision);
}

export async function listAssetPacks(
  options: { limit?: number; offset?: number; containsCategory?: AssetCategory; containsSubcategory?: string; sort?: AssetPackListSort; tags?: string[] } = {},
) {
  const response = await getDefaultClient().listAssetPacks(options);
  return response.packs;
}

export async function fetchAssetPackBySlug(creatorUsername: string, packName: string) {
  const response = await getDefaultClient().fetchAssetPackBySlug(creatorUsername, packName);
  return response.pack;
}

export async function fetchAssetPackDetailBySlug(creatorUsername: string, packName: string) {
  const response = await getDefaultClient().fetchAssetPackDetailBySlug(creatorUsername, packName);
  if (!Array.isArray(response.assets)) {
    throw new Error('asset_pack_detail_assets_missing');
  }
  return response;
}

export async function fetchAssetPackRelated(creatorUsername: string, packName: string) {
  return await getDefaultClient().fetchAssetPackRelated(creatorUsername, packName);
}

export async function downloadAssetPackSource(
  creatorUsername: string,
  packName: string,
  version: string,
) {
  return await getDefaultClient().downloadAssetPackSource(creatorUsername, packName, version);
}

export async function downloadAssetPack(
  creatorUsername: string,
  packName: string,
  version: string,
) {
  return await getDefaultClient().downloadAssetPack(creatorUsername, packName, version);
}

export async function listAssetPackVersions(
  creatorUsername: string,
  packName: string,
  options: { limit?: number; offset?: number } = {},
) {
  const response = await getDefaultClient().listAssetPackVersions(creatorUsername, packName, options);
  return response.versions;
}

export async function listAssetPacksForCreator(
  creatorUsername: string,
  options: { limit?: number; offset?: number; containsCategory?: AssetCategory; containsSubcategory?: string; sort?: AssetPackListSort; tags?: string[] } = {},
) {
  const response = await getDefaultClient().listAssetPacksForCreator(creatorUsername, options);
  return response.packs;
}

export async function listAssetPacksForCreatorPage(
  creatorUsername: string,
  options: { limit?: number; offset?: number; containsCategory?: AssetCategory; containsSubcategory?: string; sort?: AssetPackListSort; tags?: string[] } = {},
) {
  return await getDefaultClient().listAssetPacksForCreator(creatorUsername, options);
}

export async function updateAssetPack(
  creatorUsername: string,
  name: string,
  request: UpdateAssetPackRequest,
) {
  return await getDefaultClient().updateAssetPack(creatorUsername, name, request);
}

export async function updateAssetPackVersion(
  creatorUsername: string,
  name: string,
  version: string,
  request: UpdateAssetPackVersionRequest,
) {
  return await getDefaultClient().updateAssetPackVersion(creatorUsername, name, version, request);
}

export async function deleteAssetPackVersion(
  creatorUsername: string,
  name: string,
  version: string,
) {
  return await getDefaultClient().deleteAssetPackVersion(creatorUsername, name, version);
}

export async function deleteAssetPack(creatorUsername: string, name: string) {
  return await getDefaultClient().deleteAssetPack(creatorUsername, name);
}

export async function getAppVersion(creatorUsername: string, appName: string, version: string) {
  return await getDefaultClient().getAppVersion(creatorUsername, appName, version);
}

export async function fetchAppRuntimeAssets(creatorUsername: string, appName: string, version: string) {
  return await getDefaultClient().fetchAppRuntimeAssets(creatorUsername, appName, version);
}

export async function resolveRuntimeAssets(request: ResolveRuntimeAssetsRequest) {
  return await getDefaultClient().resolveRuntimeAssets(request);
}

export async function listAppVersions(creatorUsername: string, appName: string) {
  return await getDefaultClient().listAppVersions(creatorUsername, appName);
}

export async function updateAppVersion(
  creatorUsername: string,
  appName: string,
  version: string,
  updates: {
    releaseNotes?: string | null;
    visibility?: AppVersionVisibility;
    license?: ContentLicense;
    setAsCurrent?: boolean;
  },
) {
  return await getDefaultClient().updateAppVersion(creatorUsername, appName, version, updates);
}

export async function deleteAppVersion(creatorUsername: string, appName: string, version: string) {
  return await getDefaultClient().deleteAppVersion(creatorUsername, appName, version);
}

export async function deleteApp(creatorUsername: string, appName: string) {
  return await getDefaultClient().deleteApp(creatorUsername, appName);
}

export async function fetchAdminApps() {
  return await getDefaultClient().fetchAdminApps();
}

export async function fetchAdminGameCollections(): Promise<AdminGameCollectionsResponse> {
  return await getDefaultClient().fetchAdminGameCollections();
}

export async function createAdminGameCollection(
  request: CreateAdminGameCollectionRequest,
): Promise<AdminGameCollectionResponse> {
  return await getDefaultClient().createAdminGameCollection(request);
}

export async function fetchAdminGameCollection(id: number): Promise<AdminGameCollectionResponse> {
  return await getDefaultClient().fetchAdminGameCollection(id);
}

export async function updateAdminGameCollection(
  id: number,
  request: UpdateAdminGameCollectionRequest,
): Promise<AdminGameCollectionResponse> {
  return await getDefaultClient().updateAdminGameCollection(id, request);
}

export async function replaceAdminGameCollectionGames(
  id: number,
  request: UpdateAdminGameCollectionGamesRequest,
): Promise<AdminGameCollectionResponse> {
  return await getDefaultClient().replaceAdminGameCollectionGames(id, request);
}

export async function searchAdminGameCollectionCandidates(
  options: { q: string; limit?: number },
): Promise<AdminGameCollectionCandidatesResponse> {
  return await getDefaultClient().searchAdminGameCollectionCandidates(options);
}

export async function uploadAdminGameCollectionIcon(
  id: number,
  formData: FormData,
): Promise<AdminGameCollectionResponse> {
  return await getDefaultClient().uploadAdminGameCollectionIcon(id, formData);
}

export async function deleteAdminGameCollection(id: number) {
  return await getDefaultClient().deleteAdminGameCollection(id);
}

export async function fetchAdminAppVersionReviews(options?: { state?: ReviewState; visibility?: AppVersionVisibility; limit?: number; offset?: number }) {
  return await getDefaultClient().fetchAdminAppVersionReviews(options);
}

export async function enqueueNextAdminAppVersionReviewTask() {
  return await getDefaultClient().enqueueNextAdminAppVersionReviewTask();
}

export async function updateAdminAppVersionReview(
  versionId: number,
  request: { reviewState?: ReviewState; reviewMessage?: string | null; creatorFeedback?: string | null },
) {
  return await getDefaultClient().updateAdminAppVersionReview(versionId, request);
}

export async function fetchAdminAppPlayerMeta(appId: number) {
  return await getDefaultClient().fetchAdminAppPlayerMeta(appId);
}

export async function fetchAdminAppPlayerMetaUser(appId: number, userId: number) {
  return await getDefaultClient().fetchAdminAppPlayerMetaUser(appId, userId);
}

export async function retireAdminAchievement(appId: number, key: string) {
  return await getDefaultClient().retireAdminAchievement(appId, key);
}

export async function retireAdminLeaderboard(appId: number, key: string) {
  return await getDefaultClient().retireAdminLeaderboard(appId, key);
}

export async function mutateAdminAchievementState(
  appId: number,
  userId: number,
  key: string,
  request: AdminMutateAchievementStateRequest,
) {
  return await getDefaultClient().mutateAdminAchievementState(appId, userId, key, request);
}

export async function mutateAdminLeaderboardScore(
  appId: number,
  userId: number,
  key: string,
  request: AdminMutateLeaderboardScoreRequest,
) {
  return await getDefaultClient().mutateAdminLeaderboardScore(appId, userId, key, request);
}

export async function fetchAppDetail(
  creatorUsername: string,
  appName: string,
  options: AppDetailRequest = {},
): Promise<AppDetailResponse> {
  return await getDefaultClient().fetchAppBySlug(creatorUsername, appName, options);
}

export async function downloadAppSource(creatorUsername: string, appName: string, version: string) {
  return await getDefaultClient().downloadAppSource(creatorUsername, appName, version);
}

export function configureWebClientRuntime(config: { platform: PlatformInfo; client: ClientInfo }): void {
  runtimeState.platform = {
    name: config.platform.name.trim().toLowerCase(),
    version: config.platform.version.trim(),
  };
  runtimeState.client = {
    version: config.client.version.trim(),
    build: config.client.build.trim(),
  };
}

export function getRuntimeState() {
  return runtimeState;
}

export function getClientVersionLabel(): string {
  const client = runtimeState.client;
  if (!client) {
    return '0.0.0 (build 0)';
  }
  return `${client.version} (build ${client.build})`;
}

export {
  APP_SURFACE_VALUES, APP_TYPE_DEFAULT_DISPLAY, APP_TYPE_VALUES, DEFAULT_APP_SURFACE_TARGETS, DEFAULT_APP_TYPE, FEEDBACK_CATEGORY_VALUES,
  FEEDBACK_CLIENT_VALUES,
  FEEDBACK_STATUS_VALUES,
  normalizeAppType
} from '@playdrop/types';

export { ApiError, UnsupportedClientError } from '@playdrop/types';

export type * from '@playdrop/types';

export type App = AppResponse;
export type Asset = AssetResponse;
export type AssetSummary = AssetSummaryResponse;
export type AssetPack = AssetPackResponse;
export type AssetSpec = AssetSpecResponse;
