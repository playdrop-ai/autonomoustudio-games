export type ApiRequestLike = {
  method: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
  path: string;
  body?: unknown;
  headers?: Record<string, string>;
};

export type ApiResponseLike<T> = {
  status: number;
  body: T;
  headers: Headers;
};

export type RequestExecutor = <T>(request: ApiRequestLike) => Promise<ApiResponseLike<T>>;

export const DEFAULT_REQUEST_TIMEOUT_MS = 15000;

export function resolveRequestTimeoutMs(value: number | undefined): number {
  if (value === undefined) {
    return DEFAULT_REQUEST_TIMEOUT_MS;
  }
  const parsed = Number(value);
  if (!Number.isFinite(parsed) || parsed <= 0) {
    throw new Error('invalid_api_request_timeout_ms');
  }
  return Math.floor(parsed);
}

function trimTrailingSlash(value: string): string {
  return value.replace(/\/+$/, '');
}

function normalizeHostname(value: string): string {
  return value.trim().toLowerCase();
}

function isLoopbackHostname(hostname: string): boolean {
  return hostname === 'localhost'
    || hostname === '127.0.0.1'
    || hostname === '0.0.0.0';
}

function resolvePlaydropSurface(hostname: string): 'prod' | 'preview' | 'blue' | 'green' | null {
  if (hostname === 'playdrop.ai' || hostname === 'www.playdrop.ai') {
    return 'prod';
  }
  if (hostname === 'preview.playdrop.ai') {
    return 'preview';
  }
  if (hostname === 'blue.playdrop.ai') {
    return 'blue';
  }
  if (hostname === 'green.playdrop.ai') {
    return 'green';
  }
  return null;
}

function buildPlaydropApiOrigin(protocol: string, surface: 'prod' | 'preview' | 'blue' | 'green'): string {
  const host = surface === 'prod'
    ? 'api.playdrop.ai'
    : `api.${surface}.playdrop.ai`;
  return `${protocol}//${host}`;
}

function resolveBrowserApiBaseUrl(): string {
  const { protocol, hostname } = window.location;
  const normalizedProtocol = protocol === 'https:' ? 'https:' : 'http:';
  const normalizedHostname = normalizeHostname(hostname);

  if (isLoopbackHostname(normalizedHostname)) {
    return 'http://localhost:4000';
  }
  if (normalizedHostname === 'www.localhost') {
    return `${normalizedProtocol}//api.localhost`;
  }
  if (normalizedHostname === 'play.local') {
    return `${normalizedProtocol}//api.local`;
  }
  if (normalizedHostname.endsWith('.localhost')) {
    return `${normalizedProtocol}//api.${normalizedHostname.slice(0, -'.localhost'.length)}.localhost`;
  }
  if (normalizedHostname.endsWith('.local')) {
    return `${normalizedProtocol}//api.${normalizedHostname.slice(0, -'.local'.length)}.local`;
  }

  const playdropSurface = resolvePlaydropSurface(normalizedHostname);
  if (playdropSurface) {
    return buildPlaydropApiOrigin(normalizedProtocol, playdropSurface);
  }

  if (normalizedHostname.startsWith('www.') && normalizedHostname.includes('.')) {
    return `${normalizedProtocol}//api.${normalizedHostname.slice('www.'.length)}`;
  }
  return `${normalizedProtocol}//${normalizedHostname}:4000`;
}

export function createBaseUrlResolver(baseUrl: string | undefined): () => string {
  return () => {
    if (baseUrl) {
      return baseUrl;
    }
    if (typeof window !== 'undefined') {
      return resolveBrowserApiBaseUrl();
    }
    if (typeof process !== 'undefined' && process.env["NEXT_PUBLIC_API_BASE"]) {
      return trimTrailingSlash(process.env["NEXT_PUBLIC_API_BASE"]);
    }
    return 'http://localhost:4000';
  };
}

export function resolveUrl(base: string, path: string): string {
  if (/^https?:/i.test(path)) {
    return path;
  }
  const normalizedBase = base.endsWith('/') ? base : `${base}/`;
  const trimmedPath = path.startsWith('/') ? path.slice(1) : path;
  return new URL(trimmedPath, normalizedBase).toString();
}

export function buildBrowserCredentialsInit(
  includeBrowserCredentials: boolean,
): Partial<Pick<RequestInit, 'credentials'>> {
  if (!includeBrowserCredentials || typeof window === 'undefined') {
    return {};
  }
  return { credentials: 'include' };
}

export async function parseResponseBody<T>(response: Response): Promise<T> {
  if (response.status === 204 || response.status === 205 || response.status === 304) {
    return undefined as T;
  }
  const contentType = response.headers.get('content-type') || '';
  if (contentType.includes('application/json')) {
    try {
      return (await response.clone().json()) as T;
    } catch {
      // fall through to text if parsing fails
    }
  }
  try {
    const text = await response.clone().text();
    return text as unknown as T;
  } catch {
    return undefined as T;
  }
}

export function createRequestExecutor(input: {
  fetchImpl: typeof fetch;
  resolveBaseUrl: () => string;
  resolveUrl: (base: string, path: string) => string;
  parseResponseBody: <T>(response: Response) => Promise<T>;
  resolveToken: () => Promise<string | null>;
  getClientHeaders: () => Record<string, string>;
  requestTimeoutMs: number;
  includeBrowserCredentials: boolean;
}): RequestExecutor {
  const {
    fetchImpl,
    resolveBaseUrl,
    resolveUrl: resolveUrlInput,
    parseResponseBody: parseResponseBodyInput,
    resolveToken,
    getClientHeaders,
    requestTimeoutMs,
    includeBrowserCredentials,
  } = input;

  return async function request<T>(req: ApiRequestLike): Promise<ApiResponseLike<T>> {
    const base = resolveBaseUrl();
    const targetUrl = resolveUrlInput(base, req.path);
    const headers = new Headers();

    for (const [key, value] of Object.entries(getClientHeaders())) {
      headers.set(key, value);
    }

    headers.set('accept', 'application/json');
    if (req.body !== undefined && req.body !== null && req.method !== 'GET') {
      headers.set('content-type', 'application/json');
    }

    if (req.headers) {
      for (const [key, value] of Object.entries(req.headers)) {
        headers.set(key, value);
      }
    }

    const token = await resolveToken();
    if (token) {
      headers.set('authorization', `Bearer ${token}`);
    }

    const init: RequestInit = {
      method: req.method,
      headers,
      ...buildBrowserCredentialsInit(includeBrowserCredentials),
    };
    if (req.body !== undefined && req.body !== null && req.method !== 'GET') {
      init.body = typeof req.body === 'string' ? req.body : JSON.stringify(req.body);
    }

    let timeoutHandle: ReturnType<typeof setTimeout> | null = null;
    let controller: AbortController | null = null;
    if (typeof AbortController !== 'undefined') {
      controller = new AbortController();
      init.signal = controller.signal;
      timeoutHandle = setTimeout(() => {
        controller?.abort();
      }, requestTimeoutMs);
    }

    try {
      const response = await fetchImpl(targetUrl, init);
      const parsed = await parseResponseBodyInput<T>(response);
      return {
        status: response.status,
        body: parsed,
        headers: response.headers,
      };
    } catch (error) {
      if (controller?.signal.aborted) {
        throw new Error(`api_request_timeout:${req.method}:${req.path}`);
      }
      throw error;
    } finally {
      if (timeoutHandle) {
        clearTimeout(timeoutHandle);
      }
    }
  };
}
