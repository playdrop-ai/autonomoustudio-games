import { ApiError, UnsupportedClientError } from '@playdrop/types/api';

export type ApiResponseLike<T> = {
  status: number;
  body: T;
  headers: Headers;
};

export function parseUnsupportedError(status: number, payload: unknown): UnsupportedClientError | null {
  if (status !== 426 && status !== 400) {
    return null;
  }

  const data = (payload && typeof payload === 'object') ? (payload as Record<string, unknown>) : null;
  const code = typeof data?.["error"] === 'string' ? data["error"] : undefined;

  const unsupportedCodes = new Set([
    'unsupported_client',
    'unsupported_client_version',
    'unsupported_client_build',
    'unsupported_platform_version',
    'missing_client_metadata',
  ]);

  const isGuardResponse = status === 426 || (status === 400 && code !== undefined && unsupportedCodes.has(code));
  if (!isGuardResponse) {
    return null;
  }

  const message = typeof data?.["message"] === 'string' ? data["message"] : 'Unsupported client version';
  return new UnsupportedClientError(code ?? 'unsupported_client', message, data ?? null);
}

export function handleApiError(response: ApiResponseLike<any>, context: string): never {
  const unsupported = parseUnsupportedError(response.status, response.body);
  if (unsupported) {
    throw unsupported;
  }

  const payload = response.body && typeof response.body === 'object' ? response.body : {};
  const details = response.body && typeof response.body === 'object'
    ? response.body as Record<string, unknown>
    : null;
  const code = typeof payload["error"] === 'string' ? payload["error"] : context;

  let message: string;
  if (typeof payload["message"] === 'string') {
    message = payload["message"];
  } else if (typeof payload["error"] === 'string') {
    message = payload["error"];
    if (typeof payload["errorPath"] === 'string') {
      message = `${payload["error"]}: ${payload["errorPath"]}`;
    }
    if (Array.isArray(payload["missing"]) && payload["missing"].length > 0) {
      message = `${payload["error"]}: missing exports [${payload["missing"].join(', ')}]`;
    }
  } else {
    const statusMessage = response.status === 429
      ? 'HTTP 429 rate limited'
      : `HTTP ${response.status}`;
    const retryAfter = response.headers.get('retry-after')?.trim();
    message = `${context} failed: ${statusMessage}${retryAfter ? `; Retry-After ${retryAfter}` : ''}`;
  }

  throw new ApiError(message, response.status, code, details);
}
