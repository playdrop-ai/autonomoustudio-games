export const CONTENT_LICENSE_VALUES = ['CLOSED', 'PLAYDROP', 'MIT', 'CC0'] as const;

export type ContentLicense = (typeof CONTENT_LICENSE_VALUES)[number];

export const DEFAULT_CONTENT_LICENSE: ContentLicense = 'PLAYDROP';

export interface ContentPermissions {
  canDownloadSource: boolean;
  canRemix: boolean;
  canReuseOnPlaydrop: boolean;
  canUseOffPlatform: boolean;
}

export function isContentLicense(value: unknown): value is ContentLicense {
  if (typeof value !== 'string') {
    return false;
  }
  return (CONTENT_LICENSE_VALUES as readonly string[]).includes(value.trim().toUpperCase());
}

export function parseContentLicense(value: unknown): ContentLicense | null {
  if (typeof value !== 'string') {
    return null;
  }
  const normalized = value.trim().toUpperCase();
  return isContentLicense(normalized) ? (normalized as ContentLicense) : null;
}

export function isOpenContentLicense(value: ContentLicense): boolean {
  return value === 'MIT' || value === 'CC0';
}
