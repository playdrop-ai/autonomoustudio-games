export const AGENT_TASK_PLAYTEST_PROOF_MOMENT_VALUES = ['primaryInput', 'win', 'loss'] as const;

export type AgentTaskPlaytestProofMomentName = (typeof AGENT_TASK_PLAYTEST_PROOF_MOMENT_VALUES)[number];

export type AgentTaskPlaytestProofMoment = {
  action: string;
  observed: string;
  capture: string;
  captureSha256: string;
};

export type AgentTaskPlaytestProof = {
  version: 1;
  primaryInput: AgentTaskPlaytestProofMoment;
  win: AgentTaskPlaytestProofMoment;
  loss: AgentTaskPlaytestProofMoment;
};

export type NormalizeAgentTaskPlaytestProofResult =
  | { ok: true; value: AgentTaskPlaytestProof }
  | { ok: false; error: string };

const PROOF_KEYS = new Set(['version', ...AGENT_TASK_PLAYTEST_PROOF_MOMENT_VALUES]);
const MOMENT_KEYS = new Set(['action', 'observed', 'capture', 'captureSha256']);
const SHA256_HEX = /^[0-9a-f]{64}$/;

function normalizeRequiredString(value: unknown, maxLength: number): string | null {
  if (typeof value !== 'string') return null;
  const normalized = value.trim();
  return normalized && normalized.length <= maxLength ? normalized : null;
}

function normalizeCapturePath(value: unknown): string | null {
  const normalized = normalizeRequiredString(value, 500);
  if (!normalized || normalized.startsWith('/') || normalized.includes('\\')) return null;
  const segments = normalized.split('/');
  if (segments.some((segment) => !segment || segment === '.' || segment === '..')) return null;
  return normalized;
}

export function normalizeAgentTaskPlaytestProof(value: unknown): NormalizeAgentTaskPlaytestProofResult {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    return { ok: false, error: 'agent_task_playtest_proof_invalid' };
  }
  const record = value as Record<string, unknown>;
  const unexpectedKey = Object.keys(record).find((key) => !PROOF_KEYS.has(key));
  if (unexpectedKey) {
    return { ok: false, error: `agent_task_playtest_proof_invalid_key:${unexpectedKey}` };
  }
  if (record['version'] !== 1) {
    return { ok: false, error: 'agent_task_playtest_proof_invalid_version' };
  }
  const proof = { version: 1 } as AgentTaskPlaytestProof;
  for (const momentName of AGENT_TASK_PLAYTEST_PROOF_MOMENT_VALUES) {
    const rawMoment = record[momentName];
    if (!rawMoment || typeof rawMoment !== 'object' || Array.isArray(rawMoment)) {
      return { ok: false, error: `agent_task_playtest_proof_missing:${momentName}` };
    }
    const moment = rawMoment as Record<string, unknown>;
    const unexpectedMomentKey = Object.keys(moment).find((key) => !MOMENT_KEYS.has(key));
    if (unexpectedMomentKey) {
      return { ok: false, error: `agent_task_playtest_proof_invalid_key:${momentName}:${unexpectedMomentKey}` };
    }
    const action = normalizeRequiredString(moment['action'], 500);
    const observed = normalizeRequiredString(moment['observed'], 500);
    const capture = normalizeCapturePath(moment['capture']);
    const captureSha256 = typeof moment['captureSha256'] === 'string' ? moment['captureSha256'].trim().toLowerCase() : '';
    if (!action || !observed || !capture || !SHA256_HEX.test(captureSha256)) {
      return { ok: false, error: `agent_task_playtest_proof_invalid:${momentName}` };
    }
    proof[momentName] = { action, observed, capture, captureSha256 };
  }
  if (new Set(AGENT_TASK_PLAYTEST_PROOF_MOMENT_VALUES.map((moment) => proof[moment].capture)).size !== 3) {
    return { ok: false, error: 'agent_task_playtest_proof_captures_not_distinct' };
  }
  return { ok: true, value: proof };
}
