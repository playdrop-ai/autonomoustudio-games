import {
  APP_SURFACE_VALUES,
  type AppSurface,
  parseAppSurface,
} from './app.js';

export const APP_PLAYTEST_TAPE_VERSION = 1 as const;
export const APP_PLAYTEST_DEFAULT_TAP_DURATION_MS = 50;

export const APP_PLAYTEST_SUCCESS_SIGNAL_KIND_VALUES = [
  'SURVIVE_LONGER',
  'SCORE_ABOVE_IDLE',
  'VISIBLE_PROGRESS',
  'STATE_REACHED',
] as const;

export type AppPlaytestSuccessSignalKind = typeof APP_PLAYTEST_SUCCESS_SIGNAL_KIND_VALUES[number];

export type AppPlaytestSuccessSignal = {
  kind: AppPlaytestSuccessSignalKind;
  description: string;
};

type AppPlaytestTimedEvent = {
  atMs: number;
};

export type AppPlaytestPointerEvent = AppPlaytestTimedEvent & {
  type: 'pointerDown' | 'pointerMove' | 'pointerUp';
  x: number;
  y: number;
  pointerId?: number;
};

export type AppPlaytestTapEvent = AppPlaytestTimedEvent & {
  type: 'tap';
  x: number;
  y: number;
  durationMs?: number;
};

export type AppPlaytestKeyboardEvent = AppPlaytestTimedEvent & {
  type: 'keyDown' | 'keyUp';
  key: string;
};

export type AppPlaytestTapeEvent =
  | AppPlaytestPointerEvent
  | AppPlaytestTapEvent
  | AppPlaytestKeyboardEvent;

export type AppPlaytestTape = {
  version: typeof APP_PLAYTEST_TAPE_VERSION;
  durationMs: number;
  startOnlyEventCount: number;
  successSignals: AppPlaytestSuccessSignal[];
  events: AppPlaytestTapeEvent[];
};

export type AppPlaytestTapes = Partial<Record<AppSurface, AppPlaytestTape>>;

export type NormalizeAppPlaytestTapesResult =
  | { ok: true; value: AppPlaytestTapes }
  | { ok: false; error: string };

const SUCCESS_SIGNAL_KINDS = new Set<string>(APP_PLAYTEST_SUCCESS_SIGNAL_KIND_VALUES);
const SURFACES = new Set<string>(APP_SURFACE_VALUES);
const MAX_TAPE_DURATION_MS = 120_000;
const MAX_TAPE_EVENTS = 2_000;
const MAX_SUCCESS_SIGNALS = 8;

function isRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value) && typeof value === 'object' && !Array.isArray(value);
}

function isFiniteNumber(value: unknown): value is number {
  return typeof value === 'number' && Number.isFinite(value);
}

function normalizeCoordinate(value: unknown, field: string): number {
  if (!isFiniteNumber(value) || value < 0 || value > 1) {
    throw new Error(`invalid_playtest_tape_coordinate:${field}`);
  }
  return value;
}

function normalizeNonNegativeInteger(value: unknown, field: string, maximum: number): number {
  if (!Number.isInteger(value) || (value as number) < 0 || (value as number) > maximum) {
    throw new Error(`invalid_playtest_tape_integer:${field}`);
  }
  return value as number;
}

function normalizeEvent(
  value: unknown,
  surface: AppSurface,
  durationMs: number,
  index: number,
): AppPlaytestTapeEvent {
  if (!isRecord(value)) {
    throw new Error(`invalid_playtest_tape_event:${surface}:${index}`);
  }
  const type = typeof value['type'] === 'string' ? value['type'] : '';
  const atMs = normalizeNonNegativeInteger(value['atMs'], `${surface}:${index}:atMs`, durationMs);

  if (type === 'pointerDown' || type === 'pointerMove' || type === 'pointerUp') {
    const event: AppPlaytestPointerEvent = {
      type,
      atMs,
      x: normalizeCoordinate(value['x'], `${surface}:${index}:x`),
      y: normalizeCoordinate(value['y'], `${surface}:${index}:y`),
    };
    if (value['pointerId'] !== undefined) {
      event.pointerId = normalizeNonNegativeInteger(value['pointerId'], `${surface}:${index}:pointerId`, 15);
    }
    return event;
  }

  if (type === 'tap') {
    const event: AppPlaytestTapEvent = {
      type,
      atMs,
      x: normalizeCoordinate(value['x'], `${surface}:${index}:x`),
      y: normalizeCoordinate(value['y'], `${surface}:${index}:y`),
    };
    if (value['durationMs'] !== undefined) {
      const remainingMs = durationMs - atMs;
      event.durationMs = normalizeNonNegativeInteger(value['durationMs'], `${surface}:${index}:durationMs`, remainingMs);
      if (event.durationMs <= 0) {
        throw new Error(`invalid_playtest_tape_tap_duration:${surface}:${index}`);
      }
    }
    return event;
  }

  if (type === 'keyDown' || type === 'keyUp') {
    if (surface !== 'DESKTOP') {
      throw new Error(`keyboard_input_not_allowed_on_mobile_tape:${surface}:${index}`);
    }
    const key = typeof value['key'] === 'string' ? value['key'].trim() : '';
    if (!key || key.length > 64) {
      throw new Error(`invalid_playtest_tape_key:${surface}:${index}`);
    }
    return { type, atMs, key };
  }

  throw new Error(`invalid_playtest_tape_event_type:${surface}:${index}:${type || 'missing'}`);
}

function normalizeTape(value: unknown, surface: AppSurface): AppPlaytestTape {
  if (!isRecord(value)) {
    throw new Error(`invalid_playtest_tape:${surface}`);
  }
  if (value['version'] !== APP_PLAYTEST_TAPE_VERSION) {
    throw new Error(`invalid_playtest_tape_version:${surface}`);
  }
  const durationMs = normalizeNonNegativeInteger(value['durationMs'], `${surface}:durationMs`, MAX_TAPE_DURATION_MS);
  if (durationMs <= 0) {
    throw new Error(`invalid_playtest_tape_duration:${surface}`);
  }
  if (!Array.isArray(value['successSignals']) || value['successSignals'].length === 0 || value['successSignals'].length > MAX_SUCCESS_SIGNALS) {
    throw new Error(`invalid_playtest_tape_success_signals:${surface}`);
  }
  const successSignals = value['successSignals'].map((rawSignal, index): AppPlaytestSuccessSignal => {
    if (!isRecord(rawSignal)) {
      throw new Error(`invalid_playtest_tape_success_signal:${surface}:${index}`);
    }
    const kind = typeof rawSignal['kind'] === 'string' ? rawSignal['kind'].trim().toUpperCase() : '';
    const description = typeof rawSignal['description'] === 'string' ? rawSignal['description'].trim() : '';
    if (!SUCCESS_SIGNAL_KINDS.has(kind)) {
      throw new Error(`invalid_playtest_tape_success_signal_kind:${surface}:${index}`);
    }
    if (!description || description.length > 240) {
      throw new Error(`invalid_playtest_tape_success_signal_description:${surface}:${index}`);
    }
    return { kind: kind as AppPlaytestSuccessSignalKind, description };
  });
  if (!Array.isArray(value['events']) || value['events'].length === 0 || value['events'].length > MAX_TAPE_EVENTS) {
    throw new Error(`invalid_playtest_tape_events:${surface}`);
  }
  const events = value['events'].map((event, index) => normalizeEvent(event, surface, durationMs, index));
  const startOnlyEventCount = value['startOnlyEventCount'] === undefined
    ? 0
    : normalizeNonNegativeInteger(value['startOnlyEventCount'], `${surface}:startOnlyEventCount`, events.length);
  for (let index = 1; index < events.length; index += 1) {
    if (events[index]!.atMs < events[index - 1]!.atMs) {
      throw new Error(`playtest_tape_events_not_ordered:${surface}:${index}`);
    }
  }
  const activePointers = new Set<number>();
  const activeKeys = new Set<string>();
  for (let index = 0; index < events.length; index += 1) {
    const event = events[index]!;
    if (event.type === 'tap') {
      if (activePointers.has(0)) {
        throw new Error(`playtest_tape_tap_pointer_active:${surface}:${index}`);
      }
      const tapEndMs = event.atMs + (event.durationMs ?? APP_PLAYTEST_DEFAULT_TAP_DURATION_MS);
      const nextEvent = events[index + 1];
      if (tapEndMs > durationMs || (nextEvent && nextEvent.atMs < tapEndMs)) {
        throw new Error(`playtest_tape_tap_overlaps_next_event:${surface}:${index}`);
      }
      continue;
    }
    if (event.type === 'keyDown' || event.type === 'keyUp') {
      if (event.type === 'keyDown') {
        if (activeKeys.has(event.key)) {
          throw new Error(`playtest_tape_key_already_active:${surface}:${index}:${event.key}`);
        }
        activeKeys.add(event.key);
        continue;
      }
      if (!activeKeys.has(event.key)) {
        throw new Error(`playtest_tape_key_not_active:${surface}:${index}:${event.key}`);
      }
      activeKeys.delete(event.key);
      continue;
    }
    const pointerEvent = event as AppPlaytestPointerEvent;
    const pointerId = pointerEvent.pointerId ?? 0;
    if (pointerEvent.type === 'pointerDown') {
      if (activePointers.has(pointerId)) {
        throw new Error(`playtest_tape_pointer_already_active:${surface}:${index}:${pointerId}`);
      }
      activePointers.add(pointerId);
      continue;
    }
    if (!activePointers.has(pointerId)) {
      throw new Error(`playtest_tape_pointer_not_active:${surface}:${index}:${pointerId}`);
    }
    if (pointerEvent.type === 'pointerUp') {
      activePointers.delete(pointerId);
    }
  }
  if (activePointers.size > 0) {
    throw new Error(`playtest_tape_pointer_left_active:${surface}:${Array.from(activePointers).sort((a, b) => a - b).join(',')}`);
  }
  if (activeKeys.size > 0) {
    throw new Error(`playtest_tape_key_left_active:${surface}:${Array.from(activeKeys).sort().join(',')}`);
  }

  const startOnlyPointers = new Set<number>();
  const startOnlyKeys = new Set<string>();
  for (let index = 0; index < startOnlyEventCount; index += 1) {
    const event = events[index]!;
    if (event.type === 'tap') continue;
    if (event.type === 'keyDown') {
      startOnlyKeys.add(event.key);
      continue;
    }
    if (event.type === 'keyUp') {
      startOnlyKeys.delete(event.key);
      continue;
    }
    const pointerId = 'pointerId' in event ? event.pointerId ?? 0 : 0;
    if (event.type === 'pointerDown') {
      startOnlyPointers.add(pointerId);
    } else if (event.type === 'pointerUp') {
      startOnlyPointers.delete(pointerId);
    }
  }
  if (startOnlyPointers.size > 0 || startOnlyKeys.size > 0) {
    throw new Error(`playtest_tape_start_only_input_left_active:${surface}:${startOnlyEventCount}`);
  }
  return {
    version: APP_PLAYTEST_TAPE_VERSION,
    durationMs,
    startOnlyEventCount,
    successSignals,
    events,
  };
}

export function normalizeAppPlaytestTapes(
  value: unknown,
  options: {
    surfaceTargets?: readonly AppSurface[];
    requireComplete?: boolean;
  } = {},
): NormalizeAppPlaytestTapesResult {
  if (!isRecord(value)) {
    return { ok: false, error: 'invalid_playtest_tapes' };
  }
  try {
    const tapes: AppPlaytestTapes = {};
    for (const [rawSurface, rawTape] of Object.entries(value)) {
      const surface = parseAppSurface(rawSurface);
      if (!surface || !SURFACES.has(surface)) {
        throw new Error(`invalid_playtest_tape_surface:${rawSurface}`);
      }
      tapes[surface] = normalizeTape(rawTape, surface);
    }
    const declaredSurfaces = options.surfaceTargets ? Array.from(new Set(options.surfaceTargets)) : [];
    for (const surface of Object.keys(tapes) as AppSurface[]) {
      if (declaredSurfaces.length > 0 && !declaredSurfaces.includes(surface)) {
        throw new Error(`playtest_tape_surface_not_declared:${surface}`);
      }
    }
    if (options.requireComplete) {
      if (declaredSurfaces.length === 0) {
        throw new Error('playtest_tape_surface_targets_required');
      }
      for (const surface of declaredSurfaces) {
        if (!tapes[surface]) {
          throw new Error(`playtest_tape_missing_for_surface:${surface}`);
        }
      }
    }
    return { ok: true, value: tapes };
  } catch (error) {
    return {
      ok: false,
      error: error instanceof Error ? error.message : 'invalid_playtest_tapes',
    };
  }
}
