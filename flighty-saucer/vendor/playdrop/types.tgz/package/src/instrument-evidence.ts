export const INSTRUMENT_EVIDENCE_NAMES = [
  'first-frame',
  'core',
  'win',
  'loss',
] as const;

export const REQUIRED_INSTRUMENT_EVIDENCE_NAMES = [
  'first-frame',
  'core',
  'loss',
] as const;

export type InstrumentEvidenceName = (typeof INSTRUMENT_EVIDENCE_NAMES)[number];

export type ClaudeChromeScreenshot = {
  screenshotId: string;
  tabId: number;
  toolUseId: string;
  mediaType: 'image/jpeg' | 'image/png';
  dataBase64: string;
  width: number | null;
  height: number | null;
};

export type InstrumentEvidenceCapture = {
  name: InstrumentEvidenceName;
  screenshotId: string;
  tabId: number;
  toolUseId: string;
  mediaType: 'image/jpeg' | 'image/png';
  fileName: string;
  sourceSha256: string;
  sha256: string;
  capturedAt: string;
  url?: string;
};

export type InstrumentEvidenceManifest = {
  version: 1;
  groupId: string;
  controlledTabId: number;
  captures: Partial<Record<InstrumentEvidenceName, InstrumentEvidenceCapture>>;
};

const SCREENSHOT_ID_PATTERN = /^ss_[A-Za-z0-9_-]+$/;
const SCREENSHOT_ID_IN_TEXT_PATTERN = /\bID:\s*(ss_[A-Za-z0-9_-]+)\b/g;
const MAX_STREAM_LINE_LENGTH = 20 * 1024 * 1024;

export const PLAYWRIGHT_MCP_SCREENSHOT_TOOL = 'mcp__playwright__browser_take_screenshot';
export const PLAYWRIGHT_MCP_CONTROLLED_TAB_ID = 1;
// Hard ceiling on screenshots per judge session. A judge evaluates a game; it does not need to
// film it. Exceeding this is an instrument failure, not a score.
export const PLAYWRIGHT_MCP_SCREENSHOT_BUDGET = 100;
// Captures are keyed by the filename the judge passes to the screenshot tool, never by position:
// a screenshot that fails simply produces no id, instead of desynchronizing every id after it.
const PLAYWRIGHT_SCREENSHOT_ID_PATTERN = /^pw-[1-9][0-9]*$/;

export function isInstrumentScreenshotId(value: string): boolean {
  return SCREENSHOT_ID_PATTERN.test(value) || PLAYWRIGHT_SCREENSHOT_ID_PATTERN.test(value);
}



function asRecord(value: unknown): Record<string, unknown> | null {
  return value && typeof value === 'object' && !Array.isArray(value)
    ? value as Record<string, unknown>
    : null;
}

function readPositiveInteger(value: unknown): number | null {
  const parsed = typeof value === 'number' ? value : Number(value);
  return Number.isInteger(parsed) && parsed > 0 ? parsed : null;
}

function collectScreenshotTabIds(toolName: string, input: Record<string, unknown>): number[] {
  if (toolName === 'mcp__claude-in-chrome__computer') {
    const tabId = input['action'] === 'screenshot' ? readPositiveInteger(input['tabId']) : null;
    return tabId === null ? [] : [tabId];
  }
  if (toolName !== 'mcp__claude-in-chrome__browser_batch' || !Array.isArray(input['actions'])) {
    return [];
  }
  const tabIds: number[] = [];
  for (const value of input['actions']) {
    const action = asRecord(value);
    const actionInput = asRecord(action?.['input']);
    if (action?.['name'] !== 'computer' || actionInput?.['action'] !== 'screenshot') {
      continue;
    }
    const tabId = readPositiveInteger(actionInput['tabId']);
    if (tabId !== null) {
      tabIds.push(tabId);
    }
  }
  return tabIds;
}

function readScreenshotDimensions(text: string): { width: number | null; height: number | null } {
  const match = text.match(/captured screenshot \((\d+)x(\d+),\s*(?:jpeg|png)\)/i);
  if (!match) {
    return { width: null, height: null };
  }
  return {
    width: readPositiveInteger(match[1]),
    height: readPositiveInteger(match[2]),
  };
}

export class ClaudeChromeScreenshotStreamParser {
  private buffer = '';
  private readonly screenshotTabsByToolUseId = new Map<string, number[]>();
  private readonly emittedScreenshotIds = new Set<string>();

  constructor(private readonly onScreenshot: (screenshot: ClaudeChromeScreenshot) => void) {}

  push(chunk: string): number {
    if (!chunk) {
      return 0;
    }
    this.buffer += chunk;
    if (this.buffer.length > MAX_STREAM_LINE_LENGTH && !this.buffer.includes('\n')) {
      throw new Error('claude_stream_json_line_too_large');
    }
    let emitted = 0;
    for (;;) {
      const newlineIndex = this.buffer.indexOf('\n');
      if (newlineIndex < 0) {
        break;
      }
      const line = this.buffer.slice(0, newlineIndex);
      this.buffer = this.buffer.slice(newlineIndex + 1);
      emitted += this.processLine(line);
    }
    return emitted;
  }

  finish(): number {
    const line = this.buffer;
    this.buffer = '';
    return line.trim() ? this.processLine(line) : 0;
  }

  private processLine(line: string): number {
    const trimmed = line.trim();
    if (!trimmed) {
      return 0;
    }
    let payload: Record<string, unknown>;
    try {
      const parsed = JSON.parse(trimmed) as unknown;
      const record = asRecord(parsed);
      if (!record) {
        throw new Error('invalid_claude_stream_json');
      }
      payload = record;
    } catch (error) {
      throw new Error(`invalid_claude_stream_json:${error instanceof Error ? error.message : String(error)}`);
    }
    if (payload['type'] === 'assistant') {
      this.recordToolUse(payload);
      return 0;
    }
    if (payload['type'] === 'user') {
      return this.recordToolResults(payload);
    }
    return 0;
  }

  private recordToolUse(payload: Record<string, unknown>): void {
    const message = asRecord(payload['message']);
    const content = Array.isArray(message?.['content']) ? message['content'] : [];
    for (const value of content) {
      const item = asRecord(value);
      const id = typeof item?.['id'] === 'string' ? item['id'].trim() : '';
      const name = typeof item?.['name'] === 'string' ? item['name'].trim() : '';
      const input = asRecord(item?.['input']);
      if (item?.['type'] !== 'tool_use' || !id || !name || !input) {
        continue;
      }
      const tabIds = collectScreenshotTabIds(name, input);
      if (tabIds.length > 0) {
        this.screenshotTabsByToolUseId.set(id, tabIds);
      }
    }
  }

  private recordToolResults(payload: Record<string, unknown>): number {
    const message = asRecord(payload['message']);
    const content = Array.isArray(message?.['content']) ? message['content'] : [];
    let emitted = 0;
    for (const value of content) {
      const toolResult = asRecord(value);
      if (toolResult?.['type'] !== 'tool_result') {
        continue;
      }
      const toolUseId = typeof toolResult['tool_use_id'] === 'string' ? toolResult['tool_use_id'].trim() : '';
      const resultContent = Array.isArray(toolResult['content']) ? toolResult['content'] : [];
      const tabIds = this.screenshotTabsByToolUseId.get(toolUseId) ?? [];
      const screenshotIds: string[] = [];
      let dimensions: { width: number | null; height: number | null } = { width: null, height: null };
      for (const resultValue of resultContent) {
        const resultItem = asRecord(resultValue);
        if (resultItem?.['type'] === 'text' && typeof resultItem['text'] === 'string') {
          const text = resultItem['text'];
          dimensions = readScreenshotDimensions(text);
          for (const match of text.matchAll(SCREENSHOT_ID_IN_TEXT_PATTERN)) {
            const screenshotId = match[1];
            if (screenshotId && SCREENSHOT_ID_PATTERN.test(screenshotId)) {
              screenshotIds.push(screenshotId);
            }
          }
        }
      }
      const images = resultContent
        .map(asRecord)
        .filter((item) => item?.['type'] === 'image');
      for (let imageIndex = 0; imageIndex < images.length; imageIndex += 1) {
        const resultItem = images[imageIndex];
        const screenshotId = screenshotIds[imageIndex];
        if (!screenshotId) {
          continue;
        }
        const source = asRecord(resultItem?.['source']);
        const mediaType = source?.['media_type'];
        const dataBase64 = typeof source?.['data'] === 'string' ? source['data'] : '';
        const tabId = tabIds[imageIndex] ?? null;
        if ((mediaType !== 'image/jpeg' && mediaType !== 'image/png') || !dataBase64) {
          throw new Error(`invalid_claude_screenshot_payload:${screenshotId}`);
        }
        if (tabId === null) {
          throw new Error(`claude_screenshot_tab_attribution_missing:${screenshotId}`);
        }
        if (this.emittedScreenshotIds.has(screenshotId)) {
          continue;
        }
        this.emittedScreenshotIds.add(screenshotId);
        this.onScreenshot({
          screenshotId,
          tabId,
          toolUseId,
          mediaType,
          dataBase64,
          width: dimensions.width,
          height: dimensions.height,
        });
        emitted += 1;
      }
      this.screenshotTabsByToolUseId.delete(toolUseId);
    }
    return emitted;
  }
}

// Parses Claude stream-json for Playwright MCP screenshot tool results. Screenshot ids are
// assigned deterministically in emission order (pw-1, pw-2, ...), so the worker and the server
// derive identical ids from the same immutable transcript, and the judge can reference its Nth
// capture without ever seeing tool-use ids.
export class PlaywrightMcpScreenshotStreamParser {
  private buffer = '';
  private readonly pendingScreenshotToolUseIds = new Set<string>();
  private readonly handledToolUseIds = new Set<string>();
  private screenshotCallCount = 0;
  private sequence = 0;

  constructor(private readonly onScreenshot: (screenshot: ClaudeChromeScreenshot) => void) {}

  push(chunk: string): number {
    if (!chunk) {
      return 0;
    }
    this.buffer += chunk;
    if (this.buffer.length > MAX_STREAM_LINE_LENGTH && !this.buffer.includes('\n')) {
      throw new Error('claude_stream_json_line_too_large');
    }
    let emitted = 0;
    for (;;) {
      const newlineIndex = this.buffer.indexOf('\n');
      if (newlineIndex < 0) {
        break;
      }
      const line = this.buffer.slice(0, newlineIndex);
      this.buffer = this.buffer.slice(newlineIndex + 1);
      emitted += this.processLine(line);
    }
    return emitted;
  }

  finish(): number {
    const line = this.buffer;
    this.buffer = '';
    return line.trim() ? this.processLine(line) : 0;
  }

  private processLine(line: string): number {
    const trimmed = line.trim();
    if (!trimmed) {
      return 0;
    }
    let payload: Record<string, unknown>;
    try {
      const parsed = JSON.parse(trimmed) as unknown;
      const record = asRecord(parsed);
      if (!record) {
        throw new Error('invalid_claude_stream_json');
      }
      payload = record;
    } catch (error) {
      throw new Error(`invalid_claude_stream_json:${error instanceof Error ? error.message : String(error)}`);
    }
    if (payload['type'] === 'assistant') {
      this.recordToolUse(payload);
      return 0;
    }
    if (payload['type'] === 'user') {
      return this.recordToolResults(payload);
    }
    if (payload['type'] === 'item.started') {
      this.recordCodexToolUse(payload);
      return 0;
    }
    if (payload['type'] === 'item.completed') {
      return this.recordCodexToolResult(payload);
    }
    return 0;
  }

  private recordScreenshotToolUse(id: string): void {
    this.screenshotCallCount += 1;
    if (this.screenshotCallCount > PLAYWRIGHT_MCP_SCREENSHOT_BUDGET) {
      throw new Error(`playwright_screenshot_budget_exceeded:${PLAYWRIGHT_MCP_SCREENSHOT_BUDGET}`);
    }
    this.pendingScreenshotToolUseIds.add(id);
  }

  private recordToolUse(payload: Record<string, unknown>): void {
    const message = asRecord(payload['message']);
    const content = Array.isArray(message?.['content']) ? message['content'] : [];
    for (const value of content) {
      const item = asRecord(value);
      const id = typeof item?.['id'] === 'string' ? item['id'].trim() : '';
      const name = typeof item?.['name'] === 'string' ? item['name'].trim() : '';
      if (item?.['type'] !== 'tool_use' || !id || name !== PLAYWRIGHT_MCP_SCREENSHOT_TOOL) {
        continue;
      }
      // NEVER pass `filename` to the screenshot tool: Playwright MCP then saves to disk and
      // returns only a text link, with no image bytes, so the capture cannot be verified against
      // the immutable transcript. Captures are registered here in emission order and the judge
      // persists the one it just took, so it never needs to know an id at all.
      this.recordScreenshotToolUse(id);
    }
  }

  private recordCodexToolUse(payload: Record<string, unknown>): void {
    const item = asRecord(payload['item']);
    const id = typeof item?.['id'] === 'string' ? item['id'].trim() : '';
    if (
      item?.['type'] === 'mcp_tool_call'
      && item['server'] === 'playwright'
      && item['tool'] === 'browser_take_screenshot'
      && id
    ) {
      this.recordScreenshotToolUse(id);
    }
  }

  private recordToolResults(payload: Record<string, unknown>): number {
    const message = asRecord(payload['message']);
    const content = Array.isArray(message?.['content']) ? message['content'] : [];
    let emitted = 0;
    for (const value of content) {
      const toolResult = asRecord(value);
      if (toolResult?.['type'] !== 'tool_result') {
        continue;
      }
      const toolUseId = typeof toolResult['tool_use_id'] === 'string' ? toolResult['tool_use_id'].trim() : '';
      if (!this.pendingScreenshotToolUseIds.has(toolUseId) || this.handledToolUseIds.has(toolUseId)) {
        continue;
      }
      this.handledToolUseIds.add(toolUseId);
      this.pendingScreenshotToolUseIds.delete(toolUseId);
      const resultContent = Array.isArray(toolResult['content']) ? toolResult['content'] : [];
      const images = resultContent
        .map(asRecord)
        .filter((item) => item?.['type'] === 'image');
      if (images.length === 0) {
        // A failed screenshot returns no image: no id is registered, and the ids of every other
        // capture are unaffected because they are names, not positions.
        continue;
      }
      if (images.length > 1) {
        throw new Error(`playwright_screenshot_multiple_images:${toolUseId}`);
      }
      const source = asRecord(images[0]?.['source']);
      const mediaType = source?.['media_type'];
      const dataBase64 = typeof source?.['data'] === 'string' ? source['data'] : '';
      if ((mediaType !== 'image/jpeg' && mediaType !== 'image/png') || !dataBase64) {
        throw new Error(`invalid_playwright_screenshot_payload:${toolUseId}`);
      }
      this.sequence += 1;
      this.onScreenshot({
        screenshotId: `pw-${this.sequence}`,
        tabId: PLAYWRIGHT_MCP_CONTROLLED_TAB_ID,
        toolUseId,
        mediaType,
        dataBase64,
        width: null,
        height: null,
      });
      emitted += 1;
    }
    return emitted;
  }

  private recordCodexToolResult(payload: Record<string, unknown>): number {
    const item = asRecord(payload['item']);
    const toolUseId = typeof item?.['id'] === 'string' ? item['id'].trim() : '';
    if (
      item?.['type'] !== 'mcp_tool_call'
      || item['server'] !== 'playwright'
      || item['tool'] !== 'browser_take_screenshot'
      || !this.pendingScreenshotToolUseIds.has(toolUseId)
      || this.handledToolUseIds.has(toolUseId)
    ) {
      return 0;
    }
    this.handledToolUseIds.add(toolUseId);
    this.pendingScreenshotToolUseIds.delete(toolUseId);
    const result = asRecord(item['result']);
    const content = Array.isArray(result?.['content']) ? result['content'] : [];
    const images = content
      .map(asRecord)
      .filter((contentItem) => contentItem?.['type'] === 'image');
    if (images.length === 0) {
      return 0;
    }
    if (images.length > 1) {
      throw new Error(`playwright_screenshot_multiple_images:${toolUseId}`);
    }
    const mediaType = images[0]?.['mimeType'];
    const dataBase64 = typeof images[0]?.['data'] === 'string' ? images[0]['data'] : '';
    if ((mediaType !== 'image/jpeg' && mediaType !== 'image/png') || !dataBase64) {
      throw new Error(`invalid_playwright_screenshot_payload:${toolUseId}`);
    }
    this.sequence += 1;
    this.onScreenshot({
      screenshotId: `pw-${this.sequence}`,
      tabId: PLAYWRIGHT_MCP_CONTROLLED_TAB_ID,
      toolUseId,
      mediaType,
      dataBase64,
      width: null,
      height: null,
    });
    return 1;
  }
}
