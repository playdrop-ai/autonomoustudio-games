import type { AgentTaskTerminalReason } from './api.js';

export function classifyAgentTaskTerminalReason(
  rawError: string,
  source: AgentTaskTerminalReason['source'],
): AgentTaskTerminalReason {
  const raw = rawError.trim() || 'agent_failure';
  const lower = raw.toLowerCase();
  const candidates = [
    matchFailure(lower, /(upload_validation(?::[a-z0-9_.-]+)?|upload[^\n.!?]{0,80}validat|validat(?:e|ion)[^\n.!?]{0,80}upload|invalid[^\n.!?]{0,80}archive|invalid[^\n.!?]{0,80}catalogue)/, {
      category: 'upload_validation',
      retryable: false,
      source,
      message: 'The uploaded result did not pass validation.',
    }),
    matchFailure(lower, /(instrument_error(?::[a-z0-9_.-]+)?|browser_control|renderer|screenshot|playwright|chrome instrument|waitforselector|(?:native )?listing (?:recorder|capture)|screen[ -]?(?:recording|capture)|capture report|preparing preview|tccs?|stream(?: that)? (?:is )?already stopped)/, {
      category: 'instrument_error',
      retryable: true,
      source: 'instrument',
      message: 'The required browser or capture instrument failed.',
    }),
    matchFailure(lower, /(capacity|overloaded|rate.?limit|too many requests|quota|(?:^|\D)429(?:\D|$))/, {
      category: 'provider_capacity',
      retryable: true,
      source: 'provider',
      message: 'The agent provider had no available capacity.',
    }),
    matchFailure(lower, /(econnreset|econnrefused|connection|network|socket|disconnected|dns|fetch failed)/, {
      category: 'provider_connection',
      retryable: true,
      source: 'provider',
      message: 'The connection to the agent provider was lost.',
    }),
    matchFailure(lower, /(timed? ?out|timeout|deadline exceeded)/, {
      category: 'provider_timeout',
      retryable: true,
      source: 'provider',
      message: 'The agent provider did not finish before the timeout.',
    }),
  ].filter((candidate): candidate is FailureMatch => candidate !== null)
    .sort((a, b) => a.index - b.index);
  const firstSpecificFailure = candidates[0];
  if (firstSpecificFailure) {
    return terminal(
      firstSpecificFailure.category,
      raw,
      firstSpecificFailure.retryable,
      firstSpecificFailure.source,
      firstSpecificFailure.message,
      firstSpecificFailure.code,
    );
  }
  const interrupted = /(worker_shutdown|worker_session_expired|agent_task_stale_running_reaped|lease_expired|signal_|sigterm|sigkill|interrupted)/.test(lower);
  return terminal(
    'agent_failure',
    raw,
    interrupted,
    source,
    interrupted ? 'The agent process was interrupted.' : 'The agent failed to complete the task.',
    interrupted ? 'interrupted_worker_process' : 'agent_failure',
  );
}

type FailureMatch = {
  category: Extract<AgentTaskTerminalReason['category'], 'provider_capacity' | 'provider_connection' | 'provider_timeout' | 'instrument_error' | 'upload_validation'>;
  retryable: boolean;
  source: AgentTaskTerminalReason['source'];
  message: string;
  index: number;
  code: string;
};

function matchFailure(
  raw: string,
  pattern: RegExp,
  failure: Omit<FailureMatch, 'index' | 'code'>,
): FailureMatch | null {
  const match = pattern.exec(raw);
  if (!match) {
    return null;
  }
  const specificCode = /^(?:instrument_error|upload_validation):[a-z0-9_.-]+$/.test(match[0])
    ? match[0]
    : failure.category;
  return {
    ...failure,
    index: match.index,
    code: specificCode,
  };
}

export function queueExpiredTerminalReason(rawError: string): AgentTaskTerminalReason {
  return {
    kind: 'expiration',
    category: 'queue_expired',
    code: rawError.trim() || 'queue_expired',
    message: 'The task expired before a compatible worker could start it.',
    retryable: true,
    rawError: rawError.trim() || null,
    source: 'server',
  };
}

export function cancelledTerminalReason(code = 'cancelled'): AgentTaskTerminalReason {
  return {
    kind: 'cancellation',
    category: 'cancelled',
    code,
    message: 'The task was cancelled.',
    retryable: false,
    rawError: null,
    source: 'server',
  };
}

function terminal(
  category: AgentTaskTerminalReason['category'],
  rawError: string,
  retryable: boolean,
  source: AgentTaskTerminalReason['source'],
  message: string,
  code: string = category,
): AgentTaskTerminalReason {
  return {
    kind: 'failure',
    category,
    code,
    message,
    retryable,
    rawError,
    source,
  };
}
