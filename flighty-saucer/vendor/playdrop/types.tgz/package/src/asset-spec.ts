import type { AppResponse } from './api.js';
import type { AssetResponse } from './asset.js';
import { SEMVER_REGEX } from './version.js';
import ASSET_SPEC_CONTRACT_META_SCHEMA_JSON from './asset-spec-contract-meta-schema.json' with { type: 'json' };

export const ASSET_SPEC_NAME_REGEX = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;
export const ASSET_SPEC_CONTRACT_MAX_BYTES = 256 * 1024;

export const ASSET_SPEC_VISIBILITY_VALUES = ['PRIVATE', 'PUBLIC'] as const;
export type AssetSpecVisibility = (typeof ASSET_SPEC_VISIBILITY_VALUES)[number];

export const ASSET_SPEC_VALIDATION_KIND_VALUES = ['NONE', 'JSON_SCHEMA'] as const;
export type AssetSpecValidationKind = (typeof ASSET_SPEC_VALIDATION_KIND_VALUES)[number];

export const ASSET_VALIDATION_STATUS_VALUES = ['NOT_RUN', 'PASSED', 'FAILED'] as const;
export type AssetValidationStatus = (typeof ASSET_VALIDATION_STATUS_VALUES)[number];

export const ASSET_SPEC_STATUS_VALUES = ['ACTIVE', 'DEPRECATED', 'RETRACTED'] as const;
export type AssetSpecStatus = (typeof ASSET_SPEC_STATUS_VALUES)[number];

export const ASSET_SPEC_CAPABILITY_VALUES = ['READ', 'WRITE', 'EDIT', 'PREVIEW', 'IMPORT'] as const;
export type AssetSpecCapability = (typeof ASSET_SPEC_CAPABILITY_VALUES)[number];

export const ASSET_SPEC_ROLE_MODE_VALUES = ['TEXT', 'BINARY'] as const;
export type AssetSpecRoleMode = (typeof ASSET_SPEC_ROLE_MODE_VALUES)[number];

export const ASSET_SPEC_REFERENCE_TARGET_KIND_VALUES = ['ASSET'] as const;
export type AssetSpecReferenceTargetKind = (typeof ASSET_SPEC_REFERENCE_TARGET_KIND_VALUES)[number];

export const ASSET_SPEC_REFERENCE_CARDINALITY_VALUES = ['ONE', 'MANY'] as const;
export type AssetSpecReferenceCardinality = (typeof ASSET_SPEC_REFERENCE_CARDINALITY_VALUES)[number];

export interface AssetSpecFamilyRef {
  kind: 'asset-spec';
  creatorUsername: string;
  name: string;
}

export interface AssetSpecVersionRef extends AssetSpecFamilyRef {
  version: string;
}

export interface AssetSpecRoleContract {
  name: string;
  required: boolean;
  contentTypes: string[];
  extensions?: string[];
  mode: AssetSpecRoleMode;
  jsonSchema?: Record<string, unknown> | null;
}

export interface AssetSpecReferenceContract {
  name: string;
  required: boolean;
  targetKind: AssetSpecReferenceTargetKind;
  cardinality: AssetSpecReferenceCardinality;
  targetSpec?: string | null;
  versionRange?: string | null;
}

export interface AssetSpecContract {
  primaryRole: string;
  roles: AssetSpecRoleContract[];
  references?: AssetSpecReferenceContract[];
}

export interface AppMetadataAssetSpecSupport {
  assetSpecRef: string;
  versionRange: string;
  capabilities: AssetSpecCapability[];
}

export interface AssetSpecVersionResponse {
  id: number;
  version: string;
  major: number;
  minor: number;
  patch: number;
  visibility: AssetSpecVisibility;
  status: AssetSpecStatus;
  validationKind: AssetSpecValidationKind;
  contractJson: AssetSpecContract | Record<string, unknown>;
  documentationUrl?: string | null;
  validatorUrl?: string | null;
  releaseNotes?: string | null;
  successorVersionRef?: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface AssetSpecResponse {
  id: number;
  name: string;
  displayName: string;
  description?: string | null;
  creatorId: number;
  creatorUsername: string;
  symbolUrl?: string | null;
  currentVersion?: AssetSpecVersionResponse | null;
  currentVersionRef?: string | null;
  status?: AssetSpecStatus | null;
  publicAssetCount: number;
  supportingAppCount: number;
  documentationAvailable: boolean;
  createdAt: string;
  updatedAt: string;
}

export const ASSET_SPEC_LIST_SORT_VALUES = ['recent', 'assets', 'apps', 'alpha'] as const;
export type AssetSpecListSort = (typeof ASSET_SPEC_LIST_SORT_VALUES)[number];

export interface AssetSpecListResponse {
  assetSpecs: AssetSpecResponse[];
  pagination: {
    limit: number;
    offset: number;
    count: number;
    hasMore: boolean;
  };
}

export interface AssetSpecDetailResponse {
  assetSpec: AssetSpecResponse;
}

export interface AssetSpecVersionsListResponse {
  versions: AssetSpecVersionResponse[];
  pagination?: {
    limit: number;
    offset: number;
    count: number;
    hasMore: boolean;
  };
}

export interface AssetSpecAssetsListResponse {
  assetSpec: AssetSpecResponse;
  assets: AssetResponse[];
  pagination: {
    limit: number;
    offset: number;
    count: number;
    hasMore: boolean;
  };
}

export interface AssetSpecAppsListResponse {
  assetSpec: AssetSpecResponse;
  apps: AppResponse[];
  pagination: {
    limit: number;
    offset: number;
    count: number;
    hasMore: boolean;
  };
}

export interface AssetSpecSearchResult {
  kind: 'asset-spec';
  targetPath: string;
  assetSpec: AssetSpecResponse;
}

export interface CreateAssetSpecVersionResponse {
  assetSpec: AssetSpecResponse;
  version: AssetSpecVersionResponse;
}

export interface UpdateAssetSpecVersionResponse {
  assetSpec: AssetSpecResponse;
  version: AssetSpecVersionResponse;
}

export interface DeleteAssetSpecVersionResponse {
  success: boolean;
}

export interface DeleteAssetSpecResponse {
  success: boolean;
}

export const ASSET_SPEC_CONTRACT_META_SCHEMA = ASSET_SPEC_CONTRACT_META_SCHEMA_JSON as Record<string, unknown>;

export function isAssetSpecVisibility(value: unknown): value is AssetSpecVisibility {
  return typeof value === 'string' && (ASSET_SPEC_VISIBILITY_VALUES as readonly string[]).includes(value);
}

export function isAssetSpecValidationKind(value: unknown): value is AssetSpecValidationKind {
  return typeof value === 'string' && (ASSET_SPEC_VALIDATION_KIND_VALUES as readonly string[]).includes(value);
}

export function isAssetValidationStatus(value: unknown): value is AssetValidationStatus {
  return typeof value === 'string' && (ASSET_VALIDATION_STATUS_VALUES as readonly string[]).includes(value);
}

export function isAssetSpecStatus(value: unknown): value is AssetSpecStatus {
  return typeof value === 'string' && (ASSET_SPEC_STATUS_VALUES as readonly string[]).includes(value);
}

export function isAssetSpecCapability(value: unknown): value is AssetSpecCapability {
  return typeof value === 'string' && (ASSET_SPEC_CAPABILITY_VALUES as readonly string[]).includes(value);
}

export function isJsonLikeAssetSpecContentType(value: string): boolean {
  const normalized = value.trim().toLowerCase();
  if (normalized === 'application/json') {
    return true;
  }
  return /^application\/[a-z0-9!#$&^_.+-]+\+json$/i.test(normalized);
}

export function isValidAssetSpecName(value: unknown): value is string {
  return typeof value === 'string' && ASSET_SPEC_NAME_REGEX.test(value.trim());
}

export function parseAssetSpecFamilyRef(raw: string): AssetSpecFamilyRef | null {
  if (typeof raw !== 'string') {
    return null;
  }
  const trimmed = raw.trim();
  if (!trimmed.length) {
    return null;
  }
  const match = /^asset-spec:([^/]+)\/([^@]+)$/i.exec(trimmed);
  if (!match) {
    return null;
  }
  const [, rawCreatorUsername, rawName] = match;
  if (!rawCreatorUsername || !rawName) {
    return null;
  }
  const creatorUsername = rawCreatorUsername.trim();
  const name = rawName.trim();
  if (!creatorUsername.length || !name.length) {
    return null;
  }
  return {
    kind: 'asset-spec',
    creatorUsername,
    name,
  };
}

export function parseAssetSpecVersionRef(raw: string): AssetSpecVersionRef | null {
  if (typeof raw !== 'string') {
    return null;
  }
  const trimmed = raw.trim();
  if (!trimmed.length) {
    return null;
  }
  const match = /^asset-spec:([^/]+)\/([^@]+)@(.+)$/i.exec(trimmed);
  if (!match) {
    return null;
  }
  const [, rawCreatorUsername, rawName, rawVersion] = match;
  if (!rawCreatorUsername || !rawName || !rawVersion) {
    return null;
  }
  const creatorUsername = rawCreatorUsername.trim();
  const name = rawName.trim();
  const version = rawVersion.trim();
  if (!creatorUsername.length || !name.length || !version.length || !SEMVER_REGEX.test(version)) {
    return null;
  }
  return {
    kind: 'asset-spec',
    creatorUsername,
    name,
    version,
  };
}

export function formatAssetSpecFamilyRef(ref: AssetSpecFamilyRef): string {
  return `asset-spec:${ref.creatorUsername}/${ref.name}`;
}

export function formatAssetSpecVersionRef(ref: AssetSpecVersionRef): string {
  return `asset-spec:${ref.creatorUsername}/${ref.name}@${ref.version}`;
}
