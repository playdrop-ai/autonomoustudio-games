export interface CreatorPublicImageSource {
  xProfileImageUrl?: string | null;
  googleProfileImageUrl?: string | null;
  profileAssetPreviewUrl?: string | null;
}

export type CreatorPublicImageKind =
  | "x-profile-image"
  | "google-profile-image"
  | "profile-asset-preview";

export interface CreatorPublicImageCandidate {
  kind: CreatorPublicImageKind;
  url: string;
}

function normalizeUrl(value: string | null | undefined): string | null {
  if (typeof value !== "string") {
    return null;
  }
  const trimmed = value.trim();
  return trimmed.length > 0 ? trimmed : null;
}

export function resolveCreatorPublicImageCandidate(
  profile: CreatorPublicImageSource | null | undefined,
): CreatorPublicImageCandidate | null {
  if (!profile) {
    return null;
  }

  const xProfileImageUrl = normalizeUrl(profile.xProfileImageUrl);
  if (xProfileImageUrl) {
    return {
      kind: "x-profile-image",
      url: xProfileImageUrl,
    };
  }

  const googleProfileImageUrl = normalizeUrl(profile.googleProfileImageUrl);
  if (googleProfileImageUrl) {
    return {
      kind: "google-profile-image",
      url: googleProfileImageUrl,
    };
  }

  const profileAssetPreviewUrl = normalizeUrl(profile.profileAssetPreviewUrl);
  if (profileAssetPreviewUrl) {
    return {
      kind: "profile-asset-preview",
      url: profileAssetPreviewUrl,
    };
  }

  return null;
}

export function resolveCreatorPublicImageUrl(
  profile: CreatorPublicImageSource | null | undefined,
): string | null {
  return resolveCreatorPublicImageCandidate(profile)?.url ?? null;
}
