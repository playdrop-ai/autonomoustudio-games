import type { AppAuthFilter, AppControllerFilter, AppSurfaceFilter } from './app-capability-filters.js';
import type { AppOrigin, AppSurface, AppType } from './app.js';
import type { AppPlaytestTapes } from './app-playtest-tape.js';
import type { AssetPackResponse } from './asset-pack.js';
import type {
  AppMetadataAssetSpecSupport,
  AssetSpecListResponse,
  AssetSpecResponse,
  AssetSpecSearchResult,
  AssetSpecVersionResponse,
  AssetSpecVersionsListResponse,
} from './asset-spec.js';
import type { AssetCategory, AssetResponse } from './asset.js';
import type { ContentLicense, ContentPermissions } from './content-license.js';
import type { InstrumentEvidenceManifest } from './instrument-evidence.js';
import type {
  AppAuthMode,
  AppControllerMode,
  AppHostingMode,
  AppVersionResponse,
  AppVersionSummary,
  AppVersionVisibility,
  ReviewState,
} from './version.js';

// ============================================================================
// API Request Types
// ============================================================================

// Note: description, emoji, color are now per-version (set via version upload)
export interface CreateAppRequest {
  name: string;
  displayName?: string;
  agentTaskId?: number;
  remixRef?: string;
}

// Note: description, emoji, color are now per-version (set via version upload)
export interface UpdateAppRequest {
  displayName?: string;
  type?: AppType;
}

export interface AdminUpdateAppRequest {
  type?: AppType;
}

export interface LoginRequest {
  username: string;
  password: string;
}

export interface RegisterRequest {
  username: string;
  password: string;
  displayName: string;
  inviteCode?: string;
}

export interface RegisterResponse {
  accessToken?: string;
  user: PublicUser;
}

export interface ApiKeyLoginRequest {
  apiKey: string;
}

export interface CliLoginStartResponse {
  requestId: string;
  pollToken: string;
  loginUrl: string;
  expiresAt: string;
  pollIntervalMs: number;
}

export interface CliLoginPollRequest {
  requestId: string;
  pollToken: string;
}

export interface CliLoginPendingResponse {
  status: 'pending';
  expiresAt: string;
}

export type CliLoginPollResponse = LoginResponse | CliLoginPendingResponse;

export interface CliLoginStatusResponse {
  status: 'pending' | 'approved' | 'expired';
  expiresAt: string;
}

export interface CliLoginApproveRequest {
  requestId: string;
}

export interface CliLoginApproveResponse {
  success: boolean;
}

export interface CliWebLaunchStartRequest {
  redirectPath: string;
}

export interface CliWebLaunchStartResponse {
  launchUrl: string;
  expiresAt: string;
}

export interface CliApiKeyStatusResponse {
  hasKey: boolean;
  prefix?: string;
  createdAt?: string;
  lastUsedAt?: string | null;
}

export interface CreateCliApiKeyResponse {
  apiKey: string;
  prefix: string;
  createdAt: string;
}

export interface CliApiTokenSummary {
  id: number;
  name: string;
  prefix: string;
  createdAt: string;
  lastUsedAt: string | null;
}

export interface CliApiTokensResponse {
  tokens: CliApiTokenSummary[];
}

export interface CreateCliApiTokenRequest {
  name: string;
}

export interface CliApiTokenSecretResponse extends CliApiTokenSummary {
  apiKey: string;
}

export interface DeleteCliApiTokenResponse {
  success: true;
}

export interface CreateUserRequest {
  username: string;
  password: string;
  role: 'CREATOR' | 'ADMIN';
}

export interface SetProfileAssetRequest {
  assetRef: string;
}

export interface SetProfileAssetResponse {
  selectedProfileAssetRef: string;
}

export const CREATOR_FUNNEL_EVENT_NAMES = [
  'creator_landed',
  'sign_up',
  'creator_signup_provider_selected',
  'creator_agent_selected',
  'creator_install_prompt_copied',
  'creator_install_prompt_sent',
  'creator_cli_connected',
  'creator_create_unlocked',
  'creator_create_option_selected',
  'creator_agent_prompt_copied',
  'creator_agent_deep_link_retried',
  'creator_game_registered',
  'creator_game_uploaded',
] as const;

export type CreatorFunnelEventName = typeof CREATOR_FUNNEL_EVENT_NAMES[number];

export const CREATOR_FUNNEL_SOURCE_SURFACES = [
  'home',
  'dream_team',
  'create',
  'getting_started',
  'signup',
  'cli',
  'api',
] as const;

export type CreatorFunnelSourceSurface = typeof CREATOR_FUNNEL_SOURCE_SURFACES[number];

export const CREATOR_CREATE_MODES = ['agent', 'scratch', 'guided', 'remix'] as const;

export type CreatorCreateMode = typeof CREATOR_CREATE_MODES[number];

export const CREATOR_FUNNEL_AI_AGENTS = ['CODEX', 'CLAUDE_CODE', 'OTHER'] as const;

export type CreatorFunnelAiAgent = typeof CREATOR_FUNNEL_AI_AGENTS[number];

// ============================================================================
// API Response Types
// ============================================================================

export interface ApiErrorResponse {
  error: string;
  message?: string;
}

export const TAG_SLUG_REGEX = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;

export interface ContentTagSummary {
  ref: string;
  groupSlug: string;
  groupDisplayName: string;
  slug: string;
  displayName: string;
}

export const AGENT_TASK_STATUS_VALUES = ['QUEUED', 'RUNNING', 'DONE', 'FAILED', 'EXPIRED', 'CANCELLED'] as const;
export type AgentTaskStatus = typeof AGENT_TASK_STATUS_VALUES[number];

export type JsonValue =
  | null
  | boolean
  | number
  | string
  | JsonValue[]
  | { [key: string]: JsonValue };

export const AGENT_TASK_CREATOR_FEEDBACK_STATUS_VALUES = ['UNSEEN', 'VIEWED', 'PLAYED', 'APPROVED', 'DISAPPROVED'] as const;
export type AgentTaskCreatorFeedbackStatus = typeof AGENT_TASK_CREATOR_FEEDBACK_STATUS_VALUES[number];

export const AGENT_TASK_KIND_VALUES = ['NEW_GAME', 'REMIX_GAME', 'GAME_UPDATE', 'GAME_REVIEW', 'GAME_EVAL'] as const;
export type AgentTaskKind = typeof AGENT_TASK_KIND_VALUES[number];

export const AGENT_EXECUTION_TARGET_VALUES = ['FIRST_PARTY', 'PERSONAL'] as const;
export type AgentExecutionTarget = typeof AGENT_EXECUTION_TARGET_VALUES[number];

export const AGENT_TASK_SURFACE_SOURCE_CLIENT_VALUES = ['WEB', 'IOS', 'IPADOS', 'MACOS', 'ANDROID', 'WINDOWS', 'UNKNOWN'] as const;
export type AgentTaskSurfaceSourceClient = typeof AGENT_TASK_SURFACE_SOURCE_CLIENT_VALUES[number];

export const AGENT_TASK_SURFACE_DEVICE_CLASS_VALUES = ['PHONE', 'TABLET', 'DESKTOP', 'UNKNOWN'] as const;
export type AgentTaskSurfaceDeviceClass = typeof AGENT_TASK_SURFACE_DEVICE_CLASS_VALUES[number];

export const AGENT_TASK_SURFACE_ORIENTATION_VALUES = ['PORTRAIT', 'LANDSCAPE', 'UNKNOWN'] as const;
export type AgentTaskSurfaceOrientation = typeof AGENT_TASK_SURFACE_ORIENTATION_VALUES[number];

export interface AgentTaskSurfaceContextRequest {
  deviceClass?: AgentTaskSurfaceDeviceClass;
  orientation?: AgentTaskSurfaceOrientation;
}

export interface AgentTaskSurfaceContext extends AgentTaskSurfaceContextRequest {
  sourceClient: AgentTaskSurfaceSourceClient;
  deviceClass: AgentTaskSurfaceDeviceClass;
  orientation: AgentTaskSurfaceOrientation;
}

export const GAME_CREATION_SOURCE_VALUES = ['playdrop_cloud', 'my_agent', 'direct_upload'] as const;
export type GameCreationSource = typeof GAME_CREATION_SOURCE_VALUES[number];

export const GAME_CREATION_SOURCE_LABELS: Record<GameCreationSource, string> = {
  playdrop_cloud: 'PlayDrop Cloud',
  my_agent: 'My Agent',
  direct_upload: 'Direct Upload',
};

export const AGENT_TASK_PROMPT_MIN_LENGTH = 4;
export const AGENT_TASK_PROMPT_MAX_LENGTH = 100_000;

export const AGENT_RUNTIME_VALUES = ['CODEX', 'CLAUDE_CODE', 'CURSOR_COMPOSER'] as const;
export type AgentRuntime = typeof AGENT_RUNTIME_VALUES[number];

export function normalizeAgentTaskModel(_agent: AgentRuntime, model: string): string | null {
  const normalized = model.trim();
  if (!normalized || normalized.length > 120 || /\s/.test(normalized)) {
    return null;
  }
  return normalized;
}

export const AGENT_TASK_EFFORT_VALUES = ['simple', 'standard', 'complex'] as const;
export type AgentTaskEffort = typeof AGENT_TASK_EFFORT_VALUES[number];

export const AGENT_TASK_EFFORT_KIND_VALUES = ['BUILD_COMPLEXITY', 'CHANGE_MAGNITUDE', 'REVIEW_DEPTH'] as const;
export type AgentTaskEffortKind = typeof AGENT_TASK_EFFORT_KIND_VALUES[number];

export const AGENT_WORKER_LIFECYCLE_STATE_VALUES = ['READY', 'QUIESCING', 'UPDATING', 'DEGRADED', 'STOPPED'] as const;
export type AgentWorkerLifecycleState = typeof AGENT_WORKER_LIFECYCLE_STATE_VALUES[number];

export const AGENT_WORKER_UPDATE_STATE_VALUES = [
  'CURRENT',
  'UPDATE_AVAILABLE',
  'UPDATE_REQUIRED',
  'UPDATING',
  'UPDATE_BLOCKED',
] as const;
export type AgentWorkerUpdateState = typeof AGENT_WORKER_UPDATE_STATE_VALUES[number];

export const AGENT_TASK_AVAILABILITY_FAILURE_REASON_VALUES = [
  'agent_not_installed',
  'agent_not_authenticated',
  'agent_quota_exhausted',
  'agent_temporarily_unavailable',
  'unavailable_runtime',
  'agent_model_unsupported',
  'worker_capability_missing',
] as const;
export type AgentAvailabilityFailureReason = typeof AGENT_TASK_AVAILABILITY_FAILURE_REASON_VALUES[number];

export interface AgentAttemptOption {
  agent: AgentRuntime;
  model: string;
  reasoningEffort?: string | null;
}

export interface AgentAttemptPlan {
  options: AgentAttemptOption[];
}

export interface AgentAttemptResult {
  attemptIndex: number;
  agent: AgentRuntime;
  model: string;
  reasoningEffort?: string | null;
  status: 'selected' | 'unavailable' | 'started' | 'completed' | 'failed';
  reason?: AgentAvailabilityFailureReason | string | null;
  message?: string | null;
  recordedAt: string;
}

export interface AgentTaskAgentPreference extends AgentAttemptOption {
  reason?: string | null;
}

export const AGENT_TASK_EVENT_KIND_VALUES = ['progress', 'agent_message', 'system', 'catalogue_preview'] as const;
export type AgentTaskEventKind = typeof AGENT_TASK_EVENT_KIND_VALUES[number];

export const AGENT_TASK_TRANSCRIPT_STREAM_VALUES = ['stdout', 'stderr', 'combined'] as const;
export type AgentTaskTranscriptStream = typeof AGENT_TASK_TRANSCRIPT_STREAM_VALUES[number];

export interface AgentWorkerCapabilities {
  supportedKinds: AgentTaskKind[];
  maxParallelTasks: number;
  runningTaskCount: number;
  cliVersion?: string;
  codexVersion?: string;
  nodeVersion?: string;
  npmVersion?: string;
  playwright?: {
    version?: string;
    chromiumInstalled?: boolean;
  };
  agents: Array<{
    agent: AgentRuntime;
    cliVersion?: string;
    authenticated?: boolean;
    models?: string[];
    acceptsCustomModels?: boolean;
    ready?: boolean;
  }>;
  ready?: boolean;
  degradedReasons?: string[];
  wrapperContractVersion?: number;
  targetUpdateFailure?: AgentWorkerTargetUpdateFailure;
  os?: string;
  arch?: string;
  [key: string]: unknown;
}

export interface AgentWorkerTargetUpdateFailure {
  error: string;
  writtenAt: string;
  targetCliVersion?: string | null;
  minimumCliVersion?: string | null;
}

export interface AgentWorkerLatestUpdateIntentResponse {
  id: number;
  status: string;
  reason: string;
  error?: string | null;
  targetCliVersion?: string | null;
  createdAt: string;
  updatedAt: string;
  completedAt?: string | null;
}

export interface AgentWorkerResponse {
  id: number;
  workerKey: string;
  name: string;
  environment: string;
  capabilities: AgentWorkerCapabilities | null;
  lifecycleState?: AgentWorkerLifecycleState;
  updateState?: AgentWorkerUpdateState;
  ready?: boolean;
  degradedReasons?: string[];
  activeTaskCount?: number;
  cliVersion?: string | null;
  targetCliVersion?: string | null;
  activeUpdateIntentId?: number | null;
  latestUpdateIntent?: AgentWorkerLatestUpdateIntentResponse | null;
  lastSeenAt: string;
  online: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface AgentTaskEnrichmentResponse {
  title: string | null;
  summary: string | null;
  safetyFlags: string[];
}

export interface AgentTaskAgentModelSelection {
  agent: AgentRuntime;
  model: string;
}

export interface AgentTaskAgentModelOption extends AgentTaskAgentModelSelection {
  label: string;
  onlineWorkers: number;
  totalSlots: number;
  runningTasks: number;
  availableSlots: number;
}

export interface AgentTaskTerminalReason {
  kind: 'failure' | 'expiration' | 'cancellation';
  category:
    | 'provider_capacity'
    | 'provider_connection'
    | 'provider_timeout'
    | 'instrument_error'
    | 'upload_validation'
    | 'agent_failure'
    | 'queue_expired'
    | 'cancelled';
  code: string;
  message: string;
  retryable: boolean;
  rawError: string | null;
  source: 'server' | 'worker' | 'agent' | 'provider' | 'instrument';
}

export interface AgentTaskRefundResponse {
  state: 'refunded' | 'withheld';
  credits: number;
  note: string;
}

export interface AgentTaskSubjectResponse {
  creatorUsername: string | null;
  appId: number | null;
  appSlug: string | null;
  appDisplayName: string | null;
  appVersionId: number | null;
  version: string | null;
}

export const AGENT_TASK_NEXT_STEP_CATEGORIES = [
  'POLISH',
  'CONTENT',
  'MECHANICS',
  'VISUALS',
  'AUDIO',
  'MONETIZATION',
  'PUBLISHING',
] as const;

export const AGENT_TASK_NEXT_STEP_ID_REGEX = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;

export type AgentTaskNextStepCategory = typeof AGENT_TASK_NEXT_STEP_CATEGORIES[number];

export interface AgentTaskNextStepSuggestion {
  id: string;
  title: string;
  description: string;
  prompt: string;
  category: AgentTaskNextStepCategory;
}

export interface AgentTaskResponse {
  id: number;
  agentBundleSha?: string | null;
  workerCliVersion: string | null;
  platformReleaseSha: string | null;
  kind: AgentTaskKind;
  status: AgentTaskStatus;
  executionTarget: AgentExecutionTarget;
  agent: AgentRuntime;
  model: string;
  attemptPlan?: AgentAttemptPlan | null;
  selectedAttempt?: AgentAttemptOption | null;
  attemptResults?: AgentAttemptResult[];
  effort: AgentTaskEffort;
  effortKind: AgentTaskEffortKind;
  appOrigin: AppOrigin | null;
  outputVersion: string | null;
  claimedAppName: string | null;
  claimedDisplayName: string | null;
  userInput: string | null;
  enrichment: AgentTaskEnrichmentResponse | null;
  subject: AgentTaskSubjectResponse;
  creatorId?: number;
  creatorUsername?: string | null;
  baseAppId: number | null;
  baseAppVersionId: number | null;
  appId: number | null;
  appVersionId: number | null;
  costCredits: number;
  freeCloudGenerationTransactionId: number | null;
  usesFreeCloudGeneration: boolean;
  refund: AgentTaskRefundResponse | null;
  payload?: {
    safety?: Record<string, unknown>;
    model?: string;
    [key: string]: unknown;
  };
  result: Record<string, unknown> | null;
  completionSummary: string | null;
  nextSteps: AgentTaskNextStepSuggestion[];
  creatorFeedbackStatus: AgentTaskCreatorFeedbackStatus;
  error: string | null;
  terminalReason: AgentTaskTerminalReason | null;
  workerId?: number | null;
  workerName?: string | null;
  lastHeartbeatAt: string | null;
  cancelRequestedAt: string | null;
  attempts: number;
  queuePosition: number | null;
  tokensUsed: number | null;
  latestCataloguePreviewEvent?: AgentTaskEventResponse | null;
  createdAt: string;
  startedAt: string | null;
  completedAt: string | null;
  updatedAt: string;
}

export interface AgentTaskEventResponse {
  id: number;
  taskId: number;
  attempt: number;
  kind: AgentTaskEventKind;
  phase: string | null;
  message: string;
  done?: string | null;
  current?: string | null;
  pct: number | null;
  payload?: Record<string, unknown> | null;
  createdAt: string;
}

export interface AgentTaskTranscriptChunkResponse {
  id: number;
  taskId: number;
  attempt: number;
  sequence: number;
  stream: AgentTaskTranscriptStream;
  content: string;
  workerId: number | null;
  createdAt: string;
}

export interface AgentTaskAttachmentInput {
  id: string;
  fileName: string;
  contentType: string;
  storageKey?: string;
  sizeBytes: number;
  description?: string | null;
}

export interface AgentTaskAttachmentUploadResponse {
  attachment: AgentTaskAttachmentInput;
}

export type AgentTaskInputKind =
  | 'MEDIA'
  | 'GAME_PLAN'
  | 'REFERENCE_GAME'
  | 'REFERENCE_ASSET'
  | 'REFERENCE_PACK';

export type GamePlanQuestionId =
  | 'graphics'
  | 'surface_targets'
  | 'genre'
  | 'theme'
  | 'controls'
  | 'player_goal'
  | 'challenge'
  | 'first_version_scope'
  | 'notes';

export type GamePlanQuestionKind = 'SINGLE_CHOICE' | 'MULTI_CHOICE' | 'TEXT';

export interface GamePlanSelectedOption {
  optionId: string;
  optionLabel: string;
  answer: string;
}

export interface GamePlanAnswerInput {
  questionId: GamePlanQuestionId;
  label: string;
  kind: GamePlanQuestionKind;
  selectedOptions?: GamePlanSelectedOption[];
  answer?: string;
}

export interface AgentTaskInputBase {
  id: string;
  kind: AgentTaskInputKind;
  note?: string | null;
}

export interface AgentTaskMediaInput extends AgentTaskInputBase {
  kind: 'MEDIA';
  media: AgentTaskAttachmentInput;
}

export interface AgentTaskGamePlanInput extends AgentTaskInputBase {
  kind: 'GAME_PLAN';
  gamePlan: {
    answers: GamePlanAnswerInput[];
  };
}

export interface AgentTaskReferenceInput extends AgentTaskInputBase {
  kind: 'REFERENCE_GAME' | 'REFERENCE_ASSET' | 'REFERENCE_PACK';
  reference: {
    ref: string;
    creatorUsername?: string | null;
    name?: string | null;
    version?: string | null;
    displayName?: string | null;
  };
}

export type AgentTaskInput =
  | AgentTaskMediaInput
  | AgentTaskGamePlanInput
  | AgentTaskReferenceInput;

export interface CreateNewGameAgentTaskRequest {
  target: AgentExecutionTarget;
  agent?: AgentRuntime;
  model?: string;
  agentPreference?: AgentTaskAgentPreference;
  prompt: string;
  surfaceContext?: AgentTaskSurfaceContextRequest;
  inputs?: AgentTaskInput[];
  agentBundleSha?: string;
}

export interface CreateNewGameAgentTaskResponse {
  task: AgentTaskResponse;
  events: AgentTaskEventResponse[];
}

export interface CreateRemixGameAgentTaskRequest {
  target: AgentExecutionTarget;
  agent?: AgentRuntime;
  model?: string;
  agentPreference?: AgentTaskAgentPreference;
  prompt: string;
  sourceAppVersionRef: string;
  surfaceContext?: AgentTaskSurfaceContextRequest;
  inputs?: AgentTaskInput[];
  agentBundleSha?: string;
}

export interface CreateRemixGameAgentTaskResponse {
  task: AgentTaskResponse;
  events: AgentTaskEventResponse[];
}

export const GAME_EVAL_MODE_VALUES = ['absolute', 'pairwise', 'n-way'] as const;
export type GameEvalMode = typeof GAME_EVAL_MODE_VALUES[number];

export const GAME_EVAL_DIMENSION_VALUES = [
  'request_fidelity',
  'core_loop_fun',
  'controls',
  'polish',
  'stability',
  'store_listing',
] as const;
export type GameEvalDimension = typeof GAME_EVAL_DIMENSION_VALUES[number];

export interface GameEvalTargetInput {
  appVersionRef: string;
  creatorPrompt: string;
  primarySurface: AppSurface;
}

export interface GameEvalRequirements {
  declaredPrimarySurface?: boolean;
  completePlaytestTapes?: boolean;
}

export interface CreateGameEvalAgentTaskRequest {
  mode: GameEvalMode;
  agent: AgentRuntime;
  model: string;
  judgePromptVersion: string;
  judgeInstructionSha256: string;
  tieBand?: number | null;
  targets: GameEvalTargetInput[];
  requirements?: GameEvalRequirements;
  agentBundleSha?: string;
}

export interface CreateGameEvalAgentTaskResponse {
  task: AgentTaskResponse;
  events: AgentTaskEventResponse[];
}

export interface AgentTaskDetailResponse {
  task: AgentTaskResponse;
}

export interface AgentTaskEventsResponse {
  events: AgentTaskEventResponse[];
}

export interface AgentTasksResponse {
  tasks: AgentTaskResponse[];
  pagination: PaginationMeta;
}

export interface AgentTaskLiveActivityRequest {
  activityId: string;
  pushToken: string;
  apnsEnvironment: ApplePushEnvironment;
}

export interface AgentTaskLiveActivityResponse {
  success: true;
}

export interface CancelAgentTaskResponse {
  task: AgentTaskResponse;
}

export interface ClearAgentTaskResponse {
  taskId: number;
  cleared: true;
}

export interface RetryAgentTaskResponse {
  task: AgentTaskResponse;
  events: AgentTaskEventResponse[];
}

export interface MeAgentWorkersResponse {
  workers: AgentWorkerResponse[];
  updatePolicy: AgentWorkerUpdatePolicyResponse;
}

export interface WorkerPresenceRequest {
  workerKey: string;
  name?: string;
  environment?: string;
  capabilities?: AgentWorkerCapabilities;
  lifecycleState?: AgentWorkerLifecycleState;
  updateState?: AgentWorkerUpdateState;
  ready?: boolean;
  degradedReasons?: string[];
  activeTaskCount?: number;
  cliVersion?: string | null;
  targetCliVersion?: string | null;
  activeUpdateIntentId?: number | null;
}

export interface WorkerPresenceResponse {
  worker: AgentWorkerResponse;
  action?: 'continue' | 'quiesce_for_update';
  updatePolicy?: AgentWorkerUpdatePolicyResponse | null;
}

export interface WorkerClaimTaskRequestV2 {
  protocolVersion: 2;
  workerKey: string;
  capabilities: AgentWorkerCapabilities;
}

export interface WorkerTaskPluginV2 {
  sha256: string;
  fileName: string;
  sizeBytes: number;
  contentBase64: string;
}

export interface WorkerTaskWorkspaceArchiveV2 {
  path: string;
  format: 'zip';
  sha256: string;
  sizeBytes: number;
  contentBase64: string;
}

export interface WorkerTaskWorkspaceFileV2 {
  path: string;
  sha256: string;
  sizeBytes: number;
  contentType: string;
  contentBase64: string;
}

export interface WorkerTaskAttachmentV2 {
  id: string;
  path: string;
  fileName: string;
  contentType: string;
  sizeBytes: number;
  sha256: string;
  description?: string | null;
}

export interface WorkerTaskAssignmentV2 {
  task: {
    id: number;
    token: string;
    type: string;
    executionTarget: AgentExecutionTarget;
    attempt: number;
    metadata: Record<string, JsonValue>;
  };
  workspace: {
    folderName: string;
    archives: WorkerTaskWorkspaceArchiveV2[];
    files: WorkerTaskWorkspaceFileV2[];
  };
  plugin: WorkerTaskPluginV2 | null;
  request: {
    prompt: string;
    attachments: WorkerTaskAttachmentV2[];
  };
  agent: {
    runtime: AgentRuntime;
    model: string;
    reasoningEffort: string | null;
    browser: 'NONE' | 'CHROME' | 'PLAYWRIGHT';
  };
}

export type WorkerClaimTaskResponseV2 =
  | {
      protocolVersion: 2;
      action: 'idle' | 'quiesce_for_update';
      assignment: null;
      lease: null;
      updatePolicy: AgentWorkerUpdatePolicyResponse | null;
    }
  | {
      protocolVersion: 2;
      action: 'run';
      assignment: WorkerTaskAssignmentV2;
      lease: {
        token: string;
        expiresAt: string;
      };
      updatePolicy: AgentWorkerUpdatePolicyResponse | null;
    };

export type WorkerClaimAgentTaskRequest = WorkerClaimTaskRequestV2;
export type WorkerClaimAgentTaskResponse = WorkerClaimTaskResponseV2;

export interface RegisterAgentBundleRequest {
  sha256: string;
  fileName: string;
  contentBase64: string;
}

export interface RegisterAgentBundleResponse {
  created: boolean;
  bundle: {
    sha256: string;
    fileName: string;
    sizeBytes: number;
    registrationSource: 'EVAL';
    createdAt: string;
  };
}

export interface WorkerClaimAgentTaskSlugRequest {
  appName: string;
  displayName: string;
}

export interface WorkerClaimAgentTaskSlugResponse {
  task: AgentTaskResponse;
  appName: string;
  displayName: string;
}

export interface WorkerAgentTaskAttemptUnavailableRequest {
  workerKey: string;
  leaseToken?: string;
  taskToken?: string;
  attemptIndex: number;
  reason: AgentAvailabilityFailureReason;
  message?: string | null;
}

export interface WorkerAgentTaskAttemptUnavailableResponse {
  task: AgentTaskResponse;
  requeued: boolean;
  exhausted: boolean;
  nextAttempt?: AgentAttemptOption | null;
}

export interface AgentWorkerUpdatePolicyResponse {
  executionTarget: AgentExecutionTarget;
  targetCliVersion: string | null;
  minimumCliVersion: string | null;
  requiredWrapperContractVersion: number;
}

export interface WorkerUpdateIntentRequest {
  workerKey: string;
  environment?: string;
  reason?: 'manual_update' | 'setup_apply' | 'server_policy';
}

export interface WorkerUpdateIntentResponse {
  intent: {
    id: number;
    workerId: number;
    status: string;
    reason: string;
    targetCliVersion: string | null;
    createdAt: string;
  };
  worker: AgentWorkerResponse;
  updatePolicy: AgentWorkerUpdatePolicyResponse;
}

export interface WorkerHeartbeatAgentTaskRequest {
  workerKey: string;
  leaseToken: string;
}

export interface WorkerHeartbeatAgentTaskResponse {
  leaseExpiresAt: string;
  action: 'continue' | 'abort';
}

export interface WorkerCreateAgentTaskEventRequest {
  kind?: AgentTaskEventKind;
  phase?: string | null;
  message?: string | null;
  done?: string | null;
  current?: string | null;
  pct?: number | null;
  taskToken?: string;
  workerKey?: string;
  leaseToken?: string;
  payload?: Record<string, unknown>;
}

export interface WorkerCreateAgentTaskEventResponse {
  event: AgentTaskEventResponse;
}

export interface WorkerCreateAgentTaskTranscriptChunkRequest {
  workerKey?: string;
  leaseToken?: string;
  chunks: Array<{
    stream: AgentTaskTranscriptStream;
    content: string;
  }>;
}

export interface WorkerCreateAgentTaskTranscriptChunkResponse {
  chunks: AgentTaskTranscriptChunkResponse[];
}

export interface AgentTaskRunTokenUsageResponse {
  inputTokens: number | null;
  outputTokens: number | null;
  cacheCreationInputTokens: number | null;
  cacheReadInputTokens: number | null;
  totalTokens: number | null;
  rawProviderUsage?: Record<string, unknown> | null;
  usageParseError?: string | null;
}

export interface AgentTaskRunResponse {
  id: number;
  taskId: number;
  attempt: number;
  workerId: number | null;
  creatorId: number;
  workerOwnerId: number;
  agent: AgentRuntime | null;
  requestedModel: string | null;
  resolvedRuntimeModel: string | null;
  reasoningEffort: string | null;
  status: AgentTaskStatus;
  exitCode: number | null;
  signal: string | null;
  timedOut: boolean;
  tokenUsage: AgentTaskRunTokenUsageResponse;
  availableSkillPaths: string[];
  observedSkillPaths: string[];
  terminalReason: AgentTaskTerminalReason | null;
  startedAt: string | null;
  completedAt: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface AgentTaskAiGenerationSummaryResponse {
  generationId: string | null;
  jobId: string | null;
  status: string;
  modality: string;
  model: string | null;
  costCredits: number | null;
  paidBy: string | null;
  paidByUserId: number | null;
  createdAt: string;
  completedAt: string | null;
}

export interface WorkerRecordAgentTaskRunTelemetryRequest {
  workerKey: string;
  leaseToken?: string;
  taskToken?: string;
  attempt: number;
  agent?: AgentRuntime | null;
  requestedModel?: string | null;
  resolvedRuntimeModel?: string | null;
  reasoningEffort?: string | null;
  status: AgentTaskStatus;
  exitCode?: number | null;
  signal?: string | null;
  timedOut?: boolean;
  tokenUsage?: {
    inputTokens?: number | null;
    outputTokens?: number | null;
    cacheCreationInputTokens?: number | null;
    cacheReadInputTokens?: number | null;
    totalTokens?: number | null;
    rawProviderUsage?: Record<string, unknown> | null;
    usageParseError?: string | null;
  };
  availableSkillPaths?: string[];
  observedSkillPaths?: string[];
  startedAt?: string | null;
  completedAt?: string | null;
  terminalReason?: AgentTaskTerminalReason | null;
}

export interface WorkerRecordAgentTaskRunTelemetryResponse {
  run: AgentTaskRunResponse;
  task: AgentTaskResponse;
}

export interface WorkerSubmitAgentTaskReviewRequest {
  taskToken?: string;
  workerKey?: string;
  leaseToken?: string;
  appVersionId: number;
  reviewState: ReviewState;
  reviewMessage: string;
  creatorFeedback: string | null;
  nextSteps?: AgentTaskNextStepSuggestion[];
  evidenceFiles?: Array<{
    name: string;
    contentType: string;
    contentBase64: string;
  }>;
  instrumentEvidence?: InstrumentEvidenceManifest;
}

export interface WorkerSubmitAgentTaskReviewResponse {
  task: AgentTaskResponse;
  version: AppVersionResponse;
}

export interface GameEvalDimensionResult {
  score: number;
  comment: string;
  caps?: string[];
  subChecks?: Record<string, unknown>;
}

export interface GameEvalTargetResult {
  targetId: string;
  overall: number;
  tapeCheck?: {
    surface: AppSurface;
    idleOutcome: string;
    startOnlyOutcome?: string;
    tapeOutcome: string;
    criterion: string;
    passed: boolean;
  };
  replayCheck?: {
    applicable: boolean;
    action: string;
    outcome: string;
    passed: boolean;
  };
  challengeCheck?: {
    claim: string;
    action: string;
    outcome: string;
    passed: boolean;
  };
  readability3DCheck?: {
    applicable: boolean;
    controlledEntity: string;
    objectiveOrHazard: string;
    primaryActionEffect: string;
    passed: boolean;
  };
  dimensions: Record<GameEvalDimension, GameEvalDimensionResult>;
  comments: string;
  evidence?: Record<string, unknown>;
}

export const GAME_EVAL_DEGRADATION_ATTRIBUTION_VALUES = ['instrument', 'game', 'none'] as const;
export type GameEvalDegradationAttribution = typeof GAME_EVAL_DEGRADATION_ATTRIBUTION_VALUES[number];

export interface GameEvalVerdict {
  mode: GameEvalMode;
  judgeAgent: AgentRuntime;
  judgeModel: string;
  judgePromptVersion: string;
  judgeInstructionSha256: string;
  summary: string;
  degradationAttribution?: GameEvalDegradationAttribution;
  degradationReason?: string;
  degradationEvidence?: string[];
  winnerTargetId?: string | null;
  tie?: boolean;
  tieBand?: number | null;
  targets: GameEvalTargetResult[];
}

export interface WorkerSubmitAgentTaskEvalRequest {
  taskToken?: string;
  workerKey?: string;
  leaseToken?: string;
  result: GameEvalVerdict;
  instrumentEvidence?: InstrumentEvidenceManifest[];
  evidenceFiles?: Array<{
    groupId: string;
    name: string;
    contentType: string;
    contentBase64: string;
  }>;
}

export interface WorkerSubmitAgentTaskEvalResponse {
  task: AgentTaskResponse;
  result: GameEvalVerdict;
}

export interface WorkerCompleteAgentTaskRequest {
  taskToken?: string;
  workerKey?: string;
  leaseToken?: string;
  appId: number;
  appVersionId: number;
  result?: Record<string, unknown>;
  summary?: string;
  nextSteps?: AgentTaskNextStepSuggestion[];
  tokensUsed?: number | null;
}

export interface WorkerFailAgentTaskRequest {
  taskToken?: string;
  workerKey?: string;
  leaseToken?: string;
  error: string;
  terminalReason: AgentTaskTerminalReason;
  result?: Record<string, unknown>;
}

export interface AdminAgentTasksResponse {
  tasks: AgentTaskResponse[];
  pagination: PaginationMeta;
}

export interface AdminAgentTaskDetailResponse {
  task: AgentTaskResponse;
  events: AgentTaskEventResponse[];
  runs: AgentTaskRunResponse[];
  aiGenerations: AgentTaskAiGenerationSummaryResponse[];
}

export interface AdminAgentTaskTranscriptResponse {
  chunks: AgentTaskTranscriptChunkResponse[];
}

export interface AdminAgentWorkersStatusResponse {
  checkedAt: string;
  onlineWorkerCount: number;
  onlineWorkers: AgentWorkerResponse[];
  updatePolicies: {
    cloud: AgentWorkerUpdatePolicyResponse;
    personal: AgentWorkerUpdatePolicyResponse;
  };
  playdropCloud: {
    onlineWorkerCount: number;
    runningTaskCount: number;
    maxParallelTaskCount: number;
    busyWorkerCount: number;
    busyPercent: number;
    workers: AgentWorkerResponse[];
  };
  creators: {
    onlineWorkerCount: number;
    runningTaskCount: number;
  };
  queuedTaskCount: number;
  runningTaskCount: number;
  oldestQueuedTaskId: number | null;
  oldestQueuedAgeMs: number | null;
}

export const AGENT_TASK_UNAVAILABLE_REASON_VALUES = [
  'insufficient_credits',
  'active_task_exists',
  'active_task_cap_reached',
  'daily_cap_reached',
  'no_online_worker',
  'app_not_eligible_for_update',
  'first_party_requires_playdrop_cloud_origin',
] as const;
export type AgentTaskUnavailableReason = typeof AGENT_TASK_UNAVAILABLE_REASON_VALUES[number];

export interface AgentTaskTargetAvailability {
  target: AgentExecutionTarget;
  available: boolean;
  reason: AgentTaskUnavailableReason | null;
  priceCredits: number;
  effectivePriceCredits: number;
  usesFreeCloudGeneration: boolean;
  onlineWorkers: AgentWorkerResponse[];
  agentModels: AgentTaskAgentModelOption[];
  attemptPlan: AgentAttemptPlan;
}

export interface AgentTaskAvailabilityResponse {
  kind: AgentTaskKind;
  creditBalance: number;
  freeCloudGenerationBalance: number;
  activeTaskCount: number;
  activeTaskCap: number;
  dailyTaskCount: number;
  dailyTaskCap: number;
  targets: AgentTaskTargetAvailability[];
  appOrigin?: AppOrigin | null;
  pendingOutputVersion?: string | null;
  latestCataloguePreviewEvent?: AgentTaskEventResponse | null;
}

export interface AgentTaskNewGameSuggestion {
  id: string;
  prompt: string;
}

export interface AgentTaskNewGameSuggestionsResponse {
  suggestions: AgentTaskNewGameSuggestion[];
}

export interface CreateAppAgentTaskRequest {
  target: AgentExecutionTarget;
  agent?: AgentRuntime;
  model?: string;
  agentPreference?: AgentTaskAgentPreference;
  prompt: string;
  surfaceContext?: AgentTaskSurfaceContextRequest;
  inputs?: AgentTaskInput[];
  agentBundleSha?: string;
}

export interface CreateAppAgentTaskResponse {
  task: AgentTaskResponse;
  events: AgentTaskEventResponse[];
}

export interface AppAgentTaskResponse {
  task: AgentTaskResponse | null;
  events: AgentTaskEventResponse[];
}

export type CreatorGameState =
  | 'CREATING'
  | 'FAILED_CREATE'
  | 'DRAFT'
  | 'LIVE'
  | 'LIVE_WITH_DRAFT'
  | 'UPDATING'
  | 'FAILED_UPDATE';

export type CreatorGameActionKind =
  | 'notify'
  | 'publish'
  | 'share'
  | 'play'
  | 'edit'
  | 'retry'
  | 'cancel'
  | 'delete'
  | 'history';

export interface CreatorGameAction {
  kind: CreatorGameActionKind;
  enabled: boolean;
  label: string;
}

export interface CreatorGameListItem {
  id: string;
  state: CreatorGameState;
  app: AppResponse | null;
  latestVersion: AppVersionSummary | null;
  latestTask: AgentTaskResponse | null;
  preview: AgentTaskEventResponse | null;
  title: string;
  description?: string | null;
  heroImageUrl?: string | null;
  emoji?: string | null;
  color?: string | null;
  draftPlayed: boolean;
  primaryAction: 'open' | 'retry' | 'cancel' | 'play' | 'publish' | 'share';
  actions: CreatorGameAction[];
}

export interface CreatorGamesListResponse {
  items: CreatorGameListItem[];
  pagination: PaginationMeta;
}

export interface CreatorGameStatusResponse {
  item: CreatorGameListItem;
  currentVersion: AppVersionSummary | null;
  draftVersion: AppVersionSummary | null;
  activeOrLatestTask: AgentTaskResponse | null;
  events: AgentTaskEventResponse[];
  updateBaseVersion: AppVersionSummary | null;
  availability: AgentTaskAvailabilityResponse | null;
}

export interface CreatorGameVersionsResponse {
  item: CreatorGameListItem;
  versions: AppVersionSummary[];
  tasks: AgentTaskResponse[];
}

export interface CreatorGameShareResponse {
  success: true;
  objectiveSummary: FreeCreditObjectiveSummary;
  unclaimedCount: number;
}

export interface CreatorGameCreatorFeedbackStatusRequest {
  appVersionId: number;
  creatorFeedbackStatus: AgentTaskCreatorFeedbackStatus;
}

export interface CreatorGameCreatorFeedbackStatusResponse {
  success: true;
  creatorFeedbackStatus: AgentTaskCreatorFeedbackStatus;
  draftPlayed: boolean;
}


export interface TagGroupSummary {
  slug: string;
  displayName: string;
  allowedTargetKinds: SavedItemKind[];
  createdAt: string;
  updatedAt: string;
}

export interface TagSummary extends ContentTagSummary {
  createdAt: string;
  updatedAt: string;
}

export interface TagGroupWithTagsSummary extends TagGroupSummary {
  tags: TagSummary[];
}

export interface AppResponse {
  id?: number;
  name: string;
  displayName: string;
  description: string;
  creatorId?: number;
  creatorUsername: string;
  createdAt: string;
  updatedAt: string;
  origin?: AppOrigin;
  type: AppType;
  emoji?: string | null;
  color?: string | null;
  lastPlayedAt?: string;

  // Version info (from currentVersion)
  /** Current version string (e.g., "1.2.3"), null if no versions exist */
  currentVersion?: string | null;
  /** Hosting mode of current version */
  hostingMode?: AppHostingMode;
  /** Auth mode of current version */
  authMode?: AppAuthMode;
  /** Controller mode of current version */
  controllerMode?: AppControllerMode;
  /** Whether the current hosted version can boot as a non-interactive detail-page preview */
  previewable?: boolean;
  /** Visibility of current version */
  visibility?: AppVersionVisibility;
  /** Review state of current version */
  reviewState?: ReviewState;
  reviewStartedAt?: string | null;
  reviewCompletedAt?: string | null;
  /** License of the current version */
  license?: ContentLicense;
  /** Server-derived capability flags for the current version */
  permissions?: ContentPermissions;
  /** Base URL for loading the app (from current version) */
  assetUrl: string | null;
  /** Entry point file within assetUrl */
  entryPoint?: string | null;
  /** Surface targets from current version (undefined for draft apps with no version) */
  surfaceTargets?: AppSurface[];
  primarySurface?: AppSurface | null;
  playtestTapes?: AppPlaytestTapes | null;
  /** Asset spec support declarations from the current version */
  assetSpecSupport?: AppMetadataAssetSpecSupport[];

  // HOSTED mode fields (from current version)
  bundleSize?: number | null;
  sourceUrl?: string | null;

  // Listing URLs (from current version)
  iconUrl?: string | null;
  heroPortraitUrl?: string | null;
  heroLandscapeUrl?: string | null;
  socialLandscapeUrl?: string | null;
  screenshotPortraitUrls?: string[];
  screenshotLandscapeUrls?: string[];
  videoPortraitUrls?: string[];
  videoLandscapeUrls?: string[];
  viewerSaved?: boolean;
  viewerLiked?: boolean;
  viewerDisliked?: boolean;
  likeCount?: number;
  dislikeCount?: number;
  viewCount?: number;
  playCount?: number;
  commentCount?: number;
  remixCount?: number;
  remixedFrom?: RemixRelatedItemSummary[];
  boostedUntil?: string | null;
  promotionSource?: string | null;
  promotionToken?: string | null;
  tags: ContentTagSummary[];
}

export type AdminAppResponse = AppResponse;

export interface AdminAppsListResponse {
  apps: AdminAppResponse[];
}

export const PLATFORM_ANALYTICS_CLIENT_SURFACE_VALUES = [
  'web_desktop',
  'web_mobile',
  'native_ios',
  'native_macos',
  'native_android',
  'native_windows',
  'cli',
  'admin',
] as const;

export type PlatformAnalyticsClientSurface = typeof PLATFORM_ANALYTICS_CLIENT_SURFACE_VALUES[number];

export interface AdminPlatformAnalyticsDailyBucket {
  dateUtc: string;
  newAccounts: number;
  dau: number;
  cliPaired: number;
  gamesRegistered: number;
  gamesUploaded: number;
  aiGenerations: number;
  gamesPlayed: number;
  adsDisplayed: number;
}

export interface AdminPlatformAnalyticsTotals {
  newAccounts: number;
  activeUsers: number;
  cliPaired: number;
  gamesRegistered: number;
  gamesUploaded: number;
  aiGenerations: number;
  gamesPlayed: number;
  adsDisplayed: number;
}

export interface AdminPlatformAnalyticsDailySeriesPoint {
  dateUtc: string;
  count: number;
}

export interface AdminPlatformAnalyticsAiModalityDailyPoint extends AdminPlatformAnalyticsDailySeriesPoint {
  modality: string;
}

export interface AdminPlatformAnalyticsAdFormatDailyPoint extends AdminPlatformAnalyticsDailySeriesPoint {
  format: string;
}

export interface AdminPlatformAnalyticsCreationSourceSummary {
  source: GameCreationSource;
  label: string;
  gamesRegistered: number;
  gamesUploaded: number;
  tasksCreated: number;
  tasksDone: number;
  tasksFailed: number;
  creditsSpent: number;
  tokensUsed: number;
  averageQueueSeconds: number | null;
  averageRunSeconds: number | null;
}

export interface AdminPlatformAnalyticsCreationSourceDailyPoint {
  dateUtc: string;
  source: GameCreationSource;
  label: string;
  gamesRegistered: number;
  gamesUploaded: number;
  tasksCreated: number;
  tasksDone: number;
  tasksFailed: number;
}

export interface AdminPlatformAnalyticsReviewQualitySourceSummary {
  source: GameCreationSource;
  label: string;
  reviewedVersions: number;
  reviewStateCounts: Partial<Record<ReviewState, number>>;
  averageParsedQualityScore: number | null;
  scoreParseErrorCount: number;
}

export interface AdminPlatformAnalyticsClientSurfaceDailyPoint {
  dateUtc: string;
  clientSurface: PlatformAnalyticsClientSurface;
  activeUsers: number;
  eventCount: number;
}

export type AdminPlatformAnalyticsRequest =
  | {
      days?: 7 | 30 | 90;
      fromDateUtc?: never;
      toDateUtc?: never;
    }
  | {
      days?: never;
      fromDateUtc: string;
      toDateUtc: string;
    };

export interface AdminPlatformAnalyticsResponse {
  days: number;
  fromDateUtc: string;
  toDateUtc: string;
  currentDau: number;
  averageDau: number;
  totals: AdminPlatformAnalyticsTotals;
  daily: AdminPlatformAnalyticsDailyBucket[];
  aiGenerationsByModality: Array<{ modality: string; count: number }>;
  aiGenerationsByModalityDaily: AdminPlatformAnalyticsAiModalityDailyPoint[];
  adsByFormat: Array<{ format: string; count: number }>;
  adsByFormatDaily: AdminPlatformAnalyticsAdFormatDailyPoint[];
  creationSources: AdminPlatformAnalyticsCreationSourceSummary[];
  creationSourcesDaily: AdminPlatformAnalyticsCreationSourceDailyPoint[];
  reviewQualitySources: AdminPlatformAnalyticsReviewQualitySourceSummary[];
  clientSurfaces: Array<{
    clientSurface: PlatformAnalyticsClientSurface;
    activeUsers: number;
    eventCount: number;
  }>;
  clientSurfacesDaily: AdminPlatformAnalyticsClientSurfaceDailyPoint[];
}

export interface AdminGameCollectionSummary {
  id: number;
  slug: string;
  displayName: string;
  description: string | null;
  iconUrl: string | null;
  gameCount: number;
  createdAt: string;
  updatedAt: string;
}

export interface AdminGameCollectionGame {
  id: number;
  name: string;
  displayName: string;
  creatorUsername: string;
  iconUrl: string | null;
  publishedAt: string | null;
}

export interface AdminGameCollectionDetail extends AdminGameCollectionSummary {
  games: AdminGameCollectionGame[];
}

export interface AdminGameCollectionsResponse {
  collections: AdminGameCollectionSummary[];
}

export interface AdminGameCollectionResponse {
  collection: AdminGameCollectionDetail;
}

export interface AdminGameCollectionCandidatesResponse {
  games: AdminGameCollectionGame[];
}

export interface CreateAdminGameCollectionRequest {
  slug: string;
  displayName: string;
  description?: string | null;
}

export interface UpdateAdminGameCollectionRequest {
  displayName?: string;
  description?: string | null;
}

export interface UpdateAdminGameCollectionGamesRequest {
  appIds: number[];
}

export interface DeleteAdminGameCollectionResponse {
  success: boolean;
}

export interface PublicUser {
  id: number;
  username: string;
  displayName: string;
  role: 'CREATOR' | 'ADMIN';
  selectedProfileAssetRef: string;
  profileAssetPreviewUrl: string;
  socialImageUrl: string | null;
  bio: string | null;
  youtubeUsername: string | null;
  githubUsername: string | null;
  websiteUrl: string | null;
  supportUrl: string | null;
  xUsername: string | null;
  xProfileImageUrl: string | null;
  googleEmail: string | null;
  googleProfileImageUrl: string | null;
  appleLinked?: boolean;
  appleEmail?: string | null;
  followerCount: number;
  followingCount: number;
  viewerFollowing?: boolean;
  viewerBlocked?: boolean;
  followsViewer?: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface MeUser extends PublicUser {
  creditBalance: number;
  freeCloudGenerationBalance: number;
  ownedAssetsCount: number;
  hasPassword: boolean;
  followingCreatorsCount: number;
  unreadNotificationsCount: number;
  unclaimedFreeCreditCount: number;
  creatorQuota?: CreatorQuotaResponse | null;
  preferredAiAgent: 'CODEX' | 'CLAUDE_CODE' | 'OTHER' | null;
}

export interface InviteUserSummary {
  id: number;
  username: string;
  displayName: string;
  profileAssetPreviewUrl: string | null;
  viewerFollowing?: boolean;
  followsViewer?: boolean;
}

export interface CreatorQuotaLimitsResponse {
  maxAppsPerCreator: number;
  maxAssetPacksPerCreator: number;
  maxAssetsPerCreator: number;
  maxStoredContentBytes: number;
  maxVersionsPerApp: number;
  maxVersionsPerAsset: number;
  maxVersionsPerAssetPack: number;
}

export interface CreatorQuotaUsageResponse {
  appCount: number;
  assetPackCount: number;
  assetCount: number;
  storedContentBytes: number;
}

export interface CreatorQuotaResponse {
  tier: 'CREATOR' | 'ADMIN';
  limits: CreatorQuotaLimitsResponse;
  usage: CreatorQuotaUsageResponse;
}

export type AdminUserDetail = MeUser;

export interface UpdateProfileRequest {
  displayName?: string;
  bio?: string | null;
  youtubeUsername?: string | null;
  githubUsername?: string | null;
  websiteUrl?: string | null;
  supportUrl?: string | null;
  preferredAiAgent?: 'CODEX' | 'CLAUDE_CODE' | 'OTHER' | null;
}

export interface UpdateProfileResponse {
  user: MeUser;
}

export interface ChangePasswordRequest {
  currentPassword?: string;  // Optional: not required when user has no password (OAuth-only)
  newPassword: string;
}

export interface ChangePasswordResponse {
  success: boolean;
}

export interface DeleteMyAccountRequest {
  username: string;
  currentPassword?: string;
}

export interface DeleteMyAccountResponse {
  success: boolean;
}

export type CreatorDeleteBlockingContentKind = 'ASSET_PACK' | 'ASSET' | 'ASSET_SPEC';

export type CreatorDeleteBlockingContentReason =
  | 'asset_pack_in_use'
  | 'asset_in_use'
  | 'asset_spec_in_use'
  | 'asset_spec_has_assets'
  | 'asset_spec_has_versions';

export interface CreatorDeleteBlockingContent {
  kind: CreatorDeleteBlockingContentKind;
  name: string;
  reason: CreatorDeleteBlockingContentReason;
}

export interface CreatorDeleteBlockedResponse extends ApiErrorResponse {
  error: 'creator_delete_blocked';
  message: string;
  blockingContent: CreatorDeleteBlockingContent[];
}

export interface PrivacyExportLinkedAccount {
  provider: 'PASSWORD' | 'GOOGLE' | 'X' | 'APPLE';
  identifier: string | null;
}

export interface PrivacyExportFollowedCreator {
  username: string;
  displayName: string;
  followedAt: string;
  latestPublishedAt: string | null;
}

export interface PrivacyExportSavedItem {
  kind: SavedItemKind;
  creatorUsername: string;
  itemName: string;
  displayName: string;
  savedAt: string;
}

export interface PrivacyExportComment {
  id: number;
  kind: SavedItemKind;
  creatorUsername: string;
  itemName: string;
  parentCommentId: number | null;
  body: string;
  deletedAt: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface PrivacyExportPublishedApp {
  name: string;
  displayName: string;
  type: AppType;
  createdAt: string;
  updatedAt: string;
}

export interface PrivacyExportPublishedAsset {
  name: string;
  displayName: string;
  category: AssetCategory;
  createdAt: string;
  updatedAt: string;
}

export interface PrivacyExportPublishedPack {
  name: string;
  displayName: string;
  createdAt: string;
  updatedAt: string;
}

export interface PrivacyExportAiGenerationJob {
  id: string;
  modality: AiGenerationType;
  status: 'PENDING' | 'RUNNING' | 'SUCCESS' | 'FAILURE';
  requestPrompt: string;
  requestPayload: unknown;
  resultData: unknown;
  errorCode: string | null;
  errorMessage: string | null;
  linkedGenerationId: string | null;
  createdAt: string;
  updatedAt: string;
  startedAt: string | null;
  completedAt: string | null;
  failedAt: string | null;
}

export interface PrivacyExportResponse {
  exportedAt: string;
  account: MeUser;
  linkedAccounts: PrivacyExportLinkedAccount[];
  followedCreators: PrivacyExportFollowedCreator[];
  savedItems: PrivacyExportSavedItem[];
  comments: PrivacyExportComment[];
  notifications: UserNotificationResponse[];
  creditTransactions: CreditTransaction[];
  iapReceipts: IapReceipt[];
  aiActivity: {
    generations: AiGenerationDetail[];
    jobs: PrivacyExportAiGenerationJob[];
  };
  publishedContent: {
    apps: PrivacyExportPublishedApp[];
    assets: PrivacyExportPublishedAsset[];
    packs: PrivacyExportPublishedPack[];
  };
}

export interface UnlinkXResponse {
  success: boolean;
}

export interface UnlinkGoogleResponse {
  success: boolean;
}

export type NativeOAuthProvider = 'google' | 'x' | 'apple';
export type AppleOAuthProvider = NativeOAuthProvider;
export type AppleOAuthTarget =
  | 'apple-playdrop-ios'
  | 'apple-playdrop-mac'
  | 'apple-playdrop-mac-beta'
  | 'apple-playdrop-mac-debug'
  | 'apple-music'
  | 'apple-games';
export type NativeOAuthTarget = AppleOAuthTarget | 'windows-playdrop';

export interface NativeOAuthLinkStartRequest {
  provider: NativeOAuthProvider;
  target?: NativeOAuthTarget;
  appAuthState?: string | null;
}

export type AppleOAuthLinkStartRequest = NativeOAuthLinkStartRequest;

export interface NativeOAuthLinkStartResponse {
  startUrl: string;
}

export type AppleOAuthLinkStartResponse = NativeOAuthLinkStartResponse;

export interface NativeOAuthHandoffExchangeRequest {
  token: string;
}

export type AppleOAuthHandoffExchangeRequest = NativeOAuthHandoffExchangeRequest;
export type NativeOAuthHandoffExchangeResponse = LoginResponse;
export type AppleOAuthHandoffExchangeResponse = LoginResponse;

export interface GoogleAppleSignInRequest {
  idToken: string;
}

export interface GoogleAppleLoginResponse {
  result: 'login';
  accessToken: string;
  user: PublicUser;
}

export interface GoogleAppleSignupResponse {
  result: 'signup';
  pendingToken: string;
}

export type GoogleAppleSignInResponse =
  | GoogleAppleLoginResponse
  | GoogleAppleSignupResponse;

export interface GoogleAppleLinkRequest {
  idToken: string;
}

export interface GoogleAppleLinkResponse {
  success: boolean;
}

export interface AppleNativeChallengeResponse {
  nonce: string;
  challengeToken: string;
}

export interface GooglePendingSignupResponse {
  googleEmail: string;
  googleName: string | null;
  googlePicture: string | null;
  suggestedUsername: string;
  suggestedDisplayName: string;
  usernameAvailable: boolean;
  invitePreview?: InvitePreviewResponse | null;
}

export interface UsernameAvailableResponse {
  available: boolean;
}

export interface CompleteGoogleSignupRequest {
  pendingToken: string;
  username: string;
  displayName: string;
  selectedProfileAssetRef: string;
}

export interface CompleteGoogleSignupResponse {
  accessToken?: string;
  user: PublicUser;
}

export interface XPendingSignupResponse {
  xUsername: string;
  xName: string | null;
  xProfileImageUrl: string | null;
  suggestedUsername: string;
  suggestedDisplayName: string;
  usernameAvailable: boolean;
  invitePreview?: InvitePreviewResponse | null;
}

export interface CompleteXSignupRequest {
  pendingToken: string;
  username: string;
  displayName: string;
  selectedProfileAssetRef: string;
}

export interface CompleteXSignupResponse {
  accessToken?: string;
  user: PublicUser;
}

export interface AppleSignInRequest {
  identityToken: string;
  challengeToken: string;
  fullName?: string | null;
}

export interface AppleLoginResponse {
  result: 'login';
  accessToken: string;
  user: PublicUser;
}

export interface AppleSignupResponse {
  result: 'signup';
  pendingToken: string;
}

export type AppleSignInResponse =
  | AppleLoginResponse
  | AppleSignupResponse;

export interface AppleLinkRequest {
  identityToken: string;
  challengeToken: string;
}

export interface AppleLinkResponse {
  success: boolean;
}

export interface ApplePendingSignupResponse {
  appleEmail: string | null;
  appleEmailIsPrivate: boolean;
  suggestedUsername: string;
  suggestedDisplayName: string;
  usernameAvailable: boolean;
  invitePreview?: InvitePreviewResponse | null;
}

export interface CompleteAppleSignupRequest {
  pendingToken: string;
  username: string;
  displayName: string;
  selectedProfileAssetRef: string;
}

export interface CompleteAppleSignupResponse {
  accessToken?: string;
  user: PublicUser;
}

export interface GoogleOneTapExchangeRequest {
  credential: string;
  nextPath?: string | null;
}

export interface GoogleOneTapLoginResponse {
  result: 'login';
  accessToken?: string;
  user: PublicUser;
}

export interface GoogleOneTapSignupResponse {
  result: 'signup';
  pendingToken: string;
}

export type GoogleOneTapExchangeResponse =
  | GoogleOneTapLoginResponse
  | GoogleOneTapSignupResponse;

export type UserResponse = PublicUser;

// ============================================================================
// API Response Wrappers
// ============================================================================

export interface AppsListResponse {
  apps: AppResponse[];
  pagination?: PaginationMeta;
}

export interface AppRuntimeAssetFileSummary {
  role: string;
  url: string;
  contentType?: string | null;
  sizeBytes?: number | null;
  sha256?: string | null;
}

export interface AppRuntimeAssetSummary {
  assetRef: string;
  runtimeKey: string | null;
  sourceType: 'OWNED' | 'DIRECT' | 'PACK';
  sourcePackRef?: string | null;
  files: AppRuntimeAssetFileSummary[];
}

export interface ResolveRuntimeAssetsRequest {
  assets: Array<{
    ref: string;
    runtimeKey: string | null;
  }>;
  packs: string[];
}

export interface ResolvedRuntimeAsset extends AppRuntimeAssetSummary {
  assetSpecVersionRef: string | null;
}

export interface ResolveRuntimeAssetsResponse {
  assets: ResolvedRuntimeAsset[];
}

export interface AppRuntimeAssetsResponse {
  appVersionId: number;
  appVersion: string;
  assets: AppRuntimeAssetSummary[];
}

export interface AppOwnedAssetSummary {
  assetRef: string;
  runtimeKey: string | null;
  creatorUsername: string;
  name: string;
  displayName: string | null;
}

export interface AppDirectAssetSummary {
  assetRef: string;
  runtimeKey: string | null;
  creatorUsername: string;
  name: string;
  displayName: string | null;
}

export interface AppPackDependencySummary {
  packRef: string;
  creatorUsername: string;
  name: string;
  displayName: string | null;
}

export interface AppDependencySummary {
  ownedAssets: AppOwnedAssetSummary[];
  directAssets: AppDirectAssetSummary[];
  packs: AppPackDependencySummary[];
}

export interface AppDetailRequest {
  includeDependencies?: boolean;
}

export interface AppDetailResponse {
  app: AppResponse;
  dependencies?: AppDependencySummary;
}

export const APP_MORE_COLLECTION_KEYS = [
  'by-creator',
  'similar',
  'remixes',
  'contains',
  'uses',
] as const;

export type AppMoreCollectionKey = (typeof APP_MORE_COLLECTION_KEYS)[number];

export type AppMoreItem =
  | {
      kind: 'APP';
      app: AppResponse;
    }
  | {
      kind: 'ASSET';
      asset: AssetResponse;
    }
  | {
      kind: 'PACK';
      pack: AssetPackResponse;
    };

export interface AppMoreCollectionsRequest {
  limit?: number;
}

export interface AppMoreCollectionRequest extends AppMoreCollectionsRequest {
  offset?: number;
}

export interface AppMoreCollectionPage {
  key: AppMoreCollectionKey;
  items: AppMoreItem[];
  pagination: PaginationMeta;
}

export interface AppMoreCollectionsResponse {
  collections: AppMoreCollectionPage[];
}

type RemixRelatedItemSummaryBase = {
  creatorUsername: string;
  name: string;
  displayName: string | null;
  linkedVersionRef: string | null;
};

export type RemixRelatedItemSummary =
  | ({
      kind: 'APP';
      appType: AppType;
    } & RemixRelatedItemSummaryBase)
  | ({
      kind: 'ASSET';
    } & RemixRelatedItemSummaryBase)
  | ({
      kind: 'PACK';
    } & RemixRelatedItemSummaryBase);

export interface ContentRemixRelationsResponse {
  remixedFrom: RemixRelatedItemSummary[];
  remixedBy: RemixRelatedItemSummary[];
}

export interface AppAccessTokenResponse {
  appAccessToken: string;
  appId: number;
  sessionId: string;
}

export interface ReviewerAppAccessTokenResponse extends AppAccessTokenResponse {
  player: {
    id: number;
    username: string;
    displayName: string;
    reviewer: true;
  };
}

export interface CaptureAppAccessTokenResponse extends AppAccessTokenResponse {
  player: {
    id: number;
    username: string;
    displayName: string;
    capture: true;
  };
}

export interface DevPlayerSummary {
  userId: number;
  slot: number;
  username: string;
  displayName: string;
  userKind: 'TEST';
  ownerUserId: number;
  ownerUsername: string;
}

export interface DevAppAccessTokenResponse extends AppAccessTokenResponse {
  player: DevPlayerSummary;
}

export interface DevPlayerResetResponse {
  resetAll: boolean;
  playerSlots: number[];
  deletedAppDataCount: number;
  deletedAchievementCount: number;
  deletedLeaderboardScoreCount: number;
  deletedIapReceiptCount: number;
}

export type LogSeverity = 'debug' | 'info' | 'warn' | 'error';

export interface AppLogEntryContext {
  appName?: string | null;
  creatorUsername?: string | null;
  viewerId?: number | null;
  viewerUsername?: string | null;
}

export interface AppLogEntryRequest {
  severity: LogSeverity;
  message: string;
  payload?: unknown;
  context?: AppLogEntryContext;
}

export interface AppLogEntryResponse {
  success: boolean;
}

export interface CreateAppResponse {
  app: AppResponse;
  templateUrl: string;
  sourceArchiveUrl?: string;
}

export type RemixScaffoldMode = 'archive' | 'inline-html' | 'external-metadata-only';

export interface ExternalRemixScaffoldMetadata {
  name: string;
  displayName: string;
  description: string;
  creatorUsername: string;
  type: AppType;
  emoji: string | null;
  color: string | null;
  surfaceTargets: AppSurface[];
}

export interface ArchiveRemixScaffoldResponse {
  remixMode: 'archive';
  html?: string | null;
  metadata?: Record<string, unknown>;
  archiveUrl: string;
  externalListingUrl?: string;
}

export interface InlineHtmlRemixScaffoldResponse {
  remixMode: 'inline-html';
  html: string;
  metadata?: Record<string, unknown>;
  archiveUrl?: string;
  externalListingUrl?: string;
}

export interface ExternalMetadataOnlyRemixScaffoldResponse {
  remixMode: 'external-metadata-only';
  html?: string | null;
  metadata: ExternalRemixScaffoldMetadata;
  archiveUrl?: string;
  externalListingUrl: string;
}

export type RemixScaffoldResponse =
  | ArchiveRemixScaffoldResponse
  | InlineHtmlRemixScaffoldResponse
  | ExternalMetadataOnlyRemixScaffoldResponse;

export interface TemplateScaffoldResponse {
  html: string;
  metadata?: Record<string, unknown>;
  archiveUrl?: string;
}

export interface UploadAppResponse {
  app: AppResponse;
}

export interface UpdateAppResponse {
  app: AppResponse;
  fileUnchanged?: boolean;
  metadataUnchanged?: boolean;
  sourceUnchanged?: boolean;
}

export interface AdminUpdateAppResponse {
  app: AdminAppResponse;
}

export interface AdminAppVersionReviewSummary {
  versionId: number;
  version: string;
  appId: number;
  appName: string;
  appDisplayName: string;
  appType: AppType;
  typeSlug: string;
  creatorId: number;
  creatorUsername: string;
  isCurrent: boolean;
  visibility: AppVersionVisibility;
  source: GameCreationSource;
  sourceLabel: string;
  agentTaskId: number | null;
  reviewTaskId: number | null;
  reviewTaskStatus: AgentTaskStatus | null;
  reviewState: ReviewState;
  reviewMessage?: string | null;
  creatorFeedback?: string | null;
  parsedOutcome: string | null;
  parsedGate: string | null;
  parsedPrimarySurface: string | null;
  parsedAverageScore: number | null;
  parsedCriteriaScores: Record<string, number>;
  parsedPunchline: string | null;
  reviewParseErrors: string[];
  reviewStartedAt?: string | null;
  reviewCompletedAt?: string | null;
  createdAt: string;
  updatedAt: string;
  surfaceTargets: AppSurface[];
  assetUrl: string;
}

export interface AdminAppVersionReviewsListResponse {
  versions: AdminAppVersionReviewSummary[];
}

export interface AdminUpdateAppVersionReviewRequest {
  reviewState?: ReviewState;
  reviewMessage?: string | null;
  creatorFeedback?: string | null;
}

export interface AdminUpdateAppVersionReviewResponse {
  version: AdminAppVersionReviewSummary;
}

export interface AdminEnqueueNextAppVersionReviewTaskResponse {
  version: AdminAppVersionReviewSummary | null;
}

export interface ProfileAssetSummary {
  assetRef: string;
  assetId: number;
  name: string;
  displayName: string;
  previewUrl: string;
  meshUrl: string;
  boxelUrl: string;
}

export interface StarterProfileAssetSummary {
  assetRef: string;
  assetId: number;
  name: string;
  displayName: string;
  previewUrl: string;
}

export interface OwnedProfileAssetsResponse {
  assets: ProfileAssetSummary[];
}

export interface StarterProfileAssetsResponse {
  assets: StarterProfileAssetSummary[];
}

export interface PaginationMeta {
  limit: number;
  offset: number;
  count: number;
  hasMore: boolean;
}

// ============================================================================
// Feedback
// ============================================================================

export const FEEDBACK_CLIENT_VALUES = [
  'cli',
  'web',
  'games-ios',
  'music-ios',
  'games-android',
  'mac',
  'windows-playdrop',
  'other',
] as const;

export type FeedbackClient = typeof FEEDBACK_CLIENT_VALUES[number];

export const FEEDBACK_CATEGORY_VALUES = [
  'bug',
  'feature',
  'question',
  'content',
  'account',
  'other',
] as const;

export type FeedbackCategory = typeof FEEDBACK_CATEGORY_VALUES[number];

export const FEEDBACK_STATUS_VALUES = [
  'sent',
  'ignored',
  'planned',
  'done',
] as const;

export type FeedbackStatus = typeof FEEDBACK_STATUS_VALUES[number];

export interface FeedbackEntry {
  id: number;
  userId: number | null;
  username: string | null;
  client: FeedbackClient;
  category: FeedbackCategory;
  version: string | null;
  build: string | null;
  title: string;
  comment: string;
  createdAt: string;
}

export interface AdminFeedbackEntry extends FeedbackEntry {
  email: string | null;
  status: FeedbackStatus;
  internalNote: string | null;
  statusUpdatedAt: string | null;
  statusUpdatedBy: number | null;
}

export interface SubmitFeedbackRequest {
  title: string;
  comment: string;
  client: FeedbackClient;
  category?: FeedbackCategory;
  email?: string | null;
  version?: string | null;
  build?: string | null;
}

export interface SubmitFeedbackResponse {
  feedback: FeedbackEntry;
}

export interface FeedbackListResponse {
  feedback: FeedbackEntry[];
  pagination: PaginationMeta;
}

export interface AdminFeedbackListResponse {
  feedback: AdminFeedbackEntry[];
  pagination: PaginationMeta;
}

export interface AdminFeedbackResponse {
  feedback: AdminFeedbackEntry;
}

export interface UpdateAdminFeedbackRequest {
  status?: FeedbackStatus;
  internalNote?: string | null;
}

export interface UpdateAdminFeedbackResponse {
  feedback: AdminFeedbackEntry;
}

export interface DeleteFeedbackResponse {
  success: boolean;
}

export interface LoginResponse {
  accessToken?: string;
  user: PublicUser;
}

export interface LogoutResponse {
  success: boolean;
}

export interface PublicUserResponse {
  user: PublicUser;
}

export interface CreatorSummaryResponse {
  profile: PublicUser;
  appCount: number;
  assetCount: number;
  packCount: number;
  creatorAppTabCounts: {
    games: number;
    demos: number;
    tools: number;
  };
  creatorAssetTabCounts: {
    images: number;
    music: number;
    sfx: number;
    videos: number;
    model3d: number;
  };
  hasIndexableContent: boolean;
}

export interface MeResponse {
  user: MeUser;
}

export interface AdminUserResponse {
  user: AdminUserDetail;
}

export type UserDetailResponse = PublicUserResponse;

export const SEARCH_RESULT_KIND_VALUES = ['creator', 'app', 'asset', 'asset-spec', 'pack'] as const;
export type SearchResultKind = typeof SEARCH_RESULT_KIND_VALUES[number];

export const SEARCH_KIND_VALUES = ['all', ...SEARCH_RESULT_KIND_VALUES] as const;
export type SearchKind = typeof SEARCH_KIND_VALUES[number];

export const SEARCH_MODE_VALUES = ['grouped', 'flat'] as const;
export type SearchMode = typeof SEARCH_MODE_VALUES[number];

export const SEARCH_ASSET_TYPE_VALUES = ['image', 'video', 'audio', 'song', 'sfx', '3d'] as const;
export type SearchAssetType = typeof SEARCH_ASSET_TYPE_VALUES[number];

export const SEARCH_SORT_VALUES = [
  'relevance',
  'views',
  'recent',
  'updated',
  'used',
  'newest',
  'likes',
  'downloads',
  'remixes',
  'comments',
  'assets',
  'apps',
  'alpha',
] as const;
export type SearchSort = typeof SEARCH_SORT_VALUES[number];

export interface SearchRequest {
  q: string;
  mode?: SearchMode;
  kind?: SearchKind;
  sort?: SearchSort;
  creatorUsername?: string;
  page?: number;
  pageSize?: number;
  appType?: AppType;
  auth?: AppAuthFilter;
  surface?: AppSurfaceFilter;
  controller?: AppControllerFilter;
  assetType?: SearchAssetType;
  assetCategory?: AssetCategory;
  assetSubcategory?: string;
  assetSpec?: string;
  assetSpecOwner?: string;
  assetSpecName?: string;
  packContainsCategory?: AssetCategory;
  packContainsSubcategory?: string;
  tags?: string[];
  includeCounts?: boolean;
}

export const APP_LIST_SORT_VALUES = [
  'newest',
  'updated',
  'views',
  'likes',
  'used',
] as const;
export type AppListSort = typeof APP_LIST_SORT_VALUES[number];

export interface AppBrowseRequest {
  limit?: number;
  offset?: number;
  tags?: string[];
  sort?: AppListSort;
  auth?: AppAuthFilter;
  surface?: AppSurfaceFilter;
  controller?: AppControllerFilter;
  controllerCompatible?: boolean;
}

export interface CreatorAppsBrowseRequest extends AppBrowseRequest {
  type?: AppType;
}

export interface SearchSuggestRequest {
  q: string;
}

export interface SearchCountsByKind {
  creator: number;
  app: number;
  asset: number;
  assetSpec: number;
  pack: number;
  total: number;
}

export interface SearchTabCounts {
  topResults: number;
  creators: number;
  apps: number;
  demos: number;
  tools: number;
  templates: number;
  images: number;
  videos: number;
  audio: number;
  songs: number;
  sfx: number;
  models3d: number;
  assetSpecs: number;
  packs: number;
}

// Creator info for home page collections
export interface HomeCreatorResponse {
  id: number;
  username: string;
  displayName: string;
  profileAssetPreviewUrl: string | null;
  xProfileImageUrl: string | null;
  googleProfileImageUrl: string | null;
  createdAt?: string;
  viewerFollowing?: boolean;
  followsViewer?: boolean;
}

export const SAVED_ITEM_KIND_VALUES = ['APP', 'ASSET', 'PACK'] as const;
export type SavedItemKind = typeof SAVED_ITEM_KIND_VALUES[number];

export interface ListTagsRequest {
  targetKind?: SavedItemKind;
  groupSlug?: string;
  limit?: number;
  offset?: number;
}

export interface TagListResponse {
  groups: TagGroupWithTagsSummary[];
  pagination: PaginationMeta;
}

export interface PopularTagSummary extends TagSummary {
  publicContentCount: number;
}

export interface TagDirectoryGroupSummary {
  group: TagGroupSummary;
  tagCount: number;
  tags: PopularTagSummary[];
  tagPagination: PaginationMeta;
}

export interface TagDirectoryResponse {
  groups: TagDirectoryGroupSummary[];
  pagination: PaginationMeta;
}

export interface TagDetailResponse {
  tag: TagSummary & {
    group: TagGroupSummary;
  };
}

export const TAG_GROUP_SORT_VALUES = ["alpha", "popularity"] as const;
export type TagGroupSort = typeof TAG_GROUP_SORT_VALUES[number];

export interface TagGroupDetailResponse {
  group: TagGroupSummary;
  tags: PopularTagSummary[];
  pagination: PaginationMeta;
  sort: TagGroupSort;
}

export interface AdminTagGroupsResponse {
  groups: TagGroupWithTagsSummary[];
}

export interface AdminTagGroupResponse {
  group: TagGroupSummary;
}

export interface AdminTagResponse {
  tag: TagSummary;
}

export interface CreateTagGroupRequest {
  slug: string;
  displayName: string;
  allowedTargetKinds?: SavedItemKind[];
}

export interface UpdateTagGroupRequest {
  displayName?: string;
  allowedTargetKinds?: SavedItemKind[];
}

export interface CreateTagRequest {
  slug: string;
  displayName: string;
}

export interface UpdateTagRequest {
  displayName?: string;
}

export interface CatalogueTagDefinition {
  slug: string;
  displayName: string;
}

export interface CatalogueTagGroupDefinition {
  slug: string;
  displayName: string;
  allowedTargetKinds?: SavedItemKind[];
  tags: CatalogueTagDefinition[];
}

export function isValidTagSlug(value: unknown): value is string {
  return typeof value === 'string' && TAG_SLUG_REGEX.test(value);
}

export function normalizeTagSlug(value: string): string {
  const normalized = value.trim().toLowerCase();
  if (!TAG_SLUG_REGEX.test(normalized)) {
    throw new Error(`invalid_tag_slug:${value}`);
  }
  return normalized;
}

export const COLLECTION_SLUG_REGEX = TAG_SLUG_REGEX;

export function isValidCollectionSlug(value: unknown): value is string {
  return typeof value === 'string' && COLLECTION_SLUG_REGEX.test(value);
}

export function normalizeCollectionSlug(value: string): string {
  const normalized = value.trim().toLowerCase();
  if (!COLLECTION_SLUG_REGEX.test(normalized)) {
    throw new Error(`invalid_collection_slug:${value}`);
  }
  return normalized;
}

export function parseTagRef(value: string): { groupSlug: string; tagSlug: string } | null {
  if (typeof value !== 'string') {
    return null;
  }
  const trimmed = value.trim().toLowerCase();
  const parts = trimmed.split('/');
  if (parts.length !== 2) {
    return null;
  }
  const groupSlug = parts[0];
  const tagSlug = parts[1];
  if (!groupSlug || !tagSlug) {
    return null;
  }
  if (!TAG_SLUG_REGEX.test(groupSlug) || !TAG_SLUG_REGEX.test(tagSlug)) {
    return null;
  }
  return { groupSlug, tagSlug };
}

export function normalizeTagRef(value: string): string {
  const parsed = parseTagRef(value);
  if (!parsed) {
    throw new Error(`invalid_tag_ref:${value}`);
  }
  return `${parsed.groupSlug}/${parsed.tagSlug}`;
}

export const ENGAGEMENT_EVENT_TYPE_VALUES = [
  'VIEW',
  'LAUNCH',
  'PLAY',
  'DOWNLOAD',
  'LIKE',
  'UNLIKE',
  'DISLIKE',
  'UNDISLIKE',
  'SAVE',
  'UNSAVE',
  'FOLLOW',
  'UNFOLLOW',
] as const;
export type EngagementEventType = typeof ENGAGEMENT_EVENT_TYPE_VALUES[number];

export const ENGAGEMENT_TARGET_KIND_VALUES = ['CREATOR', 'APP', 'ASSET', 'PACK'] as const;
export type EngagementTargetKind = typeof ENGAGEMENT_TARGET_KIND_VALUES[number];

export const APP_LAUNCH_CONTEXT_VALUES = ['CARD', 'DETAIL', 'OTHER'] as const;
export type AppLaunchContext = typeof APP_LAUNCH_CONTEXT_VALUES[number];

export const NOTIFICATION_EVENT_TYPE_VALUES = [
  'NEW_CONTENT',
  'UPDATED',
  'CONTENT_COMMENT',
  'CONTENT_REPLY',
  'CONTENT_LIKE',
  'NEW_FOLLOWER',
  'ASSET_PURCHASED',
  'PAYMENT_SUCCEEDED',
  'PAYMENT_REFUNDED',
  'ADMIN_ACTION',
  'AI_JOB_SUCCEEDED',
  'AI_JOB_FAILED',
  'GAME_PLAY_MILESTONE',
  'GAME_RECOMMENDED',
  'REMIX_PUBLISHED',
] as const;
export type NotificationEventType = typeof NOTIFICATION_EVENT_TYPE_VALUES[number];

export const LIBRARY_CATEGORY_VALUES = [
  'games',
  'demos',
  'tools',
  'templates',
  'images',
  'music',
  'sfx',
  'videos',
  '3d',
  'packs',
] as const;
export type LibraryCategory = typeof LIBRARY_CATEGORY_VALUES[number];

export const LIBRARY_SORT_VALUES = ['saved_desc', 'alpha_asc'] as const;
export type LibrarySort = typeof LIBRARY_SORT_VALUES[number];

export const FOLLOWING_SORT_VALUES = ['activity_desc', 'alpha_asc'] as const;
export type FollowingSort = typeof FOLLOWING_SORT_VALUES[number];

export const NOTIFICATION_STATUS_VALUES = ['all', 'unread'] as const;
export type NotificationStatus = typeof NOTIFICATION_STATUS_VALUES[number];

export const NOTIFICATION_PREVIEW_KIND_VALUES = ['item', 'person', 'credit', 'account'] as const;
export type NotificationPreviewKind = typeof NOTIFICATION_PREVIEW_KIND_VALUES[number];

export const FOLLOWING_APP_SECTION_VALUES = ['games', 'demos', 'tools', 'templates'] as const;
export type FollowingAppSection = typeof FOLLOWING_APP_SECTION_VALUES[number];

export const FOLLOWING_FEED_SECTION_VALUES = [
  ...FOLLOWING_APP_SECTION_VALUES,
  'images',
  'music',
  'sfx',
  'speech',
  'videos',
  '3d',
  'packs',
] as const;
export type FollowingFeedSection = typeof FOLLOWING_FEED_SECTION_VALUES[number];

export interface SavedAppItem {
  kind: 'APP';
  savedAt: string;
  app: AppResponse;
}

export interface SavedAssetItem {
  kind: 'ASSET';
  savedAt: string;
  asset: AssetResponse;
}

export interface SavedPackItem {
  kind: 'PACK';
  savedAt: string;
  pack: AssetPackResponse;
}

export type LibraryItem = SavedAppItem | SavedAssetItem | SavedPackItem;

export type LibraryCounts = Record<LibraryCategory, number>;

export interface LibraryResponse {
  category: LibraryCategory;
  sort: LibrarySort;
  counts: LibraryCounts;
  items: LibraryItem[];
}

export interface TrackEngagementEventRequest {
  eventType: EngagementEventType;
  targetKind: EngagementTargetKind;
  creatorUsername: string;
  itemName?: string;
  launchContext?: AppLaunchContext;
  promotionToken?: string | null;
}

export interface TrackEngagementEventResponse {
  recorded: boolean;
}

export interface FollowedCreatorResponse extends HomeCreatorResponse {
  followedAt: string;
  latestPublishedAt: string | null;
}

export interface FollowingCreatorsResponse {
  creators: FollowedCreatorResponse[];
}

export interface FollowingAppsFeedResponse {
  section: FollowingAppSection;
  apps: AppResponse[];
}

export interface FollowingAssetsFeedResponse {
  section: HomeAssetSectionKey;
  assets: AssetResponse[];
}

export interface FollowingPacksFeedResponse {
  section: 'packs';
  packs: AssetPackResponse[];
}

export type FollowingFeedResponse =
  | FollowingAppsFeedResponse
  | FollowingAssetsFeedResponse
  | FollowingPacksFeedResponse;

export interface CreatorSearchResult {
  kind: 'creator';
  targetPath: string;
  creator: HomeCreatorResponse;
}

export interface AppSearchResult {
  kind: 'app';
  targetPath: string;
  app: AppResponse;
}

export interface AssetSearchResult {
  kind: 'asset';
  targetPath: string;
  asset: AssetResponse;
}

export interface AssetPackSearchResult {
  kind: 'pack';
  targetPath: string;
  pack: AssetPackResponse;
}

export type SearchResult =
  | CreatorSearchResult
  | AppSearchResult
  | AssetSearchResult
  | AssetSpecSearchResult
  | AssetPackSearchResult;

export interface SearchGroupedResults {
  creators: CreatorSearchResult[];
  apps: AppSearchResult[];
  assets: AssetSearchResult[];
  assetSpecs: AssetSpecSearchResult[];
  packs: AssetPackSearchResult[];
}

export interface SearchResponse {
  q: string;
  mode: SearchMode;
  kind: SearchKind;
  countsByKind: SearchCountsByKind;
  tabCounts: SearchTabCounts;
  groups?: SearchGroupedResults;
  results?: SearchResult[];
  pagination?: PaginationMeta;
}

export interface SearchSuggestResponse {
  q: string;
  countsByKind: SearchCountsByKind;
  groups: SearchGroupedResults;
}

export type AssetSpecsResponse = AssetSpecListResponse;
export type AssetSpecVersionsResponse = AssetSpecVersionsListResponse;
export interface AssetSpecVersionResponseEnvelope {
  assetSpec: AssetSpecResponse;
  version: AssetSpecVersionResponse;
}

export interface SavedItemMutationResponse {
  saved: boolean;
}

export interface LikedItemMutationResponse {
  liked: boolean;
}

export interface DislikedItemMutationResponse {
  disliked: boolean;
}

export interface CreatorBlockMutationResponse {
  blocked: boolean;
}

export const MODERATION_REPORT_REASON_CODE_VALUES = [
  'SPAM',
  'HARASSMENT',
  'NSFW',
  'COPYRIGHT',
  'IMPERSONATION',
  'OTHER',
] as const;

export type ModerationReportReasonCode = typeof MODERATION_REPORT_REASON_CODE_VALUES[number];

export interface CreateModerationReportRequest {
  reasonCode: ModerationReportReasonCode;
  message?: string;
}

export type CreateContentReportRequest = CreateModerationReportRequest;
export type CreateCreatorReportRequest = CreateModerationReportRequest;
export type CreateCommentReportRequest = CreateModerationReportRequest;

export interface ModerationReportResponse {
  success: boolean;
}

export interface ContentCommentAuthor {
  id: number;
  username: string;
  displayName: string;
  profileAssetPreviewUrl?: string | null;
  xProfileImageUrl?: string | null;
  googleProfileImageUrl?: string | null;
}

export interface ContentCommentNode {
  id: number;
  kind: SavedItemKind;
  parentCommentId: number | null;
  body: string;
  isDeleted: boolean;
  authorIsCreator: boolean;
  canDelete: boolean;
  createdAt: string;
  updatedAt: string;
  likeCount: number;
  viewerLiked?: boolean;
  viewerDisliked?: boolean;
  author: ContentCommentAuthor;
  replies: ContentCommentNode[];
}

export interface ContentCommentsResponse {
  comments: ContentCommentNode[];
}

export interface CreateContentCommentRequest {
  body: string;
  parentCommentId?: number | null;
}

export interface CreateContentCommentResponse {
  comment: ContentCommentNode;
}

export interface DeleteContentCommentResponse {
  success: boolean;
}

export interface CreatorFollowMutationResponse {
  following: boolean;
}

export const FREE_CREDIT_OBJECTIVE_VALUES = [
  'WELCOME',
  'PLAY_GAME',
  'FOLLOW_CREATOR',
  'INVITED',
  'SHARE_CODE',
  'ENABLE_PUSH',
  'CREATE_SONG',
  'CREATE_IMAGE',
  'CREATE_3D',
  'CLI_LOGIN',
  'CREATE_GAME',
  'CREATE_GAME_UPDATE',
  'CREATE_GAME_REMIX',
  'PUBLISH_GAME',
  'SHARE_GAME',
  'BOOST_GAME',
] as const;
export type FreeCreditObjectiveKey = typeof FREE_CREDIT_OBJECTIVE_VALUES[number];

export const FREE_CREDIT_REWARD_STATUS_VALUES = ['INCOMPLETE', 'CLAIMABLE', 'CLAIMED'] as const;
export type FreeCreditRewardStatus = typeof FREE_CREDIT_REWARD_STATUS_VALUES[number];

export interface FreeCreditObjectiveSummary {
  objective: FreeCreditObjectiveKey;
  title: string;
  description: string;
  rewardCredits: number;
  maxCompletions: number;
  completedCount: number;
  claimableCount: number;
  claimedCount: number;
  status: FreeCreditRewardStatus;
  nextClaimRewardId: number | null;
}

export interface FreeCreditsResponse {
  items: FreeCreditObjectiveSummary[];
  unclaimedCount: number;
  inviteCode: string | null;
  inviteUrlPath: string | null;
}

export interface InvitePreviewResponse {
  inviteCode: string;
  shareCount: number;
  shareLimit: number;
  redeemable: boolean;
  inviter: InviteUserSummary;
}

export interface MyInviteCodeResponse {
  inviteCode: string;
  inviteUrlPath: string;
  shareCount: number;
  shareLimit: number;
  canEnterInviteCode: boolean;
  inviteEntryDeadline: string | null;
  invitedBy: InviteUserSummary | null;
  invitedUsers: InviteUserSummary[];
}

export interface ClaimFreeCreditRewardResponse {
  rewardId: number;
  objective: FreeCreditObjectiveKey;
  rewardCredits: number;
  transactionId: number;
  creditBalance: number;
  unclaimedCount: number;
  objectiveSummary: FreeCreditObjectiveSummary;
  counterpartUser: InviteUserSummary | null;
}

export type NotificationMetadata = Record<string, unknown>;

export interface UserNotificationResponse {
  id: number;
  eventType: NotificationEventType;
  title: string;
  body: string;
  targetPath: string;
  previewImageUrl?: string | null;
  previewKind?: NotificationPreviewKind | null;
  itemKind?: SavedItemKind | null;
  creator?: HomeCreatorResponse | null;
  actor?: HomeCreatorResponse | null;
  itemCreatorUsername?: string | null;
  itemName?: string | null;
  itemDisplayName?: string | null;
  appType?: AppType | null;
  assetCategory?: AssetCategory | null;
  assetSubcategory?: string | null;
  metadata?: NotificationMetadata | null;
  createdAt: string;
  readAt: string | null;
}

export interface NotificationsResponse {
  notifications: UserNotificationResponse[];
  unreadCount: number;
  pagination: PaginationMeta;
}

export interface NotificationReadResponse {
  success: boolean;
  unreadCount: number;
}

export interface WebPushSubscriptionKeys {
  p256dh: string;
  auth: string;
}

export interface WebPushSubscriptionObject {
  endpoint: string;
  expirationTime: number | null;
  keys: WebPushSubscriptionKeys;
}

export interface WebPushConfigResponse {
  vapidPublicKey: string;
}

export interface UpsertWebPushSubscriptionRequest {
  subscription: WebPushSubscriptionObject;
}

export interface WebPushSubscriptionStatusResponse {
  subscribed: boolean;
}

export interface PushSubscriptionMutationResponse {
  success: boolean;
  subscribed: boolean;
}

export const CREATOR_EMAIL_CHANNEL_VALUES = [
  'WELCOME',
  'CREATOR_ACTIVITY',
  'CREATOR_TIPS',
  'CREATOR_NEWS',
] as const;
export type CreatorEmailChannel = typeof CREATOR_EMAIL_CHANNEL_VALUES[number];

export const CREATOR_ENGAGEMENT_RULE_EXECUTION_STATUS_VALUES = [
  'PENDING',
  'PROCESSING',
  'SUPPRESSED',
  'COMPLETED',
  'PARTIAL_FAILED',
  'FAILED',
] as const;
export type CreatorEngagementRuleExecutionStatus =
  typeof CREATOR_ENGAGEMENT_RULE_EXECUTION_STATUS_VALUES[number];

export const COMMUNICATION_ACTION_EXECUTION_STATUS_VALUES = [
  'PENDING',
  'PROCESSING',
  'SUPPRESSED',
  'DRY_RUN',
  'SENT',
  'DELIVERED',
  'FAILED',
] as const;
export type CommunicationActionExecutionStatus =
  typeof COMMUNICATION_ACTION_EXECUTION_STATUS_VALUES[number];

export const COMMUNICATION_ACTION_TYPE_VALUES = ['EMAIL', 'IN_APP_NOTIFICATION'] as const;
export type CommunicationActionType = typeof COMMUNICATION_ACTION_TYPE_VALUES[number];

export const EMAIL_SUPPRESSION_REASON_VALUES = [
  'HARD_BOUNCE',
  'COMPLAINT',
  'SOFT_BOUNCE_THRESHOLD',
  'MANUAL',
] as const;
export type EmailSuppressionReason = typeof EMAIL_SUPPRESSION_REASON_VALUES[number];

export const EMAIL_MESSAGE_PROVIDER_STATUS_VALUES = ['PROCESSING', 'DRY_RUN', 'SENT', 'FAILED'] as const;
export type EmailMessageProviderStatus = typeof EMAIL_MESSAGE_PROVIDER_STATUS_VALUES[number];

export const EMAIL_EVENT_TYPE_VALUES = [
  'SEND',
  'DELIVERY',
  'BOUNCE',
  'COMPLAINT',
  'REJECT',
  'DELIVERY_DELAY',
  'OPEN',
  'CLICK',
] as const;
export type EmailEventType = typeof EMAIL_EVENT_TYPE_VALUES[number];

export interface UserCommunicationPreferencesResponse {
  userId: number;
  creatorActivityEnabled: boolean;
  creatorTipsEnabled: boolean;
  creatorNewsEnabled: boolean;
  creatorActivityUnsubscribedAt: string | null;
  creatorTipsUnsubscribedAt: string | null;
  creatorNewsUnsubscribedAt: string | null;
  marketingUnsubscribedAt: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface UpdateUserCommunicationPreferencesRequest {
  creatorActivityEnabled?: boolean;
  creatorTipsEnabled?: boolean;
  creatorNewsEnabled?: boolean;
}

export interface EmailPreferencesResponse {
  preferences: UserCommunicationPreferencesResponse;
}

export interface PublicEmailPreferencesResponse extends EmailPreferencesResponse {
  channel: CreatorEmailChannel | null;
  email: string;
}

export interface PublicEmailPreferencesUpdateRequest extends UpdateUserCommunicationPreferencesRequest {
  unsubscribeAllMarketing?: boolean;
}

export type EmailUnsubscribeResponse = EmailPreferencesResponse;

export interface CreatorEngagementRuleSummary {
  id: string;
  trigger: string;
  channel: CreatorEmailChannel | null;
  enabled: boolean;
  delaySeconds: number;
  sender?: string;
  subject: string | null;
  actions: Array<{
    id: string;
    type: CommunicationActionType;
    channel: CreatorEmailChannel | null;
    enabled: boolean;
    defaultEnabled: boolean;
    overrideEnabled: boolean | null;
  }>;
}

export interface AdminCreatorEngagementRulesResponse {
  globalKillSwitch: boolean;
  dryRun: boolean;
  rules: CreatorEngagementRuleSummary[];
}

export interface AdminCreatorEngagementExecutionSummary {
  id: number;
  ruleId: string;
  trigger: string;
  userId: number;
  objectKind: string;
  objectId: string;
  channel: CreatorEmailChannel | null;
  status: CreatorEngagementRuleExecutionStatus;
  suppressionReason: string | null;
  failureReason: string | null;
  claimedAt: string | null;
  claimExpiresAt: string | null;
  attemptCount: number;
  lastAttemptError: string | null;
  scheduledAt: string;
  evaluatedAt: string | null;
  createdAt: string;
  updatedAt: string;
  messageCount: number;
  actions: AdminCommunicationActionExecutionResponse[];
}

export interface AdminCreatorEngagementExecutionsResponse {
  executions: AdminCreatorEngagementExecutionSummary[];
  pagination: PaginationMeta;
}

export interface AdminEmailSuppressionResponse {
  id: number;
  email: string;
  reason: EmailSuppressionReason;
  source: string;
  details: Record<string, unknown> | null;
  suppressedAt: string;
  createdAt: string;
  updatedAt: string;
}

export interface AdminEmailMessageResponse {
  id: number;
  ruleExecutionId: number | null;
  communicationActionExecutionId: number | null;
  userId: number;
  channel: CreatorEmailChannel;
  fromEmail: string;
  replyToEmail: string | null;
  toEmail: string;
  subject: string;
  resendMessageId: string | null;
  providerStatus: EmailMessageProviderStatus;
  providerError: string | null;
  sentAt: string | null;
  createdAt: string;
}

export interface AdminCommunicationActionExecutionResponse {
  id: number;
  ruleExecutionId: number;
  actionId: string;
  actionType: CommunicationActionType;
  status: CommunicationActionExecutionStatus;
  outputKind: string | null;
  outputId: string | null;
  suppressionReason: string | null;
  failureReason: string | null;
  claimedAt: string | null;
  claimExpiresAt: string | null;
  nextAttemptAt: string | null;
  attemptCount: number;
  lastAttemptError: string | null;
  executedAt: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface AdminNotificationEventResponse {
  id: number;
  communicationActionExecutionId: number | null;
  eventType: NotificationEventType;
  dedupeKey: string;
  creatorId: number;
  actorUserId: number | null;
  title: string;
  body: string;
  targetPath: string;
  pushEligible: boolean;
  recipientStrategy: string;
  fanoutStatus: string;
  occurredAt: string;
  createdAt: string;
}

export interface AdminUserNotificationResponse {
  id: number;
  eventId: number | null;
  userId: number;
  communicationActionExecutionId: number | null;
  eventType: NotificationEventType;
  dedupeKey: string;
  title: string | null;
  body: string | null;
  targetPath: string | null;
  readAt: string | null;
  createdAt: string;
  deliveries: Array<{
    id: number;
    status: string;
    attemptCount: number;
    deliveredAt: string | null;
    lastError: string | null;
    createdAt: string;
    updatedAt: string;
  }>;
}

export interface AdminEmailEventResponse {
  id: number;
  emailMessageId: number | null;
  resendMessageId: string | null;
  eventType: EmailEventType;
  providerEventId: string | null;
  emailAddress: string | null;
  eventAt: string;
  rawPayload: Record<string, unknown>;
  createdAt: string;
}

export interface AdminCreatorEngagementUserResponse {
  preferences: UserCommunicationPreferencesResponse;
  suppressions: AdminEmailSuppressionResponse[];
  executions: AdminCreatorEngagementExecutionSummary[];
  messages: AdminEmailMessageResponse[];
  events: AdminEmailEventResponse[];
  notificationEvents: AdminNotificationEventResponse[];
  notifications: AdminUserNotificationResponse[];
}

export interface AdminCreatorEngagementRulePreviewRequest {
  userId?: number;
  objectKind?: string;
  objectId?: string;
  payload?: Record<string, unknown>;
}

export interface AdminCreatorEngagementRulePreviewResponse {
  rule: CreatorEngagementRuleSummary;
  suppressed: boolean;
  suppressionReason: string | null;
  message: {
    fromEmail: string;
    replyToEmail: string | null;
    toEmail: string;
    subject: string;
    textBody: string;
    htmlBody: string;
    headers: Record<string, string>;
  } | null;
  notification?: {
    title: string;
    body: string;
  } | null;
}

export type ApplePushEnvironment = 'development' | 'production';

export interface ApplePushDeviceRequest {
  deviceToken: string;
  apnsEnvironment: ApplePushEnvironment;
}

export interface ApplePushDeviceStatusResponse {
  subscribed: boolean;
}

export interface FirebasePushDeviceRequest {
  deviceToken: string;
}

export interface FirebasePushDeviceStatusResponse {
  subscribed: boolean;
}

export const HOME_GAMES_COLLECTION_IDS = {
  FOR_YOU_GAMES: 'for_you_games',
  TOP_GAMES: 'top_games',
  MOST_LIKED_GAMES: 'most_liked_games',
  BOOSTED_GAMES: 'boosted_games',
  TOP_CREATORS: 'top_creators',
  FEATURED_GAMES: 'featured_games',
  NEW_GAMES: 'new_games',
  GAME_GENRES: 'game_genres',
  CONTINUE_PLAYING: 'continue_playing',
  FOLLOWING_CREATORS: 'following_creators',
} as const;

export type HomeGamesCollectionId =
  typeof HOME_GAMES_COLLECTION_IDS[keyof typeof HOME_GAMES_COLLECTION_IDS];

// Base fields shared by all home collection types
interface HomeCollectionBase {
  id: string;
  title: string;
  description?: string | null;
  metadata?: Record<string, unknown> | null;
}

// Collection of apps
export interface AppsHomeCollection extends HomeCollectionBase {
  type: 'apps';
  apps: AppResponse[];
}

// Collection of creators
export interface CreatorsHomeCollection extends HomeCollectionBase {
  type: 'creators';
  creators: HomeCreatorResponse[];
}

export interface TagsHomeCollection extends HomeCollectionBase {
  type: 'tags';
  group: TagGroupSummary;
  tags: PopularTagSummary[];
}

// Discriminated union of all collection types
export type HomeCollection = AppsHomeCollection | CreatorsHomeCollection | TagsHomeCollection;

export interface HomeCollectionsResponse {
  section: 'games';
  collections: HomeCollection[];
}

export interface HomeCollectionPageResponse {
  section: 'games';
  collection: HomeCollection;
  pagination: PaginationMeta;
}

export interface CreatorsListResponse {
  creators: HomeCreatorResponse[];
  pagination: PaginationMeta;
}

export type HomeAssetSectionKey = 'images' | 'music' | 'sfx' | 'speech' | 'videos' | '3d';
export type HomeSectionKey = 'games' | HomeAssetSectionKey | 'packs';

export interface HomeAssetsSectionResponse {
  section: HomeAssetSectionKey;
  assets: AssetResponse[];
  pagination: PaginationMeta;
}

export interface HomePacksSectionResponse {
  section: 'packs';
  packs: AssetPackResponse[];
  pagination: PaginationMeta;
}

export type HomeResponse = HomeCollectionsResponse | HomeAssetsSectionResponse | HomePacksSectionResponse;

export interface FetchHomeOptions {
  section?: HomeSectionKey;
  limit?: number;
  offset?: number;
}

export interface MyAppsResponse {
  apps: AppResponse[];
  pagination?: PaginationMeta;
}

export interface DeleteAppResponse {
  success: boolean;
}

export interface UsersListResponse {
  users: AdminUserDetail[];
}

export interface CreateUserResponse {
  user: AdminUserDetail;
}

export interface UpdateAdminUserRequest {
  role?: 'CREATOR' | 'ADMIN';
  displayName?: string;
  creditDelta?: number;
  freeCloudGenerationDelta?: number;
  bio?: string | null;
  youtubeUsername?: string | null;
  githubUsername?: string | null;
  websiteUrl?: string | null;
  supportUrl?: string | null;
  // X OAuth credentials (admin can set/update these)
  xUserId?: string | null;
  xUsername?: string | null;
  xProfileImageUrl?: string | null;
}

export interface DeleteAdminUserResponse {
  success: boolean;
}

export interface BatchCreateUsersResponse {
  created: number;
  skipped: number;
  errors: number;
  details: Array<{
    xUsername: string;
    status: 'created' | 'skipped' | 'error';
    message?: string;
  }>;
}

export interface BootstrapResponse {
  readmeUri: string;
  agentsUri: string;
  catalogue?: string;
}

// ============================================================================
// Validation Helpers
// ============================================================================

export function isPaginationMeta(value: unknown): value is PaginationMeta {
  if (typeof value !== 'object' || value === null) {
    return false;
  }
  const meta = value as Record<string, unknown>;
  const limit = meta['limit'];
  const offset = meta['offset'];
  const count = meta['count'];
  const hasMore = meta['hasMore'];
  return (
    Number.isInteger(limit)
    && Number.isInteger(offset)
    && Number.isInteger(count)
    && (limit as number) >= 0
    && (offset as number) >= 0
    && (count as number) >= 0
    && typeof hasMore === 'boolean'
  );
}

// ============================================================================
// Client Error Types
// ============================================================================

export class UnsupportedClientError extends Error {
  code: string;
  details: Record<string, unknown> | null;

  constructor(code: string, message: string, details: Record<string, unknown> | null = null) {
    super(message);
    this.name = 'UnsupportedClientError';
    this.code = code;
    this.details = details;
  }
}

// Shop and Credit types
export interface CreditPack {
  sku: string;
  name: string;
  amount: number;
  cost: number;
}

export interface ShopCollection {
  id: string;
  title: string;
  metadata?: Record<string, unknown> | null;
  items: ShopItem[];
}

export type ShopItem =
  | {
      type: 'credit_pack';
      id: string;
      sku: string;
      name: string;
      amount: number;
      costCents: number;
    }
  | {
      type: 'asset';
      id: string;
      assetId: number;
      assetRef: string;
      name: string;
      displayName: string;
      category: string;
      subcategory: string;
      previewUrl: string | null;
      priceCredits: number;
      owned: boolean;
      creatorUsername: string;
    }
  | {
      type: 'boost_pack';
      id: string;
      sku: BoostSku;
      name: string;
      units: number;
      priceCredits: number;
    };

export interface ShopResponse {
  collections: ShopCollection[];
  boostBalance?: number;
}

export interface AdminCreditPack {
  sku: string;
  displayName: string;
  amount: number;
  costCents: number;
  stripeProductId: string | null;
  stripePriceId: string | null;
  createdAt: string;
  updatedAt: string;
}

export type PaymentProvider = 'STRIPE' | 'APPLE_IAP' | 'GOOGLE_PLAY';
export type PaymentStatus = 'PENDING' | 'AUTHORIZED' | 'SUCCEEDED' | 'FULFILLED' | 'FAILED' | 'CANCELLED' | 'REFUNDED';
export type PaymentEventProcessStatus = 'PENDING' | 'PROCESSED' | 'FAILED';
export type PaymentRefundStatus = 'PENDING' | 'SUCCEEDED' | 'FAILED' | 'CANCELLED';

export interface CreditPacksResponse {
  creditPacks: AdminCreditPack[];
}

export interface CreditPackResponse {
  creditPack: AdminCreditPack;
}

export type CreditTransactionDirection = 'IN' | 'OUT';
export type CreditTransactionKind = 'CONSUMABLE' | 'ENTITLEMENT';
export type CreditTransactionStatus = 'PENDING' | 'AUTHORIZED' | 'CONSUMED' | 'GRANTED' | 'CANCELLED';
export type CreditTransactionType =
  | 'CREDIT_PACK'
  | 'ASSET'
  | 'IN_APP'
  | 'AI_SERVICE'
  | 'ADMIN_GRANT'
  | 'FREE_CREDIT'
  | 'AD_PAYOUT'
  | 'BOOST_PURCHASE';

export interface CreditTransaction {
  id: number;
  sourceId: number;
  sourceName: string;
  paymentId?: number | null;
  paymentProvider?: PaymentProvider | null;
  providerPaymentId?: string | null;
  paymentStoreEnvironment?: string | null;
  type: string;
  kind: CreditTransactionKind;
  status: CreditTransactionStatus;
  displayName: string;
  sku: string | null;
  amount: number;
  creatorPayoutAmount: number | null;
  platformFeeAmount: number | null;
  direction: CreditTransactionDirection;
  netAmount: number;
  buyer: string;
  seller: string;
  metadata?: Record<string, unknown> | null;
  createdAt: string;
  updatedAt: string;
}

export interface TransactionsResponse {
  transactions: CreditTransaction[];
}

export interface AdminCreditTransaction {
  id: number;
  sourceId: number;
  sourceName: string;
  paymentId?: number | null;
  type: CreditTransactionType;
  kind: CreditTransactionKind;
  status: CreditTransactionStatus;
  displayName: string;
  sku: string | null;
  amount: number;
  creatorPayoutAmount: number | null;
  platformFeeAmount: number | null;
  buyerId: number;
  buyer: string;
  sellerId: number;
  seller: string;
  metadata?: Record<string, unknown> | null;
  createdAt: string;
  updatedAt: string;
}

export const BOOST_SKU_VALUES = ['boost_1', 'boost_3', 'boost_7', 'boost_14', 'boost_31'] as const;
export type BoostSku = typeof BOOST_SKU_VALUES[number];

export interface BoostOffer {
  sku: BoostSku;
  displayName: string;
  units: number;
  priceCredits: number;
  durationHours: number;
}

export interface BoostBalanceResponse {
  balance: number;
  offers: BoostOffer[];
}

export interface BoostPurchaseRequest {
  sku: BoostSku;
  quantity?: number;
}

export interface BoostEligibleGameSummary {
  name: string;
  displayName: string;
  creatorUsername: string;
  type: AppType;
}

export interface BoostPurchaseResponse {
  offer: BoostOffer;
  quantity: number;
  unitsAdded: number;
  boostBalance: number;
  creditBalance: number;
  transaction: CreditTransaction;
  eligibleGameCount: number;
  eligibleGame: BoostEligibleGameSummary | null;
}

export interface BoostActivationRequest {
  units?: number;
}

export interface BoostRunSummary {
  id: number;
  status: 'ACTIVE' | 'EXPIRED' | 'CANCELLED';
  startedAt: string;
  endsAt: string;
  consumedUnits: number;
  adBudgetCredits: number;
  adReservedCredits: number;
  adSpentCredits: number;
  adRemainingCredits: number;
  deliveredImpressionCount: number;
  promotedDetailViewCount: number;
  promotedPlayCount: number;
  createdAt: string;
  updatedAt: string;
}

export interface BoostStatusResponse {
  app: AppResponse;
  boostsAvailable: number;
  isActive: boolean;
  boostedUntil: string | null;
  currentRun: BoostRunSummary | null;
  totals: {
    deliveredImpressions: number;
    promotedDetailViews: number;
    promotedPlays: number;
  };
}

export interface BoostHistoryResponse {
  runs: BoostRunSummary[];
}

export interface BoostReportQuery {
  days?: number;
  startDateUtc?: string;
  endDateUtc?: string;
}

export interface BoostReportPoint {
  dateUtc: string;
  provisional: boolean;
  regularDetailViews: number;
  promotedDetailViews: number;
  regularPlays: number;
  promotedPlays: number;
  boostedHomeViews: number;
  adViews: number;
  boostedHomePlays: number;
  adPlays: number;
  interstitialImpressions: number;
  rewardedImpressions: number;
  creditedImpressions: number;
  adEarnings: number;
}

export interface BoostReportResponse {
  appId: number;
  days: BoostReportPoint[];
}

export interface CreatorEarningsAppDayRow {
  appId: number;
  appName: string;
  creatorUsername: string;
  format: 'interstitial' | 'rewarded';
  amount: number;
  servedCount: number;
  creditedCount: number;
  settled: boolean;
}

export interface CreatorEarningsDay {
  dateUtc: string;
  provisional: boolean;
  totalAmount: number;
  interstitialAmount: number;
  rewardedAmount: number;
  servedCount: number;
  creditedCount: number;
  apps: CreatorEarningsAppDayRow[];
}

export interface CreatorEarningsSummary {
  provisionalToday: number;
  settledLast7Days: number;
  settledLast30Days: number;
  boostSpendLast30Days: number;
}

export interface CreatorEarningsResponse {
  summary: CreatorEarningsSummary;
  days: CreatorEarningsDay[];
}

export type AdFormat = 'INTERSTITIAL' | 'REWARDED';
export type AdLoadStatus = 'ready' | 'no_fill' | 'rate_limited' | 'blocked';
export type AdInterstitialShowStatus = 'dismissed' | 'not_ready' | 'expired';
export type AdRewardedShowStatus = 'completed' | 'dismissed' | 'not_ready' | 'expired';
export type AdTargetType =
  | 'BOOSTED_APP'
  | 'HOUSE_AVATAR'
  | 'HOUSE_GAME'
  | 'HOUSE_CREATE_ACCOUNT'
  | 'HOUSE_INVITE_FRIENDS';

export interface AdCreative {
  targetType: AdTargetType;
  title: string;
  body: string | null;
  ctaLabel: string | null;
  targetHref: string;
  imageUrl: string | null;
  promotedApp?: AppResponse | null;
}

export interface AdLoadRequest {
  sourceAppId: number;
  viewerSurface: AppSurface;
}

export type AdLoadResult =
  | { status: 'ready' }
  | { status: 'no_fill' }
  | { status: 'rate_limited'; retryAfterSeconds: number }
  | { status: 'blocked'; reason: string };

export type AdLoadResponse =
  | {
      status: 'ready';
      format: AdFormat;
      reservationId: string;
      creative: AdCreative;
    }
  | {
      status: 'no_fill';
      format: AdFormat;
    }
  | {
      status: 'rate_limited';
      format: AdFormat;
      retryAfterSeconds: number;
    }
  | {
      status: 'blocked';
      format: AdFormat;
      reason: string;
    };

export interface AdShowRequest {
  reservationId: string;
  viewedMs: number;
}

export type AdInterstitialShowResponse =
  | {
      status: 'dismissed';
      reservationId: string;
      impressionId: number;
    }
  | {
      status: 'not_ready';
      reservationId: null;
      impressionId?: null;
    }
  | {
      status: 'expired';
      reservationId: string | null;
      impressionId?: null;
    };

export type AdRewardedShowResponse =
  | {
      status: 'completed' | 'dismissed';
      reservationId: string;
      impressionId: number;
    }
  | {
      status: 'not_ready';
      reservationId: null;
      impressionId?: null;
    }
  | {
      status: 'expired';
      reservationId: string | null;
      impressionId?: null;
    };

export interface AdminCreditTransactionsResponse {
  transactions: AdminCreditTransaction[];
  pagination: PaginationMeta;
}

export interface IapReceipt {
  id: number;
  type: string;
  kind: CreditTransactionKind;
  status: CreditTransactionStatus;
  displayName: string;
  sku: string | null;
  amount: number;
  creatorPayoutAmount: number | null;
  platformFeeAmount: number | null;
  sourceId: number;
  sourceName: string;
  buyerId: number;
  buyer: string;
  sellerId: number;
  seller: string;
  createdAt: string;
  updatedAt: string;
}

export interface IapReceiptsResponse {
  receipts: IapReceipt[];
  pagination: PaginationMeta;
}

export interface IapPurchaseRequest {
  appId: number;
  kind: 'consumable' | 'entitlement';
  sku: string;
  displayName: string;
  priceCredits: number;
}

export const MUSIC_PROMPT_MAX_LENGTH = 4000;

export type AiGenerationType = 'TEXT' | 'JSON' | 'IMAGE' | 'MUSIC' | 'SFX' | 'SPEECH' | 'VIDEO' | 'MODEL_3D';
export type AiGenerationStatus = 'SUCCESS' | 'FAILURE';
export type AiGenerationPaidBy = 'USER' | 'CREATOR';

export interface AiGenerationSummary {
  id: string;
  createdAt: string;
  userId: number | null;
  username: string | null;
  creatorId: number | null;
  creatorUsername: string | null;
  sourceId: number | null;
  sourceName: string | null;
  type: AiGenerationType;
  status: AiGenerationStatus;
  provider: string;
  model: string;
  amount: number;
  paidBy: AiGenerationPaidBy;
  transactionId: number | null;
}

export interface AiGenerationDetail extends AiGenerationSummary {
  inputData: unknown;
  inputAssets: string[];
  outputData: unknown;
  outputAssets: string[];
  errorCode: string | null;
  errorMessage: string | null;
  transaction: AdminCreditTransaction | null;
}

export interface AiGenerationsResponse {
  generations: AiGenerationSummary[];
  pagination: PaginationMeta;
}

export interface AiGenerationDetailResponse {
  generation: AiGenerationDetail;
}

export interface IapPurchaseResponse {
  receipt: IapReceipt;
  creditBalance: number;
}

export interface IapReceiptResponse {
  receipt: IapReceipt;
}

export interface IapReceiptListParams {
  kind?: 'consumable' | 'entitlement';
  status?: CreditTransactionStatus | CreditTransactionStatus[];
  from?: string | Date;
  to?: string | Date;
  appId?: number;
  limit?: number;
  offset?: number;
}

export interface AssetPurchaseRequest {
  type: 'asset';
  assetRef: string;
}

export type PurchaseRequest = AssetPurchaseRequest;

export interface CreditPackCheckoutSessionRequest {
  nextPath?: string;
}

export interface CreditPackCheckoutSessionResponse {
  checkoutSessionId: string;
  checkoutUrl: string;
  expiresAt: string | null;
  paymentId?: number;
  provider?: PaymentProvider;
  isReturningCustomer?: boolean;
}

export interface CreditPackCheckoutStatusResponse {
  checkoutSessionId: string;
  fulfilled: boolean;
  paymentStatus: string;
  transactionId: number | null;
  creditBalance: number | null;
  paymentId?: number | null;
  provider?: PaymentProvider;
  providerPaymentId?: string | null;
}

export interface AppleCreditPackFulfillmentRequest {
  productId: string;
  transactionId: string;
  signedTransactionInfo: string;
}

export interface GoogleCreditPackFulfillmentRequest {
  productId: string;
  purchaseToken: string;
}

export interface MobileCreditPackFulfillmentResponse {
  provider: PaymentProvider;
  providerPaymentId: string;
  storeEnvironment?: string | null;
  paymentId: number;
  transactionId: number;
  creditBalance: number;
  alreadyFulfilled: boolean;
  creditPack: {
    sku: string;
    displayName: string;
    amount: number;
  };
}

export interface AdminPaymentSummary {
  id: number;
  provider: PaymentProvider;
  status: PaymentStatus;
  userId: number;
  username: string;
  userCreditBalance: number;
  creditPackSku: string | null;
  creditPackDisplayName: string | null;
  currency: string;
  amountCents: number;
  providerPaymentId: string | null;
  providerIntentId: string | null;
  providerChargeId: string | null;
  providerPaymentDashboardUrl: string | null;
  providerIntentDashboardUrl: string | null;
  providerChargeDashboardUrl: string | null;
  fulfilledCreditTransactionId: number | null;
  failureCode: string | null;
  failureMessage: string | null;
  refundCount: number;
  refundedAmountCents: number;
  createdAt: string;
  updatedAt: string;
}

export interface AdminPaymentEvent {
  id: number;
  provider: PaymentProvider;
  providerEventId: string;
  eventType: string;
  signatureVerified: boolean;
  processStatus: PaymentEventProcessStatus;
  processError: string | null;
  processedAt: string | null;
  createdAt: string;
}

export interface AdminPaymentRefund {
  id: number;
  paymentId: number;
  provider: PaymentProvider;
  providerRefundId: string | null;
  providerRefundDashboardUrl: string | null;
  amountCents: number;
  status: PaymentRefundStatus;
  reason: string | null;
  initiatedByAdminUserId: number;
  initiatedByAdminUsername: string;
  reversalCreditTransactionId: number | null;
  postRefundCreditBalance: number | null;
  debtAmount: number | null;
  createdAt: string;
  updatedAt: string;
}

export interface AdminPaymentDetail extends AdminPaymentSummary {
  events: AdminPaymentEvent[];
  refunds: AdminPaymentRefund[];
}

export interface AdminPaymentsListResponse {
  payments: AdminPaymentSummary[];
  pagination: PaginationMeta;
}

export interface AdminPaymentDetailResponse {
  payment: AdminPaymentDetail;
}

export interface AdminRefundPaymentRequest {
  reason?: string | null;
}

export interface PurchaseResponse {
  success: boolean;
  transaction: {
    id: number;
    amount: number;
    type: string;
    sku: string | null;
    createdAt: string;
  };
  creditBalance?: number;
  grantedAssetRef?: string | null;
}

export class ApiError extends Error {
  status: number;
  code?: string;
  details: Record<string, unknown> | null;

  constructor(message: string, status: number, code?: string, details: Record<string, unknown> | null = null) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.details = details;
    if (code !== undefined) {
      this.code = code;
    }
  }
}
