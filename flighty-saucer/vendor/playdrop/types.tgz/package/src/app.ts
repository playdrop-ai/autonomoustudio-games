export const APP_TYPE_VALUES = ['GAME', 'TEMPLATE', 'TOOL', 'DEMO'] as const;

export type AppType = (typeof APP_TYPE_VALUES)[number];

export const DEFAULT_APP_TYPE: AppType = 'GAME';

export const APP_SURFACE_VALUES = ['DESKTOP', 'MOBILE_LANDSCAPE', 'MOBILE_PORTRAIT'] as const;

export type AppSurface = (typeof APP_SURFACE_VALUES)[number];

export const APP_ORIGIN_VALUES = ['PLAYDROP_CLOUD', 'USER'] as const;

export type AppOrigin = (typeof APP_ORIGIN_VALUES)[number];

export const DEFAULT_APP_SURFACE_TARGETS: ReadonlyArray<AppSurface> = ['DESKTOP', 'MOBILE_LANDSCAPE'];

export function isAppType(value: unknown): value is AppType {
  if (typeof value !== 'string') {
    return false;
  }
  return (APP_TYPE_VALUES as readonly string[]).includes(value.trim().toUpperCase());
}

export function parseAppType(value: unknown): AppType | null {
  if (typeof value !== 'string') {
    return null;
  }
  const normalized = value.trim().toUpperCase();
  return isAppType(normalized) ? (normalized as AppType) : null;
}

export function normalizeAppType(value: unknown, fallback: AppType = DEFAULT_APP_TYPE): AppType {
  const parsed = parseAppType(value);
  return parsed ?? fallback;
}

export function isAppSurface(value: unknown): value is AppSurface {
  if (typeof value !== 'string') {
    return false;
  }
  return (APP_SURFACE_VALUES as readonly string[]).includes(value.trim().toUpperCase());
}

export function parseAppSurface(value: unknown): AppSurface | null {
  if (typeof value !== 'string') {
    return null;
  }
  const normalized = value.trim().toUpperCase();
  return isAppSurface(normalized) ? (normalized as AppSurface) : null;
}

export function normalizeAppSurfaceList(
  value: unknown,
  fallback: ReadonlyArray<AppSurface> = DEFAULT_APP_SURFACE_TARGETS,
): AppSurface[] {
  if (Array.isArray(value)) {
    const parsed = value
      .map((entry) => parseAppSurface(entry))
      .filter((entry): entry is AppSurface => Boolean(entry));
    if (parsed.length > 0) {
      return Array.from(new Set(parsed));
    }
  }
  return Array.from(fallback);
}

export const APP_TYPE_DEFAULT_DISPLAY: Record<AppType, { emoji: string; color: string }> = {
  GAME: { emoji: '🚀', color: '#FF383C' },
  TOOL: { emoji: '🛠️', color: '#0088FF' },
  TEMPLATE: { emoji: '📋', color: '#8E8E93' },
  DEMO: { emoji: '💡', color: '#000000' },
};

export function getDefaultAppDisplayMetadata(type: AppType): { emoji: string; color: string } {
  return APP_TYPE_DEFAULT_DISPLAY[type] ?? APP_TYPE_DEFAULT_DISPLAY[DEFAULT_APP_TYPE];
}
