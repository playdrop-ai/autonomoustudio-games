import { formatAssetSpecVersionRef, parseAssetSpecVersionRef, type AssetSpecVersionRef } from './asset-spec.js';

export const VERSION_NODE_KIND_VALUES = ['APP_VERSION', 'ASSET_VERSION', 'PACK_VERSION', 'ASSET_SPEC_VERSION'] as const;
export type VersionNodeKind = (typeof VERSION_NODE_KIND_VALUES)[number];

export const RELATION_TYPE_VALUES = ['USES', 'CONTAINS', 'REMIXES'] as const;
export type RelationType = (typeof RELATION_TYPE_VALUES)[number];

export interface VersionNodeRef {
  id: string;
  kind: VersionNodeKind;
  appVersionId?: number | null;
  assetVersionId?: number | null;
  packVersionId?: number | null;
  assetSpecVersionId?: number | null;
  createdAt: string;
  updatedAt: string;
}

export interface NodeRelationRecord {
  id: number;
  fromNodeId: string;
  toNodeId: string;
  type: RelationType;
  createdAt: string;
  updatedAt: string;
}

export interface BatchUpsertNodeRelationsRequest {
  relations: Array<{
    fromNodeId: string;
    toNodeId: string;
    type: RelationType;
  }>;
}

export interface BatchUpsertNodeRelationsResponse {
  relations: NodeRelationRecord[];
}

export type AppVersionRef = {
  kind: 'app';
  creatorUsername: string;
  name: string;
  version: string;
};

export type AssetVersionRef = {
  kind: 'asset';
  creatorUsername: string;
  name: string;
  revision: number;
};

export type PackVersionRef = {
  kind: 'pack';
  creatorUsername: string;
  name: string;
  version: string;
};

export type ContentVersionRef = AppVersionRef | AssetVersionRef | PackVersionRef | AssetSpecVersionRef;

const SEMVER_VERSION_REF_REGEX = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$/;

export function parseContentVersionRef(raw: string): ContentVersionRef | null {
  if (typeof raw !== 'string') {
    return null;
  }
  const trimmed = raw.trim();
  if (!trimmed.length) {
    return null;
  }
  const match = /^(app|asset|pack|asset-spec):([^/]+)\/([^@]+)@(.+)$/i.exec(trimmed);
  if (!match) {
    return null;
  }
  const [, rawKind, rawCreatorUsername, rawName, rawVersionValue] = match;
  if (!rawKind || !rawCreatorUsername || !rawName || !rawVersionValue) {
    return null;
  }
  const kind = rawKind.toLowerCase();
  const creatorUsername = rawCreatorUsername.trim();
  const name = rawName.trim();
  const rawVersion = rawVersionValue.trim();
  if (!creatorUsername.length || !name.length || !rawVersion.length) {
    return null;
  }
  if (kind === 'asset') {
    const revisionMatch = /^r(\d+)$/i.exec(rawVersion);
    if (!revisionMatch) {
      return null;
    }
    const revisionValue = revisionMatch[1];
    if (!revisionValue) {
      return null;
    }
    const revision = Number.parseInt(revisionValue, 10);
    if (!Number.isInteger(revision) || revision <= 0) {
      return null;
    }
    return {
      kind: 'asset',
      creatorUsername,
      name,
      revision,
    };
  }
  if (!SEMVER_VERSION_REF_REGEX.test(rawVersion)) {
    return null;
  }
  if (kind === 'app') {
    return {
      kind: 'app',
      creatorUsername,
      name,
      version: rawVersion,
    };
  }
  if (kind === 'pack') {
    return {
      kind: 'pack',
      creatorUsername,
      name,
      version: rawVersion,
    };
  }
  if (kind === 'asset-spec') {
    return parseAssetSpecVersionRef(trimmed);
  }
  return null;
}

export function formatContentVersionRef(ref: ContentVersionRef): string {
  if (ref.kind === 'asset') {
    return `asset:${ref.creatorUsername}/${ref.name}@r${ref.revision}`;
  }
  if (ref.kind === 'app') {
    return `app:${ref.creatorUsername}/${ref.name}@${ref.version}`;
  }
  if (ref.kind === 'asset-spec') {
    return formatAssetSpecVersionRef(ref);
  }
  return `pack:${ref.creatorUsername}/${ref.name}@${ref.version}`;
}

export function isVersionNodeKind(value: unknown): value is VersionNodeKind {
  return typeof value === 'string' && (VERSION_NODE_KIND_VALUES as readonly string[]).includes(value);
}

export function isRelationType(value: unknown): value is RelationType {
  return typeof value === 'string' && (RELATION_TYPE_VALUES as readonly string[]).includes(value);
}
