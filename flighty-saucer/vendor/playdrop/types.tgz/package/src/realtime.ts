// ============================================================================
// WebSocket Protocol Types - Extracted from services/realtime-server/src/index.ts
// ============================================================================

/**
 * Error codes used in ServerError frames.
 */
export const PLAYDROP_REALTIME_TYPES_VERSION = 1 as const;

export const enum ErrorCode {
  Unknown = 0,
  BadOpcode = 1,
  InvalidPayload = 2,
  Unauthorized = 3,
  Forbidden = 4,
  NotFound = 5,
  RateLimited = 6,
  PayloadTooLarge = 7,
  Internal = 8,
}

export const enum ClientOpcode {
  Error = 0,
  Auth = 1,
  TimePing = 2,
  SetSelectedAvatar = 3,
  AppLogin = 4,
  UserAppDataOverride = 5,
  JoinRoom = 6,
  RoomDataOverride = 7,
  RoomLeave = 8,
  RoomEventJson = 9,
  RoomEventBinary = 10,
  ListRooms = 11,
  CreateRoom = 12,
  JoinRoomById = 13,
  JoinOrCreateRoom = 14,
}

export const enum ServerOpcode {
  Error = 0,
  AuthAck = 51,
  TimePong = 52,
  SetSelectedAvatarAck = 53,
  AppLoginAck = 54,
  UserAppDataOverrideAck = 55,
  JoinRoomAck = 56,
  RoomSnapshot = 57,
  RoomDataOverrideAck = 58,
  RoomDataUpdate = 59,
  RoomLeaveAck = 60,
  RoomLeaveBroadcast = 61,
  RoomEventJsonAck = 62,
  RoomEventJsonBroadcast = 63,
  RoomEventBinaryAck = 64,
  RoomEventBinaryBroadcast = 65,
  UserAppDataOverrideBroadcast = 66,
  ListRoomsAck = 67,
}

// ============================================================================
// Base Frame Types
// ============================================================================

export interface ServerError {
  opcode: 0;
  code: ErrorCode;
  message: string;
  ack: number;
}

export interface ClientRequest {
  opcode: ClientOpcode;
  seq: number;
}

export interface ServerResponse {
  opcode: ServerOpcode;
  ack: number;
}

// ============================================================================
// Authentication
// ============================================================================

export interface AuthRequest extends ClientRequest {
  opcode: ClientOpcode.Auth;
  token: string;
}

export interface AuthAck extends ServerResponse {
  opcode: ServerOpcode.AuthAck;
  userId: number;
  username: string;
  selectedAvatarId: number;
}

// ============================================================================
// Time Synchronization
// ============================================================================

export interface TimePingRequest extends ClientRequest {
  opcode: ClientOpcode.TimePing;
  t0ClientMs: number;
}

export interface TimePongResponse extends ServerResponse {
  opcode: ServerOpcode.TimePong;
  t1ServerMs: number;
  t2ServerMs: number;
}

// ============================================================================
// Avatar Management
// ============================================================================

export interface SetSelectedAvatarRequest extends ClientRequest {
  opcode: ClientOpcode.SetSelectedAvatar;
  avatarId: number;
}

export interface SetSelectedAvatarAck extends ServerResponse {
  opcode: ServerOpcode.SetSelectedAvatarAck;
}

// ============================================================================
// App Login
// ============================================================================

export interface AppLoginRequest extends ClientRequest {
  opcode: ClientOpcode.AppLogin;
  appId: number;
  ts: number;
  /** App version for room isolation (e.g., "1.2.3") */
  appVersion?: string;
}

export interface AppLoginResponse extends ServerResponse {
  opcode: ServerOpcode.AppLoginAck;
  appData: Record<string, any>;
  ts_arrival: number;
  username?: string | null;
  selectedAvatarId?: number | null;
  selectedProfileAssetRef?: string | null;
}

// ============================================================================
// User App Data
// ============================================================================

export interface UserAppDataOverrideRequest extends ClientRequest {
  opcode: ClientOpcode.UserAppDataOverride;
  appId: number;
  appData: Record<string, any>;
  ts: number;
}

export interface UserAppDataOverrideAck extends ServerResponse {
  opcode: ServerOpcode.UserAppDataOverrideAck;
}

export interface UserAppDataOverrideBroadcast extends ServerRoomBroadcast {
  opcode: ServerOpcode.UserAppDataOverrideBroadcast;
  appData: Record<string, any>;
}

// ============================================================================
// Room Management
// ============================================================================

export interface JoinRoomRequest extends ClientRequest {
  opcode: ClientOpcode.JoinRoom;
  appId: number;
  ts: number;
  /** App version for room isolation (e.g., "1.2.3") */
  appVersion?: string;
}

export type RoomConfigValue = string | number | boolean;
export type RoomConfig = Record<string, RoomConfigValue>;

export interface RoomSummary {
  id: number;
  config: RoomConfig;
  capacity: number;
  memberCount: number;
  createdAt: number;
  createdByUserId: number;
}

export interface ListRoomsRequest extends ClientRequest {
  opcode: ClientOpcode.ListRooms;
  limit?: number;
  cursor?: string;
  config?: RoomConfig;
  availableOnly?: boolean;
}

export interface ListRoomsAck extends ServerResponse {
  opcode: ServerOpcode.ListRoomsAck;
  rooms: Array<RoomSummary>;
  nextCursor: string | null;
}

export interface CreateRoomRequest extends ClientRequest {
  opcode: ClientOpcode.CreateRoom;
  config?: RoomConfig;
}

export interface JoinRoomByIdRequest extends ClientRequest {
  opcode: ClientOpcode.JoinRoomById;
  roomId: number;
}

export interface JoinOrCreateRoomRequest extends ClientRequest {
  opcode: ClientOpcode.JoinOrCreateRoom;
  config?: RoomConfig;
}

export interface ClientRoomBroadcast extends ClientRequest {
  roomId: number;
  ts: number;
  appId?: number;
}

export interface ServerRoomBroadcastAck extends ServerResponse {
  roomId: number;
  seq: number;
  ts_arrival: number;
}

export interface ServerRoomBroadcast {
  opcode: ServerOpcode;
  roomId: number;
  userId: number;
  seq: number;
  ts: number;
  ts_arrival: number;
}

export interface RoomMemberSnapshot {
  userId: number;
  username: string;
  selectedAvatarId: number;
  selectedProfileAssetRef: string;
  appData: Record<string, any>;
  roomData: Record<string, any>;
}

export interface JoinRoomAck extends ServerRoomBroadcastAck {
  opcode: ServerOpcode.JoinRoomAck;
  members: Array<RoomMemberSnapshot>;
  ts_created: number;
}

export interface JoinRoomBroadcast extends ServerRoomBroadcast {
  opcode: ServerOpcode.RoomSnapshot;
  member: RoomMemberSnapshot;
}

// ============================================================================
// Room Data Management
// ============================================================================

export interface RoomDataOverrideRequest extends ClientRoomBroadcast {
  opcode: ClientOpcode.RoomDataOverride;
  roomData: Record<string, any>;
}

export interface RoomDataOverrideAck extends ServerRoomBroadcastAck {
  opcode: ServerOpcode.RoomDataOverrideAck;
}

export interface RoomDataOverrideBroadcast extends ServerRoomBroadcast {
  opcode: ServerOpcode.RoomDataUpdate;
  roomData: Record<string, any>;
}

// ============================================================================
// Room Leave
// ============================================================================

export interface RoomLeaveRequest extends ClientRoomBroadcast {
  opcode: ClientOpcode.RoomLeave;
}

export interface RoomLeaveAck extends ServerRoomBroadcastAck {
  opcode: ServerOpcode.RoomLeaveAck;
}

export interface RoomLeaveBroadcast extends ServerRoomBroadcast {
  opcode: ServerOpcode.RoomLeaveBroadcast;
}

// ============================================================================
// Room Events - JSON
// ============================================================================

export interface RoomEventJsonSendRequest extends ClientRoomBroadcast {
  opcode: ClientOpcode.RoomEventJson;
  eventType: string;
  payload: Record<string, any>;
}

export interface RoomEventJsonAck extends ServerRoomBroadcastAck {
  opcode: ServerOpcode.RoomEventJsonAck;
}

export interface RoomEventJsonBroadcast extends ServerRoomBroadcast {
  opcode: ServerOpcode.RoomEventJsonBroadcast;
  eventType: string;
  payload: Record<string, any>;
}

// ============================================================================
// Room Events - Binary
// ============================================================================

export interface RoomEventBinarySendRequest extends ClientRoomBroadcast {
  opcode: ClientOpcode.RoomEventBinary;
  eventCode: number;
  payload: Float64Array;
}

export interface RoomEventBinaryAck extends ServerRoomBroadcastAck {
  opcode: ServerOpcode.RoomEventBinaryAck;
}

export interface RoomEventBinaryBroadcast extends ServerRoomBroadcast {
  opcode: ServerOpcode.RoomEventBinaryBroadcast;
  eventCode: number;
  payload: Float64Array;
}

// ============================================================================
// Union Types
// ============================================================================

export type ClientFrame =
  | AuthRequest
  | TimePingRequest
  | SetSelectedAvatarRequest
  | AppLoginRequest
  | UserAppDataOverrideRequest
  | ListRoomsRequest
  | CreateRoomRequest
  | JoinRoomByIdRequest
  | JoinOrCreateRoomRequest
  | RoomDataOverrideRequest
  | JoinRoomRequest
  | RoomLeaveRequest
  | RoomEventJsonSendRequest
  | RoomEventBinarySendRequest;

export type ServerFrame =
  | AuthAck
  | TimePongResponse
  | SetSelectedAvatarAck
  | AppLoginResponse
  | UserAppDataOverrideAck
  | ListRoomsAck
  | RoomDataOverrideAck
  | JoinRoomAck
  | RoomLeaveAck
  | RoomEventJsonAck
  | RoomEventBinaryAck
  | ServerError;

// ============================================================================
// Connection State Types
// ============================================================================

export interface ConnectionContext {
  userId: number;
  username: string;
  selectedAvatarId: number;
  selectedProfileAssetRef: string;
  authenticated: boolean;
  activeRoomId?: number;
  appId: number | null;
  appVersion: string | null;
}

export interface RoomState {
  id: number;
  runtimeEnv: 'dev' | 'live';
  appId: number;
  appVersion: string | null;
  members: Set<unknown>; // WebSocket in actual implementation
  memberRoomData: Map<number, Record<string, any>>;
  capacity: number;
  isLegacy: boolean;
  seq: number;
  tsCreated: number;
}
