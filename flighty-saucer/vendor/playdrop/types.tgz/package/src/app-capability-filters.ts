import type { AppSurface } from './app.js';
import type { AppAuthMode, AppControllerMode } from './version.js';

export const APP_AUTH_FILTER_VALUES = ['required', 'optional', 'none'] as const;
export type AppAuthFilter = (typeof APP_AUTH_FILTER_VALUES)[number];

export const APP_CONTROLLER_FILTER_VALUES = ['required', 'optional', 'none'] as const;
export type AppControllerFilter = (typeof APP_CONTROLLER_FILTER_VALUES)[number];

export const APP_SURFACE_FILTER_VALUES = ['desktop', 'mobile-portrait', 'mobile-landscape'] as const;
export type AppSurfaceFilter = (typeof APP_SURFACE_FILTER_VALUES)[number];

export type AppCapabilityFilters = {
  auth?: AppAuthFilter;
  controller?: AppControllerFilter;
  surface?: AppSurfaceFilter;
};

export function isAppAuthFilter(value: unknown): value is AppAuthFilter {
  if (typeof value !== 'string') {
    return false;
  }
  return (APP_AUTH_FILTER_VALUES as readonly string[]).includes(value.trim().toLowerCase());
}

export function parseAppAuthFilter(value: unknown): AppAuthFilter | null {
  if (typeof value !== 'string') {
    return null;
  }
  const normalized = value.trim().toLowerCase();
  return isAppAuthFilter(normalized) ? (normalized as AppAuthFilter) : null;
}

export function isAppControllerFilter(value: unknown): value is AppControllerFilter {
  if (typeof value !== 'string') {
    return false;
  }
  return (APP_CONTROLLER_FILTER_VALUES as readonly string[]).includes(value.trim().toLowerCase());
}

export function parseAppControllerFilter(value: unknown): AppControllerFilter | null {
  if (typeof value !== 'string') {
    return null;
  }
  const normalized = value.trim().toLowerCase();
  return isAppControllerFilter(normalized) ? (normalized as AppControllerFilter) : null;
}

export function isAppSurfaceFilter(value: unknown): value is AppSurfaceFilter {
  if (typeof value !== 'string') {
    return false;
  }
  return (APP_SURFACE_FILTER_VALUES as readonly string[]).includes(value.trim().toLowerCase());
}

export function parseAppSurfaceFilter(value: unknown): AppSurfaceFilter | null {
  if (typeof value !== 'string') {
    return null;
  }
  const normalized = value.trim().toLowerCase();
  return isAppSurfaceFilter(normalized) ? (normalized as AppSurfaceFilter) : null;
}

export function mapAppAuthFilterToMode(value: AppAuthFilter): AppAuthMode {
  if (value === 'required') {
    return 'REQUIRED';
  }
  if (value === 'optional') {
    return 'OPTIONAL';
  }
  return 'NONE';
}

export function mapAppControllerFilterToMode(value: AppControllerFilter): AppControllerMode {
  if (value === 'required') {
    return 'REQUIRED';
  }
  if (value === 'optional') {
    return 'SUPPORTED';
  }
  return 'UNSUPPORTED';
}

export function mapAppSurfaceFilterToSurface(value: AppSurfaceFilter): AppSurface {
  if (value === 'desktop') {
    return 'DESKTOP';
  }
  if (value === 'mobile-portrait') {
    return 'MOBILE_PORTRAIT';
  }
  return 'MOBILE_LANDSCAPE';
}

export function hasAppCapabilityFilters(value: AppCapabilityFilters | null | undefined): boolean {
  return Boolean(value?.auth || value?.controller || value?.surface);
}
