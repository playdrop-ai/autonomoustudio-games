import { cloneEntity } from '../../entity-utils';
import { determineTexturedBoxRenderMode, resolveOverlayFaceTextureId } from '../../textures';
import type {
  BoxelDefinition,
  Material,
  Primitive,
  TexturedBox,
  VoxelBox,
} from '../../types';
import type { BoxelValidationIssue } from '../../validation';
import { validateBoxel } from '../../validation';
import { convertTexturedBoxesToVoxel, type OverlayVoxelMode } from '../voxels/textured-to-voxel';
import { mergeOverlayIntoBase } from './merge-overlay';

export type LayerMode = 'base_only' | 'flat' | 'overlay' | 'voxel';

export interface LayerModeOptions {
  voxelMode?: OverlayVoxelMode;
  stripAlpha?: boolean;
  transparentFillColor?: [number, number, number];
}

type FaceKey = 'north' | 'south' | 'east' | 'west' | 'top' | 'bottom';

const FACE_KEYS: FaceKey[] = ['north', 'south', 'east', 'west', 'top', 'bottom'];
const OVERLAY_PROPS: Array<keyof TexturedBox> = [
  'northOverlay',
  'southOverlay',
  'eastOverlay',
  'westOverlay',
  'topOverlay',
  'bottomOverlay',
  'sidesOverlay',
  'allOverlay',
];

const stripOverlay = (primitive: TexturedBox): void => {
  const target = primitive as unknown as Record<string, string | undefined>;
  OVERLAY_PROPS.forEach(prop => {
    target[prop as string] = undefined;
  });
};

const buildOverlayPrimitive = (primitive: TexturedBox): TexturedBox | undefined => {
  const overlayTextures: Array<{ face: FaceKey; textureId: string }> = [];
  FACE_KEYS.forEach(face => {
    const textureId = resolveOverlayFaceTextureId(primitive, face);
    if (typeof textureId === 'string' && textureId.length > 0) {
      overlayTextures.push({ face, textureId });
    }
  });
  if (overlayTextures.length === 0) {
    return undefined;
  }

  const overlay: TexturedBox = {
    id: `${primitive.id}_overlay_source`,
    kind: 'textured_box',
    size: primitive.size ? ([...primitive.size] as [number, number, number]) : [1, 1, 1],
  } as TexturedBox;

  overlayTextures.forEach(({ face, textureId }) => {
    overlay[face] = textureId;
  });

  return overlay;
};

const FACE_NAMES: Array<keyof TexturedBox> = ['north', 'south', 'east', 'west', 'top', 'bottom'];

const hasOverlayFaces = (primitive: TexturedBox): boolean =>
  FACE_NAMES.some(face => {
    const value = primitive[face];
    return typeof value === 'string' && value.length > 0;
  });

const convertPrimitiveToVoxel = (
  entity: BoxelDefinition,
  primitive: TexturedBox,
  mode: OverlayVoxelMode
): VoxelBox => {
  const textureLookup = new Map(entity.textures.map(entry => [entry.id, entry] as const));
  const patternLookup = new Map(entity.patterns.map(entry => [entry.id, entry] as const));
  const materialLookup = new Map(entity.materials.map(entry => [entry.id, entry] as const));

  let overlayPrimitive = buildOverlayPrimitive(primitive);
  if (overlayPrimitive && primitive.id === 'torso_primitive') {
    overlayPrimitive.top = undefined;
    overlayPrimitive.bottom = undefined;
    if (Array.isArray(overlayPrimitive.size) && overlayPrimitive.size.length >= 3) {
      overlayPrimitive.size = overlayPrimitive.size.map(value => Math.max(1, Math.round(value ?? 1) - 2)) as [
        number,
        number,
        number,
      ];
    }
    if (!hasOverlayFaces(overlayPrimitive)) {
      overlayPrimitive = undefined;
    }
  }

  return convertTexturedBoxesToVoxel({
    base: primitive,
    overlay: overlayPrimitive,
    textureLookup,
    patternLookup,
    materialLookup,
    mode,
    targetId: primitive.id,
  });
};

const transformPrimitiveLayer = (
  entity: BoxelDefinition,
  primitive: Primitive,
  mode: LayerMode,
  voxelMode: OverlayVoxelMode
): Primitive => {
  if (primitive.kind !== 'textured_box') {
    return primitive;
  }
  const textured = primitive as TexturedBox;
  if (mode === 'overlay') {
    return textured;
  }
  if (mode === 'base_only') {
    stripOverlay(textured);
    return textured;
  }
  if (mode === 'flat') {
    mergeOverlayIntoBase(entity, textured);
    stripOverlay(textured);
    textured.renderMode = determineTexturedBoxRenderMode(entity, textured);
    return textured;
  }
  if (mode === 'voxel') {
    return convertPrimitiveToVoxel(entity, textured, voxelMode);
  }
  return textured;
};

const stripPrimitiveRenderMode = (primitive: Primitive): void => {
  if (primitive.kind === 'textured_box' && primitive.renderMode === 'cutout') {
    primitive.renderMode = undefined;
  }
};

const enforceOpaqueMaterials = (
  materials: Material[],
  fillColor: [number, number, number],
  stripAlpha: boolean
): void => {
  if (!stripAlpha) {
    return;
  }

  const [fillR, fillG, fillB] = fillColor;
  materials.forEach(material => {
    const opacity = material.opacity ?? 1;
    if (opacity <= 0) {
      material.baseColor = [fillR, fillG, fillB];
    }
    if (material.opacity !== undefined) {
      delete material.opacity;
    }
  });
};

export function applyLayerMode(
  entity: BoxelDefinition,
  mode: LayerMode,
  options?: LayerModeOptions | OverlayVoxelMode
): BoxelDefinition {
  if (mode === 'overlay') {
    return entity;
  }

  const opts: LayerModeOptions =
    typeof options === 'string' ? { voxelMode: options } : options ?? {};
  const voxelMode = opts.voxelMode ?? 'outer_wrap';
  const stripAlpha = opts.stripAlpha ?? false;
  const fillColor: [number, number, number] = opts.transparentFillColor ?? [0, 0, 0];

  const transformed = cloneEntity(entity);
  const primitives: Primitive[] = [];

  transformed.primitives.forEach(primitive => {
    const result = transformPrimitiveLayer(transformed, primitive, mode, voxelMode);
    if (Array.isArray(result)) {
      primitives.push(...(result as Primitive[]));
    } else {
      primitives.push(result);
    }
  });

  if (mode === 'flat' && stripAlpha) {
    primitives.forEach(stripPrimitiveRenderMode);
    enforceOpaqueMaterials(transformed.materials, fillColor, stripAlpha);
  }

  transformed.primitives = primitives;

  const { issues } = validateBoxel(transformed);
  if (issues.length > 0) {
    const summary = (issues as BoxelValidationIssue[])
      .slice(0, 3)
      .map(issue => `${issue.path}: ${issue.message}`)
      .join('; ');
    throw new Error(`Layer transformation produced invalid entity — ${summary}`);
  }

  return transformed;
}
