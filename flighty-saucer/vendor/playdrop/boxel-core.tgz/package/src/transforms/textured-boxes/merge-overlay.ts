import { resolveFaceTextureId, resolveOverlayFaceTextureId } from '../../textures';
import type { BoxelDefinition, TexturedBox } from '../../types';
import type { FaceName } from './infer-face';

const FACE_NAMES: FaceName[] = ['north', 'south', 'east', 'west', 'top', 'bottom'];

const getFaceTexture = (primitive: TexturedBox, face: FaceName): string | undefined => {
  switch (face) {
    case 'north':
      return primitive.north;
    case 'south':
      return primitive.south;
    case 'east':
      return primitive.east;
    case 'west':
      return primitive.west;
    case 'top':
      return primitive.top;
    case 'bottom':
      return primitive.bottom;
    default:
      return undefined;
  }
};

const setFaceTexture = (primitive: TexturedBox, face: FaceName, textureId: string | undefined): void => {
  switch (face) {
    case 'north':
      primitive.north = textureId;
      break;
    case 'south':
      primitive.south = textureId;
      break;
    case 'east':
      primitive.east = textureId;
      break;
    case 'west':
      primitive.west = textureId;
      break;
    case 'top':
      primitive.top = textureId;
      break;
    case 'bottom':
      primitive.bottom = textureId;
      break;
    default:
      break;
  }
};

export function mergeOverlayIntoBase(entity: BoxelDefinition, primitive: TexturedBox): void {
  const textureLookup = new Map(entity.textures.map(entry => [entry.id, entry] as const));
  const patternLookup = new Map(entity.patterns.map(entry => [entry.id, entry] as const));
  const materialLookup = new Map(entity.materials.map(entry => [entry.id, entry] as const));

  FACE_NAMES.forEach(face => {
    const overlayTextureId = resolveOverlayFaceTextureId(primitive, face);
    if (!overlayTextureId) {
      return;
    }
    const baseTextureId = resolveFaceTextureId(primitive, face) ?? getFaceTexture(primitive, face);
    if (!baseTextureId) {
      setFaceTexture(primitive, face, overlayTextureId);
      return;
    }

    const overlayTexture = textureLookup.get(overlayTextureId);
    const overlayPattern = overlayTexture ? patternLookup.get(overlayTexture.pattern) : undefined;
    if (!overlayTexture || !overlayPattern) {
      return;
    }

    const baseTexture = textureLookup.get(baseTextureId);
    const basePattern = baseTexture ? patternLookup.get(baseTexture.pattern) : undefined;
    if (!baseTexture || !basePattern) {
      setFaceTexture(primitive, face, overlayTextureId);
      return;
    }

    const baseData = Array.isArray(basePattern.data) ? basePattern.data.slice() : [];
    const overlayData = Array.isArray(overlayPattern.data) ? overlayPattern.data : [];

    const materialIndexLookup = new Map<string, number>();
    baseTexture.materials.forEach((materialId, idx) => {
      if (!materialIndexLookup.has(materialId)) {
        materialIndexLookup.set(materialId, idx);
      }
    });

    const ensureMaterialIndex = (materialId: string | undefined): number | undefined => {
      if (!materialId) {
        return undefined;
      }
      const existing = materialIndexLookup.get(materialId);
      if (existing !== undefined) {
        return existing;
      }
      const nextIndex = baseTexture.materials.length;
      baseTexture.materials.push(materialId);
      materialIndexLookup.set(materialId, nextIndex);
      return nextIndex;
    };

    const opaqueOverlayIndex = (overlayValue: number | undefined): number | undefined => {
      if (overlayValue === undefined) {
        return undefined;
      }
      const overlayMaterialId = overlayTexture.materials[overlayValue];
      if (!overlayMaterialId) {
        return undefined;
      }
      const overlayMaterial = materialLookup.get(overlayMaterialId);
      if (overlayMaterial && typeof overlayMaterial.opacity === 'number' && overlayMaterial.opacity <= 0) {
        return undefined;
      }
      const mapped = ensureMaterialIndex(overlayMaterialId);
      return mapped;
    };

    const combined = baseData.map((value, index) => {
      const overlayValue = overlayData[index];
      const mappedIndex = opaqueOverlayIndex(overlayValue);
      if (mappedIndex === undefined) {
        return value;
      }
      return mappedIndex;
    });

    basePattern.data = combined;
    basePattern.size = [...overlayPattern.size];
  });
}
