import { cloneEntity } from '../entity-utils';
import type {
  BoxelDefinition,
  ComboBox,
  Node,
  Pattern,
  PlainBox,
  Primitive,
  TexturedBox,
  Vec3,
  VoxelBox
} from '../types';
import { validateBoxel } from '../validation';

const DEFAULT_SCALE: Vec3 = [1, 1, 1];
const EPSILON = 1e-6;

const toNumber = (value: unknown): number => {
  const result = Number(value);
  return Number.isFinite(result) ? result : 0;
};

const round = (value: number): number => Math.round(value * 1e6) / 1e6;

const scaleVec = (input: Vec3 | undefined, factor: number): Vec3 | undefined => {
  if (!Array.isArray(input)) {
    return undefined;
  }
  return [
    round(toNumber(input[0]) * factor),
    round(toNumber(input[1]) * factor),
    round(toNumber(input[2]) * factor),
  ];
};

const divideVec = (input: Vec3 | undefined, factor: number): Vec3 => {
  const source = Array.isArray(input) ? input : DEFAULT_SCALE;
  return [
    round(toNumber(source[0]) / factor),
    round(toNumber(source[1]) / factor),
    round(toNumber(source[2]) / factor),
  ];
};

const upscalePatternInPlace = (pattern: Pattern, factor: number): void => {
  const width = Math.max(1, Math.round(toNumber(pattern.size?.[0])));
  const height = Math.max(1, Math.round(toNumber(pattern.size?.[1])));
  const source = Array.isArray(pattern.data) ? pattern.data.slice() : [];
  const scaledWidth = width * factor;
  const scaledHeight = height * factor;
  const scaled = new Array<number>(scaledWidth * scaledHeight).fill(0);

  for (let y = 0; y < height; y += 1) {
    for (let x = 0; x < width; x += 1) {
      const value = source[y * width + x] ?? 0;
      for (let dy = 0; dy < factor; dy += 1) {
        for (let dx = 0; dx < factor; dx += 1) {
          const targetX = x * factor + dx;
          const targetY = y * factor + dy;
          scaled[targetY * scaledWidth + targetX] = value;
        }
      }
    }
  }

  pattern.size = [scaledWidth, scaledHeight];
  pattern.data = scaled;
};

const upscaleVoxelInPlace = (voxel: VoxelBox, factor: number): void => {
  const [sx, sy, sz] = voxel.size;
  const nx = Math.max(1, Math.round(sx * factor));
  const ny = Math.max(1, Math.round(sy * factor));
  const nz = Math.max(1, Math.round(sz * factor));
  const source = voxel.voxels ?? [];
  const result = new Array<number>(nx * ny * nz).fill(0);

  const sourceIndex = (x: number, y: number, z: number): number => x + sx * (y + sy * z);
  const targetIndex = (x: number, y: number, z: number): number => x + nx * (y + ny * z);

  for (let z = 0; z < sz; z += 1) {
    for (let y = 0; y < sy; y += 1) {
      for (let x = 0; x < sx; x += 1) {
        const value = source[sourceIndex(x, y, z)] ?? 0;
        if (value === 0) continue;
        for (let dz = 0; dz < factor; dz += 1) {
          for (let dy = 0; dy < factor; dy += 1) {
            for (let dx = 0; dx < factor; dx += 1) {
              const tx = x * factor + dx;
              const ty = y * factor + dy;
              const tz = z * factor + dz;
              result[targetIndex(tx, ty, tz)] = value;
            }
          }
        }
      }
    }
  }

  voxel.size = [nx, ny, nz];
  voxel.voxels = result;
};

const upscalePrimitive = (primitive: Primitive, factor: number): void => {
  switch (primitive.kind) {
    case 'plain_box': {
      const box = primitive as PlainBox;
      box.size = box.size.map(value => round(toNumber(value) * factor)) as [number, number, number];
      break;
    }
    case 'textured_box': {
      const box = primitive as TexturedBox;
      if (Array.isArray(box.size)) {
        box.size = box.size.map(value => round(toNumber(value) * factor)) as [number, number, number];
      }
      break;
    }
    case 'voxel_box': {
      upscaleVoxelInPlace(primitive as VoxelBox, factor);
      break;
    }
    case 'combo_box': {
      const combo = primitive as ComboBox;
      if (Array.isArray(combo.size)) {
        combo.size = combo.size.map(value => round(toNumber(value) * factor)) as [number, number, number];
      }
      combo.slots.forEach(slot => {
        slot.offset = slot.offset.map(value => round(toNumber(value) * factor)) as [number, number, number];
      });
      break;
    }
    default:
      break;
  }
};

const scalePrimitiveSizes = (entity: BoxelDefinition, factor: number): void => {
  if (Math.abs(Math.round(factor) - factor) > EPSILON) {
    throw new Error('Upscale factor must be an integer for primitive scaling');
  }
  const intFactor = Math.max(1, Math.round(factor));
  if (intFactor === 1) {
    return;
  }

  entity.primitives.forEach(primitive => {
    upscalePrimitive(primitive, intFactor);
  });
};

const upscaleEntityPrimitives = (entity: BoxelDefinition, factor: number): void => {
  if (Math.abs(Math.round(factor) - factor) > EPSILON) {
    throw new Error('Upscale factor must be an integer for primitive scaling');
  }
  const intFactor = Math.max(1, Math.round(factor));
  if (intFactor === 1) {
    return;
  }

  entity.patterns.forEach(pattern => {
    upscalePatternInPlace(pattern, intFactor);
  });

  scalePrimitiveSizes(entity, factor);
};

const scaleNode = (node: Node, factor: number): void => {
  if (node.position) {
    node.position = scaleVec(node.position, factor) ?? node.position;
  }
  if (node.center) {
    node.center = scaleVec(node.center, factor) ?? node.center;
  }
  if (node.size) {
    node.size = scaleVec(node.size, factor) ?? node.size;
  }
  node.children?.forEach(child => scaleNode(child, factor));
};

const scaleAnimationPositions = (entity: BoxelDefinition, factor: number): void => {
  entity.animations?.forEach(animation => {
    animation.channels?.forEach(channel => {
      if (channel.property !== 'position') {
        return;
      }
      channel.keyframes?.forEach(keyframe => {
        const value = keyframe.value;
        if (!Array.isArray(value)) {
          return;
        }
        keyframe.value = [
          round(toNumber(value[0]) * factor),
          round(toNumber(value[1]) * factor),
          round(toNumber(value[2]) * factor),
        ];
      });
    });
  });
};

interface UpscaleInternalOptions {
  scaleTextures: boolean;
}

function upscaleEntityInternal(entity: BoxelDefinition, factor = 2, options: UpscaleInternalOptions): BoxelDefinition {
  if (factor <= EPSILON) {
    throw new Error('Scale factor must be greater than zero');
  }
  const clone = cloneEntity(entity);

  if (!clone.geometry?.root) {
    return clone;
  }

  if (!clone.geometry.root.scale || !Array.isArray(clone.geometry.root.scale)) {
    clone.geometry.root.scale = [...DEFAULT_SCALE];
  }

  clone.geometry.root.scale = divideVec(clone.geometry.root.scale, factor);
  scaleNode(clone.geometry.root, factor);
  scaleAnimationPositions(clone, factor);
  if (options.scaleTextures) {
    upscaleEntityPrimitives(clone, factor);
  } else {
    scalePrimitiveSizes(clone, factor);
  }

  const { issues } = validateBoxel(clone);
  if (issues.length > 0) {
    const summary = issues
      .slice(0, 3)
      .map(issue => `${issue.path}: ${issue.message}`)
      .join('; ');
    throw new Error(`Upscaled entity failed validation — ${summary}`);
  }

  return clone;
}

export function upscaleEntity(entity: BoxelDefinition, factor = 2): BoxelDefinition {
  return upscaleEntityInternal(entity, factor, { scaleTextures: true });
}

export function upscaleEntityGeometry(entity: BoxelDefinition, factor = 2): BoxelDefinition {
  return upscaleEntityInternal(entity, factor, { scaleTextures: false });
}
