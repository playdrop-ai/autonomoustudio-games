import { collectFaceTextureIds, resolveFaceTextureId, resolveOverlayFaceTextureId } from './textures';
import type {
  Animation,
  AnimationChannel,
  BoxelDefinition,
  ComboBox,
  ConnectMode,
  Material,
  Node,
  Pattern,
  Primitive,
  Texture,
  TexturedBox,
  Vec2,
  Vec3,
  VoxelBox,
} from './types';

const VEC2_LENGTH = 2;
const VEC3_LENGTH = 3;

const CONNECT_MODES: ConnectMode[] = ['none', 'child', 'parent', 'both'];

const isConnectMode = (value: unknown): value is ConnectMode => typeof value === 'string' && CONNECT_MODES.includes(value as ConnectMode);

export interface BoxelValidationIssue {
  path: string;
  message: string;
}

export class BoxelValidationError extends Error {
  readonly issues: BoxelValidationIssue[];

  constructor(message: string, issues: BoxelValidationIssue[]) {
    super(message);
    this.issues = issues;
    this.name = 'BoxelValidationError';
  }
}

const sanitizeMessage = (error: unknown): string => {
  if (!error) return 'Unknown validation error';
  if (typeof error === 'string') return error;
  if (error instanceof Error) return error.message;
  if (typeof error === 'object' && 'message' in error) {
    const candidate = (error as { message?: unknown }).message;
    return typeof candidate === 'string' ? candidate : 'Unknown validation error';
  }
  return String(error);
};

const pushIssue = (issues: BoxelValidationIssue[], path: string, error: unknown) => {
  issues.push({ path, message: sanitizeMessage(error) });
};

export function isTupleOfNumbers(value: unknown, expectedLength: number): value is number[] {
  return Array.isArray(value) && value.length === expectedLength && value.every(item => typeof item === 'number' && Number.isFinite(item));
}

export function assertVec3(value: unknown, context: string): asserts value is Vec3 {
  if (!isTupleOfNumbers(value, VEC3_LENGTH)) {
    throw new Error(`Invalid Vec3 for ${context}`);
  }
}

export function assertVec2(value: unknown, context: string): asserts value is Vec2 {
  if (!isTupleOfNumbers(value, VEC2_LENGTH)) {
    throw new Error(`Invalid Vec2 for ${context}`);
  }
}

export function assertPattern(value: unknown, index: number): asserts value is Pattern {
  if (!value || typeof value !== 'object') {
    throw new Error(`Pattern at index ${index} must be an object`);
  }

  const pattern = value as Partial<Pattern>;
  if (typeof pattern.id !== 'string') {
    throw new Error(`Pattern at index ${index} is missing id`);
  }

  assertVec2(pattern.size as unknown, `pattern ${pattern.id} size`);
  const patternSize = pattern.size as [number, number];

  if (!Array.isArray(pattern.data) || !pattern.data.every(cell => Number.isInteger(cell) && cell >= 0)) {
    throw new Error(`Pattern ${pattern.id} data must be an array of non-negative integers`);
  }

  const expectedLength = patternSize[0] * patternSize[1];
  if (pattern.data.length !== expectedLength) {
    throw new Error(`Pattern ${pattern.id} data length ${pattern.data.length} does not match expected size ${expectedLength}`);
  }
}

export function assertMaterial(value: unknown, index: number): asserts value is Material {
  if (!value || typeof value !== 'object') {
    throw new Error(`Material at index ${index} must be an object`);
  }

  const material = value as Partial<Material>;
  if (typeof material.id !== 'string') {
    throw new Error(`Material at index ${index} is missing id`);
  }

  assertVec3(material.baseColor as unknown, `material ${material.id} baseColor`);

  if (material.emissiveColor !== undefined) {
    assertVec3(material.emissiveColor as unknown, `material ${material.id} emissiveColor`);
  }

  if (material.opacity !== undefined && (typeof material.opacity !== 'number' || !Number.isFinite(material.opacity))) {
    throw new Error(`Material ${material.id} opacity must be a finite number`);
  }
}

export function assertTexture(value: unknown, index: number): asserts value is Texture {
  if (!value || typeof value !== 'object') {
    throw new Error(`Texture at index ${index} must be an object`);
  }

  const texture = value as Partial<Texture>;
  if (typeof texture.id !== 'string') {
    throw new Error(`Texture at index ${index} is missing id`);
  }

  if (typeof texture.pattern !== 'string') {
    throw new Error(`Texture ${texture.id} pattern must be a string`);
  }

  if (!Array.isArray(texture.materials) || !texture.materials.every(id => typeof id === 'string')) {
    throw new Error(`Texture ${texture.id} materials must be an array of strings`);
  }
}

function assertPlainBox(primitive: Primitive, context: string): asserts primitive is Primitive & { kind: 'plain_box'; material: string } {
  if (primitive.kind !== 'plain_box') {
    throw new Error(`${context} expected kind plain_box`);
  }
  if (typeof (primitive as { material?: unknown }).material !== 'string') {
    throw new Error(`${context} material must be a string`);
  }
}

function assertTexturedBox(primitive: Primitive, context: string): asserts primitive is TexturedBox {
  if (primitive.kind !== 'textured_box') {
    throw new Error(`${context} expected kind textured_box`);
  }

  const candidate = primitive as TexturedBox;
  const faces: Array<keyof TexturedBox> = ['top', 'bottom', 'north', 'south', 'east', 'west', 'sides', 'all'];
  faces.forEach(face => {
    const value = candidate[face];
    if (value !== undefined && typeof value !== 'string') {
      throw new Error(`${context} face ${face} must be a string id`);
    }
  });
}

function assertVoxelBox(primitive: Primitive, context: string): asserts primitive is VoxelBox {
  if (primitive.kind !== 'voxel_box') {
    throw new Error(`${context} expected kind voxel_box`);
  }

  const candidate = primitive as VoxelBox;
  if (!Array.isArray(candidate.voxels) || !candidate.voxels.every(cell => typeof cell === 'number')) {
    throw new Error(`${context} voxels must be an array of numbers`);
  }
  if (candidate.palette !== undefined) {
    if (!Array.isArray(candidate.palette) || !candidate.palette.every(entry => typeof entry === 'string')) {
      throw new Error(`${context} palette must be an array of material ids`);
    }
  }
  const size = (primitive as VoxelBox).size;
  assertVec3(size as unknown, `${context} size`);
  const dims = size.map(axis => Math.round(axis));
  if (dims.some(value => value <= 0 || !Number.isFinite(value))) {
    throw new Error(`${context} size must contain positive finite numbers`);
  }
  const expected = dims[0] * dims[1] * dims[2];
  if (candidate.voxels.length !== expected) {
    throw new Error(`${context} voxels length ${candidate.voxels.length} does not match size product ${expected}`);
  }
}

function assertComboBox(primitive: Primitive, context: string): asserts primitive is ComboBox {
  if (primitive.kind !== 'combo_box') {
    throw new Error(`${context} expected kind combo_box`);
  }

  const candidate = primitive as ComboBox;
  if (!Array.isArray(candidate.slots)) {
    throw new Error(`${context} slots must be an array`);
  }

  candidate.slots.forEach((slot, idx) => {
    if (!slot || typeof slot !== 'object') {
      throw new Error(`${context} slot ${idx} must be an object`);
    }
    const slotId = (slot as { id?: unknown }).id;
    if (slotId !== undefined && typeof slotId !== 'string') {
      throw new Error(`${context} slot ${idx} id must be a string when provided`);
    }
    if (typeof slot.primitive !== 'string') {
      throw new Error(`${context} slot ${idx} primitive must be a string`);
    }
    assertVec3(slot.offset as unknown, `${context} slot ${idx} offset`);
  });
}

export function assertPrimitive(value: unknown, index: number): asserts value is Primitive {
  if (!value || typeof value !== 'object') {
    throw new Error(`Primitive at index ${index} must be an object`);
  }

  const primitive = value as Primitive;
  if (typeof primitive.id !== 'string') {
    throw new Error(`Primitive at index ${index} is missing id`);
  }

  const primitiveId = primitive.id;
  if (typeof primitive.kind !== 'string') {
    throw new Error(`Primitive ${primitiveId} kind must be a string discriminator`);
  }

  assertVec3(primitive.size as unknown, `primitive ${primitiveId} size`);

  switch (primitive.kind) {
    case 'plain_box':
      assertPlainBox(primitive, `primitive ${primitiveId}`);
      break;
    case 'textured_box':
      assertTexturedBox(primitive, `primitive ${primitiveId}`);
      break;
    case 'voxel_box':
      assertVoxelBox(primitive, `primitive ${primitiveId}`);
      break;
    case 'combo_box':
      assertComboBox(primitive, `primitive ${primitiveId}`);
      break;
    default: {
      const unknownKind = (value as { kind?: unknown }).kind;
      throw new Error(`Unknown primitive kind ${String(unknownKind)} for primitive ${primitiveId}`);
    }
  }
}

const animationProperties: AnimationChannel['property'][] = ['position', 'rotation', 'scale'];

function assertAnimationChannel(value: unknown, context: string): asserts value is AnimationChannel {
  if (!value || typeof value !== 'object') {
    throw new Error(`${context} channel must be an object`);
  }
  const channel = value as Partial<AnimationChannel>;
  if (typeof channel.node !== 'string') {
    throw new Error(`${context} channel node must be a string`);
  }
  if (!animationProperties.includes(channel.property as AnimationChannel['property'])) {
    throw new Error(`${context} channel property must be one of ${animationProperties.join(', ')}`);
  }
  if (!Array.isArray(channel.keyframes)) {
    throw new Error(`${context} keyframes must be an array`);
  }
  channel.keyframes.forEach((keyframe, idx) => {
    if (!keyframe || typeof keyframe !== 'object') {
      throw new Error(`${context} keyframe ${idx} must be an object`);
    }
    const reference = keyframe as AnimationChannel['keyframes'][number];
    if (typeof reference.time !== 'number' || !Number.isFinite(reference.time) || reference.time < 0) {
      throw new Error(`${context} keyframe ${idx} time must be a non-negative number`);
    }
    assertVec3(reference.value as unknown, `${context} keyframe ${idx} value`);
  });
}

export function assertAnimation(value: unknown, index: number): asserts value is Animation {
  if (!value || typeof value !== 'object') {
    throw new Error(`Animation at index ${index} must be an object`);
  }
  const animation = value as Partial<Animation>;
  if (typeof animation.id !== 'string' || !animation.id) {
    throw new Error(`Animation at index ${index} is missing id`);
  }
  if (typeof animation.duration !== 'number' || !Number.isFinite(animation.duration) || animation.duration < 0) {
    throw new Error(`Animation ${animation.id} duration must be a non-negative finite number`);
  }
  if (!Array.isArray(animation.channels)) {
    throw new Error(`Animation ${animation.id} channels must be an array`);
  }
  animation.channels.forEach((channel, channelIndex) => assertAnimationChannel(channel, `animation ${animation.id} channel ${channelIndex}`));
}

const FACE_DIMENSIONS: Record<'top' | 'bottom' | 'north' | 'south' | 'east' | 'west' | 'sides' | 'all', (size: Vec3) => [number, number]> = {
  top: size => [size[0], size[2]],
  bottom: size => [size[0], size[2]],
  north: size => [size[0], size[1]],
  south: size => [size[0], size[1]],
  east: size => [size[2], size[1]],
  west: size => [size[2], size[1]],
  sides: () => [0, 0],
  all: () => [0, 0],
};

function normalizeDimension(value: number): number {
  if (!Number.isFinite(value)) {
    return NaN;
  }
  return Math.abs(Math.round(value));
}

export function assertTexturedBoxFaceSizes(
  box: TexturedBox,
  textureLookup: Map<string, Texture>,
  patternLookup: Map<string, Pattern>,
  materialLookup: Map<string, Material>
): void {
  const size = box.size as Vec3;
  const [sizeX, sizeY, sizeZ] = size;
  [sizeX, sizeY, sizeZ].forEach((component, idx) => {
    if (!Number.isFinite(component)) {
      throw new Error(`primitive ${box.id} size component ${idx} must be finite to validate textures`);
    }
  });

  const normalizedSize: Vec3 = [
    normalizeDimension(sizeX),
    normalizeDimension(sizeY),
    normalizeDimension(sizeZ),
  ];

  if (normalizedSize.some(dimension => dimension === 0)) {
    throw new Error(`primitive ${box.id} must not contain zero-sized dimensions for textured faces`);
  }

  (['top', 'bottom', 'north', 'south', 'east', 'west'] as const).forEach(face => {
    const textureId = resolveFaceTextureId(box, face);
    if (!textureId) {
      return;
    }
    const texture = textureLookup.get(textureId);
    if (!texture) {
      throw new Error(`primitive ${box.id} face ${face} references missing texture ${textureId}`);
    }
    const pattern = patternLookup.get(texture.pattern);
    if (!pattern) {
      throw new Error(`texture ${texture.id} referenced by primitive ${box.id} face ${face} is missing pattern ${texture.pattern}`);
    }
    if (!Array.isArray(pattern.size) || pattern.size.length !== 2) {
      throw new Error(`pattern ${pattern.id} must define a 2D size for primitive ${box.id} face ${face}`);
    }
    const size2D = pattern.size as [number, number];
    const patternWidth = normalizeDimension(size2D[0]);
    const patternHeight = normalizeDimension(size2D[1]);
    if (!Number.isFinite(patternWidth) || !Number.isFinite(patternHeight) || patternWidth <= 0 || patternHeight <= 0) {
      throw new Error(`pattern ${pattern.id} has invalid size for primitive ${box.id} face ${face}`);
    }

    const [expectedWidthRaw, expectedHeightRaw] = FACE_DIMENSIONS[face](normalizedSize);
    const expectedWidth = normalizeDimension(expectedWidthRaw);
    const expectedHeight = normalizeDimension(expectedHeightRaw);

    if (patternWidth !== expectedWidth || patternHeight !== expectedHeight) {
      throw new Error(
        `primitive ${box.id} face ${face} expects texture size ${expectedWidth}x${expectedHeight} but texture ${textureId} pattern ${pattern.id} is ${patternWidth}x${patternHeight}`
      );
    }
  });

  (['top', 'bottom', 'north', 'south', 'east', 'west'] as const).forEach(face => {
    const textureId = resolveOverlayFaceTextureId(box, face);
    if (!textureId) {
      return;
    }
    const texture = textureLookup.get(textureId);
    if (!texture) {
      throw new Error(`primitive ${box.id} overlay face ${face} references missing texture ${textureId}`);
    }
    const pattern = patternLookup.get(texture.pattern);
    if (!pattern) {
      throw new Error(
        `texture ${texture.id} referenced by primitive ${box.id} overlay face ${face} is missing pattern ${texture.pattern}`
      );
    }
    if (!Array.isArray(pattern.size) || pattern.size.length !== 2) {
      throw new Error(`pattern ${pattern.id} must define a 2D size for primitive ${box.id} overlay face ${face}`);
    }
    const size2D = pattern.size as [number, number];
    const patternWidth = normalizeDimension(size2D[0]);
    const patternHeight = normalizeDimension(size2D[1]);
    if (!Number.isFinite(patternWidth) || !Number.isFinite(patternHeight) || patternWidth <= 0 || patternHeight <= 0) {
      throw new Error(`pattern ${pattern.id} has invalid size for primitive ${box.id} overlay face ${face}`);
    }

    const [expectedWidthRaw, expectedHeightRaw] = FACE_DIMENSIONS[face](normalizedSize);
    const expectedWidth = normalizeDimension(expectedWidthRaw);
    const expectedHeight = normalizeDimension(expectedHeightRaw);

    if (patternWidth !== expectedWidth || patternHeight !== expectedHeight) {
      throw new Error(
        `primitive ${box.id} overlay face ${face} expects texture size ${expectedWidth}x${expectedHeight} but texture ${textureId} pattern ${pattern.id} is ${patternWidth}x${patternHeight}`
      );
    }
  });

  const mode = box.renderMode ?? 'plain';
  if (mode !== 'plain' && mode !== 'cutout') {
    throw new Error(`primitive ${box.id} has invalid renderMode ${String(mode)}`);
  }

  const faceTextureIds = collectFaceTextureIds(box);
  const usesTransparency = faceTextureIds.some(textureId => {
    const texture = textureLookup.get(textureId);
    if (!texture) {
      return false;
    }
    return texture.materials.some(materialId => {
      const material = materialLookup.get(materialId);
      if (!material) {
        return false;
      }
      if (material.opacity === undefined) {
        return false;
      }
      return Number(material.opacity) < 1;
    });
  });

  if (mode === 'plain' && usesTransparency) {
    throw new Error(`primitive ${box.id} renderMode plain but references textures with transparent materials`);
  }
}

function assertNode(value: unknown, path: string, primitiveLookup: Map<string, Primitive>): asserts value is Node {
  if (!value || typeof value !== 'object') {
    throw new Error(`Node ${path} must be an object`);
  }

  const node = value as Partial<Node>;
  if (typeof node.id !== 'string') {
    throw new Error(`Node ${path} is missing id`);
  }

  assertVec3(node.position as unknown, `node ${node.id} position`);

  if (node.rotation !== undefined) {
    assertVec3(node.rotation as unknown, `node ${node.id} rotation`);
  }

  if (node.scale !== undefined) {
    assertVec3(node.scale as unknown, `node ${node.id} scale`);
  }

  if (node.size !== undefined) {
    assertVec3(node.size as unknown, `node ${node.id} size`);
  }

  if (node.center !== undefined) {
    assertVec3(node.center as unknown, `node ${node.id} center`);
  }

  if (node.connect !== undefined) {
    const connectValue = node.connect as unknown;
    if (connectValue === true) {
      node.connect = 'child';
    } else if (connectValue === false) {
      delete node.connect;
    } else if (typeof connectValue === 'string') {
      if (!isConnectMode(connectValue)) {
        throw new Error(`Node ${node.id} connect must be one of ${CONNECT_MODES.join(', ')}`);
      }
      node.connect = connectValue;
    } else {
      throw new Error(`Node ${node.id} connect must be a boolean or enum value`);
    }
  }

  if (node.mesh !== undefined) {
    if (typeof node.mesh !== 'string') {
      throw new Error(`Node ${node.id} mesh must be a primitive id`);
    }

    if (!primitiveLookup.has(node.mesh)) {
      throw new Error(`Node ${node.id} references unknown primitive ${node.mesh}`);
    }
  }

  if (!Array.isArray(node.children)) {
    throw new Error(`Node ${node.id} children must be an array`);
  }

  node.children.forEach((child, idx) => assertNode(child, `${path}.${child?.id ?? idx}`, primitiveLookup));
}

function collectNodeIds(node: Node, set: Set<string>): void {
  set.add(node.id);
  node.children.forEach(child => collectNodeIds(child, set));
}

function assertAnimationChannels(animation: Animation, nodeIds: Set<string>): void {
  const seenChannels = new Set<string>();
  const epsilon = 1e-5;
  animation.channels.forEach((channel, channelIndex) => {
    const key = `${channel.node}:${channel.property}`;
    if (seenChannels.has(key)) {
      throw new Error(`Animation ${animation.id} channel ${channelIndex} duplicates node ${channel.node} property ${channel.property}`);
    }
    seenChannels.add(key);

    if (!nodeIds.has(channel.node)) {
      throw new Error(`Animation ${animation.id} channel ${channelIndex} references unknown node ${channel.node}`);
    }

    let previousTime = -Infinity;
    channel.keyframes.forEach((keyframe, keyframeIndex) => {
      if (keyframe.time > animation.duration + epsilon) {
        throw new Error(
          `Animation ${animation.id} channel ${channelIndex} keyframe ${keyframeIndex} time ${keyframe.time} exceeds duration ${animation.duration}`
        );
      }
      if (keyframe.time + epsilon < previousTime) {
        throw new Error(
          `Animation ${animation.id} channel ${channelIndex} keyframes must be in ascending time order (found ${keyframe.time} after ${previousTime})`
        );
      }
      previousTime = keyframe.time;
    });
  });
}

export function validateBoxel(candidate: unknown): { boxel: BoxelDefinition | null; issues: BoxelValidationIssue[] } {
  const issues: BoxelValidationIssue[] = [];
  if (!candidate || typeof candidate !== 'object') {
    pushIssue(issues, 'boxel', 'BoxelDefinition must be an object');
    return { boxel: null, issues };
  }

  const raw = candidate as Partial<BoxelDefinition>;

  let id: string | null = null;
  if (typeof raw.id === 'string' && raw.id.trim().length > 0) {
    id = raw.id;
  } else {
    pushIssue(issues, 'boxel.id', 'BoxelDefinition id must be a non-empty string');
  }

  const primitives: Primitive[] = [];
  const primitiveLookup = new Map<string, Primitive>();
  if (!Array.isArray(raw.primitives)) {
    pushIssue(issues, 'boxel.primitives', 'BoxelDefinition primitives must be an array');
  } else {
    raw.primitives.forEach((primitive, index) => {
      try {
        assertPrimitive(primitive, index);
        primitives.push(primitive as Primitive);
        primitiveLookup.set((primitive as Primitive).id, primitive as Primitive);
      } catch (error) {
        pushIssue(issues, `boxel.primitives[${index}]`, error);
      }
    });
  }

  let geometry: BoxelDefinition['geometry'] | null = null;
  const geometryNodeIds = new Set<string>();
  if (!raw.geometry || typeof raw.geometry !== 'object') {
    pushIssue(issues, 'boxel.geometry', 'BoxelDefinition geometry is missing or invalid');
  } else {
    const geo = raw.geometry as BoxelDefinition['geometry'];
    if (typeof geo.id !== 'string') {
      pushIssue(issues, 'boxel.geometry.id', 'Geometry id must be a string');
    } else if (!geo.root) {
      pushIssue(issues, 'boxel.geometry.root', 'Geometry root is missing');
    } else {
      try {
        assertNode(geo.root, 'root', primitiveLookup);
        geometry = geo;
        collectNodeIds(geo.root, geometryNodeIds);
      } catch (error) {
        pushIssue(issues, 'boxel.geometry.root', error);
      }
    }
  }

  const patterns: Pattern[] = [];
  const patternLookup = new Map<string, Pattern>();
  if (!Array.isArray(raw.patterns)) {
    pushIssue(issues, 'boxel.patterns', 'BoxelDefinition patterns must be an array');
  } else {
    raw.patterns.forEach((pattern, index) => {
      try {
        assertPattern(pattern, index);
        patterns.push(pattern as Pattern);
        patternLookup.set((pattern as Pattern).id, pattern as Pattern);
      } catch (error) {
        pushIssue(issues, `boxel.patterns[${index}]`, error);
      }
    });
  }

  const materials: Material[] = [];
  const materialLookup = new Map<string, Material>();
  if (!Array.isArray(raw.materials)) {
    pushIssue(issues, 'boxel.materials', 'BoxelDefinition materials must be an array');
  } else {
    raw.materials.forEach((material, index) => {
      try {
        assertMaterial(material, index);
        materials.push(material as Material);
        materialLookup.set((material as Material).id, material as Material);
      } catch (error) {
        pushIssue(issues, `boxel.materials[${index}]`, error);
      }
    });
  }

  const textures: Texture[] = [];
  const textureLookup = new Map<string, Texture>();
  if (!Array.isArray(raw.textures)) {
    pushIssue(issues, 'boxel.textures', 'BoxelDefinition textures must be an array');
  } else {
    raw.textures.forEach((texture, index) => {
      try {
        assertTexture(texture, index);
        const typed = texture as Texture;
        const pattern = patternLookup.get(typed.pattern);
        if (!pattern) {
          throw new Error(`Texture ${typed.id} references unknown pattern ${typed.pattern}`);
        }
        typed.materials.forEach(materialId => {
          if (!materialLookup.has(materialId)) {
            throw new Error(`Texture ${typed.id} references unknown material ${materialId}`);
          }
        });
        const paletteSize = typed.materials.length;
        for (let i = 0; i < pattern.data.length; i += 1) {
          const value = pattern.data[i];
          if (value >= paletteSize) {
            throw new Error(
              `Texture ${typed.id} pattern index ${value} exceeds palette size ${paletteSize} (pattern ${pattern.id})`
            );
          }
        }
        textures.push(typed);
        textureLookup.set(typed.id, typed);
      } catch (error) {
        pushIssue(issues, `boxel.textures[${index}]`, error);
      }
    });
  }

  if (textures.length > 0) {
    primitives
      .filter(primitive => primitive.kind === 'textured_box')
      .forEach(primitive => {
        try {
          assertTexturedBoxFaceSizes(primitive as TexturedBox, textureLookup, patternLookup, materialLookup);
        } catch (error) {
          pushIssue(issues, `boxel.primitives[${primitive.id}]`, error);
        }
      });
  }

  const animations: Animation[] = [];
  if (!Array.isArray(raw.animations)) {
    if (raw.animations !== undefined) {
      pushIssue(issues, 'boxel.animations', 'BoxelDefinition animations must be an array');
    }
  } else {
    raw.animations.forEach((animation, index) => {
      try {
        assertAnimation(animation, index);
        if (geometry) {
          assertAnimationChannels(animation as Animation, geometryNodeIds);
        }
        animations.push(animation as Animation);
      } catch (error) {
        pushIssue(issues, `boxel.animations[${index}]`, error);
      }
    });
  }

  if (id === null || !geometry) {
    return { boxel: null, issues };
  }

  const boxel: BoxelDefinition = {
    id,
    geometry,
    patterns,
    materials,
    textures,
    primitives,
    animations,
  };

  return { boxel: issues.length === 0 ? boxel : null, issues };
}

export function assertBoxel(candidate: unknown): BoxelDefinition {
  const { boxel, issues } = validateBoxel(candidate);
  if (boxel) {
    return boxel;
  }
  throw new BoxelValidationError('BoxelDefinition validation failed', issues);
}

export function collectBoxelValidationIssues(candidate: unknown): BoxelValidationIssue[] {
  return validateBoxel(candidate).issues;
}
