import type {
  BridgeEnvelope,
  BridgeMessageHandler,
  BridgeTransport,
  HostAudioPolicyPayload,
  HostBridgeOptions,
  HostControllerStatePayload,
  HostPhaseChangePayload,
  HostInitPayload,
  HostPausePayload,
  HostResumePayload,
  HostSessionUpdatePayload,
} from './types.js';
import {
  BridgeEvent
} from './types.js';

const HOST_BRIDGE_DEBUG = true;

function debugHostBridge(...args: unknown[]): void {
  if (!HOST_BRIDGE_DEBUG) {
    return;
  }
  try {
    console.debug('[web-bridge][host]', ...args);
  } catch {
    // ignore to keep bridge resilient even if console is unavailable
  }
}

const DEFAULT_MAX_QUEUE = 32;

function isStartupEnvelope(envelope: BridgeEnvelope | null | undefined): boolean {
  const type = envelope?.type;
  return type === BridgeEvent.HostInit || type === BridgeEvent.HostStart;
}

function createIframeTransport(
  iframe: { contentWindow: Window | null } | null | undefined,
  origin: string,
  hostWindow?: Window
): BridgeTransport {
  const win = hostWindow ?? (typeof window !== 'undefined' ? window : undefined);
  const target = iframe?.contentWindow;

  if (!win || !target) {
    throw new Error('[web-bridge] iframe transport requires a window and iframe');
  }

  const listeners = new Set<(envelope: BridgeEnvelope) => void>();

  const onMessage = (event: MessageEvent) => {
    if (event.source !== target) {
      return;
    }
    if (origin !== '*' && event.origin !== origin) {
      return;
    }
    const envelope = event.data;
    if (!envelope || typeof envelope !== 'object') {
      return;
    }
    listeners.forEach((listener) => {
      try {
        listener(envelope as BridgeEnvelope);
      } catch {
        // ignore listener errors to avoid breaking others
      }
    });
  };

  win.addEventListener('message', onMessage);

  return {
    send(envelope: BridgeEnvelope): void {
      target.postMessage(envelope, origin);
    },
    subscribe(handler: (envelope: BridgeEnvelope) => void): () => void {
      listeners.add(handler);
      return () => listeners.delete(handler);
    },
    close(): void {
      listeners.clear();
      win.removeEventListener('message', onMessage);
    },
  };
}

export class HostBridge {
  private readonly transport: BridgeTransport;
  private readonly handlers = new Map<string, Set<BridgeMessageHandler>>();
  private readonly maxQueue: number;
  private ready = false;
  private queue: BridgeEnvelope[] = [];
  private unsubscribe?: () => void;

  constructor(options: HostBridgeOptions) {
    this.maxQueue = options.maxQueue ?? DEFAULT_MAX_QUEUE;
    this.transport =
      options.transport ??
      createIframeTransport(options.iframe, options.targetOrigin ?? '*', options.hostWindow);

    this.unsubscribe = this.transport.subscribe((envelope) => this.handleIncoming(envelope));
  }

  on<T = unknown>(type: string, handler: BridgeMessageHandler<T>): () => void {
    if (!this.handlers.has(type)) {
      this.handlers.set(type, new Set());
    }
    const bucket = this.handlers.get(type)!;
    bucket.add(handler as BridgeMessageHandler);
    return () => {
      bucket.delete(handler as BridgeMessageHandler);
      if (bucket.size === 0) {
        this.handlers.delete(type);
      }
    };
  }

  send<T = unknown>(type: string, payload?: T): void {
    const envelope: BridgeEnvelope = { type, payload };
    debugHostBridge('send', envelope, { ready: this.ready });
    if (this.ready) {
      this.transport.send(envelope);
      return;
    }
    this.enqueue(envelope);
  }

  sendInit(payload: HostInitPayload): void {
    this.send(BridgeEvent.HostInit, payload);
  }

  sendStart(): void {
    this.send(BridgeEvent.HostStart);
  }

  sendPause(payload: HostPausePayload): void {
    this.send(BridgeEvent.HostPause, payload);
  }

  sendResume(payload: HostResumePayload): void {
    this.send(BridgeEvent.HostResume, payload);
  }

  sendAudioPolicy(payload: HostAudioPolicyPayload): void {
    this.send(BridgeEvent.HostAudioPolicy, payload);
  }

  sendPhaseChange(payload: HostPhaseChangePayload): void {
    this.send(BridgeEvent.HostPhaseChange, payload);
  }

  sendSessionUpdated(payload: HostSessionUpdatePayload): void {
    this.send(BridgeEvent.HostSessionUpdated, payload);
  }

  sendControllerState(payload: HostControllerStatePayload): void {
    this.send(BridgeEvent.HostControllerState, payload);
  }

  isClientReady(): boolean {
    return this.ready;
  }

  resetReadiness(): void {
    debugHostBridge('reset-readiness');
    this.ready = false;
    this.queue = [];
  }

  destroy(): void {
    this.handlers.clear();
    this.queue = [];
    this.unsubscribe?.();
    this.transport.close?.();
  }

  private handleIncoming(envelope: BridgeEnvelope): void {
    debugHostBridge('received', envelope);
    const type = envelope?.type;
    if (typeof type !== 'string' || type.length === 0) {
      return;
    }

    if (!this.ready && type === BridgeEvent.ClientInit) {
      debugHostBridge('client:init observed, flushing queue', { queued: this.queue.length });
      this.ready = true;
      this.flushQueue();
    }

    const bucket = this.handlers.get(type);
    if (!bucket || bucket.size === 0) {
      return;
    }
    bucket.forEach((handler) => {
      try {
        handler(envelope.payload, envelope);
      } catch {
        // swallow to avoid cascading failures
      }
    });
  }

  private enqueue(envelope: BridgeEnvelope): void {
    debugHostBridge('queueing', envelope, { queueLength: this.queue.length });
    if (isStartupEnvelope(envelope)) {
      this.queue = this.queue.filter((queued) => queued.type !== envelope.type);
    }
    this.queue.push(envelope);
    while (this.queue.length > this.maxQueue) {
      const droppableIndex = this.queue.findIndex((queued) => !isStartupEnvelope(queued));
      if (droppableIndex === -1) {
        this.queue.splice(0, this.queue.length - this.maxQueue);
        break;
      }
      this.queue.splice(droppableIndex, 1);
    }
  }

  private flushQueue(): void {
    if (!this.queue.length) {
      return;
    }
    const pending = this.queue;
    this.queue = [];
    debugHostBridge('flushing queued envelopes', { count: pending.length });
    for (const envelope of pending) {
      this.transport.send(envelope);
    }
  }
}

export function createHostBridge(options: HostBridgeOptions): HostBridge {
  return new HostBridge(options);
}
