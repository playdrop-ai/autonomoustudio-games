import type {
  AssetEmbeddedMetadata,
  AssetMetadataEmbeddingStatus,
  AssetSpeechMetadata,
  PlaydropSpeechVoiceId,
} from '@playdrop/types';

export type TextGenerationMode = 'text';
export type TextGenerationSize = 'small' | 'medium' | 'large';
export type ImageAttachment = {
  data?: string;
  mimeType?: string;
  url?: string;
};

export type AiImageAspectRatio = '1:1' | '3:4' | '9:16' | '4:3' | '16:9';
export type AiImageSize = '1K' | '4K';

export type GenerationBilling = {
  amount: number;
  paidBy: 'USER' | 'CREATOR';
  generationId: string;
  transactionId: number;
  creditBalance: number;
};

export type GeneratedAssetRef = {
  creatorUsername: string;
  assetName: string;
  revision: number;
  versionId: number;
  subcategory: string;
  ref: string;
};

export type GenerateTextResponse = {
  input: string;
  output: string;
  model: string;
  totalTokenCount: number | null;
  promptTokenCount: number | null;
  responseTokenCount: number | null;
  maxOutputTokens: number | null;
  size: TextGenerationSize;
  mode: TextGenerationMode;
  cost: number;
  createdAt: string;
  billing: GenerationBilling;
};

export type GenerateTextOptions = {
  signal?: AbortSignal;
  size?: TextGenerationSize;
  mode?: TextGenerationMode;
  system?: string;
};

export type GenerateImageResponse = {
  input: string;
  imageUrl: string;
  imageMimeType: string;
  inputImageUrls: string[];
  aspectRatio: AiImageAspectRatio;
  imageSize: AiImageSize;
  metadata?: unknown;
  embeddedMetadata?: AssetEmbeddedMetadata;
  embeddingStatus?: AssetMetadataEmbeddingStatus;
  metadataUrl?: string | null;
  generatedAssetDisplayName?: string | null;
  generatedAssetDescription?: string | null;
  model: string;
  mode: 'image';
  cost: number;
  totalTokenCount: number | null;
  promptTokenCount: number | null;
  responseTokenCount: number | null;
  generatedAsset?: GeneratedAssetRef;
  createdAt: string;
  billing: GenerationBilling;
};

export type GenerateJsonResponse = {
  input: string;
  system: string | null;
  output: unknown;
  raw: string;
  size: TextGenerationSize;
  model: string;
  mode: 'json';
  cost: number;
  totalTokenCount: number | null;
  promptTokenCount: number | null;
  responseTokenCount: number | null;
  responseSchemaProvided: boolean;
  responseSchema: unknown;
  createdAt: string;
  billing: GenerationBilling;
};

export type GenerateMusicResponse = {
  input: string;
  durationMs: number | null;
  forceInstrumental: boolean;
  audioUrl: string;
  audioMimeType: string;
  coverUrl: string | null;
  coverMimeType: string | null;
  providerSongMetadata: ElevenLabsSongMetadata | null;
  providerCompositionPlan: ElevenLabsCompositionPlan | null;
  providerWordTimestamps: ElevenLabsWordTimestamp[] | null;
  embeddedMetadata?: AssetEmbeddedMetadata;
  embeddingStatus?: AssetMetadataEmbeddingStatus;
  metadataUrl?: string | null;
  model: string;
  mode: 'music';
  cost: number;
  generatedAsset?: GeneratedAssetRef;
  createdAt: string;
  billing: GenerationBilling;
};

export type GenerateSfxResponse = {
  input: string;
  durationSeconds: number | null;
  loop: boolean;
  audioUrl: string;
  audioMimeType: string;
  coverUrl: string | null;
  coverMimeType: string | null;
  embeddedMetadata?: AssetEmbeddedMetadata;
  embeddingStatus?: AssetMetadataEmbeddingStatus;
  metadataUrl?: string | null;
  model: string;
  mode: 'sfx';
  cost: number;
  generatedAsset?: GeneratedAssetRef;
  createdAt: string;
  billing: GenerationBilling;
};

export type GenerateSpeechResponse = {
  input: string;
  audioUrl: string;
  audioMimeType: string;
  previewUrl: string | null;
  previewMimeType: string | null;
  speech: AssetSpeechMetadata;
  embeddedMetadata?: AssetEmbeddedMetadata;
  embeddingStatus?: AssetMetadataEmbeddingStatus;
  metadataUrl?: string | null;
  model: string;
  mode: 'speech';
  cost: number;
  generatedAsset?: GeneratedAssetRef;
  createdAt: string;
  billing: GenerationBilling;
};

export type GenerateVideoResponse = {
  input: string;
  durationSeconds: 4 | 8;
  aspectRatio: '16:9' | '9:16';
  resolution: '720p';
  videoUrl: string;
  videoMimeType: string;
  thumbnailUrl: string | null;
  embeddedMetadata?: AssetEmbeddedMetadata;
  embeddingStatus?: AssetMetadataEmbeddingStatus;
  metadataUrl?: string | null;
  generatedAssetDisplayName?: string | null;
  generatedAssetDescription?: string | null;
  model: string;
  mode: 'video';
  cost: number;
  generatedAsset?: GeneratedAssetRef;
  createdAt: string;
  billing: GenerationBilling;
};

export type GenerateModel3DResponse = {
  input: string;
  sourceMode: 'TEXT' | 'IMAGE';
  topology: 'triangle' | 'quad';
  targetPolycount: number;
  shouldRemesh: boolean;
  shouldTexture: boolean;
  modelUrl: string;
  modelMimeType: string;
  thumbnailUrl: string | null;
  modelSizeBytes?: number | null;
  metadata?: unknown;
  embeddedMetadata?: AssetEmbeddedMetadata;
  embeddingStatus?: AssetMetadataEmbeddingStatus;
  metadataUrl?: string | null;
  generatedAssetDisplayName?: string | null;
  generatedAssetDescription?: string | null;
  model: string;
  mode: 'model_3d';
  cost: number;
  generatedAsset?: GeneratedAssetRef;
  createdAt: string;
  billing: GenerationBilling;
};

export type GenerateAssetModality = 'IMAGE' | 'MUSIC' | 'SFX' | 'SPEECH' | 'VIDEO' | 'MODEL_3D';

export type GenerateAssetRequest = {
  modality: GenerateAssetModality;
  input: string;
  signal?: AbortSignal;
  assetName?: string;
  assetDisplayName?: string;
  assetDescription?: string;
  assetVisibility?: 'PRIVATE' | 'PUBLIC';
  assetSubcategory?: string;
  attachAppVersionId?: number;
  remixAssetVersionRef?: string;
  suggestedTagRefs?: string[];
  image1?: ImageAttachment | null;
  image2?: ImageAttachment | null;
  durationMs?: number;
  forceInstrumental?: boolean;
  durationSeconds?: number;
  loop?: boolean;
  coverPrompt?: string;
  speechVoice?: PlaydropSpeechVoiceId;
  speechProviderVoiceId?: string;
  aspectRatio?: AiImageAspectRatio;
  imageSize?: AiImageSize;
  resolution?: '720p';
  sourceMode?: 'TEXT' | 'IMAGE';
  topology?: 'triangle' | 'quad';
  targetPolycount?: number;
  shouldRemesh?: boolean;
  shouldTexture?: boolean;
};

export type GenerationJobStatus = 'PENDING' | 'RUNNING' | 'SUCCESS' | 'FAILURE';

export const GENERATION_JOB_ETA_BASELINE_SECONDS: Record<GenerateAssetModality, number> = {
  IMAGE: 20,
  MUSIC: 40,
  SFX: 15,
  SPEECH: 15,
  VIDEO: 90,
  MODEL_3D: 420,
};

export type GenerationJobRecord = {
  id: string;
  modality: GenerateAssetModality;
  status: GenerationJobStatus;
  requestPrompt: string;
  requestPayload: unknown;
  resultData: unknown | null;
  errorCode: string | null;
  errorMessage: string | null;
  linkedGenerationId: string | null;
  createdAt: string;
  updatedAt: string;
  startedAt: string | null;
  completedAt: string | null;
  failedAt: string | null;
  progressPercent: number | null;
  etaSecondsRemaining: number | null;
};

export type CreateGenerationJobRequest = GenerateAssetRequest;

export type CreateGenerationJobResponse = {
  job: GenerationJobRecord;
};

export type GetGenerationJobResponse = {
  job: GenerationJobRecord;
};

type PaginationMeta = {
  limit: number;
  offset: number;
  count: number;
  hasMore: boolean;
};

type GenerationRecordBase = {
  id: string;
  type: 'text' | 'json' | 'image' | 'music' | 'sfx' | 'speech' | 'video' | 'model_3d';
  cost: number;
  createdAt: string;
};

export type ElevenLabsSongMetadata = {
  title?: string | null;
  description?: string | null;
  genres: string[];
  languages: string[];
  isExplicit?: boolean | null;
};

export type ElevenLabsWordTimestamp = {
  word: string;
  startMs: number;
  endMs: number;
};

export type ElevenLabsCompositionPlanSection = {
  sectionName?: string;
  durationMs?: number;
  positiveLocalStyles?: string[];
  negativeLocalStyles?: string[];
  lines?: string[];
};

export type ElevenLabsCompositionPlan = {
  durationMs?: number;
  positiveGlobalStyles?: string[];
  negativeGlobalStyles?: string[];
  sections?: ElevenLabsCompositionPlanSection[];
};

export type ListTextGenerationRecord = GenerationRecordBase & {
  type: 'text';
  systemPrompt: string | null;
  inputPrompt: string;
  outputText: string;
  modelSize: TextGenerationSize;
};

export type ListJsonGenerationRecord = GenerationRecordBase & {
  type: 'json';
  systemPrompt: string | null;
  inputPrompt: string;
  outputSchema: unknown;
  outputJSON: unknown;
};

export type ListImageGenerationRecord = GenerationRecordBase & {
  type: 'image';
  inputPrompt: string;
  inputImages: string[];
  outputImage: string | null;
  aspectRatio: AiImageAspectRatio | null;
  imageSize: AiImageSize | null;
  metadata?: unknown;
  embeddedMetadata?: AssetEmbeddedMetadata | null;
  embeddingStatus?: AssetMetadataEmbeddingStatus | null;
  metadataUrl?: string | null;
  generatedAssetDisplayName?: string | null;
  generatedAssetDescription?: string | null;
  generatedAsset?: GeneratedAssetRef;
};

export type ListMusicGenerationRecord = GenerationRecordBase & {
  type: 'music';
  inputPrompt: string;
  durationMs: number | null;
  forceInstrumental: boolean;
  audioUrl: string | null;
  audioMimeType: string | null;
  coverUrl: string | null;
  coverMimeType: string | null;
  providerSongMetadata: ElevenLabsSongMetadata | null;
  providerCompositionPlan: ElevenLabsCompositionPlan | null;
  providerWordTimestamps: ElevenLabsWordTimestamp[] | null;
  embeddedMetadata?: AssetEmbeddedMetadata | null;
  embeddingStatus?: AssetMetadataEmbeddingStatus | null;
  metadataUrl?: string | null;
  generatedAsset?: GeneratedAssetRef;
};

export type ListSfxGenerationRecord = GenerationRecordBase & {
  type: 'sfx';
  inputPrompt: string;
  durationSeconds: number | null;
  loop: boolean;
  audioUrl: string | null;
  audioMimeType: string | null;
  coverUrl: string | null;
  coverMimeType: string | null;
  embeddedMetadata?: AssetEmbeddedMetadata | null;
  embeddingStatus?: AssetMetadataEmbeddingStatus | null;
  metadataUrl?: string | null;
  generatedAsset?: GeneratedAssetRef;
};

export type ListSpeechGenerationRecord = GenerationRecordBase & {
  type: 'speech';
  inputPrompt: string;
  audioUrl: string | null;
  audioMimeType: string | null;
  previewUrl: string | null;
  previewMimeType: string | null;
  speech: AssetSpeechMetadata | null;
  embeddedMetadata?: AssetEmbeddedMetadata | null;
  embeddingStatus?: AssetMetadataEmbeddingStatus | null;
  metadataUrl?: string | null;
  generatedAsset?: GeneratedAssetRef;
};

export type ListVideoGenerationRecord = GenerationRecordBase & {
  type: 'video';
  inputPrompt: string;
  durationSeconds: number | null;
  aspectRatio: string | null;
  resolution: string | null;
  videoUrl: string | null;
  videoMimeType: string | null;
  thumbnailUrl: string | null;
  metadata?: unknown;
  embeddedMetadata?: AssetEmbeddedMetadata | null;
  embeddingStatus?: AssetMetadataEmbeddingStatus | null;
  metadataUrl?: string | null;
  generatedAssetDisplayName?: string | null;
  generatedAssetDescription?: string | null;
  generatedAsset?: GeneratedAssetRef;
};

export type ListModel3DGenerationRecord = GenerationRecordBase & {
  type: 'model_3d';
  inputPrompt: string;
  sourceMode: 'TEXT' | 'IMAGE' | null;
  topology: 'triangle' | 'quad' | null;
  targetPolycount: number | null;
  shouldRemesh: boolean;
  shouldTexture: boolean;
  modelUrl: string | null;
  modelMimeType: string | null;
  thumbnailUrl: string | null;
  modelSizeBytes?: number | null;
  metadata?: unknown;
  embeddedMetadata?: AssetEmbeddedMetadata | null;
  embeddingStatus?: AssetMetadataEmbeddingStatus | null;
  metadataUrl?: string | null;
  generatedAssetDisplayName?: string | null;
  generatedAssetDescription?: string | null;
  generatedAsset?: GeneratedAssetRef;
};

export type GenerationRecord =
  | ListTextGenerationRecord
  | ListJsonGenerationRecord
  | ListImageGenerationRecord
  | ListMusicGenerationRecord
  | ListSfxGenerationRecord
  | ListSpeechGenerationRecord
  | ListVideoGenerationRecord
  | ListModel3DGenerationRecord;

export type ListGenerationsOptions = {
  signal?: AbortSignal;
  type?: 'text' | 'json' | 'image' | 'music' | 'sfx' | 'speech' | 'video' | 'model_3d';
  limit?: number;
  offset?: number;
};

export type ListGenerationsResponse = {
  generations: GenerationRecord[];
  pagination: PaginationMeta;
};

export type ListGenerationJobsOptions = {
  signal?: AbortSignal;
  modality?: GenerateAssetModality;
  status?: GenerationJobStatus;
  limit?: number;
  offset?: number;
};

export type ListGenerationJobsResponse = {
  jobs: GenerationJobRecord[];
  pagination: PaginationMeta;
};

export type GenerateJsonOptions = {
  signal?: AbortSignal;
  size?: TextGenerationSize;
  system?: string;
  responseJsonSchema?: string;
};

export type AiClientConfig = {
  baseUrl?: string;
  fetchImpl?: typeof fetch;
  tokenProvider?: () => string | null | Promise<string | null>;
  clientHeaders?: () => Record<string, string> | Promise<Record<string, string>>;
};

export interface AiClient {
  generateText(input: string, options?: GenerateTextOptions): Promise<GenerateTextResponse>;
  createGenerationJob(request: CreateGenerationJobRequest): Promise<CreateGenerationJobResponse>;
  getGenerationJob(id: string, options?: { signal?: AbortSignal }): Promise<GetGenerationJobResponse>;
  listGenerationJobs(options?: ListGenerationJobsOptions): Promise<ListGenerationJobsResponse>;
  deleteGenerationJob(id: string, options?: { signal?: AbortSignal }): Promise<void>;
  generateJson(input: string, options?: GenerateJsonOptions): Promise<GenerateJsonResponse>;
  listGenerations(options?: ListGenerationsOptions): Promise<ListGenerationsResponse>;
  listDiscoverGenerations(options?: ListGenerationsOptions): Promise<ListGenerationsResponse>;
}

const DEFAULT_LOCAL_BASE = 'http://localhost:8083';
const CLIENT_HEADER_NAMES = {
  client: 'x-playdrop-client',
  clientVersion: 'x-playdrop-client-version',
  clientBuild: 'x-playdrop-client-build',
  platform: 'x-playdrop-platform',
  platformVersion: 'x-playdrop-platform-version',
} as const;

type BrowserRuntimeMetaRoot = typeof globalThis & {
  __PLAYDROP_CLIENT_META?: unknown;
};

function stripTrailingSlash(value: string): string {
  return value.endsWith('/') ? value.slice(0, -1) : value;
}

function normalizeProtocol(protocol: string | null | undefined): string {
  if (!protocol) {
    return 'http';
  }
  return protocol.replace(/:$/, '') || 'http';
}

function isIpv4Hostname(hostname: string): boolean {
  return /^\d{1,3}(?:\.\d{1,3}){3}$/.test(hostname);
}

function isLocalHostname(hostname: string): boolean {
  if (!hostname) {
    return true;
  }

  const normalizedHostname = hostname.trim().toLowerCase();
  if (!normalizedHostname) {
    return true;
  }

  if (normalizedHostname === 'localhost' || normalizedHostname === '0.0.0.0') {
    return true;
  }

  if (isIpv4Hostname(normalizedHostname)) {
    return true;
  }

  return normalizedHostname.includes(':');
}

function formatHostnameForUrl(hostname: string): string {
  const normalizedHostname = hostname.trim();
  if (!normalizedHostname) {
    return 'localhost';
  }

  if (normalizedHostname.includes(':') && !normalizedHostname.startsWith('[')) {
    return `[${normalizedHostname}]`;
  }

  return normalizedHostname;
}

function inferBaseFromHostname(hostname: string, protocol: string): string {
  if (isLocalHostname(hostname)) {
    return `${protocol}://${formatHostnameForUrl(hostname)}:8083`;
  }

  if (hostname.includes('.')) {
    const domain = hostname
      .replace(/^www\./, '')
      .replace(/^api\./, '')
      .replace(/^play\./, '')
      .replace(/^admin\./, '')
      .replace(/^ai\./, '')
      .replace(/^assets\./, '');
    return `${protocol}://ai.${domain}`;
  }

  const host = formatHostnameForUrl(hostname || 'localhost');
  return `${protocol}://${host}:8083`;
}

function inferBaseUrl(): string {
  if (typeof process !== 'undefined' && process.env.NEXT_PUBLIC_AI_BASE) {
    return process.env.NEXT_PUBLIC_AI_BASE;
  }

  if (typeof window !== 'undefined' && window.location) {
    const { hostname, protocol } = window.location;
    return inferBaseFromHostname(hostname, normalizeProtocol(protocol));
  }

  return DEFAULT_LOCAL_BASE;
}

function resolveBrowserRequestCredentials(): RequestCredentials | undefined {
  if (typeof window === 'undefined') {
    return undefined;
  }
  return 'include';
}

function readBrowserRuntimeClientMeta(): { version: string; build: string } | null {
  if (typeof window === 'undefined') {
    return null;
  }

  const raw = (globalThis as BrowserRuntimeMetaRoot).__PLAYDROP_CLIENT_META as
    | { version?: unknown; build?: unknown }
    | undefined;
  const version = typeof raw?.version === 'string' ? raw.version.trim() : '';
  const build = typeof raw?.build === 'string' ? raw.build.trim() : '';
  if (!version || !build) {
    return null;
  }
  return { version, build };
}

function normalizeBrowserPlatformName(raw: string): string {
  const value = raw.trim().toLowerCase();
  if (value.includes('mac')) return 'macos';
  if (value.includes('win')) return 'windows';
  if (value.includes('linux')) return 'linux';
  if (value.includes('ios') || value.includes('iphone') || value.includes('ipad')) return 'ios';
  if (value.includes('android')) return 'android';
  return value || 'browser';
}


function resolveBrowserPlatform(): { name: string; version: string } {
  if (typeof window === 'undefined') {
    return { name: 'browser', version: '0.0.0' };
  }

  const envPlatform = (typeof process !== 'undefined' ? process.env.NEXT_PUBLIC_PLAYDROP_PLATFORM : '')?.trim() ?? '';
  const envPlatformVersion = (typeof process !== 'undefined' ? process.env.NEXT_PUBLIC_PLAYDROP_PLATFORM_VERSION : '')?.trim() ?? '';
  if (envPlatform && envPlatformVersion) {
    return { name: envPlatform.toLowerCase(), version: envPlatformVersion };
  }

  const nav = window.navigator;
  const userAgent = nav.userAgent || '';
  const data = (nav as any).userAgentData as { platform?: string; platformVersion?: string } | undefined;
  if (data?.platform) {
    const platformName = normalizeBrowserPlatformName(data.platform);
    const version = (data.platformVersion || '').replace(/_/g, '.').trim();
    if (version) {
      return { name: platformName, version };
    }
  }

  const macMatch = /Mac OS X ([0-9_]+(?:_[0-9_]+)*)/i.exec(userAgent);
  if (macMatch?.[1]) {
    return { name: 'macos', version: macMatch[1].replace(/_/g, '.') };
  }

  const iosMatch = /(iPhone|iPad|iPod).*OS ([0-9_]+)/i.exec(userAgent);
  if (iosMatch?.[2]) {
    return { name: 'ios', version: iosMatch[2].replace(/_/g, '.') };
  }

  const winMatch = /Windows NT ([0-9.]+)/i.exec(userAgent);
  if (winMatch?.[1]) {
    return { name: 'windows', version: winMatch[1] };
  }

  const androidMatch = /Android ([0-9.]+)/i.exec(userAgent);
  if (androidMatch?.[1]) {
    return { name: 'android', version: androidMatch[1] };
  }

  if (/Linux/i.test(userAgent)) {
    return { name: 'linux', version: '0.0.0' };
  }

  return { name: 'browser', version: '0.0.0' };
}

function resolveBrowserDefaultClientHeaders(): Record<string, string> {
  const clientMeta = readBrowserRuntimeClientMeta();
  if (!clientMeta) {
    return {};
  }

  const platform = resolveBrowserPlatform();
  return {
    [CLIENT_HEADER_NAMES.client]: 'web',
    [CLIENT_HEADER_NAMES.clientVersion]: clientMeta.version,
    [CLIENT_HEADER_NAMES.clientBuild]: clientMeta.build,
    [CLIENT_HEADER_NAMES.platform]: platform.name,
    [CLIENT_HEADER_NAMES.platformVersion]: platform.version,
  };
}

function fillMissingClientHeaders(headers: Record<string, string>): Record<string, string> {
  if (typeof window === 'undefined') {
    return headers;
  }

  const inferredHeaders = resolveBrowserDefaultClientHeaders();
  if (!Object.keys(inferredHeaders).length) {
    return headers;
  }

  return {
    ...inferredHeaders,
    ...headers,
  };
}

async function resolveAiClientToken(config: AiClientConfig): Promise<string | null> {
  if (config.tokenProvider) {
    const token = await config.tokenProvider();
    return token ?? null;
  }
  return null;
}

async function resolveAiClientHeaders(config: AiClientConfig): Promise<Record<string, string>> {
  if (config.clientHeaders) {
    try {
      const headers = await config.clientHeaders();
      return headers && typeof headers === 'object' ? { ...headers } : {};
    } catch {
      return {};
    }
  }
  return {};
}

export function createAiClient(config: AiClientConfig = {}): AiClient {
  const fetchImpl = config.fetchImpl ?? globalThis.fetch?.bind(globalThis);
  if (!fetchImpl) {
    throw new Error('ai_client_missing_fetch');
  }

  const baseUrl = stripTrailingSlash(config.baseUrl ?? inferBaseUrl());

  async function buildHeaders(): Promise<Record<string, string>> {
    const headers = fillMissingClientHeaders({
      ...(await resolveAiClientHeaders(config)),
    });
    const token = await resolveAiClientToken(config);
    if (token && !headers.Authorization) {
      headers.Authorization = `Bearer ${token}`;
    }
    return headers;
  }

  async function buildRequestInit(payload: unknown, signal?: AbortSignal): Promise<RequestInit> {
    const headers = await buildHeaders();
    headers['Content-Type'] = 'application/json';
    return {
      method: 'POST',
      headers,
      body: JSON.stringify(payload),
      credentials: resolveBrowserRequestCredentials(),
      signal,
    };
  }

  async function throwHttpError(response: Response): Promise<never> {
    let payload: any = null;
    try {
      const text = await response.text();
      if (text) {
        try {
          payload = JSON.parse(text);
        } catch {
          payload = { message: text };
        }
      }
    } catch {
      payload = null;
    }
    const code = payload?.error ?? `http_${response.status}`;
    const message = payload?.message ?? response.statusText ?? 'Request failed';
    const error = new Error(`${code}: ${message}`);
    (error as any).status = response.status;
    (error as any).code = code;
    (error as any).details = payload;
    throw error;
  }

  async function ensureOk(response: Response): Promise<void> {
    if (!response.ok) {
      await throwHttpError(response);
    }
  }

  async function generateText(input: string, options?: GenerateTextOptions): Promise<GenerateTextResponse> {
    const normalizedInput = input?.trim();
    if (!normalizedInput) {
      throw new Error('ai_client_missing_input');
    }
    const size = options?.size ?? 'small';
    const mode = options?.mode ?? 'text';
    const rawSystem = options?.system?.trim();
    const system = rawSystem && rawSystem.length ? rawSystem : undefined;

    const response = await fetchImpl(
      `${baseUrl}/text/generate`,
      await buildRequestInit(
        {
          input: normalizedInput,
          size,
          mode,
          system,
        },
        options?.signal,
      ),
    );

    await ensureOk(response);

    const data = (await response.json()) as GenerateTextResponse;
    return data;
  }

  function applyMediaGenerationPayload(
    payload: Record<string, unknown>,
    request: GenerateAssetRequest,
  ): boolean {
    if (request.modality === 'IMAGE') {
      payload.mode = 'image';
      payload.image1 = request.image1 ?? undefined;
      payload.image2 = request.image2 ?? undefined;
      payload.aspectRatio = request.aspectRatio;
      payload.imageSize = request.imageSize;
      return true;
    }
    if (request.modality === 'VIDEO') {
      payload.durationSeconds = typeof request.durationSeconds === 'number' ? request.durationSeconds : undefined;
      payload.aspectRatio = request.aspectRatio;
      payload.resolution = '720p';
      payload.image1 = request.image1 ?? undefined;
      payload.image2 = request.image2 ?? undefined;
      return true;
    }
    return false;
  }

  function applyAudioGenerationPayload(
    payload: Record<string, unknown>,
    request: GenerateAssetRequest,
  ): boolean {
    if (request.modality === 'MUSIC') {
      payload.durationMs = typeof request.durationMs === 'number' ? request.durationMs : undefined;
      payload.forceInstrumental = typeof request.forceInstrumental === 'boolean' ? request.forceInstrumental : undefined;
      payload.coverPrompt = typeof request.coverPrompt === 'string' ? request.coverPrompt : undefined;
      return true;
    }
    if (request.modality === 'SFX') {
      payload.durationSeconds = typeof request.durationSeconds === 'number' ? request.durationSeconds : undefined;
      payload.loop = typeof request.loop === 'boolean' ? request.loop : undefined;
      payload.coverPrompt = typeof request.coverPrompt === 'string' ? request.coverPrompt : undefined;
      return true;
    }
    if (request.modality === 'SPEECH') {
      payload.speechVoice = typeof request.speechVoice === 'string' ? request.speechVoice : undefined;
      payload.speechProviderVoiceId =
        typeof request.speechProviderVoiceId === 'string' ? request.speechProviderVoiceId : undefined;
      return true;
    }
    return false;
  }

  function applyGenerateAssetPayloadByModality(
    payload: Record<string, unknown>,
    request: GenerateAssetRequest,
  ): void {
    if (applyMediaGenerationPayload(payload, request) || applyAudioGenerationPayload(payload, request)) {
      return;
    }
    if (request.modality === 'MODEL_3D') {
      payload.sourceMode = request.sourceMode;
      payload.image1 = request.image1 ?? undefined;
      payload.image2 = request.image2 ?? undefined;
      payload.topology = request.topology;
      payload.targetPolycount = typeof request.targetPolycount === 'number' ? request.targetPolycount : undefined;
      payload.shouldRemesh = typeof request.shouldRemesh === 'boolean' ? request.shouldRemesh : undefined;
      payload.shouldTexture = typeof request.shouldTexture === 'boolean' ? request.shouldTexture : undefined;
    }
  }

  function buildGenerateAssetPayload(request: GenerateAssetRequest): Record<string, unknown> {
    const normalizedInput = request.input?.trim();
    if (!normalizedInput) {
      throw new Error('ai_client_missing_input');
    }
    const payload: Record<string, unknown> = {
      modality: request.modality,
      input: normalizedInput,
      assetName: request.assetName,
      assetDisplayName: request.assetDisplayName,
      assetDescription: request.assetDescription,
      assetVisibility: request.assetVisibility,
      attachAppVersionId: request.attachAppVersionId,
      remixAssetVersionRef: request.remixAssetVersionRef,
      suggestedTagRefs: request.suggestedTagRefs,
    };
    if (request.modality !== 'SPEECH') {
      payload.assetSubcategory = request.assetSubcategory;
    }
    applyGenerateAssetPayloadByModality(payload, request);
    return payload;
  }

  async function createGenerationJob(request: CreateGenerationJobRequest): Promise<CreateGenerationJobResponse> {
    const payload = buildGenerateAssetPayload(request);
    const response = await fetchImpl(
      `${baseUrl}/ai/assets/jobs`,
      await buildRequestInit(payload, request.signal),
    );
    await ensureOk(response);
    return (await response.json()) as CreateGenerationJobResponse;
  }

  async function getGenerationJob(id: string, options: { signal?: AbortSignal } = {}): Promise<GetGenerationJobResponse> {
    const normalizedId = id?.trim();
    if (!normalizedId) {
      throw new Error('ai_client_missing_job_id');
    }
    const response = await fetchImpl(`${baseUrl}/ai/assets/jobs/${encodeURIComponent(normalizedId)}`, {
      method: 'GET',
      headers: await buildHeaders(),
      credentials: resolveBrowserRequestCredentials(),
      signal: options.signal,
    });
    await ensureOk(response);
    return (await response.json()) as GetGenerationJobResponse;
  }

  async function listGenerationJobs(options: ListGenerationJobsOptions = {}): Promise<ListGenerationJobsResponse> {
    const params = new URLSearchParams();
    if (options.modality) {
      params.set('modality', options.modality);
    }
    if (options.status) {
      params.set('status', options.status);
    }
    if (typeof options.limit === 'number' && Number.isFinite(options.limit)) {
      params.set('limit', String(options.limit));
    }
    if (typeof options.offset === 'number' && Number.isFinite(options.offset)) {
      params.set('offset', String(options.offset));
    }
    const queryString = params.toString();
    const query = queryString ? `?${queryString}` : '';
    const response = await fetchImpl(`${baseUrl}/ai/assets/jobs${query}`, {
      method: 'GET',
      headers: await buildHeaders(),
      credentials: resolveBrowserRequestCredentials(),
      signal: options.signal,
    });
    await ensureOk(response);
    return (await response.json()) as ListGenerationJobsResponse;
  }

  async function deleteGenerationJob(id: string, options: { signal?: AbortSignal } = {}): Promise<void> {
    const normalizedId = id?.trim();
    if (!normalizedId) {
      throw new Error('ai_client_missing_job_id');
    }
    const response = await fetchImpl(`${baseUrl}/ai/assets/jobs/${encodeURIComponent(normalizedId)}`, {
      method: 'DELETE',
      headers: await buildHeaders(),
      credentials: resolveBrowserRequestCredentials(),
      signal: options.signal,
    });
    await ensureOk(response);
  }

  async function generateJson(input: string, options?: GenerateJsonOptions): Promise<GenerateJsonResponse> {
    const normalizedInput = input?.trim();
    if (!normalizedInput) {
      throw new Error('ai_client_missing_input');
    }
    const normalizedSystem = options?.system?.trim();
    const response = await fetchImpl(
      `${baseUrl}/json/generate`,
      await buildRequestInit(
        {
          input: normalizedInput,
          size: options?.size ?? 'small',
          system: normalizedSystem && normalizedSystem.length ? normalizedSystem : undefined,
          responseJsonSchema: options?.responseJsonSchema,
        },
        options?.signal,
      ),
    );

    await ensureOk(response);

    const data = (await response.json()) as GenerateJsonResponse;
    return data;
  }

  async function listGenerations(options: ListGenerationsOptions = {}): Promise<ListGenerationsResponse> {
    const params = new URLSearchParams();
    if (options.type) {
      params.set('type', options.type);
    }
    if (typeof options.limit === 'number' && Number.isFinite(options.limit)) {
      params.set('limit', String(options.limit));
    }
    if (typeof options.offset === 'number' && Number.isFinite(options.offset)) {
      params.set('offset', String(options.offset));
    }
    const queryString = params.toString();
    const query = queryString ? `?${queryString}` : '';
    const response = await fetchImpl(`${baseUrl}/generations${query}`, {
      method: 'GET',
      headers: await buildHeaders(),
      credentials: resolveBrowserRequestCredentials(),
      signal: options.signal,
    });

    await ensureOk(response);

    const data = (await response.json()) as ListGenerationsResponse;
    return data;
  }

  async function listDiscoverGenerations(options: ListGenerationsOptions = {}): Promise<ListGenerationsResponse> {
    const params = new URLSearchParams();
    if (options.type) {
      params.set('type', options.type);
    }
    if (typeof options.limit === 'number' && Number.isFinite(options.limit)) {
      params.set('limit', String(options.limit));
    }
    if (typeof options.offset === 'number' && Number.isFinite(options.offset)) {
      params.set('offset', String(options.offset));
    }
    const queryString = params.toString();
    const query = queryString ? `?${queryString}` : '';
    const response = await fetchImpl(`${baseUrl}/generations/discover${query}`, {
      method: 'GET',
      headers: await buildHeaders(),
      credentials: resolveBrowserRequestCredentials(),
      signal: options.signal,
    });

    await ensureOk(response);

    const data = (await response.json()) as ListGenerationsResponse;
    return data;
  }

  return {
    generateText,
    createGenerationJob,
    getGenerationJob,
    listGenerationJobs,
    deleteGenerationJob,
    generateJson,
    listGenerations,
    listDiscoverGenerations,
  };
}
