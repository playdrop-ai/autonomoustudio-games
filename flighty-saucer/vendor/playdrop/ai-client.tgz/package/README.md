# @playdrop/ai-client

Typed client for PlayDrop AI generation APIs.

## Responsibilities

- Exposes browser/server-safe helpers for text, image, music, SFX, speech, video, and model-3D generation calls.
- Shares generation response and asset metadata types with `@playdrop/types`.
- Normalizes AI server request options, billing metadata, generated asset references, and abort signals for callers.

## Consumers

- `apps/web` uses this package for creator-side AI generation and create-flow draft helpers.
- `apps/admin` can depend on the same client surface for operator generation views.
- `packages/sdk` and `packages/playdrop-cli` use the generated types and request helpers for creator-facing AI workflows.

## Run Locally

Run from the repository root:

```bash
npm run test --workspace @playdrop/ai-client
npm run build --workspace @playdrop/ai-client
```

## Related Workspaces

- Talks to `@playdrop/ai-server`.
- Depends on `@playdrop/types`.
