import * as THREEType from 'three';
import { GLTFExporter } from 'three/examples/jsm/exporters/GLTFExporter.js';
import RapierModule from '@dimforge/rapier3d-compat';
import nipplejsModule from 'nipplejs';
import PhaserModule from 'phaser';

type BoxelId = string;
type PatternId = string;
type MaterialId = string;
type TextureId = string;
type PrimitiveId = string;
type NodeId = string;
type GeometryId = string;
type AnimationId = string;
type Vec2 = [number, number];
type Vec3 = [number, number, number];
type PrimitiveKind = 'plain_box' | 'textured_box' | 'voxel_box' | 'combo_box';
type ConnectMode = 'none' | 'child' | 'parent' | 'both';
interface Node {
    id: NodeId;
    position: Vec3;
    /**
     * Applied in XYZ order (likely radians) if provided; omitted means default rotation.
     */
    rotation?: Vec3 | undefined;
    /**
     * Uniform axes scaling override; defaults to [1,1,1] when omitted.
     */
    scale?: Vec3 | undefined;
    /**
     * Bounding size for the attached primitive instance; required for combo imports and voxel authoring.
     */
    size?: Vec3 | undefined;
    /**
     * Local-space offset applied to the primitive mesh within this node. Keeps the node pivot in place
     * while sliding geometry (e.g. aligning a foot pivot); defaults to [0,0,0].
     */
    center?: Vec3 | undefined;
    /**
     * Controls how this node blends with its parent when building a skinned mesh.
     * - 'none' (default): no welding; the node remains fully bound to its own bone.
     * - 'child': child vertices overlapping the parent bounds blend into the parent bone.
     * - 'parent': parent vertices overlapping this node's bounds blend into the child bone.
     * - 'both': mirror welding on both parent and child geometry.
     * A legacy boolean `true` maps to 'child'.
     */
    connect?: ConnectMode | undefined;
    /**
     * Primitive bound to this node. When undefined, the node acts as a pure transform/group.
     */
    mesh?: PrimitiveId | undefined;
    children: Node[];
}
interface Geometry {
    id: GeometryId;
    root: Node;
}
interface Material {
    id: MaterialId;
    baseColor: Vec3;
    emissiveColor?: Vec3 | undefined;
    opacity?: number | undefined;
}
interface Pattern {
    id: PatternId;
    size: Vec2;
    data: number[];
}
interface Texture {
    id: TextureId;
    pattern: PatternId;
    materials: MaterialId[];
}
interface BoxPrimitiveBase {
    id: PrimitiveId;
    kind: PrimitiveKind;
    size: Vec3;
}
interface PlainBox extends BoxPrimitiveBase {
    kind: 'plain_box';
    material: MaterialId;
}
interface TexturedBox extends BoxPrimitiveBase {
    kind: 'textured_box';
    top?: TextureId | undefined;
    bottom?: TextureId | undefined;
    north?: TextureId | undefined;
    south?: TextureId | undefined;
    east?: TextureId | undefined;
    west?: TextureId | undefined;
    /**
     * Texture applied to all four side faces (north, south, east, west) when an individual face texture
     * is not specified. Individual face properties still win when present.
     */
    sides?: TextureId | undefined;
    /**
     * Texture applied as a catch-all fallback for every face when no face-specific or `sides` texture
     * is provided. Evaluated last after top/bottom/sides.
     */
    all?: TextureId | undefined;
    /**
     * Rendering mode for the primitive.
     * - `plain`: opaque surface; faces are single sided and rendered without alpha cutouts.
     * - `cutout`: semi-transparent/cutout surface; faces render double sided with alpha testing.
     */
    renderMode?: 'plain' | 'cutout' | undefined;
    /**
     * Optional overlay textures rendered as a thin outer shell using cutout blending. Overlay fields
     * follow the same fallback rules as their base counterparts (face > sides > all).
     */
    topOverlay?: TextureId | undefined;
    bottomOverlay?: TextureId | undefined;
    northOverlay?: TextureId | undefined;
    southOverlay?: TextureId | undefined;
    eastOverlay?: TextureId | undefined;
    westOverlay?: TextureId | undefined;
    sidesOverlay?: TextureId | undefined;
    allOverlay?: TextureId | undefined;
}
interface VoxelBox extends BoxPrimitiveBase {
    kind: 'voxel_box';
    /**
     * Flattened material indices for the voxel volume. Length must equal size[0] * size[1] * size[2].
     * Index ordering is X-major, then Y, then Z (x + y * sizeX + z * sizeX * sizeY). A value of 0
     * denotes empty space, while positive values reference palette entries (value - 1).
     */
    voxels: number[];
    /**
     * Materials available to this voxel primitive. Voxels value of N > 0 resolves to palette[N - 1],
     * so palette[0] is the material used when voxels contains 1.
     */
    palette: MaterialId[];
}
interface ComboBox extends BoxPrimitiveBase {
    kind: 'combo_box';
    slots: Array<{
        id: string;
        primitive: PrimitiveId;
        offset: Vec3;
    }>;
}
type Primitive = PlainBox | TexturedBox | VoxelBox | ComboBox;
type AnimationChannelProperty = 'position' | 'rotation' | 'scale';
interface AnimationKeyframe {
    time: number;
    value: Vec3;
}
interface AnimationChannel {
    node: NodeId;
    property: AnimationChannelProperty;
    keyframes: AnimationKeyframe[];
}
interface Animation {
    id: AnimationId;
    /**
     * Total clip length in seconds. Keyframe times are expected to fall within [0, duration].
     */
    duration: number;
    channels: AnimationChannel[];
}
interface BoxelDefinition {
    /**
     * Stable entity identifier persisted with serialized definitions so tooling can reference entities
     * without relying on filenames.
     */
    id: BoxelId;
    geometry: Geometry;
    patterns: Pattern[];
    materials: Material[];
    textures: Texture[];
    primitives: Primitive[];
    animations: Animation[];
}

declare const formatNumber: (value: number) => string;
declare const formatVec: (vec?: number[]) => string;
declare const formatColor: (vec?: number[]) => string;

declare const formatBoxel$1: (model: BoxelDefinition) => string;
declare const parseBoxel$1: (candidate: unknown) => BoxelDefinition;
declare const parseBoxelJson: (raw: string) => BoxelDefinition;

interface BoxelValidationIssue {
    path: string;
    message: string;
}
declare class BoxelValidationError extends Error {
    readonly issues: BoxelValidationIssue[];
    constructor(message: string, issues: BoxelValidationIssue[]);
}
declare function isTupleOfNumbers(value: unknown, expectedLength: number): value is number[];
declare function assertVec3(value: unknown, context: string): asserts value is Vec3;
declare function assertVec2(value: unknown, context: string): asserts value is Vec2;
declare function assertPattern(value: unknown, index: number): asserts value is Pattern;
declare function assertMaterial(value: unknown, index: number): asserts value is Material;
declare function assertTexture(value: unknown, index: number): asserts value is Texture;
declare function assertPrimitive(value: unknown, index: number): asserts value is Primitive;
declare function assertAnimation(value: unknown, index: number): asserts value is Animation;
declare function assertTexturedBoxFaceSizes(box: TexturedBox, textureLookup: Map<string, Texture>, patternLookup: Map<string, Pattern>, materialLookup: Map<string, Material>): void;
declare function validateBoxel$1(candidate: unknown): {
    boxel: BoxelDefinition | null;
    issues: BoxelValidationIssue[];
};
declare function assertBoxel(candidate: unknown): BoxelDefinition;
declare function collectBoxelValidationIssues(candidate: unknown): BoxelValidationIssue[];

type VoxelSize = [number, number, number];
interface VoxelIndex {
    x: number;
    y: number;
    z: number;
    index: number;
}
declare const clampSizeAxis: (value: number) => number;
declare const createFilledVoxelData: (size: VoxelSize, materialIndex?: number) => number[];
declare const validateVoxelData: (voxels: number[], size: VoxelSize) => boolean;
declare const cloneVoxelData: (voxels: number[]) => number[];
declare const forEachVoxel: (voxel: VoxelBox, callback: (info: VoxelIndex, material: number) => void) => void;
declare const setVoxelAt: (voxels: number[], size: VoxelSize, coord: {
    x: number;
    y: number;
    z: number;
}, value: number) => void;
declare const getVoxelIndex: (size: VoxelSize, coord: {
    x: number;
    y: number;
    z: number;
}) => number;

type FaceKey = 'top' | 'bottom' | 'north' | 'south' | 'east' | 'west';
declare function uvToCanvasPixel(u: number, v: number, width: number, height: number): {
    x: number;
    y: number;
};
declare const buildPatternAscii: (pattern: {
    size: [number, number];
    data: number[];
}) => string[];
declare function resolveFaceTextureId(box: TexturedBox, face: FaceKey): string | undefined;
declare function resolveOverlayFaceTextureId(box: TexturedBox, face: FaceKey): string | undefined;
declare function collectFaceTextureIds(box: TexturedBox): string[];
declare function collectOverlayFaceTextureIds(box: TexturedBox): string[];
declare function getFaceKeys(): FaceKey[];
declare function getTextureMaterialIds(texture: Texture): string[];
declare function collectTexturedBoxTextures(box: TexturedBox): Set<string>;
declare function collectTexturedBoxMaterials(box: TexturedBox, textureLookup: Map<string, Texture>): Set<string>;
declare function collectTexturedBoxPatterns(box: TexturedBox, textureLookup: Map<string, Texture>): Set<string>;
declare function determineTexturedBoxRenderMode(entity: BoxelDefinition, box: TexturedBox): 'plain' | 'cutout';
interface TexturedBoxDependencySummary {
    textures: Set<string>;
    materials: Set<string>;
    patterns: Set<string>;
}
declare function collectTexturedBoxDependencies(box: TexturedBox, textureLookup: Map<string, Texture>): TexturedBoxDependencySummary;
declare function collectEntityTextureLookup(entity: BoxelDefinition): Map<string, Texture>;
declare function collectEntityMaterialLookup(entity: BoxelDefinition): Map<string, Material>;
declare function collectEntityPatternLookup(entity: BoxelDefinition): Map<string, Pattern>;

declare function materialsApproximatelyEqual(a: Material, b: Material): boolean;
declare function materialFingerprint(material: Material): string;
interface MaterialMergeResult {
    additions: Material[];
    rewrites: Map<string, string>;
}
declare function mergeMaterials(existingMaterials: readonly Material[], incomingMaterials: readonly Material[]): MaterialMergeResult;
interface PaletteCarrier {
    palette?: ReadonlyArray<string> | null;
}
declare function collectPaletteIds(primitives: Iterable<PaletteCarrier>): Set<string>;
declare function cloneMaterialsByPalette(materials: readonly Material[], paletteIds: Set<string>): Material[];
interface MaterialEnsurerOptions {
    prefix?: string;
}
interface MaterialEnsurer {
    ensure(color: {
        r: number;
        g: number;
        b: number;
        a: number;
    }): string;
}
declare function createMaterialEnsurer(materials: Material[], options?: MaterialEnsurerOptions): MaterialEnsurer;

interface PrimitiveDependencySets {
    primitives: Set<string>;
    materials: Set<string>;
    textures: Set<string>;
    patterns: Set<string>;
}
declare const buildPrimitiveLookup: (entity: BoxelDefinition) => Map<string, Primitive>;
declare const buildMaterialLookup: (entity: BoxelDefinition) => Map<string, Material>;
declare const buildTextureLookup: (entity: BoxelDefinition) => Map<string, Texture>;
declare const buildPatternLookup: (entity: BoxelDefinition) => Map<string, Pattern>;
declare function findNodeById(root: Node, targetId: string): Node | null;
declare function findNode(root: Node, targetId: string): Node | undefined;
declare function applyNodeDimensions(node: Node, primitive: {
    size: [number, number, number];
}, originalSize: [number, number, number], originalCenter: [number, number, number]): void;
declare function applyNodeDimensionsAxis(node: Node, primitive: {
    size: [number, number, number];
}, originalSize: [number, number, number], originalCenter: [number, number, number], axis: 'x' | 'y'): void;
declare function updateChildPosition(parent: Node, childId: string, offsetY: number): void;
declare function updateChildPositionAxis(parent: Node, childId: string, axis: 'x' | 'y', value: number): void;
declare function anchorCenter(originalCenter: number, originalSize: number, newSize: number, orientation: 1 | -1): number;
declare function collectPrimitiveUsage(entity: BoxelDefinition, primitiveId: string): {
    nodeIds: string[];
    comboIds: string[];
};
declare function computeComboBoundingSize(combo: ComboBox, primitiveLookup: Map<string, Primitive>): [number, number, number];
/**
 * Estimate the pixel-per-meter scale of an entity using its root scale vector.
 * Returns an integer value (e.g. 16 for classic avatars, 32 for HD avatars) or null when it cannot be derived.
 */
declare function computeEntityPixelsPerMeter(entity: BoxelDefinition): number | null;
declare function collectPrimitiveDependencies(entity: BoxelDefinition, rootPrimitiveId: string): PrimitiveDependencySets;
declare function ensureNoIdCollisions<T extends {
    id: string;
}>(existing: readonly T[], incomingIds: Set<string>, entitySection: string): void;
declare function selectByIdOrder<T extends {
    id: string;
}>(items: readonly T[], ids: Set<string>): T[];
interface MaterialMergeOutcome {
    additions: Material[];
    rewrites: Map<string, string>;
}
declare function mergeIncomingMaterials(existingMaterials: readonly Material[], incomingMaterials: readonly Material[]): MaterialMergeOutcome;
declare function applyMaterialRewriteToPrimitive(primitive: Primitive, rewrite: (id: string) => string): Primitive;
declare function applyMaterialRewriteToTexture(texture: Texture, rewrite: (id: string) => string): Texture;
declare function cloneEntity<T>(value: T): T;

interface CleanEntityReport {
    primitives: string[];
    textures: string[];
    patterns: string[];
    materials: string[];
}
interface CleanEntityResult {
    entity: BoxelDefinition;
    removed: CleanEntityReport;
}
declare function cleanEntity$1(entity: BoxelDefinition): CleanEntityResult;

declare function upscaleEntity(entity: BoxelDefinition, factor?: number): BoxelDefinition;
declare function upscaleEntityGeometry(entity: BoxelDefinition, factor?: number): BoxelDefinition;

interface BuildFaceOptions {
    entity: BoxelDefinition;
    primitive: TexturedBox;
    face: FaceName$2;
    prefix?: string;
}
type FaceName$2 = 'north' | 'south' | 'east' | 'west' | 'top' | 'bottom';
declare function buildFaceFromNeighbors(options: BuildFaceOptions): string | undefined;

declare function mergeOverlayIntoBase(entity: BoxelDefinition, primitive: TexturedBox): void;

type OverlayVoxelMode = 'outer_wrap' | 'overlay_overwrite' | 'base_inset';
interface TexturedToVoxelOptions {
    base: TexturedBox;
    overlay?: TexturedBox | undefined;
    textureLookup: Map<string, Texture>;
    patternLookup: Map<string, Pattern>;
    materialLookup: Map<string, Material>;
    mode?: OverlayVoxelMode | undefined;
    targetId?: string | undefined;
}
declare function convertTexturedBoxesToVoxel(options: TexturedToVoxelOptions): VoxelBox;

type LayerMode = 'base_only' | 'flat' | 'overlay' | 'voxel';
interface LayerModeOptions {
    voxelMode?: OverlayVoxelMode;
    stripAlpha?: boolean;
    transparentFillColor?: [number, number, number];
}
declare function applyLayerMode(entity: BoxelDefinition, mode: LayerMode, options?: LayerModeOptions | OverlayVoxelMode): BoxelDefinition;

type SplitAxis = 'x' | 'y' | 'z';
interface SplitVoxelBoxResult {
    first: VoxelBox;
    second: VoxelBox;
}
interface SplitVoxelResult {
    firstId: string;
    secondId: string;
}
declare function splitVoxelPrimitive(entity: BoxelDefinition, primitiveId: string, axis: SplitAxis, plane: number): SplitVoxelResult;
declare function splitVoxelBoxClone(primitive: VoxelBox, axis: SplitAxis, plane: number): SplitVoxelBoxResult;

type CrossFillMode = 'empty' | 'solid' | 'solid-edge';
interface CrossFillOptions {
    mode: CrossFillMode;
    color?: [number, number, number] | undefined;
    alpha?: number | undefined;
}
interface SplitTexturedOptions {
    axis: SplitAxis;
    plane: number;
    fill?: CrossFillOptions | undefined;
    overlayFill?: CrossFillOptions | undefined;
}
declare function splitTexturedBox(entity: BoxelDefinition, primitiveId: string, options: SplitTexturedOptions): {
    firstId: string;
    secondId: string;
    negativeId: string;
    positiveId: string;
};

interface GreedyQuad {
    material: number;
    axis: 0 | 1 | 2;
    normal: 1 | -1;
    plane: number;
    origin: [number, number, number];
    size: [number, number];
}
declare function generateGreedyQuads(voxels: number[], dimensions: [number, number, number]): GreedyQuad[];
declare function generateQuadsForVoxelBox(primitive: VoxelBox): GreedyQuad[];

type GeometryVec3 = [number, number, number];
type GeometryFaceName = 'north' | 'south' | 'east' | 'west' | 'up' | 'down';
interface GeometryCube {
    origin: GeometryVec3;
    size: GeometryVec3;
    uv: [number, number] | Record<GeometryFaceName, [number, number, number?, number?]>;
    inflate?: number;
    mirror?: boolean;
}
interface GeometryBone {
    name: string;
    parent?: string;
    pivot?: GeometryVec3;
    mirror?: boolean;
    cubes?: GeometryCube[];
}
interface GeometryEntry {
    texturewidth?: number;
    textureheight?: number;
    bones?: GeometryBone[];
}
declare const toGeometryVec3: (input?: GeometryVec3 | Vec3) => GeometryVec3;

type FaceName$1 = 'north' | 'south' | 'east' | 'west' | 'up' | 'down';
type Rotation = 0 | 90 | 180 | 270;
interface FaceTransform {
    source: FaceName$1;
    rotate?: Rotation;
    flipHorizontal?: boolean;
    flipVertical?: boolean;
}
interface FaceUVRect$1 {
    x: number;
    y: number;
    width: number;
    height: number;
}
interface FaceSource {
    faces: Record<FaceName$1, FaceUVRect$1>;
}
declare const IDENTITY_FACE_MAP: Record<FaceName$1, FaceTransform>;
declare const RIGHT_ARM_FACE_MAP: Record<FaceName$1, FaceTransform>;
declare const LEFT_ARM_FACE_MAP: Record<FaceName$1, FaceTransform>;
declare const PART_FACE_TRANSFORMS: Record<string, Record<FaceName$1, FaceTransform>>;
declare function getFaceDimensions(size: [number, number, number], face: FaceName$1): [number, number];
declare function extractSourceFacePixels(cubeInfo: FaceSource, face: FaceName$1, textureWidth: number, textureHeight: number, texturePixels: Uint8Array): {
    width: number;
    height: number;
    data: Uint8Array;
};
declare function transformFacePixels(source: FaceSource, transform: FaceTransform, textureWidth: number, textureHeight: number, texturePixels: Uint8Array): {
    width: number;
    height: number;
    data: Uint8Array;
};

interface FaceUVRect {
    x: number;
    y: number;
    width: number;
    height: number;
}
interface HumanoidSourceCube {
    bone: GeometryBone;
    cube: GeometryCube;
    faces: Record<FaceName$1, FaceUVRect>;
}
type HumanoidOverlayCube = HumanoidSourceCube;
type HumanoidPartKey = 'torso' | 'head' | 'arm_left' | 'arm_right' | 'leg_left' | 'leg_right';
interface HumanoidSourceScan {
    geometryId: string;
    bones: GeometryBone[];
    parts: Map<HumanoidPartKey, {
        base: HumanoidSourceCube;
        overlay?: HumanoidOverlayCube | undefined;
    }>;
    textureWidth: number;
    textureHeight: number;
    texturePixels: Uint8Array;
    baseTextureWidth: number;
    baseTextureHeight: number;
    textureScaleX: number;
    textureScaleY: number;
}
interface ScanHumanoidSourceOptions {
    geometryId: string;
    geometry: GeometryEntry;
    textureWidth: number;
    textureHeight: number;
    texturePixels: Uint8Array;
    baseTextureWidth?: number;
    baseTextureHeight?: number;
    textureScaleX?: number;
    textureScaleY?: number;
}
declare function scanHumanoidSource(options: ScanHumanoidSourceOptions): HumanoidSourceScan;

interface BuildHumanoidR6Options {
    template: BoxelDefinition;
    source: HumanoidSourceScan;
    geometryId: string;
    outputId: string;
    textureWidth: number;
    textureHeight: number;
    texturePixels: Uint8Array;
}
declare function buildHumanoidR6Entity(options: BuildHumanoidR6Options): BoxelDefinition;

interface CreateFaceArtifactsParams {
    baseId: string;
    face: FaceName$1;
    source: FaceSource;
    transform: FaceTransform;
    expectedSize: [number, number];
    textureWidth: number;
    textureHeight: number;
    texturePixels: Uint8Array;
    ensureMaterial: (color: {
        r: number;
        g: number;
        b: number;
        a: number;
    }) => string;
    variant?: 'base' | 'overlay';
}
interface FaceArtifactsResult {
    pattern: Pattern | null;
    texture: Texture | null;
    hasTransparency: boolean;
    hasVisiblePixels: boolean;
}
declare function createFaceArtifacts(params: CreateFaceArtifactsParams): FaceArtifactsResult;

interface BuildHumanoidR15Options {
    template: BoxelDefinition;
    source: BoxelDefinition;
    outputId: string;
}

declare function buildHumanoidR15TexturedEntity(options: BuildHumanoidR15Options): BoxelDefinition;

declare function buildHumanoidR15Entity(options: BuildHumanoidR15Options): BoxelDefinition;

declare const TEMPLATE_REGISTRY: {
    readonly humanoid_r6: BoxelDefinition;
    readonly humanoid_r15: BoxelDefinition;
};
type HumanoidTemplateId = keyof typeof TEMPLATE_REGISTRY;
declare const getHumanoidTemplate: (id: HumanoidTemplateId) => BoxelDefinition;
declare const HUMANOID_R6_TEMPLATE_ID: HumanoidTemplateId;
declare const HUMANOID_R15_TEMPLATE_ID: HumanoidTemplateId;

declare const DEFAULT_SATURATION_FACTOR = 2;
interface MaterialSample {
    materialId: string;
    baseColor: Vec3;
    opacity?: number | undefined;
    usageCount: number;
}
interface LuminanceOptions {
    min: number;
    max: number;
    kneeLow?: number;
    kneeHigh?: number;
}
interface SaturationResult {
    color: Vec3;
    luminance: number;
    clipped: boolean;
}
interface LuminanceResult {
    color: Vec3;
    luminance: number;
}
interface MaterialCluster {
    id: string;
    centerRgb: Vec3;
    centerLab: [number, number, number];
    totalCount: number;
    samples: MaterialSample[];
}
declare function collectMaterialUsage(entity: BoxelDefinition): MaterialSample[];
declare function rebalanceLuminance(color: Vec3, options: LuminanceOptions): LuminanceResult;
declare function applySaturation(color: Vec3, options: {
    scale: number;
    luminance?: number;
}): SaturationResult;
declare function mapLuminance(samples: MaterialSample[], options: LuminanceOptions): Array<MaterialSample & {
    color: Vec3;
    luminance: number;
}>;
declare function mapSaturation(entries: Array<{
    color: Vec3;
    luminance: number;
}>, options: {
    scale: number;
}): Array<SaturationResult>;
declare function rewriteEntityPalette(entity: BoxelDefinition, colors: Map<string, Vec3>): BoxelDefinition;
declare function clusterMaterials(samples: MaterialSample[], options?: {
    deltaE?: number;
}): MaterialCluster[];
interface AnalyzePaletteOptions {
    luminance?: Partial<LuminanceOptions>;
    saturationScale?: number;
}
interface AnalyzedMaterial {
    materialId: string;
    baseColor: Vec3;
    opacity?: number | undefined;
    count: number;
    luminance: number;
    balancedColor: Vec3;
    balancedLuminance: number;
    saturatedColor: Vec3;
    saturatedLuminance: number;
    saturationClipped: boolean;
}
declare function analyzePalette(entity: BoxelDefinition, options?: AnalyzePaletteOptions): AnalyzedMaterial[];
declare const analyzeEntityMaterials: typeof analyzePalette;

type entityCore_AnalyzePaletteOptions = AnalyzePaletteOptions;
type entityCore_AnalyzedMaterial = AnalyzedMaterial;
type entityCore_Animation = Animation;
type entityCore_AnimationChannel = AnimationChannel;
type entityCore_AnimationChannelProperty = AnimationChannelProperty;
type entityCore_AnimationId = AnimationId;
type entityCore_AnimationKeyframe = AnimationKeyframe;
type entityCore_BoxelDefinition = BoxelDefinition;
type entityCore_BoxelId = BoxelId;
type entityCore_BoxelValidationError = BoxelValidationError;
declare const entityCore_BoxelValidationError: typeof BoxelValidationError;
type entityCore_BoxelValidationIssue = BoxelValidationIssue;
type entityCore_BuildFaceOptions = BuildFaceOptions;
type entityCore_BuildHumanoidR15Options = BuildHumanoidR15Options;
type entityCore_BuildHumanoidR6Options = BuildHumanoidR6Options;
type entityCore_CleanEntityResult = CleanEntityResult;
type entityCore_ComboBox = ComboBox;
type entityCore_ConnectMode = ConnectMode;
type entityCore_CreateFaceArtifactsParams = CreateFaceArtifactsParams;
type entityCore_CrossFillMode = CrossFillMode;
type entityCore_CrossFillOptions = CrossFillOptions;
declare const entityCore_DEFAULT_SATURATION_FACTOR: typeof DEFAULT_SATURATION_FACTOR;
type entityCore_FaceArtifactsResult = FaceArtifactsResult;
type entityCore_FaceKey = FaceKey;
type entityCore_FaceSource = FaceSource;
type entityCore_FaceTransform = FaceTransform;
type entityCore_Geometry = Geometry;
type entityCore_GeometryBone = GeometryBone;
type entityCore_GeometryCube = GeometryCube;
type entityCore_GeometryEntry = GeometryEntry;
type entityCore_GeometryFaceName = GeometryFaceName;
type entityCore_GeometryId = GeometryId;
type entityCore_GeometryVec3 = GeometryVec3;
type entityCore_GreedyQuad = GreedyQuad;
declare const entityCore_HUMANOID_R15_TEMPLATE_ID: typeof HUMANOID_R15_TEMPLATE_ID;
declare const entityCore_HUMANOID_R6_TEMPLATE_ID: typeof HUMANOID_R6_TEMPLATE_ID;
type entityCore_HumanoidOverlayCube = HumanoidOverlayCube;
type entityCore_HumanoidPartKey = HumanoidPartKey;
type entityCore_HumanoidSourceCube = HumanoidSourceCube;
type entityCore_HumanoidSourceScan = HumanoidSourceScan;
type entityCore_HumanoidTemplateId = HumanoidTemplateId;
declare const entityCore_IDENTITY_FACE_MAP: typeof IDENTITY_FACE_MAP;
declare const entityCore_LEFT_ARM_FACE_MAP: typeof LEFT_ARM_FACE_MAP;
type entityCore_LayerMode = LayerMode;
type entityCore_LayerModeOptions = LayerModeOptions;
type entityCore_LuminanceOptions = LuminanceOptions;
type entityCore_LuminanceResult = LuminanceResult;
type entityCore_Material = Material;
type entityCore_MaterialCluster = MaterialCluster;
type entityCore_MaterialEnsurer = MaterialEnsurer;
type entityCore_MaterialEnsurerOptions = MaterialEnsurerOptions;
type entityCore_MaterialId = MaterialId;
type entityCore_MaterialMergeOutcome = MaterialMergeOutcome;
type entityCore_MaterialMergeResult = MaterialMergeResult;
type entityCore_MaterialSample = MaterialSample;
type entityCore_Node = Node;
type entityCore_NodeId = NodeId;
type entityCore_OverlayVoxelMode = OverlayVoxelMode;
declare const entityCore_PART_FACE_TRANSFORMS: typeof PART_FACE_TRANSFORMS;
type entityCore_Pattern = Pattern;
type entityCore_PatternId = PatternId;
type entityCore_PlainBox = PlainBox;
type entityCore_Primitive = Primitive;
type entityCore_PrimitiveDependencySets = PrimitiveDependencySets;
type entityCore_PrimitiveId = PrimitiveId;
type entityCore_PrimitiveKind = PrimitiveKind;
declare const entityCore_RIGHT_ARM_FACE_MAP: typeof RIGHT_ARM_FACE_MAP;
type entityCore_SaturationResult = SaturationResult;
type entityCore_SplitAxis = SplitAxis;
type entityCore_SplitTexturedOptions = SplitTexturedOptions;
type entityCore_SplitVoxelBoxResult = SplitVoxelBoxResult;
type entityCore_SplitVoxelResult = SplitVoxelResult;
type entityCore_Texture = Texture;
type entityCore_TextureId = TextureId;
type entityCore_TexturedBox = TexturedBox;
type entityCore_TexturedBoxDependencySummary = TexturedBoxDependencySummary;
type entityCore_TexturedToVoxelOptions = TexturedToVoxelOptions;
type entityCore_Vec2 = Vec2;
type entityCore_Vec3 = Vec3;
type entityCore_VoxelBox = VoxelBox;
type entityCore_VoxelIndex = VoxelIndex;
type entityCore_VoxelSize = VoxelSize;
declare const entityCore_analyzeEntityMaterials: typeof analyzeEntityMaterials;
declare const entityCore_analyzePalette: typeof analyzePalette;
declare const entityCore_anchorCenter: typeof anchorCenter;
declare const entityCore_applyLayerMode: typeof applyLayerMode;
declare const entityCore_applyMaterialRewriteToPrimitive: typeof applyMaterialRewriteToPrimitive;
declare const entityCore_applyMaterialRewriteToTexture: typeof applyMaterialRewriteToTexture;
declare const entityCore_applyNodeDimensions: typeof applyNodeDimensions;
declare const entityCore_applyNodeDimensionsAxis: typeof applyNodeDimensionsAxis;
declare const entityCore_applySaturation: typeof applySaturation;
declare const entityCore_assertAnimation: typeof assertAnimation;
declare const entityCore_assertBoxel: typeof assertBoxel;
declare const entityCore_assertMaterial: typeof assertMaterial;
declare const entityCore_assertPattern: typeof assertPattern;
declare const entityCore_assertPrimitive: typeof assertPrimitive;
declare const entityCore_assertTexture: typeof assertTexture;
declare const entityCore_assertTexturedBoxFaceSizes: typeof assertTexturedBoxFaceSizes;
declare const entityCore_assertVec2: typeof assertVec2;
declare const entityCore_assertVec3: typeof assertVec3;
declare const entityCore_buildFaceFromNeighbors: typeof buildFaceFromNeighbors;
declare const entityCore_buildHumanoidR15Entity: typeof buildHumanoidR15Entity;
declare const entityCore_buildHumanoidR15TexturedEntity: typeof buildHumanoidR15TexturedEntity;
declare const entityCore_buildHumanoidR6Entity: typeof buildHumanoidR6Entity;
declare const entityCore_buildMaterialLookup: typeof buildMaterialLookup;
declare const entityCore_buildPatternAscii: typeof buildPatternAscii;
declare const entityCore_buildPatternLookup: typeof buildPatternLookup;
declare const entityCore_buildPrimitiveLookup: typeof buildPrimitiveLookup;
declare const entityCore_buildTextureLookup: typeof buildTextureLookup;
declare const entityCore_clampSizeAxis: typeof clampSizeAxis;
declare const entityCore_cloneEntity: typeof cloneEntity;
declare const entityCore_cloneMaterialsByPalette: typeof cloneMaterialsByPalette;
declare const entityCore_cloneVoxelData: typeof cloneVoxelData;
declare const entityCore_clusterMaterials: typeof clusterMaterials;
declare const entityCore_collectBoxelValidationIssues: typeof collectBoxelValidationIssues;
declare const entityCore_collectEntityMaterialLookup: typeof collectEntityMaterialLookup;
declare const entityCore_collectEntityPatternLookup: typeof collectEntityPatternLookup;
declare const entityCore_collectEntityTextureLookup: typeof collectEntityTextureLookup;
declare const entityCore_collectFaceTextureIds: typeof collectFaceTextureIds;
declare const entityCore_collectMaterialUsage: typeof collectMaterialUsage;
declare const entityCore_collectOverlayFaceTextureIds: typeof collectOverlayFaceTextureIds;
declare const entityCore_collectPaletteIds: typeof collectPaletteIds;
declare const entityCore_collectPrimitiveDependencies: typeof collectPrimitiveDependencies;
declare const entityCore_collectPrimitiveUsage: typeof collectPrimitiveUsage;
declare const entityCore_collectTexturedBoxDependencies: typeof collectTexturedBoxDependencies;
declare const entityCore_collectTexturedBoxMaterials: typeof collectTexturedBoxMaterials;
declare const entityCore_collectTexturedBoxPatterns: typeof collectTexturedBoxPatterns;
declare const entityCore_collectTexturedBoxTextures: typeof collectTexturedBoxTextures;
declare const entityCore_computeComboBoundingSize: typeof computeComboBoundingSize;
declare const entityCore_computeEntityPixelsPerMeter: typeof computeEntityPixelsPerMeter;
declare const entityCore_convertTexturedBoxesToVoxel: typeof convertTexturedBoxesToVoxel;
declare const entityCore_createFaceArtifacts: typeof createFaceArtifacts;
declare const entityCore_createFilledVoxelData: typeof createFilledVoxelData;
declare const entityCore_createMaterialEnsurer: typeof createMaterialEnsurer;
declare const entityCore_determineTexturedBoxRenderMode: typeof determineTexturedBoxRenderMode;
declare const entityCore_ensureNoIdCollisions: typeof ensureNoIdCollisions;
declare const entityCore_extractSourceFacePixels: typeof extractSourceFacePixels;
declare const entityCore_findNode: typeof findNode;
declare const entityCore_findNodeById: typeof findNodeById;
declare const entityCore_forEachVoxel: typeof forEachVoxel;
declare const entityCore_formatColor: typeof formatColor;
declare const entityCore_formatNumber: typeof formatNumber;
declare const entityCore_formatVec: typeof formatVec;
declare const entityCore_generateGreedyQuads: typeof generateGreedyQuads;
declare const entityCore_generateQuadsForVoxelBox: typeof generateQuadsForVoxelBox;
declare const entityCore_getFaceDimensions: typeof getFaceDimensions;
declare const entityCore_getFaceKeys: typeof getFaceKeys;
declare const entityCore_getHumanoidTemplate: typeof getHumanoidTemplate;
declare const entityCore_getTextureMaterialIds: typeof getTextureMaterialIds;
declare const entityCore_getVoxelIndex: typeof getVoxelIndex;
declare const entityCore_isTupleOfNumbers: typeof isTupleOfNumbers;
declare const entityCore_mapLuminance: typeof mapLuminance;
declare const entityCore_mapSaturation: typeof mapSaturation;
declare const entityCore_materialFingerprint: typeof materialFingerprint;
declare const entityCore_materialsApproximatelyEqual: typeof materialsApproximatelyEqual;
declare const entityCore_mergeIncomingMaterials: typeof mergeIncomingMaterials;
declare const entityCore_mergeMaterials: typeof mergeMaterials;
declare const entityCore_mergeOverlayIntoBase: typeof mergeOverlayIntoBase;
declare const entityCore_parseBoxelJson: typeof parseBoxelJson;
declare const entityCore_rebalanceLuminance: typeof rebalanceLuminance;
declare const entityCore_resolveFaceTextureId: typeof resolveFaceTextureId;
declare const entityCore_resolveOverlayFaceTextureId: typeof resolveOverlayFaceTextureId;
declare const entityCore_rewriteEntityPalette: typeof rewriteEntityPalette;
declare const entityCore_scanHumanoidSource: typeof scanHumanoidSource;
declare const entityCore_selectByIdOrder: typeof selectByIdOrder;
declare const entityCore_setVoxelAt: typeof setVoxelAt;
declare const entityCore_splitTexturedBox: typeof splitTexturedBox;
declare const entityCore_splitVoxelBoxClone: typeof splitVoxelBoxClone;
declare const entityCore_splitVoxelPrimitive: typeof splitVoxelPrimitive;
declare const entityCore_toGeometryVec3: typeof toGeometryVec3;
declare const entityCore_transformFacePixels: typeof transformFacePixels;
declare const entityCore_updateChildPosition: typeof updateChildPosition;
declare const entityCore_updateChildPositionAxis: typeof updateChildPositionAxis;
declare const entityCore_upscaleEntity: typeof upscaleEntity;
declare const entityCore_upscaleEntityGeometry: typeof upscaleEntityGeometry;
declare const entityCore_uvToCanvasPixel: typeof uvToCanvasPixel;
declare const entityCore_validateVoxelData: typeof validateVoxelData;
declare namespace entityCore {
  export { entityCore_BoxelValidationError as BoxelValidationError, entityCore_DEFAULT_SATURATION_FACTOR as DEFAULT_SATURATION_FACTOR, entityCore_HUMANOID_R15_TEMPLATE_ID as HUMANOID_R15_TEMPLATE_ID, entityCore_HUMANOID_R6_TEMPLATE_ID as HUMANOID_R6_TEMPLATE_ID, entityCore_IDENTITY_FACE_MAP as IDENTITY_FACE_MAP, entityCore_LEFT_ARM_FACE_MAP as LEFT_ARM_FACE_MAP, entityCore_PART_FACE_TRANSFORMS as PART_FACE_TRANSFORMS, entityCore_RIGHT_ARM_FACE_MAP as RIGHT_ARM_FACE_MAP, entityCore_analyzeEntityMaterials as analyzeEntityMaterials, entityCore_analyzePalette as analyzePalette, entityCore_anchorCenter as anchorCenter, entityCore_applyLayerMode as applyLayerMode, entityCore_applyMaterialRewriteToPrimitive as applyMaterialRewriteToPrimitive, entityCore_applyMaterialRewriteToTexture as applyMaterialRewriteToTexture, entityCore_applyNodeDimensions as applyNodeDimensions, entityCore_applyNodeDimensionsAxis as applyNodeDimensionsAxis, entityCore_applySaturation as applySaturation, entityCore_assertAnimation as assertAnimation, entityCore_assertBoxel as assertBoxel, entityCore_assertMaterial as assertMaterial, entityCore_assertPattern as assertPattern, entityCore_assertPrimitive as assertPrimitive, entityCore_assertTexture as assertTexture, entityCore_assertTexturedBoxFaceSizes as assertTexturedBoxFaceSizes, entityCore_assertVec2 as assertVec2, entityCore_assertVec3 as assertVec3, entityCore_buildFaceFromNeighbors as buildFaceFromNeighbors, entityCore_buildHumanoidR15Entity as buildHumanoidR15Entity, entityCore_buildHumanoidR15TexturedEntity as buildHumanoidR15TexturedEntity, entityCore_buildHumanoidR6Entity as buildHumanoidR6Entity, entityCore_buildMaterialLookup as buildMaterialLookup, entityCore_buildPatternAscii as buildPatternAscii, entityCore_buildPatternLookup as buildPatternLookup, entityCore_buildPrimitiveLookup as buildPrimitiveLookup, entityCore_buildTextureLookup as buildTextureLookup, entityCore_clampSizeAxis as clampSizeAxis, cleanEntity$1 as cleanEntity, entityCore_cloneEntity as cloneEntity, entityCore_cloneMaterialsByPalette as cloneMaterialsByPalette, entityCore_cloneVoxelData as cloneVoxelData, entityCore_clusterMaterials as clusterMaterials, entityCore_collectBoxelValidationIssues as collectBoxelValidationIssues, entityCore_collectEntityMaterialLookup as collectEntityMaterialLookup, entityCore_collectEntityPatternLookup as collectEntityPatternLookup, entityCore_collectEntityTextureLookup as collectEntityTextureLookup, entityCore_collectFaceTextureIds as collectFaceTextureIds, entityCore_collectMaterialUsage as collectMaterialUsage, entityCore_collectOverlayFaceTextureIds as collectOverlayFaceTextureIds, entityCore_collectPaletteIds as collectPaletteIds, entityCore_collectPrimitiveDependencies as collectPrimitiveDependencies, entityCore_collectPrimitiveUsage as collectPrimitiveUsage, entityCore_collectTexturedBoxDependencies as collectTexturedBoxDependencies, entityCore_collectTexturedBoxMaterials as collectTexturedBoxMaterials, entityCore_collectTexturedBoxPatterns as collectTexturedBoxPatterns, entityCore_collectTexturedBoxTextures as collectTexturedBoxTextures, entityCore_computeComboBoundingSize as computeComboBoundingSize, entityCore_computeEntityPixelsPerMeter as computeEntityPixelsPerMeter, entityCore_convertTexturedBoxesToVoxel as convertTexturedBoxesToVoxel, entityCore_createFaceArtifacts as createFaceArtifacts, entityCore_createFilledVoxelData as createFilledVoxelData, entityCore_createMaterialEnsurer as createMaterialEnsurer, entityCore_determineTexturedBoxRenderMode as determineTexturedBoxRenderMode, entityCore_ensureNoIdCollisions as ensureNoIdCollisions, entityCore_extractSourceFacePixels as extractSourceFacePixels, entityCore_findNode as findNode, entityCore_findNodeById as findNodeById, entityCore_forEachVoxel as forEachVoxel, formatBoxel$1 as formatBoxel, entityCore_formatColor as formatColor, entityCore_formatNumber as formatNumber, entityCore_formatVec as formatVec, entityCore_generateGreedyQuads as generateGreedyQuads, entityCore_generateQuadsForVoxelBox as generateQuadsForVoxelBox, entityCore_getFaceDimensions as getFaceDimensions, entityCore_getFaceKeys as getFaceKeys, entityCore_getHumanoidTemplate as getHumanoidTemplate, entityCore_getTextureMaterialIds as getTextureMaterialIds, entityCore_getVoxelIndex as getVoxelIndex, entityCore_isTupleOfNumbers as isTupleOfNumbers, entityCore_mapLuminance as mapLuminance, entityCore_mapSaturation as mapSaturation, entityCore_materialFingerprint as materialFingerprint, entityCore_materialsApproximatelyEqual as materialsApproximatelyEqual, entityCore_mergeIncomingMaterials as mergeIncomingMaterials, entityCore_mergeMaterials as mergeMaterials, entityCore_mergeOverlayIntoBase as mergeOverlayIntoBase, parseBoxel$1 as parseBoxel, entityCore_parseBoxelJson as parseBoxelJson, entityCore_rebalanceLuminance as rebalanceLuminance, entityCore_resolveFaceTextureId as resolveFaceTextureId, entityCore_resolveOverlayFaceTextureId as resolveOverlayFaceTextureId, entityCore_rewriteEntityPalette as rewriteEntityPalette, entityCore_scanHumanoidSource as scanHumanoidSource, entityCore_selectByIdOrder as selectByIdOrder, entityCore_setVoxelAt as setVoxelAt, entityCore_splitTexturedBox as splitTexturedBox, entityCore_splitVoxelBoxClone as splitVoxelBoxClone, entityCore_splitVoxelPrimitive as splitVoxelPrimitive, entityCore_toGeometryVec3 as toGeometryVec3, entityCore_transformFacePixels as transformFacePixels, entityCore_updateChildPosition as updateChildPosition, entityCore_updateChildPositionAxis as updateChildPositionAxis, entityCore_upscaleEntity as upscaleEntity, entityCore_upscaleEntityGeometry as upscaleEntityGeometry, entityCore_uvToCanvasPixel as uvToCanvasPixel, validateBoxel$1 as validateBoxel, entityCore_validateVoxelData as validateVoxelData };
  export type { entityCore_AnalyzePaletteOptions as AnalyzePaletteOptions, entityCore_AnalyzedMaterial as AnalyzedMaterial, entityCore_Animation as Animation, entityCore_AnimationChannel as AnimationChannel, entityCore_AnimationChannelProperty as AnimationChannelProperty, entityCore_AnimationId as AnimationId, entityCore_AnimationKeyframe as AnimationKeyframe, entityCore_BoxelDefinition as BoxelDefinition, entityCore_BoxelId as BoxelId, entityCore_BoxelValidationIssue as BoxelValidationIssue, entityCore_BuildFaceOptions as BuildFaceOptions, entityCore_BuildHumanoidR15Options as BuildHumanoidR15Options, entityCore_BuildHumanoidR6Options as BuildHumanoidR6Options, entityCore_CleanEntityResult as CleanEntityResult, entityCore_ComboBox as ComboBox, entityCore_ConnectMode as ConnectMode, entityCore_CreateFaceArtifactsParams as CreateFaceArtifactsParams, entityCore_CrossFillMode as CrossFillMode, entityCore_CrossFillOptions as CrossFillOptions, entityCore_FaceArtifactsResult as FaceArtifactsResult, entityCore_FaceKey as FaceKey, FaceName$2 as FaceName, entityCore_FaceSource as FaceSource, entityCore_FaceTransform as FaceTransform, entityCore_Geometry as Geometry, entityCore_GeometryBone as GeometryBone, entityCore_GeometryCube as GeometryCube, entityCore_GeometryEntry as GeometryEntry, entityCore_GeometryFaceName as GeometryFaceName, entityCore_GeometryId as GeometryId, entityCore_GeometryVec3 as GeometryVec3, entityCore_GreedyQuad as GreedyQuad, FaceName$1 as HumanoidFaceName, FaceUVRect as HumanoidFaceUVRect, entityCore_HumanoidOverlayCube as HumanoidOverlayCube, entityCore_HumanoidPartKey as HumanoidPartKey, entityCore_HumanoidSourceCube as HumanoidSourceCube, entityCore_HumanoidSourceScan as HumanoidSourceScan, entityCore_HumanoidTemplateId as HumanoidTemplateId, entityCore_LayerMode as LayerMode, entityCore_LayerModeOptions as LayerModeOptions, entityCore_LuminanceOptions as LuminanceOptions, entityCore_LuminanceResult as LuminanceResult, entityCore_Material as Material, entityCore_MaterialCluster as MaterialCluster, entityCore_MaterialEnsurer as MaterialEnsurer, entityCore_MaterialEnsurerOptions as MaterialEnsurerOptions, entityCore_MaterialId as MaterialId, entityCore_MaterialMergeOutcome as MaterialMergeOutcome, entityCore_MaterialMergeResult as MaterialMergeResult, entityCore_MaterialSample as MaterialSample, entityCore_Node as Node, entityCore_NodeId as NodeId, entityCore_OverlayVoxelMode as OverlayVoxelMode, entityCore_Pattern as Pattern, entityCore_PatternId as PatternId, entityCore_PlainBox as PlainBox, entityCore_Primitive as Primitive, entityCore_PrimitiveDependencySets as PrimitiveDependencySets, entityCore_PrimitiveId as PrimitiveId, entityCore_PrimitiveKind as PrimitiveKind, entityCore_SaturationResult as SaturationResult, entityCore_SplitAxis as SplitAxis, entityCore_SplitTexturedOptions as SplitTexturedOptions, entityCore_SplitVoxelBoxResult as SplitVoxelBoxResult, entityCore_SplitVoxelResult as SplitVoxelResult, entityCore_Texture as Texture, entityCore_TextureId as TextureId, entityCore_TexturedBox as TexturedBox, entityCore_TexturedBoxDependencySummary as TexturedBoxDependencySummary, entityCore_TexturedToVoxelOptions as TexturedToVoxelOptions, entityCore_Vec2 as Vec2, entityCore_Vec3 as Vec3, entityCore_VoxelBox as VoxelBox, entityCore_VoxelIndex as VoxelIndex, entityCore_VoxelSize as VoxelSize };
}

interface BoxelThreeContext {
    THREE: typeof THREEType;
    entity: BoxelDefinition;
}
interface BoxelSceneOptions {
    /**
     * Optional node identifier (or list of identifiers) to render instead of the full entity.
     * When omitted, the entire entity geometry tree is emitted.
     */
    nodes?: string | string[];
    /**
     * Configure optional overlay helpers (origin, bounds, sockets) to render alongside the scene.
     */
    overlays?: BoxelOverlayOptions;
}
interface BoxelSceneNodeMeta {
    /**
     * Original entity node identifier.
     */
    id: string;
    /**
     * Three.js object representing the node transform.
     */
    object: THREEType.Object3D;
    /**
     * Optional primitive identifier bound to the node.
     */
    primitiveId?: string;
    /**
     * Requested parent-connect behaviour for this node.
     */
    connectMode: ConnectMode;
}
interface BoxelSceneAnimationChannel {
    nodeId: string;
    property: 'position' | 'rotation' | 'scale';
    track: THREEType.KeyframeTrack;
}
interface BoxelSceneAnimation {
    id: string;
    duration: number;
    channels: BoxelSceneAnimationChannel[];
    clip: THREEType.AnimationClip;
}
interface BoxelSceneResult {
    /**
     * Root object containing the full entity mesh hierarchy.
     */
    root: THREEType.Group;
    /**
     * Lookup for every node emitted into the scene.
     */
    nodes: Map<string, BoxelSceneNodeMeta>;
    /**
     * Animation payload pre-bound to Three.js tracks.
     */
    animations: BoxelSceneAnimation[];
    /**
     * Ready-to-use AnimationClip objects derived from the animation payload.
     */
    clips: THREEType.AnimationClip[];
    /**
     * Three.js resources that should be disposed when the scene is torn down.
     */
    resources: {
        materials: THREEType.Material[];
        textures: THREEType.Texture[];
        geometries: THREEType.BufferGeometry[];
    };
    /**
     * Destroy helper to free underlying GPU buffers.
     */
    dispose: () => void;
}
/**
 * Controls which overlay helpers should be rendered for a target along with basic styling hints.
 */
interface BoxelOverlayOptions {
    /**
     * Render the entity/world origin helper.
     */
    origin?: boolean;
    /**
     * Render bounding boxes for nodes or primitives that declare a size.
     */
    bounds?: boolean;
    /**
     * Render sphere markers for socket locations (combo slots, node centers).
     */
    sockets?: boolean;
    /**
     * Optional tint for line/mesh helpers.
     */
    color?: number;
    /**
     * Optional opacity override for helpers; defaults to fully opaque.
     */
    opacity?: number;
    /**
     * When true, draw dashed bounding boxes instead of solid lines.
     */
    dashed?: boolean;
}
interface BoxelOverlayHandles {
    origin?: THREEType.Object3D;
    bounds?: THREEType.Object3D[];
    sockets?: THREEType.Object3D[];
    dispose: () => void;
}

declare function createBoxelScene$1(context: BoxelThreeContext, options?: BoxelSceneOptions): BoxelSceneResult;
declare function createBoxelNodeScene$1(context: BoxelThreeContext, nodeId: string, options?: BoxelSceneOptions): BoxelSceneResult;

interface CreateOverlayContext {
    THREE: typeof THREEType;
    target: THREEType.Object3D;
}
declare function attachBoxelOverlays$1(context: CreateOverlayContext, options?: BoxelOverlayOptions): BoxelOverlayHandles;

type BoxSize = [number, number, number];
declare function createBoxGeometry(THREE: typeof THREEType, size: BoxSize): THREEType.BoxGeometry;
declare function collectGroupVertexIndices(geometry: THREEType.BufferGeometry): Array<Set<number>>;

type TextureArray = Uint8Array<ArrayBuffer>;
interface TextureBundle {
    color: THREEType.DataTexture;
    emissive?: THREEType.DataTexture;
}
declare function buildTexturePixels(context: PrimitiveBuilderContext, textureDef: Texture, pattern: Pattern, materialsById: Map<string, Material>): {
    color: TextureArray;
    emissive: TextureArray | null;
};
declare function ensureTextureInstance(context: PrimitiveBuilderContext, textureDef: Texture): TextureBundle | null;
declare function createPatternPlaceholderTexture(context: PrimitiveBuilderContext, pattern: Pattern): THREEType.DataTexture;
declare function createTextureMaterial(context: PrimitiveBuilderContext, textureId: string | undefined): THREEType.MeshStandardMaterial;
declare function toThreeColorRGB(context: PrimitiveBuilderContext, rgb: number[]): THREEType.Color;

interface BuilderSettings {
    enableShadows: boolean;
}
interface PrimitiveBuilderContext {
    THREE: typeof THREEType;
    settings: BuilderSettings;
    entity: BoxelDefinition | null;
    materialsById: Map<string, Material>;
    primitivesById: Map<string, Primitive>;
    textureCache: Map<string, TextureBundle>;
}
interface BuilderUpdate {
    entity?: BoxelDefinition | null;
    settings?: Partial<BuilderSettings>;
}
declare function createBuilderContext(options: {
    THREE: typeof THREEType;
    settings: BuilderSettings;
}): PrimitiveBuilderContext;
declare function updateBuilderContext(context: PrimitiveBuilderContext, update: BuilderUpdate): void;
declare function clearTextureCache(context: PrimitiveBuilderContext): void;

declare const DEFAULT_COLOR = 3900150;
declare const DEFAULT_OPACITY = 0.45;
declare const DEFAULT_WIREFRAME_COLOR = 6333946;
declare function createBoundingBoxMesh(context: PrimitiveBuilderContext, size: [number, number, number]): THREEType.Mesh;
declare function createPrimitiveObject(context: PrimitiveBuilderContext, primitive: Primitive, alignment: 'centered' | 'grounded', visited?: Set<string>): THREEType.Object3D | null;

interface BuildVoxelMeshOptions {
    voxels: number[];
    dimensions: [number, number, number];
    size: [number, number, number];
}
interface VoxelMaterialGroup {
    material: number;
    start: number;
    count: number;
}
interface VoxelMeshResult {
    positions: Float32Array;
    normals: Float32Array;
    uvs: Float32Array;
    indices: Uint32Array;
    groups: VoxelMaterialGroup[];
    stats: {
        voxels: number;
        faces: number;
    };
}
declare function buildVoxelMesh(options: BuildVoxelMeshOptions): VoxelMeshResult;
declare function hasVoxelData(primitive: VoxelBox): boolean;

type FaceName = 'east' | 'west' | 'top' | 'bottom' | 'north' | 'south';
declare const FACE_ORDER: ReadonlyArray<FaceName>;
interface VoxelFaceGeometry {
    positions: Float32Array;
    normals: Float32Array;
    uvs: Float32Array;
    indices: Uint16Array;
}
interface VoxelFacePatch {
    face: FaceName;
    width: number;
    height: number;
    textureWidth: number;
    textureHeight: number;
    color: Uint8Array;
    emissive?: Uint8Array;
    hasEmissive: boolean;
    hasTransparency: boolean;
    geometry: VoxelFaceGeometry;
}
interface GenerateVoxelFaceSurfacesOptions {
    primitive: VoxelBox;
    materialsById: Map<string, Material>;
    defaultColor: [number, number, number];
}
declare function generateVoxelFaceSurfaces(options: GenerateVoxelFaceSurfacesOptions): VoxelFacePatch[];

interface TexturePixels {
    id: string;
    width: number;
    height: number;
    color: Uint8Array;
    emissive?: Uint8Array;
    hasEmissive: boolean;
    hasTransparency: boolean;
}
interface TextureAtlasRegion {
    uMin: number;
    vMin: number;
    uMax: number;
    vMax: number;
}
interface TextureAtlas {
    regions: Map<string, TextureAtlasRegion>;
    fallbackRegion: TextureAtlasRegion;
    map: THREEType.DataTexture;
    emissiveMap: THREEType.DataTexture | null;
    hasTransparency: boolean;
}
interface CachedVoxelPatch extends VoxelFacePatch {
    textureId: string;
}
type ExportMode = 'hierarchical' | 'merged' | 'skinned';
interface ExportModelOptions {
    THREE: typeof THREEType;
    GLTFExporterCtor: new () => GLTFExporter;
    model: BoxelDefinition;
    mode?: ExportMode;
    binary?: boolean;
    animationIds?: string[] | null;
}
declare function exportModelToGLB(options: ExportModelOptions): Promise<Blob>;
declare function createBoxelSceneGraph$1(options: {
    THREE: typeof THREEType;
    model: BoxelDefinition;
    mode?: ExportMode;
}): SceneGraphResult;
interface ExportContext {
    THREE: typeof THREEType;
    model: BoxelDefinition;
    materialsById: Map<string, Material>;
    primitivesById: Map<string, Primitive>;
    texturesById: Map<string, Texture>;
    patternsById: Map<string, Pattern>;
    atlas: TextureAtlas | null;
    voxelSurfacesByPrimitive: Map<string, CachedVoxelPatch[]>;
    plainMaterialCache: Map<string, THREEType.MeshStandardMaterial>;
}
declare function createExportContext(THREE: typeof THREEType, model: BoxelDefinition): ExportContext;
interface AtlasBuildOptions {
    THREE: typeof THREEType;
    materialsById: Map<string, Material>;
    texturesById: Map<string, Texture>;
    patternsById: Map<string, Pattern>;
    usedTextureIds: Set<string>;
}
declare function buildTextureAtlas$1(options: AtlasBuildOptions, extraEntries?: TexturePixels[]): TextureAtlas | null;
declare function collectUsedTextureIds(model: BoxelDefinition, primitivesById: Map<string, Primitive>): Set<string>;
interface SceneGraphResult {
    root: THREEType.Object3D;
    nodeLookup: Map<string, THREEType.Object3D>;
    animations: BoxelSceneAnimation[];
    dispose: () => void;
}
declare function buildSceneGraph(context: ExportContext, mode: ExportMode): SceneGraphResult;
declare function resolveAnimationClips(sceneGraph: SceneGraphResult, mode: ExportMode, animationIds?: string[] | null): THREEType.AnimationClip[];
interface AppendGeometryOptions {
    THREE: typeof THREEType;
    geometry: THREEType.BufferGeometry;
    matrix: THREEType.Matrix4;
    customUVs?: Float32Array;
}
declare class MeshAccumulator {
    private readonly positions;
    private readonly normals;
    private readonly uvs;
    private readonly indices;
    private vertexCount;
    constructor(withUVs: boolean);
    appendGeometry(options: AppendGeometryOptions): void;
    hasGeometry(): boolean;
    build(THREE: typeof THREEType): THREEType.BufferGeometry;
}
declare const __testing: {
    buildTextureAtlas: typeof buildTextureAtlas$1;
    collectUsedTextureIds: typeof collectUsedTextureIds;
    MeshAccumulator: typeof MeshAccumulator;
    createExportContext: typeof createExportContext;
    buildSceneGraph: typeof buildSceneGraph;
    resolveAnimationClips: typeof resolveAnimationClips;
};

declare const DIRECTION_VECTORS: Record<string, [number, number, number]>;
interface RenderBoxelImageOptions {
    THREE: typeof THREEType;
    renderer: THREEType.WebGLRenderer;
    entity: BoxelDefinition;
    mode?: ExportMode;
    animationIds?: string[] | null;
    animationId?: string | null;
    width?: number;
    height?: number;
    direction?: keyof typeof DIRECTION_VECTORS;
    background?: THREEType.ColorRepresentation | null;
}
declare function renderBoxelToDataURL(options: RenderBoxelImageOptions): Promise<string>;

type AtlasTransform = {
    offset: [number, number];
    scale: [number, number];
};
interface TextureAtlasResult {
    texture: THREEType.DataTexture;
    transforms: Map<THREEType.DataTexture, AtlasTransform>;
    width: number;
    height: number;
}
declare function buildTextureAtlas(THREE: typeof THREEType, textures: readonly THREEType.DataTexture[]): TextureAtlasResult | null;
declare function buildEmissiveAtlas(THREE: typeof THREEType, width: number, height: number, transforms: Map<THREEType.DataTexture, AtlasTransform>, pairs: Map<THREEType.DataTexture, THREEType.DataTexture>): THREEType.DataTexture | null;

interface BuildSkinnedMeshOptions {
    THREE: typeof THREEType;
    entity: BoxelDefinition;
}
interface BuildSkinnedMeshResult {
    mesh: THREEType.SkinnedMesh;
    bones: THREEType.Bone[];
    skeleton: THREEType.Skeleton;
    boneMap: Map<string, THREEType.Bone>;
    stats: {
        vertices: number;
        triangles: number;
        weldedVertices: number;
        weldedByNode: Record<string, number>;
        connectBreakdown: Record<string, {
            childVertices: number;
            parentVertices: number;
        }>;
        atlas?: {
            width: number;
            height: number;
        } | null;
    };
    warnings: string[];
    dispose: () => void;
}
declare function buildEntitySkinnedMesh(options: BuildSkinnedMeshOptions): BuildSkinnedMeshResult;

type InstantiateEntityObject3DMode = 'hierarchy' | 'merged' | 'skinned';
interface InstantiateBaseResult {
    mode: InstantiateEntityObject3DMode;
    dispose(): void;
}
interface InstantiateHierarchyResult extends InstantiateBaseResult {
    mode: 'hierarchy';
    object: THREEType.Group;
    scene: BoxelSceneResult;
    clips: THREEType.AnimationClip[];
    findNode(nodeId: string): THREEType.Object3D | undefined;
    forEachNode(visitor: (node: THREEType.Object3D, nodeId: string) => void): void;
}
interface InstantiateMergedResult extends InstantiateBaseResult {
    mode: 'merged';
    object: THREEType.Group;
}
interface InstantiateSkinnedResult extends InstantiateBaseResult {
    mode: 'skinned';
    object: THREEType.SkinnedMesh;
    skeleton: THREEType.Skeleton;
    boneMap: Map<string, THREEType.Bone>;
    clips: THREEType.AnimationClip[];
    stats: BuildSkinnedMeshResult['stats'];
    warnings: string[];
    findBone(nodeId: string): THREEType.Bone | undefined;
    forEachBone(visitor: (bone: THREEType.Bone, nodeId: string) => void): void;
}
type InstantiateEntityObject3DResult = InstantiateHierarchyResult | InstantiateMergedResult | InstantiateSkinnedResult;
interface InstantiateEntityObject3DOptions {
    THREE: typeof THREEType;
    entity: BoxelDefinition;
    mode?: InstantiateEntityObject3DMode;
}
declare function instantiateEntityObject3D(options: InstantiateEntityObject3DOptions): InstantiateEntityObject3DResult;

type entityThree_AtlasTransform = AtlasTransform;
type entityThree_BoxSize = BoxSize;
type entityThree_BoxelOverlayHandles = BoxelOverlayHandles;
type entityThree_BoxelOverlayOptions = BoxelOverlayOptions;
type entityThree_BoxelSceneAnimation = BoxelSceneAnimation;
type entityThree_BoxelSceneAnimationChannel = BoxelSceneAnimationChannel;
type entityThree_BoxelSceneNodeMeta = BoxelSceneNodeMeta;
type entityThree_BoxelSceneOptions = BoxelSceneOptions;
type entityThree_BoxelSceneResult = BoxelSceneResult;
type entityThree_BoxelThreeContext = BoxelThreeContext;
type entityThree_BuildSkinnedMeshOptions = BuildSkinnedMeshOptions;
type entityThree_BuildSkinnedMeshResult = BuildSkinnedMeshResult;
type entityThree_BuildVoxelMeshOptions = BuildVoxelMeshOptions;
type entityThree_BuilderSettings = BuilderSettings;
type entityThree_BuilderUpdate = BuilderUpdate;
type entityThree_ConnectMode = ConnectMode;
declare const entityThree_DEFAULT_COLOR: typeof DEFAULT_COLOR;
declare const entityThree_DEFAULT_OPACITY: typeof DEFAULT_OPACITY;
declare const entityThree_DEFAULT_WIREFRAME_COLOR: typeof DEFAULT_WIREFRAME_COLOR;
type entityThree_ExportMode = ExportMode;
declare const entityThree_FACE_ORDER: typeof FACE_ORDER;
type entityThree_FaceName = FaceName;
type entityThree_InstantiateEntityObject3DMode = InstantiateEntityObject3DMode;
type entityThree_InstantiateEntityObject3DOptions = InstantiateEntityObject3DOptions;
type entityThree_InstantiateEntityObject3DResult = InstantiateEntityObject3DResult;
type entityThree_InstantiateHierarchyResult = InstantiateHierarchyResult;
type entityThree_InstantiateMergedResult = InstantiateMergedResult;
type entityThree_InstantiateSkinnedResult = InstantiateSkinnedResult;
type entityThree_PrimitiveBuilderContext = PrimitiveBuilderContext;
type entityThree_RenderBoxelImageOptions = RenderBoxelImageOptions;
type entityThree_TextureAtlasResult = TextureAtlasResult;
type entityThree_TextureBundle = TextureBundle;
type entityThree_VoxelFaceGeometry = VoxelFaceGeometry;
type entityThree_VoxelFacePatch = VoxelFacePatch;
type entityThree_VoxelMaterialGroup = VoxelMaterialGroup;
type entityThree_VoxelMeshResult = VoxelMeshResult;
declare const entityThree_buildEmissiveAtlas: typeof buildEmissiveAtlas;
declare const entityThree_buildEntitySkinnedMesh: typeof buildEntitySkinnedMesh;
declare const entityThree_buildTextureAtlas: typeof buildTextureAtlas;
declare const entityThree_buildTexturePixels: typeof buildTexturePixels;
declare const entityThree_buildVoxelMesh: typeof buildVoxelMesh;
declare const entityThree_clearTextureCache: typeof clearTextureCache;
declare const entityThree_collectGroupVertexIndices: typeof collectGroupVertexIndices;
declare const entityThree_createBoundingBoxMesh: typeof createBoundingBoxMesh;
declare const entityThree_createBoxGeometry: typeof createBoxGeometry;
declare const entityThree_createBuilderContext: typeof createBuilderContext;
declare const entityThree_createPatternPlaceholderTexture: typeof createPatternPlaceholderTexture;
declare const entityThree_createPrimitiveObject: typeof createPrimitiveObject;
declare const entityThree_createTextureMaterial: typeof createTextureMaterial;
declare const entityThree_ensureTextureInstance: typeof ensureTextureInstance;
declare const entityThree_exportModelToGLB: typeof exportModelToGLB;
declare const entityThree_generateVoxelFaceSurfaces: typeof generateVoxelFaceSurfaces;
declare const entityThree_hasVoxelData: typeof hasVoxelData;
declare const entityThree_instantiateEntityObject3D: typeof instantiateEntityObject3D;
declare const entityThree_renderBoxelToDataURL: typeof renderBoxelToDataURL;
declare const entityThree_toThreeColorRGB: typeof toThreeColorRGB;
declare const entityThree_updateBuilderContext: typeof updateBuilderContext;
declare namespace entityThree {
  export { entityThree_DEFAULT_COLOR as DEFAULT_COLOR, entityThree_DEFAULT_OPACITY as DEFAULT_OPACITY, entityThree_DEFAULT_WIREFRAME_COLOR as DEFAULT_WIREFRAME_COLOR, entityThree_FACE_ORDER as FACE_ORDER, __testing as __boxelThreeTesting, attachBoxelOverlays$1 as attachBoxelOverlays, entityThree_buildEmissiveAtlas as buildEmissiveAtlas, entityThree_buildEntitySkinnedMesh as buildEntitySkinnedMesh, entityThree_buildTextureAtlas as buildTextureAtlas, entityThree_buildTexturePixels as buildTexturePixels, entityThree_buildVoxelMesh as buildVoxelMesh, entityThree_clearTextureCache as clearTextureCache, entityThree_collectGroupVertexIndices as collectGroupVertexIndices, entityThree_createBoundingBoxMesh as createBoundingBoxMesh, entityThree_createBoxGeometry as createBoxGeometry, createBoxelNodeScene$1 as createBoxelNodeScene, createBoxelScene$1 as createBoxelScene, createBoxelSceneGraph$1 as createBoxelSceneGraph, entityThree_createBuilderContext as createBuilderContext, entityThree_createPatternPlaceholderTexture as createPatternPlaceholderTexture, entityThree_createPrimitiveObject as createPrimitiveObject, entityThree_createTextureMaterial as createTextureMaterial, entityThree_ensureTextureInstance as ensureTextureInstance, entityThree_exportModelToGLB as exportModelToGLB, entityThree_generateVoxelFaceSurfaces as generateVoxelFaceSurfaces, entityThree_hasVoxelData as hasVoxelData, entityThree_instantiateEntityObject3D as instantiateEntityObject3D, entityThree_renderBoxelToDataURL as renderBoxelToDataURL, entityThree_toThreeColorRGB as toThreeColorRGB, entityThree_updateBuilderContext as updateBuilderContext };
  export type { entityThree_AtlasTransform as AtlasTransform, entityThree_BoxSize as BoxSize, entityThree_BoxelOverlayHandles as BoxelOverlayHandles, entityThree_BoxelOverlayOptions as BoxelOverlayOptions, entityThree_BoxelSceneAnimation as BoxelSceneAnimation, entityThree_BoxelSceneAnimationChannel as BoxelSceneAnimationChannel, entityThree_BoxelSceneNodeMeta as BoxelSceneNodeMeta, entityThree_BoxelSceneOptions as BoxelSceneOptions, entityThree_BoxelSceneResult as BoxelSceneResult, entityThree_BoxelThreeContext as BoxelThreeContext, entityThree_BuildSkinnedMeshOptions as BuildSkinnedMeshOptions, entityThree_BuildSkinnedMeshResult as BuildSkinnedMeshResult, entityThree_BuildVoxelMeshOptions as BuildVoxelMeshOptions, entityThree_BuilderSettings as BuilderSettings, entityThree_BuilderUpdate as BuilderUpdate, entityThree_ConnectMode as ConnectMode, entityThree_ExportMode as ExportMode, entityThree_FaceName as FaceName, entityThree_InstantiateEntityObject3DMode as InstantiateEntityObject3DMode, entityThree_InstantiateEntityObject3DOptions as InstantiateEntityObject3DOptions, entityThree_InstantiateEntityObject3DResult as InstantiateEntityObject3DResult, entityThree_InstantiateHierarchyResult as InstantiateHierarchyResult, entityThree_InstantiateMergedResult as InstantiateMergedResult, entityThree_InstantiateSkinnedResult as InstantiateSkinnedResult, entityThree_PrimitiveBuilderContext as PrimitiveBuilderContext, entityThree_RenderBoxelImageOptions as RenderBoxelImageOptions, entityThree_TextureAtlasResult as TextureAtlasResult, entityThree_TextureBundle as TextureBundle, entityThree_VoxelFaceGeometry as VoxelFaceGeometry, entityThree_VoxelFacePatch as VoxelFacePatch, entityThree_VoxelMaterialGroup as VoxelMaterialGroup, entityThree_VoxelMeshResult as VoxelMeshResult };
}

declare const APP_TYPE_VALUES: readonly ["GAME", "TEMPLATE", "TOOL", "DEMO"];
type AppType = (typeof APP_TYPE_VALUES)[number];
declare const APP_SURFACE_VALUES: readonly ["DESKTOP", "MOBILE_LANDSCAPE", "MOBILE_PORTRAIT"];
type AppSurface = (typeof APP_SURFACE_VALUES)[number];
declare const APP_ORIGIN_VALUES: readonly ["PLAYDROP_CLOUD", "USER"];
type AppOrigin = (typeof APP_ORIGIN_VALUES)[number];

declare const CONTENT_LICENSE_VALUES: readonly ["CLOSED", "PLAYDROP", "MIT", "CC0"];
type ContentLicense = (typeof CONTENT_LICENSE_VALUES)[number];
interface ContentPermissions {
    canDownloadSource: boolean;
    canRemix: boolean;
    canReuseOnPlaydrop: boolean;
    canUseOffPlatform: boolean;
}

declare const ASSET_CATEGORY_VALUES: readonly ["IMAGE", "VIDEO", "AUDIO", "SPRITESHEET", "MODEL_3D", "CUSTOM"];
type AssetCategory = (typeof ASSET_CATEGORY_VALUES)[number];
declare const ASSET_FORMAT_VALUES: readonly ["PNG", "JPEG", "WEBP", "GIF", "ASEPRITE", "MP4", "WEBM", "MP3", "WAV", "OGG", "GLTF", "GLB", "PLAYDROP_BOXEL_JSON", "VOX", "CUSTOM"];
type AssetFormat = (typeof ASSET_FORMAT_VALUES)[number];
declare const ASSET_VISIBILITY_VALUES: readonly ["PRIVATE", "PUBLIC"];
type AssetVisibility = (typeof ASSET_VISIBILITY_VALUES)[number];
declare const ASSET_SOURCE_KIND_VALUES: readonly ["UPLOAD", "AI", "APP_EMBEDDED", "IMPORT"];
type AssetSourceKind = (typeof ASSET_SOURCE_KIND_VALUES)[number];
interface OwnedCustomAssetVersionSummary {
    assetRef: string;
    revision: number;
    revisionLabel: string;
    visibility: AssetVisibility;
    license: ContentLicense;
    assetSpecVersionRef: string | null;
    previewUrl: string | null;
    createdAt: string;
    updatedAt: string;
}
interface OwnedCustomAssetSummary {
    creatorUsername: string;
    assetName: string;
    displayName: string | null;
    description: string | null;
    currentVersion: OwnedCustomAssetVersionSummary | null;
    latestVersion: OwnedCustomAssetVersionSummary | null;
    latestPublicVersion: OwnedCustomAssetVersionSummary | null;
}
interface AssetSubcategoryDefinition {
    category: AssetCategory;
    subcategory: string;
    formats: AssetFormat[];
    label: string;
}
declare const PLAYDROP_SPEECH_VOICE_IDS: readonly ["default_narrator", "warm_storyteller_m", "neutral_guide", "confident_guide_f", "casual_companion_m", "atmospheric_storyteller_f", "energetic_host_m", "bright_creator_f"];
type PlaydropSpeechVoiceId = (typeof PLAYDROP_SPEECH_VOICE_IDS)[number];
declare const MODEL_3D_ASSET_SUBCATEGORY_VALUES: readonly ["generic", "avatar", "humanoid", "creature", "block"];
type Model3DAssetSubcategory = (typeof MODEL_3D_ASSET_SUBCATEGORY_VALUES)[number];
type AssetMetadataEmbeddingStatus = 'embedded' | 'unsupported_format' | 'failed';
interface AssetAudioWaveform {
    durationSeconds: number;
    sampleRateHz: number;
    bins: number[];
}
interface AssetSongWordTimestamp {
    word: string;
    startMs: number;
    endMs: number;
}
interface AssetSongSection {
    name?: string;
    durationMs?: number;
    lines: string[];
    styles?: string[];
}
interface AssetSongLyrics {
    text: string;
    sections?: AssetSongSection[];
    wordTimestamps?: AssetSongWordTimestamp[];
}
interface AssetSongMetadata {
    genres?: string[];
    languages?: string[];
    styles?: string[];
    isExplicit?: boolean;
    lyrics?: AssetSongLyrics;
}
interface AssetSpeechWordTimestamp {
    word: string;
    startMs: number;
    endMs: number;
}
interface AssetSpeechVoiceMetadata {
    provider: 'elevenlabs';
    model: string;
    voiceId: string;
    voiceName?: string | null;
    playdropVoice?: PlaydropSpeechVoiceId | null;
    source: 'default' | 'provider';
}
interface AssetSpeechMetadata {
    text: string;
    language: 'en';
    durationMs: number | null;
    wordTimestamps: AssetSpeechWordTimestamp[];
    voice: AssetSpeechVoiceMetadata;
}
interface AssetEmbeddedMetadata {
    modality: 'IMAGE' | 'MUSIC' | 'SFX' | 'SPEECH' | 'VIDEO' | 'MODEL_3D';
    generationId: string;
    creatorUsername: string;
    creatorDisplayName: string;
    displayName: string;
    description: string;
    createdAt: string;
    provider: {
        name: string;
        model: string;
    };
    embeddedInPrimary: boolean;
    embeddingStatus: AssetMetadataEmbeddingStatus;
    durationMs?: number;
    durationSeconds?: number;
    aspectRatio?: string;
    imageSize?: string;
    resolution?: string;
    sourceMode?: string;
    topology?: string;
    targetPolycount?: number;
    shouldRemesh?: boolean;
    shouldTexture?: boolean;
    coverAssetUrl?: string;
    thumbnailUrl?: string;
    audio?: {
        waveform?: AssetAudioWaveform;
    };
    song?: AssetSongMetadata;
    speech?: AssetSpeechMetadata;
    providerMetadataSubset?: Record<string, unknown>;
}
interface AssetFileManifestEntry {
    role: string;
    key: string;
    url?: string;
    contentType?: string | null;
    sizeBytes?: number | null;
    sha256?: string | null;
}
interface AssetFileManifest {
    files: AssetFileManifestEntry[];
}
interface AssetGenerationInputAttachmentResponse {
    key: string;
    label: string;
    url: string;
}
interface AssetGenerationInputParamResponse {
    key: string;
    label: string;
    value: string | number | boolean | null;
}
interface AssetGenerationInputSummaryResponse {
    modality: string | null;
    prompt: string | null;
    attachments: AssetGenerationInputAttachmentResponse[];
    params: AssetGenerationInputParamResponse[];
}
interface AssetGenerationReplayAttachmentResponse {
    key: 'image1' | 'image2';
    label: string;
    url: string;
    mimeType?: string | null;
}
interface AssetGenerationReplayResponse {
    modality: 'IMAGE' | 'MUSIC' | 'SFX' | 'SPEECH' | 'VIDEO' | 'MODEL_3D';
    prompt: string;
    image1?: AssetGenerationReplayAttachmentResponse | null;
    image2?: AssetGenerationReplayAttachmentResponse | null;
    durationMs?: number | null;
    forceInstrumental?: boolean | null;
    durationSeconds?: number | null;
    loop?: boolean | null;
    coverPrompt?: string | null;
    speechVoice?: PlaydropSpeechVoiceId | null;
    speechProviderVoiceId?: string | null;
    aspectRatio?: string | null;
    imageSize?: string | null;
    resolution?: string | null;
    sourceMode?: string | null;
    topology?: string | null;
    targetPolycount?: number | null;
    shouldRemesh?: boolean | null;
    shouldTexture?: boolean | null;
    assetSubcategory?: string | null;
}
interface AssetVersionResponse {
    id: number;
    revision: number;
    revisionLabel: string;
    subcategory: string | null;
    visibility: AssetVisibility;
    format: AssetFormat;
    storageKey: string;
    fileManifest: AssetFileManifest | Record<string, unknown>;
    assetSpecVersionRef?: string | null;
    primaryRole?: string | null;
    primaryContentType?: string | null;
    primaryExtension?: string | null;
    sourceKind: AssetSourceKind;
    sourceAppVersionId?: number | null;
    sourceGenerationId?: string | null;
    sourcePrompt?: string | null;
    sourceGenerationInput?: AssetGenerationInputSummaryResponse | null;
    sourceGenerationReplay?: AssetGenerationReplayResponse | null;
    shopListed: boolean;
    shopPriceCredits: number;
    license: ContentLicense;
    permissions?: ContentPermissions;
    createdAt: string;
    updatedAt: string;
}
interface AssetResponse {
    id: number;
    name: string;
    displayName: string;
    description?: string | null;
    category: AssetCategory;
    assetSpecRef?: string | null;
    assetSpecDisplayName?: string | null;
    assetSpecSymbolUrl?: string | null;
    creatorId: number;
    creatorUsername: string;
    createdAt: string;
    updatedAt: string;
    currentVersion?: AssetVersionResponse | null;
    viewerSaved?: boolean;
    viewerLiked?: boolean;
    viewerDisliked?: boolean;
    likeCount?: number;
    viewCount?: number;
    commentCount?: number;
    remixCount?: number;
    packMembershipSummary?: AssetPackMembershipSummary | null;
    tags: ContentTagSummary[];
}
interface AssetPackMembershipSummaryItem {
    creatorUsername: string;
    name: string;
    displayName: string | null;
}
interface AssetPackMembershipSummary {
    count: number;
    packs: AssetPackMembershipSummaryItem[];
}
interface AssetRef {
    creatorUsername: string;
    name: string;
    revision: number;
}
interface UpdateAssetRequest {
    name?: string;
    displayName?: string;
    description?: string | null;
}
interface UpdateAssetVersionRequest {
    visibility?: AssetVisibility;
    license?: ContentLicense;
    setAsCurrent?: boolean;
}
declare const ASSET_LIST_SORT_VALUES: readonly ["recent", "views", "likes", "remixes", "comments"];
type AssetListSort = (typeof ASSET_LIST_SORT_VALUES)[number];
interface AssetListResponse {
    assets: AssetResponse[];
    pagination: {
        limit: number;
        offset: number;
        count: number;
        hasMore: boolean;
    };
}
interface AssetVersionsListResponse {
    versions: AssetVersionResponse[];
    pagination?: {
        limit: number;
        offset: number;
        count: number;
        hasMore: boolean;
    };
}
interface CreateAssetVersionResponse {
    asset: AssetResponse;
    version: AssetVersionResponse;
    versionNodeId: string;
    warnings?: Array<{
        code: string;
        message: string;
        successorRef?: string | null;
    }>;
}
interface UpdateAssetResponse {
    asset: AssetResponse;
}
interface UpdateAssetVersionResponse {
    version: AssetVersionResponse;
}
interface DeleteAssetVersionResponse {
    success: boolean;
}
interface DeleteAssetResponse {
    success: boolean;
}
interface AssetSourceBundleResponse {
    filename: string;
    sizeBytes: number;
    checksum?: string | null;
}

declare const ASSET_SPEC_VISIBILITY_VALUES: readonly ["PRIVATE", "PUBLIC"];
type AssetSpecVisibility = (typeof ASSET_SPEC_VISIBILITY_VALUES)[number];
declare const ASSET_SPEC_VALIDATION_KIND_VALUES: readonly ["NONE", "JSON_SCHEMA"];
type AssetSpecValidationKind = (typeof ASSET_SPEC_VALIDATION_KIND_VALUES)[number];
declare const ASSET_SPEC_STATUS_VALUES: readonly ["ACTIVE", "DEPRECATED", "RETRACTED"];
type AssetSpecStatus = (typeof ASSET_SPEC_STATUS_VALUES)[number];
declare const ASSET_SPEC_CAPABILITY_VALUES: readonly ["READ", "WRITE", "EDIT", "PREVIEW", "IMPORT"];
type AssetSpecCapability = (typeof ASSET_SPEC_CAPABILITY_VALUES)[number];
declare const ASSET_SPEC_ROLE_MODE_VALUES: readonly ["TEXT", "BINARY"];
type AssetSpecRoleMode = (typeof ASSET_SPEC_ROLE_MODE_VALUES)[number];
declare const ASSET_SPEC_REFERENCE_TARGET_KIND_VALUES: readonly ["ASSET"];
type AssetSpecReferenceTargetKind = (typeof ASSET_SPEC_REFERENCE_TARGET_KIND_VALUES)[number];
declare const ASSET_SPEC_REFERENCE_CARDINALITY_VALUES: readonly ["ONE", "MANY"];
type AssetSpecReferenceCardinality = (typeof ASSET_SPEC_REFERENCE_CARDINALITY_VALUES)[number];
interface AssetSpecRoleContract {
    name: string;
    required: boolean;
    contentTypes: string[];
    extensions?: string[];
    mode: AssetSpecRoleMode;
    jsonSchema?: Record<string, unknown> | null;
}
interface AssetSpecReferenceContract {
    name: string;
    required: boolean;
    targetKind: AssetSpecReferenceTargetKind;
    cardinality: AssetSpecReferenceCardinality;
    targetSpec?: string | null;
    versionRange?: string | null;
}
interface AssetSpecContract {
    primaryRole: string;
    roles: AssetSpecRoleContract[];
    references?: AssetSpecReferenceContract[];
}
interface AppMetadataAssetSpecSupport {
    assetSpecRef: string;
    versionRange: string;
    capabilities: AssetSpecCapability[];
}
interface AssetSpecVersionResponse {
    id: number;
    version: string;
    major: number;
    minor: number;
    patch: number;
    visibility: AssetSpecVisibility;
    status: AssetSpecStatus;
    validationKind: AssetSpecValidationKind;
    contractJson: AssetSpecContract | Record<string, unknown>;
    documentationUrl?: string | null;
    validatorUrl?: string | null;
    releaseNotes?: string | null;
    successorVersionRef?: string | null;
    createdAt: string;
    updatedAt: string;
}
interface AssetSpecResponse {
    id: number;
    name: string;
    displayName: string;
    description?: string | null;
    creatorId: number;
    creatorUsername: string;
    symbolUrl?: string | null;
    currentVersion?: AssetSpecVersionResponse | null;
    currentVersionRef?: string | null;
    status?: AssetSpecStatus | null;
    publicAssetCount: number;
    supportingAppCount: number;
    documentationAvailable: boolean;
    createdAt: string;
    updatedAt: string;
}
declare const ASSET_SPEC_LIST_SORT_VALUES: readonly ["recent", "assets", "apps", "alpha"];
type AssetSpecListSort = (typeof ASSET_SPEC_LIST_SORT_VALUES)[number];
interface AssetSpecListResponse {
    assetSpecs: AssetSpecResponse[];
    pagination: {
        limit: number;
        offset: number;
        count: number;
        hasMore: boolean;
    };
}
interface AssetSpecVersionsListResponse {
    versions: AssetSpecVersionResponse[];
    pagination?: {
        limit: number;
        offset: number;
        count: number;
        hasMore: boolean;
    };
}
interface AssetSpecAppsListResponse {
    assetSpec: AssetSpecResponse;
    apps: AppResponse[];
    pagination: {
        limit: number;
        offset: number;
        count: number;
        hasMore: boolean;
    };
}
interface AssetSpecSearchResult {
    kind: 'asset-spec';
    targetPath: string;
    assetSpec: AssetSpecResponse;
}

declare const APP_PLAYTEST_TAPE_VERSION: 1;
declare const APP_PLAYTEST_PRIMARY_VERB_VALUES: readonly ["tap", "swipe", "drag", "key"];
type AppPlaytestPrimaryVerb = typeof APP_PLAYTEST_PRIMARY_VERB_VALUES[number];
declare const APP_PLAYTEST_SUCCESS_SIGNAL_KIND_VALUES: readonly ["SURVIVE_LONGER", "SCORE_ABOVE_IDLE", "VISIBLE_PROGRESS", "STATE_REACHED"];
type AppPlaytestSuccessSignalKind = typeof APP_PLAYTEST_SUCCESS_SIGNAL_KIND_VALUES[number];
type AppPlaytestSuccessSignal = {
    kind: AppPlaytestSuccessSignalKind;
    description: string;
};
type AppPlaytestTimedEvent = {
    atMs: number;
};
type AppPlaytestPointerEvent = AppPlaytestTimedEvent & {
    type: 'pointerDown' | 'pointerMove' | 'pointerUp';
    x: number;
    y: number;
    pointerId?: number;
};
type AppPlaytestTapEvent = AppPlaytestTimedEvent & {
    type: 'tap';
    x: number;
    y: number;
    durationMs?: number;
};
type AppPlaytestKeyboardEvent = AppPlaytestTimedEvent & {
    type: 'keyDown' | 'keyUp';
    key: string;
};
type AppPlaytestTapeEvent = AppPlaytestPointerEvent | AppPlaytestTapEvent | AppPlaytestKeyboardEvent;
type AppPlaytestTape = {
    version: typeof APP_PLAYTEST_TAPE_VERSION;
    primaryVerb: AppPlaytestPrimaryVerb;
    durationMs: number;
    startOnlyEventCount: number;
    successSignals: AppPlaytestSuccessSignal[];
    events: AppPlaytestTapeEvent[];
};
type AppPlaytestTapes = Partial<Record<AppSurface, AppPlaytestTape>>;

declare const PLAYER_META_DEFINITION_STATUS_VALUES: readonly ["ACTIVE", "RETIRED"];
type PlayerMetaDefinitionStatus = (typeof PLAYER_META_DEFINITION_STATUS_VALUES)[number];
declare const APP_ACHIEVEMENT_KIND_VALUES: readonly ["STANDARD", "INCREMENTAL"];
type AppAchievementKind = (typeof APP_ACHIEVEMENT_KIND_VALUES)[number];
declare const APP_LEADERBOARD_SCORE_TYPE_VALUES: readonly ["INTEGER", "TIME_MS"];
type AppLeaderboardScoreType = (typeof APP_LEADERBOARD_SCORE_TYPE_VALUES)[number];
declare const APP_LEADERBOARD_SORT_VALUES: readonly ["DESC", "ASC"];
type AppLeaderboardSort = (typeof APP_LEADERBOARD_SORT_VALUES)[number];
interface AppAchievementDefinition {
    key: string;
    displayName: string;
    description: string;
    kind: AppAchievementKind;
    hidden: boolean;
    maxProgress: number | null;
    iconUrl: string;
    status: PlayerMetaDefinitionStatus;
}
interface AppLeaderboardDefinition {
    key: string;
    displayName: string;
    description: string;
    scoreType: AppLeaderboardScoreType;
    sort: AppLeaderboardSort;
    unitLabel?: string;
    status: PlayerMetaDefinitionStatus;
}
interface AppAchievementPlayerState {
    progress: number;
    unlocked: boolean;
    unlockedAt: string | null;
}
interface AppLeaderboardPlayerSummary {
    hasScore: boolean;
    bestScore: number | null;
    rank: number | null;
    bestScoreAt: string | null;
}
interface AchievementView {
    definition: AppAchievementDefinition;
    player: AppAchievementPlayerState | null;
}
interface LeaderboardSummary {
    definition: AppLeaderboardDefinition;
    player: AppLeaderboardPlayerSummary | null;
}
interface LeaderboardEntryUser {
    publicPlayerId: string;
    username?: string;
    displayName: string;
    avatarUrl?: string;
    profilePath?: string;
}
interface LeaderboardEntry {
    rank: number;
    score: number;
    bestScoreAt: string;
    isCurrentPlayer?: boolean;
    user: LeaderboardEntryUser;
}
interface LeaderboardView {
    definition: AppLeaderboardDefinition;
    top: LeaderboardEntry[];
    player: AppLeaderboardPlayerSummary | null;
    playerEntry: LeaderboardEntry | null;
    aroundPlayer: LeaderboardEntry[];
}
interface ListAchievementsResponse {
    achievements: AchievementView[];
}
interface GetAchievementResponse {
    achievement: AchievementView;
}
interface AppAchievementMutationSummary {
    key: string;
    displayName: string;
    iconUrl: string;
}
interface UnlockAchievementResponse {
    accepted: true;
    changed: boolean;
    unlocked: boolean;
    progress: number;
    unlockedAt: string | null;
    achievement: AppAchievementMutationSummary;
}
interface SetAchievementProgressResponse {
    accepted: true;
    changed: boolean;
    unlocked: boolean;
    progress: number;
    unlockedAt: string | null;
    achievement: AppAchievementMutationSummary;
}
interface ListLeaderboardsResponse {
    leaderboards: LeaderboardSummary[];
}
interface GetLeaderboardResponse {
    leaderboard: LeaderboardView;
}
interface AppLeaderboardMutationSummary {
    key: string;
    displayName: string;
    scoreType: AppLeaderboardScoreType;
    unitLabel?: string;
}
interface SubmitLeaderboardScoreResponse {
    accepted: true;
    improved: boolean;
    previousBestScore: number | null;
    bestScore: number;
    rank: number | null;
    previousRank: number | null;
    bestScoreAt: string;
    leaderboard: AppLeaderboardMutationSummary;
}

declare const APP_HOSTING_MODE_VALUES: readonly ["HOSTED", "EXTERNAL"];
type AppHostingMode = (typeof APP_HOSTING_MODE_VALUES)[number];
declare const APP_VERSION_VISIBILITY_VALUES: readonly ["PRIVATE", "PUBLIC"];
type AppVersionVisibility = (typeof APP_VERSION_VISIBILITY_VALUES)[number];
declare const REVIEW_STATE_VALUES: readonly ["NOT_REQUIRED", "QUEUED", "RUNNING", "SUPERSEDED", "LOW_QUALITY", "PASSED", "GOOD", "EXCELLENT", "FAILED", "ERROR"];
type ReviewState = (typeof REVIEW_STATE_VALUES)[number];
declare const APP_AUTH_MODE_VALUES: readonly ["REQUIRED", "OPTIONAL", "NONE"];
type AppAuthMode = (typeof APP_AUTH_MODE_VALUES)[number];
declare const APP_CONTROLLER_MODE_VALUES: readonly ["UNSUPPORTED", "SUPPORTED", "REQUIRED"];
type AppControllerMode = (typeof APP_CONTROLLER_MODE_VALUES)[number];

declare const APP_AUTH_FILTER_VALUES: readonly ["required", "optional", "none"];
type AppAuthFilter = (typeof APP_AUTH_FILTER_VALUES)[number];
declare const APP_CONTROLLER_FILTER_VALUES: readonly ["required", "optional", "none"];
type AppControllerFilter = (typeof APP_CONTROLLER_FILTER_VALUES)[number];
declare const APP_SURFACE_FILTER_VALUES: readonly ["desktop", "mobile-portrait", "mobile-landscape"];
type AppSurfaceFilter = (typeof APP_SURFACE_FILTER_VALUES)[number];

declare const VERSION_VISIBILITY_VALUES: readonly ["PRIVATE", "PUBLIC"];
type VersionVisibility = (typeof VERSION_VISIBILITY_VALUES)[number];
type AssetCategoryBreakdown = Partial<Record<AssetCategory, number>>;
type AssetSubcategoryBreakdown = Partial<Record<string, number>>;
interface AssetPackVersionResponse {
    id: number;
    version: string;
    major: number;
    minor: number;
    patch: number;
    visibility: VersionVisibility;
    license: ContentLicense;
    permissions?: ContentPermissions;
    hostingMode: AppHostingMode;
    externalUrl?: string | null;
    downloadUrl?: string | null;
    releaseNotes?: string | null;
    assets: AssetRef[];
    assetCategoryBreakdown?: AssetCategoryBreakdown;
    assetSubcategoryBreakdown?: AssetSubcategoryBreakdown;
    iconUrl?: string | null;
    heroPortraitUrl?: string | null;
    heroLandscapeUrl?: string | null;
    screenshotPortraitUrls?: string[];
    screenshotLandscapeUrls?: string[];
    videoPortraitUrls?: string[];
    videoLandscapeUrls?: string[];
    createdAt: string;
    updatedAt: string;
}
interface AssetPackResponse {
    id: number;
    name: string;
    displayName: string;
    description?: string | null;
    creatorId: number;
    creatorUsername: string;
    previewAppVersionId?: number | null;
    createdAt: string;
    updatedAt: string;
    currentVersion?: AssetPackVersionResponse | null;
    viewerSaved?: boolean;
    viewerLiked?: boolean;
    viewerDisliked?: boolean;
    likeCount?: number;
    viewCount?: number;
    downloadCount?: number;
    commentCount?: number;
    remixCount?: number;
    tags: ContentTagSummary[];
}
interface UpdateAssetPackRequest {
    name?: string;
    displayName?: string;
    description?: string | null;
    previewAppVersionId?: number | null;
}
interface UpdateAssetPackVersionRequest {
    visibility?: VersionVisibility;
    license?: ContentLicense;
    releaseNotes?: string | null;
    setAsCurrent?: boolean;
}
interface AssetPackListResponse {
    packs: AssetPackResponse[];
    pagination: {
        limit: number;
        offset: number;
        count: number;
        hasMore: boolean;
    };
}
interface AssetPackVersionsListResponse {
    versions: AssetPackVersionResponse[];
    pagination?: {
        limit: number;
        offset: number;
        count: number;
        hasMore: boolean;
    };
}
interface UpdateAssetPackResponse {
    pack: AssetPackResponse;
}
interface UpdateAssetPackVersionResponse {
    version: AssetPackVersionResponse;
}
interface DeleteAssetPackVersionResponse {
    success: boolean;
}
interface DeleteAssetPackResponse {
    success: boolean;
}

interface ContentTagSummary {
    ref: string;
    groupSlug: string;
    groupDisplayName: string;
    slug: string;
    displayName: string;
}
interface TagGroupSummary {
    slug: string;
    displayName: string;
    allowedTargetKinds: SavedItemKind[];
    createdAt: string;
    updatedAt: string;
}
interface TagSummary extends ContentTagSummary {
    createdAt: string;
    updatedAt: string;
}
interface TagGroupWithTagsSummary extends TagGroupSummary {
    tags: TagSummary[];
}
interface AppResponse {
    id?: number;
    name: string;
    displayName: string;
    subtitle?: string | null;
    description: string;
    creatorId?: number;
    creatorUsername: string;
    createdAt: string;
    updatedAt: string;
    origin?: AppOrigin;
    type: AppType;
    emoji?: string | null;
    color?: string | null;
    lastPlayedAt?: string;
    /** Current version string (e.g., "1.2.3"), null if no versions exist */
    currentVersion?: string | null;
    /** Hosting mode of current version */
    hostingMode?: AppHostingMode;
    /** Auth mode of current version */
    authMode?: AppAuthMode;
    /** Controller mode of current version */
    controllerMode?: AppControllerMode;
    /** Whether the current hosted version can boot as a non-interactive detail-page preview */
    previewable?: boolean;
    /** Visibility of current version */
    visibility?: AppVersionVisibility;
    /** Review state of current version */
    reviewState?: ReviewState;
    reviewStartedAt?: string | null;
    reviewCompletedAt?: string | null;
    /** License of the current version */
    license?: ContentLicense;
    /** Server-derived capability flags for the current version */
    permissions?: ContentPermissions;
    /** Base URL for loading the app (from current version) */
    assetUrl: string | null;
    /** Entry point file within assetUrl */
    entryPoint?: string | null;
    /** Surface targets from current version (undefined for draft apps with no version) */
    surfaceTargets?: AppSurface[];
    primarySurface?: AppSurface | null;
    playtestTapes?: AppPlaytestTapes | null;
    /** Asset spec support declarations from the current version */
    assetSpecSupport?: AppMetadataAssetSpecSupport[];
    bundleSize?: number | null;
    sourceUrl?: string | null;
    iconUrl?: string | null;
    heroPortraitUrl?: string | null;
    heroLandscapeUrl?: string | null;
    socialLandscapeUrl?: string | null;
    screenshotPortraitUrls?: string[];
    screenshotLandscapeUrls?: string[];
    videoPortraitUrls?: string[];
    videoLandscapeUrls?: string[];
    viewerSaved?: boolean;
    viewerLiked?: boolean;
    viewerDisliked?: boolean;
    likeCount?: number;
    dislikeCount?: number;
    viewCount?: number;
    playCount?: number;
    commentCount?: number;
    remixCount?: number;
    remixedFrom?: RemixRelatedItemSummary[];
    boostedUntil?: string | null;
    promotionSource?: string | null;
    promotionToken?: string | null;
    tags: ContentTagSummary[];
}
interface AppRuntimeAssetFileSummary {
    role: string;
    url: string;
    contentType?: string | null;
    sizeBytes?: number | null;
    sha256?: string | null;
}
interface AppRuntimeAssetSummary {
    assetRef: string;
    runtimeKey: string | null;
    sourceType: 'OWNED' | 'DIRECT' | 'PACK';
    sourcePackRef?: string | null;
    files: AppRuntimeAssetFileSummary[];
}
type RemixRelatedItemSummaryBase = {
    creatorUsername: string;
    name: string;
    displayName: string | null;
    linkedVersionRef: string | null;
};
type RemixRelatedItemSummary = ({
    kind: 'APP';
    appType: AppType;
} & RemixRelatedItemSummaryBase) | ({
    kind: 'ASSET';
} & RemixRelatedItemSummaryBase) | ({
    kind: 'PACK';
} & RemixRelatedItemSummaryBase);
interface PaginationMeta {
    limit: number;
    offset: number;
    count: number;
    hasMore: boolean;
}
declare const SEARCH_KIND_VALUES: readonly ["all", "creator", "app", "asset", "asset-spec", "pack"];
type SearchKind = typeof SEARCH_KIND_VALUES[number];
declare const SEARCH_MODE_VALUES: readonly ["grouped", "flat"];
type SearchMode = typeof SEARCH_MODE_VALUES[number];
declare const SEARCH_ASSET_TYPE_VALUES: readonly ["image", "video", "audio", "song", "sfx", "3d"];
type SearchAssetType = typeof SEARCH_ASSET_TYPE_VALUES[number];
declare const SEARCH_SORT_VALUES: readonly ["relevance", "views", "recent", "updated", "used", "newest", "likes", "downloads", "remixes", "comments", "assets", "apps", "alpha"];
type SearchSort = typeof SEARCH_SORT_VALUES[number];
interface SearchRequest {
    q: string;
    mode?: SearchMode;
    kind?: SearchKind;
    sort?: SearchSort;
    creatorUsername?: string;
    page?: number;
    pageSize?: number;
    appType?: AppType;
    auth?: AppAuthFilter;
    surface?: AppSurfaceFilter;
    controller?: AppControllerFilter;
    assetType?: SearchAssetType;
    assetCategory?: AssetCategory;
    assetSubcategory?: string;
    assetSpec?: string;
    assetSpecOwner?: string;
    assetSpecName?: string;
    packContainsCategory?: AssetCategory;
    packContainsSubcategory?: string;
    tags?: string[];
    includeCounts?: boolean;
}
interface SearchCountsByKind {
    creator: number;
    app: number;
    asset: number;
    assetSpec: number;
    pack: number;
    total: number;
}
interface SearchTabCounts {
    topResults: number;
    creators: number;
    apps: number;
    demos: number;
    tools: number;
    templates: number;
    images: number;
    videos: number;
    audio: number;
    songs: number;
    sfx: number;
    models3d: number;
    assetSpecs: number;
    packs: number;
}
interface HomeCreatorResponse {
    id: number;
    username: string;
    displayName: string;
    profileAssetPreviewUrl: string | null;
    xProfileImageUrl: string | null;
    googleProfileImageUrl: string | null;
    createdAt?: string;
    viewerFollowing?: boolean;
    followsViewer?: boolean;
}
declare const SAVED_ITEM_KIND_VALUES: readonly ["APP", "ASSET", "PACK"];
type SavedItemKind = typeof SAVED_ITEM_KIND_VALUES[number];
interface TagListResponse {
    groups: TagGroupWithTagsSummary[];
    pagination: PaginationMeta;
}
interface TagDetailResponse {
    tag: TagSummary & {
        group: TagGroupSummary;
    };
}
interface CreatorSearchResult {
    kind: 'creator';
    targetPath: string;
    creator: HomeCreatorResponse;
}
interface AppSearchResult {
    kind: 'app';
    targetPath: string;
    app: AppResponse;
}
interface AssetSearchResult {
    kind: 'asset';
    targetPath: string;
    asset: AssetResponse;
}
interface AssetPackSearchResult {
    kind: 'pack';
    targetPath: string;
    pack: AssetPackResponse;
}
type SearchResult = CreatorSearchResult | AppSearchResult | AssetSearchResult | AssetSpecSearchResult | AssetPackSearchResult;
interface SearchGroupedResults {
    creators: CreatorSearchResult[];
    apps: AppSearchResult[];
    assets: AssetSearchResult[];
    assetSpecs: AssetSpecSearchResult[];
    packs: AssetPackSearchResult[];
}
interface SearchResponse {
    q: string;
    mode: SearchMode;
    kind: SearchKind;
    countsByKind: SearchCountsByKind;
    tabCounts: SearchTabCounts;
    groups?: SearchGroupedResults;
    results?: SearchResult[];
    pagination?: PaginationMeta;
}
type AdInterstitialShowStatus = 'dismissed' | 'not_ready' | 'expired';
type AdRewardedShowStatus = 'completed' | 'dismissed' | 'not_ready' | 'expired';
type AdLoadResult = {
    status: 'ready';
} | {
    status: 'no_fill';
} | {
    status: 'rate_limited';
    retryAfterSeconds: number;
} | {
    status: 'blocked';
    reason: string;
};

declare const RELATION_TYPE_VALUES: readonly ["USES", "CONTAINS", "REMIXES"];
type RelationType = (typeof RELATION_TYPE_VALUES)[number];
interface NodeRelationRecord {
    id: number;
    fromNodeId: string;
    toNodeId: string;
    type: RelationType;
    createdAt: string;
    updatedAt: string;
}
interface BatchUpsertNodeRelationsRequest {
    relations: Array<{
        fromNodeId: string;
        toNodeId: string;
        type: RelationType;
    }>;
}
interface BatchUpsertNodeRelationsResponse {
    relations: NodeRelationRecord[];
}

type TextGenerationSize = 'small' | 'medium' | 'large';
type AiImageAspectRatio = '1:1' | '3:4' | '9:16' | '4:3' | '16:9';
type AiImageSize = '1K' | '4K';
type GenerationJobStatus = 'PENDING' | 'RUNNING' | 'SUCCESS' | 'FAILURE';
type ElevenLabsSongMetadata = {
    title?: string | null;
    description?: string | null;
    genres: string[];
    languages: string[];
    isExplicit?: boolean | null;
};
type ElevenLabsWordTimestamp = {
    word: string;
    startMs: number;
    endMs: number;
};
type ElevenLabsCompositionPlanSection = {
    sectionName?: string;
    durationMs?: number;
    positiveLocalStyles?: string[];
    negativeLocalStyles?: string[];
    lines?: string[];
};
type ElevenLabsCompositionPlan = {
    durationMs?: number;
    positiveGlobalStyles?: string[];
    negativeGlobalStyles?: string[];
    sections?: ElevenLabsCompositionPlanSection[];
};

type Deployment = 'dev' | 'live';
type Platform = 'web' | 'native';
type ConnectionStatus = 'offline' | 'connecting' | 'online';
type DeviceCategory = 'desktop' | 'tablet' | 'phone';
type DeviceOrientation = 'portrait' | 'landscape';
type SessionMode = 'dev' | 'play';
type HostPhase = 'preview' | 'play';
type HostPauseReason = 'tab_hidden' | 'auth_prompt' | 'purchase_flow' | 'host_overlay' | 'detail_hidden' | 'route_change' | 'native_background';
type HostAudioPolicyReason = HostPauseReason | 'user_preference';
type ControllerAvailability = 'ready' | 'blocked' | 'unsupported';
type LoadingState = {
    status: 'loading';
    progress?: number;
    message?: string;
} | {
    status: 'ready';
} | {
    status: 'error';
    message?: string;
};

interface AppMetadata {
    id: number | null;
    name: string | null;
    displayName: string | null;
    description: string | null;
    emoji: string | null;
    accentColor: string | null;
    type: AppType | null;
    surfaceTargets: AppSurface[];
    authMode: AppAuthMode;
    controllerMode: AppControllerMode;
    previewable: boolean;
    /** Semantic version string (e.g., "1.2.3") for multiplayer room isolation */
    version: string | null;
    assetSpecSupport: AppMetadataAssetSpecSupport[];
    routes?: {
        detailUrl: string;
        playUrl: string;
        previewUrl: string;
        devUrl: string;
        devPreviewUrl: string;
    } | null;
}
interface DeviceInputs {
    keyboard: boolean;
    mouse: boolean;
    touch: boolean;
}
interface DeviceGamepad {
    key: string;
    index: number;
    id: string;
    mapping: string;
}
interface DeviceControllerState {
    availability: ControllerAvailability;
    gamepads: DeviceGamepad[];
}
interface DeviceAPI {
    category: DeviceCategory;
    orientation: DeviceOrientation;
    inputs: DeviceInputs;
    controllerAvailability: ControllerAvailability;
    connectedGamepads: DeviceGamepad[];
    onControllerChange(cb: (state: DeviceControllerState) => void): () => void;
}
interface AudioPolicyState {
    enabled: boolean;
    reason: HostAudioPolicyReason;
}
interface HostAPI {
    ready(): void;
    /** @deprecated Use ready() instead. */
    firstFrameReady(): void;
    /** @deprecated Use ready() instead. */
    setLoadingState(state: LoadingState): void;
    error(message?: string): void;
    deployment: Deployment;
    platform: Platform;
    sdkVersion: string;
    sdkBuild: number;
    mode: SessionMode;
    phase: HostPhase;
    isPaused: boolean;
    audioEnabled: boolean;
    onPhaseChange(cb: (phase: HostPhase) => void): () => void;
    onPause(cb: (reason: HostPauseReason) => void): () => void;
    onResume(cb: (reason: HostPauseReason) => void): () => void;
    onAudioPolicyChange(cb: (policy: AudioPolicyState) => void): () => void;
}
interface ConnectionQualityMetrics {
    pingMs: number;
    jitterMs: number;
    interpDelayMs: number;
}
interface ConnectionAPI {
    getStatus(): ConnectionStatus;
    getQuality(): ConnectionQualityMetrics;
    serverNow(): number;
    renderTime(): number;
    onStatusChange(cb: (status: ConnectionStatus) => void): () => void;
    onQualityChange(cb: (quality: ConnectionQualityMetrics) => void): () => void;
}
interface SharedLibraryInfo {
    packageName: string;
    version: string;
    entryUrl: string;
    loaded: boolean;
}
interface ThreeLibraryInfo extends SharedLibraryInfo {
    packageName: 'three';
    availableAddons: ReadonlyArray<string>;
    loadedAddons: ReadonlyArray<string>;
}
interface RapierLibraryInfo extends SharedLibraryInfo {
    packageName: '@dimforge/rapier3d-compat';
}
interface NipplejsLibraryInfo extends SharedLibraryInfo {
    packageName: 'nipplejs';
}
interface PhaserLibraryInfo extends SharedLibraryInfo {
    packageName: 'phaser';
}
interface ThreeLoadOptions {
    addons?: ReadonlyArray<string>;
}
type ThreeRuntime = typeof THREEType & Record<string, unknown>;
type RapierRuntime = typeof RapierModule;
type NipplejsRuntime = typeof nipplejsModule;
type PhaserRuntime = typeof PhaserModule;
interface ThreeLibraryAPI {
    info(): ThreeLibraryInfo;
    load(options?: ThreeLoadOptions): Promise<ThreeRuntime>;
}
interface RapierLibraryAPI {
    info(): RapierLibraryInfo;
    load(): Promise<RapierRuntime>;
}
interface NipplejsLibraryAPI {
    info(): NipplejsLibraryInfo;
    load(): Promise<NipplejsRuntime>;
}
interface PhaserLibraryAPI {
    info(): PhaserLibraryInfo;
    load(): Promise<PhaserRuntime>;
}
interface LibrariesAPI {
    three: ThreeLibraryAPI;
    rapier: RapierLibraryAPI;
    nipplejs: NipplejsLibraryAPI;
    phaser: PhaserLibraryAPI;
}
interface AssetListOptions {
    limit?: number;
    offset?: number;
    category?: AssetCategory;
    subcategory?: string;
    assetSpec?: string;
    assetSpecOwner?: string;
    assetSpecName?: string;
    sort?: AssetListSort;
    containsCategory?: AssetCategory;
    containsSubcategory?: string;
    tags?: string[];
}
type AssetReference = string;
interface UploadBuiltInAssetVersionRequest {
    category: AssetCategory;
    subcategory: string;
    format: AssetFormat;
    visibility?: AssetVisibility;
    sourceKind?: AssetSourceKind;
    sourceAppVersionId?: number;
    sourceGenerationId?: string;
    tags?: string[];
    clearTags?: boolean;
    shopListed?: boolean;
    shopPriceCredits?: number;
    displayName?: string;
    description?: string;
    files: Array<{
        file: File | Blob;
        fieldName?: string;
        filename?: string;
    }>;
}
interface UploadCustomAssetVersionRequest {
    assetSpec: string;
    visibility?: AssetVisibility;
    sourceKind?: AssetSourceKind;
    sourceAppVersionId?: number;
    sourceGenerationId?: string;
    tags?: string[];
    clearTags?: boolean;
    shopListed?: boolean;
    shopPriceCredits?: number;
    displayName?: string;
    description?: string;
    files: Array<{
        file: File | Blob;
        fieldName?: string;
        filename?: string;
    }>;
}
type UploadAssetVersionRequest = UploadBuiltInAssetVersionRequest | UploadCustomAssetVersionRequest;
interface AssetsCatalogAPI {
    listCategories(): Promise<AssetSubcategoryDefinition[]>;
    listPublic(options?: AssetListOptions): Promise<AssetListResponse>;
    listForCreator(creatorUsername: string, options?: AssetListOptions): Promise<AssetListResponse>;
    get(creatorUsername: string, assetName: string): Promise<AssetResponse>;
    listVersions(creatorUsername: string, assetName: string, options?: AssetListOptions): Promise<AssetVersionsListResponse>;
    createVersion(creatorUsername: string, assetName: string, request: UploadAssetVersionRequest): Promise<CreateAssetVersionResponse>;
    update(creatorUsername: string, assetName: string, request: UpdateAssetRequest): Promise<UpdateAssetResponse>;
    updateVersion(creatorUsername: string, assetName: string, revision: string | number, request: UpdateAssetVersionRequest): Promise<UpdateAssetVersionResponse>;
    deleteVersion(creatorUsername: string, assetName: string, revision: string | number): Promise<DeleteAssetVersionResponse>;
    delete(creatorUsername: string, assetName: string): Promise<DeleteAssetResponse>;
    downloadFile(creatorUsername: string, assetName: string, revision: string | number, options?: {
        role?: string;
    }): Promise<Blob>;
    downloadSource(creatorUsername: string, assetName: string, revision: string | number): Promise<{
        blob: Blob;
        metadata: AssetSourceBundleResponse;
    }>;
}
interface AssetPacksCatalogAPI {
    listPublic(options?: AssetListOptions): Promise<AssetPackListResponse>;
    listForCreator(creatorUsername: string, options?: AssetListOptions): Promise<AssetPackListResponse>;
    get(creatorUsername: string, packName: string): Promise<AssetPackResponse>;
    listVersions(creatorUsername: string, packName: string, options?: AssetListOptions): Promise<AssetPackVersionsListResponse>;
    update(creatorUsername: string, packName: string, request: UpdateAssetPackRequest): Promise<UpdateAssetPackResponse>;
    updateVersion(creatorUsername: string, packName: string, version: string, request: UpdateAssetPackVersionRequest): Promise<UpdateAssetPackVersionResponse>;
    deleteVersion(creatorUsername: string, packName: string, version: string): Promise<DeleteAssetPackVersionResponse>;
    delete(creatorUsername: string, packName: string): Promise<DeleteAssetPackResponse>;
}
interface TagsListOptions {
    targetKind?: SavedItemKind;
    groupSlug?: string;
    limit?: number;
    offset?: number;
}
interface TagsAPI {
    list(options?: TagsListOptions): Promise<TagListResponse>;
    get(groupSlug: string, tagSlug: string): Promise<TagDetailResponse>;
}
interface AssetSpecsAPI {
    listPublic(options?: {
        limit?: number;
        offset?: number;
        sort?: AssetSpecListSort;
    }): Promise<AssetSpecListResponse>;
    get(assetSpecRef: string): Promise<AssetSpecResponse>;
    listVersions(assetSpecRef: string): Promise<AssetSpecVersionsListResponse>;
    listAssets(assetSpecRef: string, options?: AssetListOptions): Promise<AssetListResponse>;
    listApps(assetSpecRef: string, options?: {
        limit?: number;
        offset?: number;
    }): Promise<AssetSpecAppsListResponse>;
}
interface LoadedOwnedCustomAsset<T = unknown> {
    asset: OwnedCustomAssetSummary;
    version: OwnedCustomAssetVersionSummary | null;
    json: T;
    primaryText: string;
}
interface MutatedOwnedCustomAsset<T = unknown> {
    asset: OwnedCustomAssetSummary;
    version: OwnedCustomAssetVersionSummary | null;
    json: T;
    primaryText: string;
}
interface SaveOwnedCustomAssetRequest<T = unknown> {
    assetName: string;
    displayName?: string | null;
    description?: string | null;
    json: T | string;
    preview: Blob | File;
}
interface DeleteOwnedCustomAssetRequest {
    assetName: string;
    revision?: string | number;
    deleteAsset?: boolean;
}
interface CustomAssetFamilyAPI<T = unknown> {
    readonly assetSpecRef: string;
    listPublic(options?: AssetListOptions): Promise<AssetListResponse>;
    listForCreator(creatorUsername: string, options?: AssetListOptions): Promise<AssetListResponse>;
    get(creatorUsername: string, assetName: string): Promise<AssetResponse>;
    getByRef(assetRef: string): Promise<AssetResponse>;
    supports(assetSpecVersionRef: string, capability: AssetSpecCapability): boolean;
    assertSupported(assetSpecVersionRef: string, capability: AssetSpecCapability): void;
    loadJson<U = T>(input: {
        assetRef: string;
        role?: string;
    }): Promise<U>;
    loadText(input: {
        assetRef: string;
        role?: string;
    }): Promise<string>;
    downloadFile(input: {
        assetRef: string;
        role?: string;
    }): Promise<Blob>;
    listMine(): Promise<OwnedCustomAssetSummary[]>;
    loadOwned<U = T>(input: {
        assetRef: string;
    }): Promise<LoadedOwnedCustomAsset<U>>;
    saveDraft<U = T>(input: SaveOwnedCustomAssetRequest<U>): Promise<MutatedOwnedCustomAsset<U>>;
    publish<U = T>(input: SaveOwnedCustomAssetRequest<U>): Promise<MutatedOwnedCustomAsset<U>>;
    deleteOwned(input: DeleteOwnedCustomAssetRequest): Promise<{
        success: boolean;
    }>;
}
interface CustomAssetsAPI {
    forSpec<T = unknown>(assetSpecRef: string): CustomAssetFamilyAPI<T>;
}
interface AssetsGraphAPI {
    batchUpsertRelations(request: BatchUpsertNodeRelationsRequest): Promise<BatchUpsertNodeRelationsResponse>;
}
interface ModelAssetListOptions {
    subcategory: Model3DAssetSubcategory;
    limit?: number;
    offset?: number;
}
interface ModelAssetByIdRequest {
    id: number;
    subcategory?: Model3DAssetSubcategory;
}
interface ModelAssetByRefRequest {
    assetRef: AssetReference;
    subcategory?: Model3DAssetSubcategory;
}
interface ModelAssetBySlugRequest {
    subcategory: Model3DAssetSubcategory;
    slug: string;
    creatorSlug?: string;
}
type LoadBoxelRequest = {
    by: 'id';
    id: number;
    subcategory?: Model3DAssetSubcategory;
} | {
    by: 'ref';
    assetRef: AssetReference;
    subcategory?: Model3DAssetSubcategory;
} | {
    by: 'slug';
    subcategory: Model3DAssetSubcategory;
    slug: string;
    creatorSlug?: string;
};
interface ModelsAPI {
    listPublic(options: ModelAssetListOptions): Promise<AssetListResponse>;
    getById(options: ModelAssetByIdRequest): Promise<AssetResponse>;
    getByRef(options: ModelAssetByRefRequest): Promise<AssetResponse>;
    getBySlug(options: ModelAssetBySlugRequest): Promise<AssetResponse>;
    loadBoxel(options: LoadBoxelRequest): Promise<BoxelDefinition>;
}
interface AssetsAPI {
    catalog: AssetsCatalogAPI;
    specs: AssetSpecsAPI;
    custom: CustomAssetsAPI;
    models: ModelsAPI;
    packs: AssetPacksCatalogAPI;
    tags: TagsAPI;
    graph: AssetsGraphAPI;
    resolveAppAsset(runtimeKey: string): AppRuntimeAssetSummary;
    listAppAssets(): AppRuntimeAssetSummary[];
}
interface SearchAPI {
    query(request: SearchRequest): Promise<SearchResponse>;
}
interface DebugAPI {
    showUI(): void;
    hideUI(): void;
}
interface AppData {
    data: Record<string, any>;
    seq: number;
    ts_event: number;
    ts_arrival: number;
}
interface RoomData {
    data: Record<string, any>;
    seq: number;
    ts_event: number;
    ts_arrival: number;
}
interface RoomEvent {
    username: string;
    seq: number;
    ts_event: number;
    ts_arrival: number;
    payload?: Record<string, any>;
}
interface RoomBinaryEvent {
    username: string;
    userId?: number;
    seq: number;
    ts_event: number;
    ts_arrival: number;
    payload: Float64Array;
}
interface RoomMemberSnapshot {
    userId: number;
    username: string;
    selectedAvatarId: number;
    selectedProfileAssetRef: AssetReference;
    appData: AppData | null;
    roomData: RoomData | null;
}
type RoomEventHandler = (event: RoomEvent) => void;
type RoomBinaryEventHandler = (event: RoomBinaryEvent) => void;
type RoomId = number;
type RoomConfigValue = string | number | boolean;
type RoomConfig = Record<string, RoomConfigValue>;
interface RoomSummary {
    id: RoomId;
    config: RoomConfig;
    capacity: number;
    memberCount: number;
    createdAt: number;
    createdByUserId: number;
}
interface ListRoomsOptions {
    limit?: number;
    cursor?: string;
    config?: RoomConfig;
    availableOnly?: boolean;
}
interface ListRoomsResult {
    rooms: Array<RoomSummary>;
    nextCursor: string | null;
}
interface CreateRoomOptions {
    config?: RoomConfig;
}
interface JoinOrCreateRoomOptions {
    config?: RoomConfig;
}
interface Room {
    id: number;
    users: Array<RoomMemberSnapshot>;
    onUsersChange(cb: (users: Array<RoomMemberSnapshot>) => void): () => void;
    onEvent(type: string, handler: RoomEventHandler): () => void;
    sendEvent(type: string, payload?: Record<string, any>): Promise<void>;
    onBinaryEvent(eventCode: number, handler: RoomBinaryEventHandler): () => void;
    sendBinaryEvent(eventCode: number, payload: Float64Array): Promise<void>;
    getBufferedEvents(type: string): Array<RoomEvent>;
    getBufferedBinaryEvents(eventCode: number): Array<RoomBinaryEvent>;
    leave(): Promise<void>;
    updateRoomData(data: Record<string, any>): Promise<void>;
}
interface RoomsAPI {
    list(options?: ListRoomsOptions): Promise<ListRoomsResult>;
    create(options?: CreateRoomOptions): Promise<Room>;
    join(roomId: RoomId): Promise<Room>;
    joinOrCreate(options?: JoinOrCreateRoomOptions): Promise<Room>;
}
interface MeAPI {
    login(): Promise<void>;
    promptLogin(): Promise<void>;
    onAuthChange(cb: (state: Pick<MeAPI, 'isLoggedIn' | 'userId' | 'username' | 'selectedProfileAssetRef'>) => void): () => void;
    /** True only for a real PlayDrop account. Do not use this to gate game persistence. */
    isLoggedIn: boolean;
    userId: number | null;
    username: string | null;
    selectedAvatarId: number | null;
    selectedProfileAssetRef: AssetReference;
    getSelectedProfileAssetRef(): AssetReference;
    appData: AppData | null;
    /** Always callable. Persists for guests and real accounts, and remains in memory when fully logged out. */
    updateAppData(data: Record<string, any>): Promise<AppData>;
    /** @deprecated Use sdk.rooms.create(), sdk.rooms.join(), or sdk.rooms.list() instead. */
    joinRoom(): Promise<Room>;
}
type ShopPurchaseKind = 'consumable' | 'entitlement';
type ShopReceiptStatus = 'PENDING' | 'AUTHORIZED' | 'CONSUMED' | 'GRANTED' | 'CANCELLED';
interface ShopPurchasePayload {
    kind: ShopPurchaseKind;
    sku: string;
    displayName: string;
    priceCredits: number;
    previewImage?: string | null;
}
interface ShopReceipt {
    id: number;
    kind: ShopPurchaseKind;
    status: ShopReceiptStatus;
    displayName: string;
    sku: string | null;
    amount: number;
    sourceId: number;
    sourceName: string;
    buyerId: number;
    buyer: string;
    sellerId: number;
    seller: string;
    createdAt: string;
    updatedAt: string;
}
interface ShopReceiptList {
    receipts: ShopReceipt[];
    pagination: PaginationMeta;
}
interface ShopReceiptFilters {
    kind?: ShopPurchaseKind;
    status?: ShopReceiptStatus | ShopReceiptStatus[];
    from?: string | Date;
    to?: string | Date;
    limit?: number;
    offset?: number;
}
interface ShopAPI {
    purchase(payload: ShopPurchasePayload): Promise<ShopReceipt>;
    receipts(filters?: ShopReceiptFilters): Promise<ShopReceiptList>;
    consume(receiptId: number): Promise<ShopReceipt>;
    grant(receiptId: number): Promise<ShopReceipt>;
    cancel(receiptId: number): Promise<ShopReceipt>;
}
interface InterstitialAdsAPI {
    load(): Promise<AdLoadResult>;
    show(): Promise<{
        status: AdInterstitialShowStatus;
    }>;
}
interface RewardedAdsAPI {
    load(): Promise<AdLoadResult>;
    show(): Promise<{
        status: AdRewardedShowStatus;
    }>;
}
interface AdsAPI {
    interstitial: InterstitialAdsAPI;
    rewarded: RewardedAdsAPI;
}
interface AchievementListOptions {
    includeHiddenDefinitions?: boolean;
    includeRetired?: boolean;
}
interface AchievementsAPI {
    /** Always callable. Fully logged-out mutations resolve without persistence. */
    list(options?: AchievementListOptions): Promise<ListAchievementsResponse>;
    get(key: string, options?: AchievementListOptions): Promise<GetAchievementResponse>;
    unlock(key: string): Promise<UnlockAchievementResponse>;
    setProgressAtLeast(key: string, progress: number): Promise<SetAchievementProgressResponse>;
}
interface LeaderboardListOptions {
    includeRetired?: boolean;
}
interface LeaderboardGetOptions extends LeaderboardListOptions {
    top?: number;
    aroundMe?: number;
}
interface LeaderboardsAPI {
    /** Always callable. Fully logged-out submissions resolve without persistence. */
    list(options?: LeaderboardListOptions): Promise<ListLeaderboardsResponse>;
    get(key: string, options?: LeaderboardGetOptions): Promise<GetLeaderboardResponse>;
    submitScore(key: string, score: number): Promise<SubmitLeaderboardScoreResponse>;
}
type AiModelSize = TextGenerationSize;
interface Generation {
    id: string;
    cost: number;
    createdAt: string;
}
interface GeneratedAssetRef {
    creatorUsername: string;
    assetName: string;
    revision: number;
    versionId: number;
    subcategory: string;
    ref: string;
}
interface TextGeneration extends Generation {
    systemPrompt: string | null;
    inputPrompt: string;
    outputText: string;
    modelSize: TextGenerationSize;
}
interface JSONGeneration extends Generation {
    systemPrompt: string | null;
    inputPrompt: string;
    outputSchema: unknown;
    outputJSON: unknown;
}
interface ImageGeneration extends Generation {
    inputPrompt: string;
    inputImages: string[];
    outputImage: string | null;
    aspectRatio: AiImageAspectRatio | null;
    imageSize: AiImageSize | null;
    embeddedMetadata?: AssetEmbeddedMetadata | null;
    embeddingStatus?: AssetMetadataEmbeddingStatus | null;
    metadataUrl?: string | null;
    generatedAsset?: GeneratedAssetRef;
}
interface MusicGeneration extends Generation {
    inputPrompt: string;
    durationMs: number | null;
    forceInstrumental: boolean;
    audioUrl: string | null;
    audioMimeType: string | null;
    coverUrl: string | null;
    coverMimeType: string | null;
    providerSongMetadata: ElevenLabsSongMetadata | null;
    providerCompositionPlan: ElevenLabsCompositionPlan | null;
    providerWordTimestamps: ElevenLabsWordTimestamp[] | null;
    embeddedMetadata?: AssetEmbeddedMetadata | null;
    embeddingStatus?: AssetMetadataEmbeddingStatus | null;
    metadataUrl?: string | null;
    generatedAsset?: GeneratedAssetRef;
}
interface SfxGeneration extends Generation {
    inputPrompt: string;
    durationSeconds: number | null;
    loop: boolean;
    audioUrl: string | null;
    audioMimeType: string | null;
    coverUrl: string | null;
    coverMimeType: string | null;
    embeddedMetadata?: AssetEmbeddedMetadata | null;
    embeddingStatus?: AssetMetadataEmbeddingStatus | null;
    metadataUrl?: string | null;
    generatedAsset?: GeneratedAssetRef;
}
interface SpeechGeneration extends Generation {
    inputPrompt: string;
    audioUrl: string | null;
    audioMimeType: string | null;
    previewUrl: string | null;
    previewMimeType: string | null;
    speech: AssetSpeechMetadata | null;
    embeddedMetadata?: AssetEmbeddedMetadata | null;
    embeddingStatus?: AssetMetadataEmbeddingStatus | null;
    metadataUrl?: string | null;
    generatedAsset?: GeneratedAssetRef;
}
interface VideoGeneration extends Generation {
    inputPrompt: string;
    durationSeconds: number | null;
    aspectRatio: string | null;
    resolution: string | null;
    videoUrl: string | null;
    videoMimeType: string | null;
    thumbnailUrl: string | null;
    embeddedMetadata?: AssetEmbeddedMetadata | null;
    embeddingStatus?: AssetMetadataEmbeddingStatus | null;
    metadataUrl?: string | null;
    generatedAsset?: GeneratedAssetRef;
}
interface Model3DGeneration extends Generation {
    inputPrompt: string;
    sourceMode: 'TEXT' | 'IMAGE' | null;
    topology: 'triangle' | 'quad' | null;
    targetPolycount: number | null;
    shouldRemesh: boolean;
    shouldTexture: boolean;
    modelUrl: string | null;
    modelMimeType: string | null;
    thumbnailUrl: string | null;
    embeddedMetadata?: AssetEmbeddedMetadata | null;
    embeddingStatus?: AssetMetadataEmbeddingStatus | null;
    metadataUrl?: string | null;
    generatedAsset?: GeneratedAssetRef;
}
type AiImageInput = string | {
    url: string;
} | {
    data: string;
    mimeType?: string;
};
type AiAssetGenerationModality = 'IMAGE' | 'MUSIC' | 'SFX' | 'SPEECH' | 'VIDEO' | 'MODEL_3D';
interface AiGenerationJob {
    id: string;
    modality: AiAssetGenerationModality;
    status: GenerationJobStatus;
    requestPrompt: string;
    requestPayload: unknown;
    resultData: unknown | null;
    errorCode: string | null;
    errorMessage: string | null;
    linkedGenerationId: string | null;
    createdAt: string;
    updatedAt: string;
    startedAt: string | null;
    completedAt: string | null;
    failedAt: string | null;
    progressPercent: number | null;
    etaSecondsRemaining: number | null;
}
interface AiGenerationJobRequest {
    modality: AiAssetGenerationModality;
    inputPrompt: string;
    assetName?: string;
    assetDisplayName?: string;
    assetDescription?: string;
    assetVisibility?: 'PRIVATE' | 'PUBLIC';
    assetSubcategory?: string;
    attachAppVersionId?: number;
    remixAssetVersionRef?: string;
    suggestedTagRefs?: string[];
    image1?: AiImageInput | null;
    image2?: AiImageInput | null;
    durationMs?: number;
    forceInstrumental?: boolean;
    coverPrompt?: string;
    durationSeconds?: number;
    loop?: boolean;
    aspectRatio?: AiImageAspectRatio;
    imageSize?: AiImageSize;
    resolution?: '720p';
    speechVoice?: PlaydropSpeechVoiceId;
    speechProviderVoiceId?: string;
    sourceMode?: 'TEXT' | 'IMAGE';
    topology?: 'triangle' | 'quad';
    targetPolycount?: number;
    shouldRemesh?: boolean;
    shouldTexture?: boolean;
}
interface AiAssetsAPI {
    createGenerationJob(request: AiGenerationJobRequest): Promise<AiGenerationJob>;
    getGenerationJob(id: string): Promise<AiGenerationJob>;
    listGenerationJobs(options?: {
        modality?: AiAssetGenerationModality;
        status?: GenerationJobStatus;
        limit?: number;
        offset?: number;
    }): Promise<AiGenerationJob[]>;
    deleteGenerationJob(id: string): Promise<void>;
}
interface AiTextAPI {
    generate(inputPrompt: string, systemPrompt?: string | null, modelSize?: TextGenerationSize): Promise<TextGeneration>;
    generations(): Promise<TextGeneration[]>;
}
interface AiJsonAPI {
    generate(inputPrompt: string, responseSchema?: unknown, systemPrompt?: string | null, modelSize?: TextGenerationSize): Promise<JSONGeneration>;
    generations(): Promise<JSONGeneration[]>;
}
interface AiImageAPI {
    generations(): Promise<ImageGeneration[]>;
}
interface AiMusicAPI {
    generations(): Promise<MusicGeneration[]>;
}
interface AiSfxAPI {
    generations(): Promise<SfxGeneration[]>;
}
interface AiSpeechAPI {
    generations(): Promise<SpeechGeneration[]>;
}
interface AiVideoAPI {
    generations(): Promise<VideoGeneration[]>;
}
interface AiModel3DAPI {
    generations(): Promise<Model3DGeneration[]>;
}
interface AiAPI {
    text: AiTextAPI;
    json: AiJsonAPI;
    image: AiImageAPI;
    music: AiMusicAPI;
    sfx: AiSfxAPI;
    speech: AiSpeechAPI;
    video: AiVideoAPI;
    model3d: AiModel3DAPI;
    assets: AiAssetsAPI;
}
interface PlaydropSDK {
    host: HostAPI;
    device: DeviceAPI;
    connection: ConnectionAPI;
    app: AppMetadata;
    libs: LibrariesAPI;
    assets: AssetsAPI;
    search: SearchAPI;
    me: MeAPI;
    rooms: RoomsAPI;
    debug: DebugAPI;
    shop: ShopAPI;
    ads: AdsAPI;
    achievements: AchievementsAPI;
    leaderboards: LeaderboardsAPI;
    ai: AiAPI;
}

type PlaydropBoxelNamespace = {
    core: typeof entityCore;
    three: typeof entityThree;
};
type PlaydropNamespace = PlaydropSDK & {
    init: () => Promise<PlaydropSDK>;
    __hostInitPromise?: Promise<void>;
    boxel?: PlaydropBoxelNamespace;
};
declare global {
    interface Window {
        playdrop?: PlaydropNamespace;
        __playdrop_internal?: Record<string, unknown>;
    }
}

declare const host: HostAPI;

declare function getStatus(): ConnectionStatus;
declare function getQuality(): ConnectionQualityMetrics;
declare function serverNow(): number;
declare function renderTime(): number;
declare function onStatusChange(cb: (status: ConnectionStatus) => void): () => void;
declare function onQualityChange(cb: (quality: ConnectionQualityMetrics) => void): () => void;

declare const me: MeAPI;

declare const app: AppMetadata;

declare const assets: AssetsAPI;

declare const libs: LibrariesAPI;

declare const rooms: RoomsAPI;

declare const search: SearchAPI;

declare function showDebugUI(): void;
declare function hideDebugUI(): void;
declare const debug: {
    showUI: typeof showDebugUI;
    hideUI: typeof hideDebugUI;
};

declare const shop: ShopAPI;

declare const ads: AdsAPI;

declare const achievements: AchievementsAPI;
declare const leaderboards: LeaderboardsAPI;

declare const ai: AiAPI;

declare const parseBoxel: (candidate: unknown) => BoxelDefinition;
declare const formatBoxel: (model: BoxelDefinition) => string;
declare const validateBoxel: typeof validateBoxel$1;
declare const cleanEntity: typeof cleanEntity$1;
declare const createBoxelScene: typeof createBoxelScene$1;
declare const createBoxelNodeScene: typeof createBoxelNodeScene$1;
declare const createBoxelSceneGraph: typeof createBoxelSceneGraph$1;
declare const attachBoxelOverlays: typeof attachBoxelOverlays$1;

export { entityCore as BoxelCore, entityThree as BoxelThree, achievements, ads, ai, app, assets, attachBoxelOverlays, cleanEntity, createBoxelNodeScene, createBoxelScene, createBoxelSceneGraph, debug, formatBoxel, getQuality, getStatus, host, leaderboards, libs, me, onQualityChange, onStatusChange, parseBoxel, renderTime, rooms, search, serverNow, shop, validateBoxel };
export type { AchievementListOptions, AchievementsAPI, AdsAPI, AiAPI, AiImageAPI, AiImageInput, AiJsonAPI, AiModel3DAPI, AiModelSize, AiMusicAPI, AiSfxAPI, AiTextAPI, AiVideoAPI, AppData, AppMetadata, AppType, AssetReference, AssetsAPI, ConnectionAPI, ConnectionQualityMetrics, ConnectionStatus, CreateRoomOptions, DebugAPI, Deployment, DeviceAPI, DeviceCategory, DeviceInputs, DeviceOrientation, GeneratedAssetRef, Generation, HostAPI, ImageGeneration, InterstitialAdsAPI, JSONGeneration, JoinOrCreateRoomOptions, LeaderboardGetOptions, LeaderboardListOptions, LeaderboardsAPI, LibrariesAPI, ListRoomsOptions, ListRoomsResult, LoadBoxelRequest, LoadingState, MeAPI, Model3DGeneration, ModelAssetByIdRequest, ModelAssetByRefRequest, ModelAssetBySlugRequest, ModelAssetListOptions, ModelsAPI, MusicGeneration, NipplejsLibraryAPI, NipplejsLibraryInfo, NipplejsRuntime, PhaserLibraryAPI, PhaserLibraryInfo, PhaserRuntime, Platform, PlaydropNamespace, PlaydropSDK, RapierLibraryAPI, RapierLibraryInfo, RapierRuntime, RewardedAdsAPI, Room, RoomBinaryEvent, RoomBinaryEventHandler, RoomConfig, RoomConfigValue, RoomData, RoomEvent, RoomEventHandler, RoomId, RoomMemberSnapshot, RoomSummary, RoomsAPI, SearchAPI, SessionMode, SfxGeneration, SharedLibraryInfo, TextGeneration, ThreeLibraryAPI, ThreeLibraryInfo, ThreeLoadOptions, ThreeRuntime, VideoGeneration };
