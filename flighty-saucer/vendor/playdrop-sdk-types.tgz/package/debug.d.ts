import type { AppData, AppMetadata, ConnectionStatus, RoomMemberSnapshot } from './types.js';
type RoomFeedDirection = 'incoming' | 'outgoing';
interface ConnectionUpdate {
    status?: ConnectionStatus;
    pingMs?: number;
    jitterMs?: number;
    interpDelayMs?: number;
    offsetMs?: number | null;
    serverNow?: number | null;
    renderTime?: number | null;
}
interface MeUpdate {
    isLoggedIn: boolean;
    username: string | null;
    selectedProfileAssetRef: string | null;
    appData: AppData | null;
    appName: string | null;
    creatorUsername: string | null;
}
interface RoomUpdate {
    roomId: number | null;
    members: RoomMemberSnapshot[];
}
interface RoomFeedInput {
    direction: RoomFeedDirection;
    type: string;
    username: string | null;
    seq: number | null;
    ts_event: number | null;
    ts_arrival: number | null;
    payload?: Record<string, any> | null;
    roomId?: number | null;
    mismatch?: boolean;
}
declare function applyConnectionUpdate(update: ConnectionUpdate): void;
declare function applyMeUpdate(update: MeUpdate): void;
declare function applyDebugAppMetadata(metadata: AppMetadata): void;
declare function applyDebugRoomUpdate(update: RoomUpdate): void;
declare function appendDebugRoomFeed(entry: RoomFeedInput): void;
declare function resetDebugRoomState(): void;
declare function showDebugUI(): void;
declare function hideDebugUI(): void;
export declare const debug: {
    showUI: typeof showDebugUI;
    hideUI: typeof hideDebugUI;
};
declare function applyDeviceUpdate(category: string, orientation: string, inputs: {
    keyboard: boolean;
    mouse: boolean;
    touch: boolean;
}): void;
export declare const debugInternal: {
    updateConnection: typeof applyConnectionUpdate;
    updateAppMetadata: typeof applyDebugAppMetadata;
    updateMe: typeof applyMeUpdate;
    updateRoom: typeof applyDebugRoomUpdate;
    updateDevice: typeof applyDeviceUpdate;
    appendRoomFeed: typeof appendDebugRoomFeed;
    resetRoom: typeof resetDebugRoomState;
};
export {};
