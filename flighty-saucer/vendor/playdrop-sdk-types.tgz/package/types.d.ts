import type RapierModule from '@dimforge/rapier3d-compat';
import type { AiImageAspectRatio, AiImageSize, ElevenLabsCompositionPlan, ElevenLabsSongMetadata, ElevenLabsWordTimestamp, GenerationJobStatus, TextGenerationSize } from '@playdrop/ai-client';
import type { BoxelDefinition } from '@playdrop/boxel-core';
import type { AdInterstitialShowStatus, AdLoadResult, AdRewardedShowStatus, AppAuthMode, AppControllerMode, AppMetadataAssetSpecSupport, AppRuntimeAssetSummary, AppSurface, AppType, AssetCategory, AssetEmbeddedMetadata, AssetFormat, AssetListResponse, AssetListSort, AssetMetadataEmbeddingStatus, AssetPackListResponse, AssetPackResponse, AssetPackVersionsListResponse, AssetResponse, AssetSourceBundleResponse, AssetSourceKind, AssetSpecAppsListResponse, AssetSpecCapability, AssetSpecListResponse, AssetSpecListSort, AssetSpecResponse, AssetSpecVersionsListResponse, AssetSpeechMetadata, AssetSubcategoryDefinition, AssetVersionsListResponse, AssetVisibility, BatchUpsertNodeRelationsRequest, BatchUpsertNodeRelationsResponse, CreateAssetVersionResponse, DeleteAssetPackResponse, DeleteAssetPackVersionResponse, DeleteAssetResponse, DeleteAssetVersionResponse, GetAchievementResponse, GetLeaderboardResponse, ListAchievementsResponse, ListLeaderboardsResponse, Model3DAssetSubcategory, OwnedCustomAssetSummary, OwnedCustomAssetVersionSummary, PaginationMeta, PlaydropSpeechVoiceId, SavedItemKind, SearchRequest, SearchResponse, SetAchievementProgressResponse, SubmitLeaderboardScoreResponse, TagDetailResponse, TagListResponse, UnlockAchievementResponse, UpdateAssetPackRequest, UpdateAssetPackResponse, UpdateAssetPackVersionRequest, UpdateAssetPackVersionResponse, UpdateAssetRequest, UpdateAssetResponse, UpdateAssetVersionRequest, UpdateAssetVersionResponse } from '@playdrop/types';
import type nipplejsModule from 'nipplejs';
import type PhaserModule from 'phaser';
import type * as ThreeModule from 'three';
export type Deployment = 'dev' | 'live';
export type Platform = 'web' | 'native';
export type ConnectionStatus = 'offline' | 'connecting' | 'online';
export type DeviceCategory = 'desktop' | 'tablet' | 'phone';
export type DeviceOrientation = 'portrait' | 'landscape';
export type SessionMode = 'dev' | 'play';
export type HostPhase = 'preview' | 'play';
export type HostPauseReason = 'tab_hidden' | 'auth_prompt' | 'purchase_flow' | 'host_overlay' | 'detail_hidden' | 'route_change' | 'native_background';
export type HostAudioPolicyReason = HostPauseReason | 'user_preference';
export type ControllerAvailability = 'ready' | 'blocked' | 'unsupported';
export type LoadingState = {
    status: 'loading';
    progress?: number;
    message?: string;
} | {
    status: 'ready';
} | {
    status: 'error';
    message?: string;
};
export type { AppType, OwnedCustomAssetSummary, OwnedCustomAssetVersionSummary } from '@playdrop/types';
export interface AppMetadata {
    id: number | null;
    name: string | null;
    displayName: string | null;
    description: string | null;
    emoji: string | null;
    accentColor: string | null;
    type: AppType | null;
    surfaceTargets: AppSurface[];
    authMode: AppAuthMode;
    controllerMode: AppControllerMode;
    previewable: boolean;
    /** Semantic version string (e.g., "1.2.3") for multiplayer room isolation */
    version: string | null;
    assetSpecSupport: AppMetadataAssetSpecSupport[];
    routes?: {
        detailUrl: string;
        playUrl: string;
        previewUrl: string;
        devUrl: string;
        devPreviewUrl: string;
    } | null;
}
export interface DeviceInputs {
    keyboard: boolean;
    mouse: boolean;
    touch: boolean;
}
export interface DeviceGamepad {
    key: string;
    index: number;
    id: string;
    mapping: string;
}
export interface DeviceControllerState {
    availability: ControllerAvailability;
    gamepads: DeviceGamepad[];
}
export interface DeviceAPI {
    category: DeviceCategory;
    orientation: DeviceOrientation;
    inputs: DeviceInputs;
    controllerAvailability: ControllerAvailability;
    connectedGamepads: DeviceGamepad[];
    onControllerChange(cb: (state: DeviceControllerState) => void): () => void;
}
export interface AudioPolicyState {
    enabled: boolean;
    reason: HostAudioPolicyReason;
}
export interface HostAPI {
    ready(): void;
    /** @deprecated Use ready() instead. */
    firstFrameReady(): void;
    /** @deprecated Use ready() instead. */
    setLoadingState(state: LoadingState): void;
    error(message?: string): void;
    deployment: Deployment;
    platform: Platform;
    sdkVersion: string;
    sdkBuild: number;
    mode: SessionMode;
    phase: HostPhase;
    isPaused: boolean;
    audioEnabled: boolean;
    onPhaseChange(cb: (phase: HostPhase) => void): () => void;
    onPause(cb: (reason: HostPauseReason) => void): () => void;
    onResume(cb: (reason: HostPauseReason) => void): () => void;
    onAudioPolicyChange(cb: (policy: AudioPolicyState) => void): () => void;
}
export interface ConnectionQualityMetrics {
    pingMs: number;
    jitterMs: number;
    interpDelayMs: number;
}
export interface ConnectionAPI {
    getStatus(): ConnectionStatus;
    getQuality(): ConnectionQualityMetrics;
    serverNow(): number;
    renderTime(): number;
    onStatusChange(cb: (status: ConnectionStatus) => void): () => void;
    onQualityChange(cb: (quality: ConnectionQualityMetrics) => void): () => void;
}
export interface SharedLibraryInfo {
    packageName: string;
    version: string;
    entryUrl: string;
    loaded: boolean;
}
export interface ThreeLibraryInfo extends SharedLibraryInfo {
    packageName: 'three';
    availableAddons: ReadonlyArray<string>;
    loadedAddons: ReadonlyArray<string>;
}
export interface RapierLibraryInfo extends SharedLibraryInfo {
    packageName: '@dimforge/rapier3d-compat';
}
export interface NipplejsLibraryInfo extends SharedLibraryInfo {
    packageName: 'nipplejs';
}
export interface PhaserLibraryInfo extends SharedLibraryInfo {
    packageName: 'phaser';
}
export interface ThreeLoadOptions {
    addons?: ReadonlyArray<string>;
}
export type ThreeRuntime = typeof ThreeModule & Record<string, unknown>;
export type RapierRuntime = typeof RapierModule;
export type NipplejsRuntime = typeof nipplejsModule;
export type PhaserRuntime = typeof PhaserModule;
export interface ThreeLibraryAPI {
    info(): ThreeLibraryInfo;
    load(options?: ThreeLoadOptions): Promise<ThreeRuntime>;
}
export interface RapierLibraryAPI {
    info(): RapierLibraryInfo;
    load(): Promise<RapierRuntime>;
}
export interface NipplejsLibraryAPI {
    info(): NipplejsLibraryInfo;
    load(): Promise<NipplejsRuntime>;
}
export interface PhaserLibraryAPI {
    info(): PhaserLibraryInfo;
    load(): Promise<PhaserRuntime>;
}
export interface LibrariesAPI {
    three: ThreeLibraryAPI;
    rapier: RapierLibraryAPI;
    nipplejs: NipplejsLibraryAPI;
    phaser: PhaserLibraryAPI;
}
export interface AssetListOptions {
    limit?: number;
    offset?: number;
    category?: AssetCategory;
    subcategory?: string;
    assetSpec?: string;
    assetSpecOwner?: string;
    assetSpecName?: string;
    sort?: AssetListSort;
    containsCategory?: AssetCategory;
    containsSubcategory?: string;
    tags?: string[];
}
export type AssetReference = string;
export interface UploadBuiltInAssetVersionRequest {
    category: AssetCategory;
    subcategory: string;
    format: AssetFormat;
    visibility?: AssetVisibility;
    sourceKind?: AssetSourceKind;
    sourceAppVersionId?: number;
    sourceGenerationId?: string;
    tags?: string[];
    clearTags?: boolean;
    shopListed?: boolean;
    shopPriceCredits?: number;
    displayName?: string;
    description?: string;
    files: Array<{
        file: File | Blob;
        fieldName?: string;
        filename?: string;
    }>;
}
export interface UploadCustomAssetVersionRequest {
    assetSpec: string;
    visibility?: AssetVisibility;
    sourceKind?: AssetSourceKind;
    sourceAppVersionId?: number;
    sourceGenerationId?: string;
    tags?: string[];
    clearTags?: boolean;
    shopListed?: boolean;
    shopPriceCredits?: number;
    displayName?: string;
    description?: string;
    files: Array<{
        file: File | Blob;
        fieldName?: string;
        filename?: string;
    }>;
}
export type UploadAssetVersionRequest = UploadBuiltInAssetVersionRequest | UploadCustomAssetVersionRequest;
export interface AssetsCatalogAPI {
    listCategories(): Promise<AssetSubcategoryDefinition[]>;
    listPublic(options?: AssetListOptions): Promise<AssetListResponse>;
    listForCreator(creatorUsername: string, options?: AssetListOptions): Promise<AssetListResponse>;
    get(creatorUsername: string, assetName: string): Promise<AssetResponse>;
    listVersions(creatorUsername: string, assetName: string, options?: AssetListOptions): Promise<AssetVersionsListResponse>;
    createVersion(creatorUsername: string, assetName: string, request: UploadAssetVersionRequest): Promise<CreateAssetVersionResponse>;
    update(creatorUsername: string, assetName: string, request: UpdateAssetRequest): Promise<UpdateAssetResponse>;
    updateVersion(creatorUsername: string, assetName: string, revision: string | number, request: UpdateAssetVersionRequest): Promise<UpdateAssetVersionResponse>;
    deleteVersion(creatorUsername: string, assetName: string, revision: string | number): Promise<DeleteAssetVersionResponse>;
    delete(creatorUsername: string, assetName: string): Promise<DeleteAssetResponse>;
    downloadFile(creatorUsername: string, assetName: string, revision: string | number, options?: {
        role?: string;
    }): Promise<Blob>;
    downloadSource(creatorUsername: string, assetName: string, revision: string | number): Promise<{
        blob: Blob;
        metadata: AssetSourceBundleResponse;
    }>;
}
export interface AssetPacksCatalogAPI {
    listPublic(options?: AssetListOptions): Promise<AssetPackListResponse>;
    listForCreator(creatorUsername: string, options?: AssetListOptions): Promise<AssetPackListResponse>;
    get(creatorUsername: string, packName: string): Promise<AssetPackResponse>;
    listVersions(creatorUsername: string, packName: string, options?: AssetListOptions): Promise<AssetPackVersionsListResponse>;
    update(creatorUsername: string, packName: string, request: UpdateAssetPackRequest): Promise<UpdateAssetPackResponse>;
    updateVersion(creatorUsername: string, packName: string, version: string, request: UpdateAssetPackVersionRequest): Promise<UpdateAssetPackVersionResponse>;
    deleteVersion(creatorUsername: string, packName: string, version: string): Promise<DeleteAssetPackVersionResponse>;
    delete(creatorUsername: string, packName: string): Promise<DeleteAssetPackResponse>;
}
export interface TagsListOptions {
    targetKind?: SavedItemKind;
    groupSlug?: string;
    limit?: number;
    offset?: number;
}
export interface TagsAPI {
    list(options?: TagsListOptions): Promise<TagListResponse>;
    get(groupSlug: string, tagSlug: string): Promise<TagDetailResponse>;
}
export interface AssetSpecsAPI {
    listPublic(options?: {
        limit?: number;
        offset?: number;
        sort?: AssetSpecListSort;
    }): Promise<AssetSpecListResponse>;
    get(assetSpecRef: string): Promise<AssetSpecResponse>;
    listVersions(assetSpecRef: string): Promise<AssetSpecVersionsListResponse>;
    listAssets(assetSpecRef: string, options?: AssetListOptions): Promise<AssetListResponse>;
    listApps(assetSpecRef: string, options?: {
        limit?: number;
        offset?: number;
    }): Promise<AssetSpecAppsListResponse>;
}
export interface CustomAssetCapabilityError extends Error {
    code: 'custom_asset_runtime_uninitialized' | 'custom_asset_capability_unsupported' | 'custom_asset_spec_family_mismatch' | 'custom_asset_role_type_mismatch' | 'custom_asset_request_failed';
}
export interface LoadedOwnedCustomAsset<T = unknown> {
    asset: OwnedCustomAssetSummary;
    version: OwnedCustomAssetVersionSummary | null;
    json: T;
    primaryText: string;
}
export interface MutatedOwnedCustomAsset<T = unknown> {
    asset: OwnedCustomAssetSummary;
    version: OwnedCustomAssetVersionSummary | null;
    json: T;
    primaryText: string;
}
export interface SaveOwnedCustomAssetRequest<T = unknown> {
    assetName: string;
    displayName?: string | null;
    description?: string | null;
    json: T | string;
    preview: Blob | File;
}
export interface DeleteOwnedCustomAssetRequest {
    assetName: string;
    revision?: string | number;
    deleteAsset?: boolean;
}
export interface CustomAssetFamilyAPI<T = unknown> {
    readonly assetSpecRef: string;
    listPublic(options?: AssetListOptions): Promise<AssetListResponse>;
    listForCreator(creatorUsername: string, options?: AssetListOptions): Promise<AssetListResponse>;
    get(creatorUsername: string, assetName: string): Promise<AssetResponse>;
    getByRef(assetRef: string): Promise<AssetResponse>;
    supports(assetSpecVersionRef: string, capability: AssetSpecCapability): boolean;
    assertSupported(assetSpecVersionRef: string, capability: AssetSpecCapability): void;
    loadJson<U = T>(input: {
        assetRef: string;
        role?: string;
    }): Promise<U>;
    loadText(input: {
        assetRef: string;
        role?: string;
    }): Promise<string>;
    downloadFile(input: {
        assetRef: string;
        role?: string;
    }): Promise<Blob>;
    listMine(): Promise<OwnedCustomAssetSummary[]>;
    loadOwned<U = T>(input: {
        assetRef: string;
    }): Promise<LoadedOwnedCustomAsset<U>>;
    saveDraft<U = T>(input: SaveOwnedCustomAssetRequest<U>): Promise<MutatedOwnedCustomAsset<U>>;
    publish<U = T>(input: SaveOwnedCustomAssetRequest<U>): Promise<MutatedOwnedCustomAsset<U>>;
    deleteOwned(input: DeleteOwnedCustomAssetRequest): Promise<{
        success: boolean;
    }>;
}
export interface CustomAssetsAPI {
    forSpec<T = unknown>(assetSpecRef: string): CustomAssetFamilyAPI<T>;
}
export interface AssetsGraphAPI {
    batchUpsertRelations(request: BatchUpsertNodeRelationsRequest): Promise<BatchUpsertNodeRelationsResponse>;
}
export interface ModelAssetListOptions {
    subcategory: Model3DAssetSubcategory;
    limit?: number;
    offset?: number;
}
export interface ModelAssetByIdRequest {
    id: number;
    subcategory?: Model3DAssetSubcategory;
}
export interface ModelAssetByRefRequest {
    assetRef: AssetReference;
    subcategory?: Model3DAssetSubcategory;
}
export interface ModelAssetBySlugRequest {
    subcategory: Model3DAssetSubcategory;
    slug: string;
    creatorSlug?: string;
}
export type LoadBoxelRequest = {
    by: 'id';
    id: number;
    subcategory?: Model3DAssetSubcategory;
} | {
    by: 'ref';
    assetRef: AssetReference;
    subcategory?: Model3DAssetSubcategory;
} | {
    by: 'slug';
    subcategory: Model3DAssetSubcategory;
    slug: string;
    creatorSlug?: string;
};
export interface ModelsAPI {
    listPublic(options: ModelAssetListOptions): Promise<AssetListResponse>;
    getById(options: ModelAssetByIdRequest): Promise<AssetResponse>;
    getByRef(options: ModelAssetByRefRequest): Promise<AssetResponse>;
    getBySlug(options: ModelAssetBySlugRequest): Promise<AssetResponse>;
    loadBoxel(options: LoadBoxelRequest): Promise<BoxelDefinition>;
}
export interface AssetsAPI {
    catalog: AssetsCatalogAPI;
    specs: AssetSpecsAPI;
    custom: CustomAssetsAPI;
    models: ModelsAPI;
    packs: AssetPacksCatalogAPI;
    tags: TagsAPI;
    graph: AssetsGraphAPI;
    resolveAppAsset(runtimeKey: string): AppRuntimeAssetSummary;
    listAppAssets(): AppRuntimeAssetSummary[];
}
export interface SearchAPI {
    query(request: SearchRequest): Promise<SearchResponse>;
}
export interface DebugAPI {
    showUI(): void;
    hideUI(): void;
}
export interface AppData {
    data: Record<string, any>;
    seq: number;
    ts_event: number;
    ts_arrival: number;
}
export interface RoomData {
    data: Record<string, any>;
    seq: number;
    ts_event: number;
    ts_arrival: number;
}
export interface RoomEvent {
    username: string;
    seq: number;
    ts_event: number;
    ts_arrival: number;
    payload?: Record<string, any>;
}
export interface RoomBinaryEvent {
    username: string;
    userId?: number;
    seq: number;
    ts_event: number;
    ts_arrival: number;
    payload: Float64Array;
}
export interface RoomMemberSnapshot {
    userId: number;
    username: string;
    selectedAvatarId: number;
    selectedProfileAssetRef: AssetReference;
    appData: AppData | null;
    roomData: RoomData | null;
}
export type RoomEventHandler = (event: RoomEvent) => void;
export type RoomBinaryEventHandler = (event: RoomBinaryEvent) => void;
export type RoomId = number;
export type RoomConfigValue = string | number | boolean;
export type RoomConfig = Record<string, RoomConfigValue>;
export interface RoomSummary {
    id: RoomId;
    config: RoomConfig;
    capacity: number;
    memberCount: number;
    createdAt: number;
    createdByUserId: number;
}
export interface ListRoomsOptions {
    limit?: number;
    cursor?: string;
    config?: RoomConfig;
    availableOnly?: boolean;
}
export interface ListRoomsResult {
    rooms: Array<RoomSummary>;
    nextCursor: string | null;
}
export interface CreateRoomOptions {
    config?: RoomConfig;
}
export interface JoinOrCreateRoomOptions {
    config?: RoomConfig;
}
export interface Room {
    id: number;
    users: Array<RoomMemberSnapshot>;
    onUsersChange(cb: (users: Array<RoomMemberSnapshot>) => void): () => void;
    onEvent(type: string, handler: RoomEventHandler): () => void;
    sendEvent(type: string, payload?: Record<string, any>): Promise<void>;
    onBinaryEvent(eventCode: number, handler: RoomBinaryEventHandler): () => void;
    sendBinaryEvent(eventCode: number, payload: Float64Array): Promise<void>;
    getBufferedEvents(type: string): Array<RoomEvent>;
    getBufferedBinaryEvents(eventCode: number): Array<RoomBinaryEvent>;
    leave(): Promise<void>;
    updateRoomData(data: Record<string, any>): Promise<void>;
}
export interface RoomsAPI {
    list(options?: ListRoomsOptions): Promise<ListRoomsResult>;
    create(options?: CreateRoomOptions): Promise<Room>;
    join(roomId: RoomId): Promise<Room>;
    joinOrCreate(options?: JoinOrCreateRoomOptions): Promise<Room>;
}
export interface MeAPI {
    login(): Promise<void>;
    promptLogin(): Promise<void>;
    onAuthChange(cb: (state: Pick<MeAPI, 'isLoggedIn' | 'userId' | 'username' | 'selectedProfileAssetRef'>) => void): () => void;
    /** True only for a real PlayDrop account. Do not use this to gate game persistence. */
    isLoggedIn: boolean;
    userId: number | null;
    username: string | null;
    selectedAvatarId: number | null;
    selectedProfileAssetRef: AssetReference;
    getSelectedProfileAssetRef(): AssetReference;
    appData: AppData | null;
    /** Always callable. Persists for guests and real accounts, and remains in memory when fully logged out. */
    updateAppData(data: Record<string, any>): Promise<AppData>;
    /** @deprecated Use sdk.rooms.create(), sdk.rooms.join(), or sdk.rooms.list() instead. */
    joinRoom(): Promise<Room>;
}
export type ShopErrorType = 'user_denied' | 'insufficient_funds' | 'network_error' | 'server_error';
export interface ShopError extends Error {
    type: ShopErrorType;
    code?: string;
}
export type ShopPurchaseKind = 'consumable' | 'entitlement';
export type ShopReceiptStatus = 'PENDING' | 'AUTHORIZED' | 'CONSUMED' | 'GRANTED' | 'CANCELLED';
export interface ShopPurchasePayload {
    kind: ShopPurchaseKind;
    sku: string;
    displayName: string;
    priceCredits: number;
    previewImage?: string | null;
}
export interface ShopReceipt {
    id: number;
    kind: ShopPurchaseKind;
    status: ShopReceiptStatus;
    displayName: string;
    sku: string | null;
    amount: number;
    sourceId: number;
    sourceName: string;
    buyerId: number;
    buyer: string;
    sellerId: number;
    seller: string;
    createdAt: string;
    updatedAt: string;
}
export interface ShopReceiptList {
    receipts: ShopReceipt[];
    pagination: PaginationMeta;
}
export interface ShopReceiptFilters {
    kind?: ShopPurchaseKind;
    status?: ShopReceiptStatus | ShopReceiptStatus[];
    from?: string | Date;
    to?: string | Date;
    limit?: number;
    offset?: number;
}
export interface ShopAPI {
    purchase(payload: ShopPurchasePayload): Promise<ShopReceipt>;
    receipts(filters?: ShopReceiptFilters): Promise<ShopReceiptList>;
    consume(receiptId: number): Promise<ShopReceipt>;
    grant(receiptId: number): Promise<ShopReceipt>;
    cancel(receiptId: number): Promise<ShopReceipt>;
}
export interface InterstitialAdsAPI {
    load(): Promise<AdLoadResult>;
    show(): Promise<{
        status: AdInterstitialShowStatus;
    }>;
}
export interface RewardedAdsAPI {
    load(): Promise<AdLoadResult>;
    show(): Promise<{
        status: AdRewardedShowStatus;
    }>;
}
export interface AdsAPI {
    interstitial: InterstitialAdsAPI;
    rewarded: RewardedAdsAPI;
}
export interface AchievementListOptions {
    includeHiddenDefinitions?: boolean;
    includeRetired?: boolean;
}
export interface AchievementsAPI {
    /** Always callable. Fully logged-out mutations resolve without persistence. */
    list(options?: AchievementListOptions): Promise<ListAchievementsResponse>;
    get(key: string, options?: AchievementListOptions): Promise<GetAchievementResponse>;
    unlock(key: string): Promise<UnlockAchievementResponse>;
    setProgressAtLeast(key: string, progress: number): Promise<SetAchievementProgressResponse>;
}
export interface LeaderboardListOptions {
    includeRetired?: boolean;
}
export interface LeaderboardGetOptions extends LeaderboardListOptions {
    top?: number;
    aroundMe?: number;
}
export interface LeaderboardsAPI {
    /** Always callable. Fully logged-out submissions resolve without persistence. */
    list(options?: LeaderboardListOptions): Promise<ListLeaderboardsResponse>;
    get(key: string, options?: LeaderboardGetOptions): Promise<GetLeaderboardResponse>;
    submitScore(key: string, score: number): Promise<SubmitLeaderboardScoreResponse>;
}
export type AiModelSize = TextGenerationSize;
export interface Generation {
    id: string;
    cost: number;
    createdAt: string;
}
export interface GeneratedAssetRef {
    creatorUsername: string;
    assetName: string;
    revision: number;
    versionId: number;
    subcategory: string;
    ref: string;
}
export interface TextGeneration extends Generation {
    systemPrompt: string | null;
    inputPrompt: string;
    outputText: string;
    modelSize: TextGenerationSize;
}
export interface JSONGeneration extends Generation {
    systemPrompt: string | null;
    inputPrompt: string;
    outputSchema: unknown;
    outputJSON: unknown;
}
export interface ImageGeneration extends Generation {
    inputPrompt: string;
    inputImages: string[];
    outputImage: string | null;
    aspectRatio: AiImageAspectRatio | null;
    imageSize: AiImageSize | null;
    embeddedMetadata?: AssetEmbeddedMetadata | null;
    embeddingStatus?: AssetMetadataEmbeddingStatus | null;
    metadataUrl?: string | null;
    generatedAsset?: GeneratedAssetRef;
}
export interface MusicGeneration extends Generation {
    inputPrompt: string;
    durationMs: number | null;
    forceInstrumental: boolean;
    audioUrl: string | null;
    audioMimeType: string | null;
    coverUrl: string | null;
    coverMimeType: string | null;
    providerSongMetadata: ElevenLabsSongMetadata | null;
    providerCompositionPlan: ElevenLabsCompositionPlan | null;
    providerWordTimestamps: ElevenLabsWordTimestamp[] | null;
    embeddedMetadata?: AssetEmbeddedMetadata | null;
    embeddingStatus?: AssetMetadataEmbeddingStatus | null;
    metadataUrl?: string | null;
    generatedAsset?: GeneratedAssetRef;
}
export interface SfxGeneration extends Generation {
    inputPrompt: string;
    durationSeconds: number | null;
    loop: boolean;
    audioUrl: string | null;
    audioMimeType: string | null;
    coverUrl: string | null;
    coverMimeType: string | null;
    embeddedMetadata?: AssetEmbeddedMetadata | null;
    embeddingStatus?: AssetMetadataEmbeddingStatus | null;
    metadataUrl?: string | null;
    generatedAsset?: GeneratedAssetRef;
}
export interface SpeechGeneration extends Generation {
    inputPrompt: string;
    audioUrl: string | null;
    audioMimeType: string | null;
    previewUrl: string | null;
    previewMimeType: string | null;
    speech: AssetSpeechMetadata | null;
    embeddedMetadata?: AssetEmbeddedMetadata | null;
    embeddingStatus?: AssetMetadataEmbeddingStatus | null;
    metadataUrl?: string | null;
    generatedAsset?: GeneratedAssetRef;
}
export interface VideoGeneration extends Generation {
    inputPrompt: string;
    durationSeconds: number | null;
    aspectRatio: string | null;
    resolution: string | null;
    videoUrl: string | null;
    videoMimeType: string | null;
    thumbnailUrl: string | null;
    embeddedMetadata?: AssetEmbeddedMetadata | null;
    embeddingStatus?: AssetMetadataEmbeddingStatus | null;
    metadataUrl?: string | null;
    generatedAsset?: GeneratedAssetRef;
}
export interface Model3DGeneration extends Generation {
    inputPrompt: string;
    sourceMode: 'TEXT' | 'IMAGE' | null;
    topology: 'triangle' | 'quad' | null;
    targetPolycount: number | null;
    shouldRemesh: boolean;
    shouldTexture: boolean;
    modelUrl: string | null;
    modelMimeType: string | null;
    thumbnailUrl: string | null;
    embeddedMetadata?: AssetEmbeddedMetadata | null;
    embeddingStatus?: AssetMetadataEmbeddingStatus | null;
    metadataUrl?: string | null;
    generatedAsset?: GeneratedAssetRef;
}
export type AiImageInput = string | {
    url: string;
} | {
    data: string;
    mimeType?: string;
};
export type AiAssetGenerationModality = 'IMAGE' | 'MUSIC' | 'SFX' | 'SPEECH' | 'VIDEO' | 'MODEL_3D';
export interface AiGenerationJob {
    id: string;
    modality: AiAssetGenerationModality;
    status: GenerationJobStatus;
    requestPrompt: string;
    requestPayload: unknown;
    resultData: unknown | null;
    errorCode: string | null;
    errorMessage: string | null;
    linkedGenerationId: string | null;
    createdAt: string;
    updatedAt: string;
    startedAt: string | null;
    completedAt: string | null;
    failedAt: string | null;
    progressPercent: number | null;
    etaSecondsRemaining: number | null;
}
export interface AiGenerationJobRequest {
    modality: AiAssetGenerationModality;
    inputPrompt: string;
    assetName?: string;
    assetDisplayName?: string;
    assetDescription?: string;
    assetVisibility?: 'PRIVATE' | 'PUBLIC';
    assetSubcategory?: string;
    attachAppVersionId?: number;
    remixAssetVersionRef?: string;
    suggestedTagRefs?: string[];
    image1?: AiImageInput | null;
    image2?: AiImageInput | null;
    durationMs?: number;
    forceInstrumental?: boolean;
    coverPrompt?: string;
    durationSeconds?: number;
    loop?: boolean;
    aspectRatio?: AiImageAspectRatio;
    imageSize?: AiImageSize;
    resolution?: '720p';
    speechVoice?: PlaydropSpeechVoiceId;
    speechProviderVoiceId?: string;
    sourceMode?: 'TEXT' | 'IMAGE';
    topology?: 'triangle' | 'quad';
    targetPolycount?: number;
    shouldRemesh?: boolean;
    shouldTexture?: boolean;
}
export interface AiAssetsAPI {
    createGenerationJob(request: AiGenerationJobRequest): Promise<AiGenerationJob>;
    getGenerationJob(id: string): Promise<AiGenerationJob>;
    listGenerationJobs(options?: {
        modality?: AiAssetGenerationModality;
        status?: GenerationJobStatus;
        limit?: number;
        offset?: number;
    }): Promise<AiGenerationJob[]>;
    deleteGenerationJob(id: string): Promise<void>;
}
export interface AiTextAPI {
    generate(inputPrompt: string, systemPrompt?: string | null, modelSize?: TextGenerationSize): Promise<TextGeneration>;
    generations(): Promise<TextGeneration[]>;
}
export interface AiJsonAPI {
    generate(inputPrompt: string, responseSchema?: unknown, systemPrompt?: string | null, modelSize?: TextGenerationSize): Promise<JSONGeneration>;
    generations(): Promise<JSONGeneration[]>;
}
export interface AiImageAPI {
    generations(): Promise<ImageGeneration[]>;
}
export interface AiMusicAPI {
    generations(): Promise<MusicGeneration[]>;
}
export interface AiSfxAPI {
    generations(): Promise<SfxGeneration[]>;
}
export interface AiSpeechAPI {
    generations(): Promise<SpeechGeneration[]>;
}
export interface AiVideoAPI {
    generations(): Promise<VideoGeneration[]>;
}
export interface AiModel3DAPI {
    generations(): Promise<Model3DGeneration[]>;
}
export interface AiAPI {
    text: AiTextAPI;
    json: AiJsonAPI;
    image: AiImageAPI;
    music: AiMusicAPI;
    sfx: AiSfxAPI;
    speech: AiSpeechAPI;
    video: AiVideoAPI;
    model3d: AiModel3DAPI;
    assets: AiAssetsAPI;
}
export interface PlaydropSDK {
    host: HostAPI;
    device: DeviceAPI;
    connection: ConnectionAPI;
    app: AppMetadata;
    libs: LibrariesAPI;
    assets: AssetsAPI;
    search: SearchAPI;
    me: MeAPI;
    rooms: RoomsAPI;
    debug: DebugAPI;
    shop: ShopAPI;
    ads: AdsAPI;
    achievements: AchievementsAPI;
    leaderboards: LeaderboardsAPI;
    ai: AiAPI;
}
