import type { BoxelDefinition, Node, TexturedBox, Material, Pattern, Texture } from '../../types';
import { createMaterialEnsurer } from '../../materials';
import type { HumanoidSourceScan, HumanoidPartKey } from './scanner';
import {
  FaceName,
  FaceTransform,
  PART_FACE_TRANSFORMS,
  getFaceDimensions,
} from './textures/face-map';
import { createFaceArtifacts } from './textures/artifacts';

export interface BuildHumanoidR6Options {
  template: BoxelDefinition;
  source: HumanoidSourceScan;
  geometryId: string;
  outputId: string;
  textureWidth: number;
  textureHeight: number;
  texturePixels: Uint8Array;
}

export function buildHumanoidR6Entity(options: BuildHumanoidR6Options): BoxelDefinition {
  const { template, source, outputId } = options;

  const entity = JSON.parse(JSON.stringify(template)) as BoxelDefinition;
  entity.id = outputId;
  entity.geometry.id = `${outputId}_geometry`;

  const textureScaleX = source.textureScaleX ?? 1;
  const textureScaleY = source.textureScaleY ?? 1;

  const nodesById = new Map<string, Node>();
  (function collect(node: Node) {
    nodesById.set(node.id, node);
    node.children.forEach((child: Node) => collect(child));
  })(entity.geometry.root);

  const primitives: TexturedBox[] = [];
  const materials: Material[] = [];
  const patterns: Pattern[] = [];
  const textures: Texture[] = [];

  const materialEnsurer = createMaterialEnsurer(materials, { prefix: 'humanoid_r6_mat' });
  const ensureMaterial = (color: { r: number; g: number; b: number; a: number }): string => materialEnsurer.ensure(color);

  const registerPrimitive = (nodeId: string, primitive: TexturedBox) => {
    const node = nodesById.get(nodeId);
    if (!node) {
      throw new Error(`Template node "${nodeId}" is missing`);
    }
    node.mesh = primitive.id;
    primitives.push(primitive);
  };

  const torsoNode = nodesById.get('torso');
  const torsoSource = source.parts.get('torso');
  const torsoWidth = Number(torsoSource?.base.cube.size?.[0] ?? torsoNode?.size?.[0] ?? 8);

  const partToNode: Record<HumanoidPartKey, string> = {
    torso: 'torso',
    head: 'head',
    arm_left: 'arm_left',
    arm_right: 'arm_right',
    leg_left: 'leg_left',
    leg_right: 'leg_right',
  };

  (Object.keys(partToNode) as HumanoidPartKey[]).forEach(partKey => {
    const part = source.parts.get(partKey);
    if (!part) {
      throw new Error(`Conversion source missing part "${partKey}"`);
    }

    const nodeId = partToNode[partKey];
    const node = nodesById.get(nodeId);
    if (!node) {
      throw new Error(`Template missing node "${nodeId}"`);
    }

    const sourceSizeRaw = part.base.cube.size ?? [0, 0, 0];
    const sourceSize = sourceSizeRaw.map(value => Number(value)) as [number, number, number];
    const hasSourceSize = sourceSize.every(value => Number.isFinite(value) && value > 0);
    const basePosition: [number, number, number] = [
      Number(node.position?.[0] ?? 0),
      Number(node.position?.[1] ?? 0),
      Number(node.position?.[2] ?? 0),
    ];

    let targetSize: [number, number, number];

    if (partKey === 'arm_left' || partKey === 'arm_right') {
      const sign = partKey === 'arm_right' ? -1 : 1;
      const [width, height, depth] = sourceSize;
      const length = height;
      const thicknessY = width;
      const thicknessZ = depth;
      targetSize = [length, thicknessY, thicknessZ];
      node.size = [...targetSize];
      node.center = [sign * (length / 2 - thicknessY / 2), 0, 0];
      node.position = [
        sign * (torsoWidth / 2 + thicknessY / 2),
        basePosition[1],
        basePosition[2],
      ];
    } else if (partKey === 'leg_left' || partKey === 'leg_right') {
      const [width, height, depth] = sourceSize;
      targetSize = [width, height, depth];
      node.size = [...targetSize];
      node.center = [0, -height / 2, 0];
      const pivotX = Number(part.base.bone.pivot?.[0]);
      const targetX = Number.isFinite(pivotX) ? pivotX : basePosition[0];
      node.position = [targetX, basePosition[1], basePosition[2]];
    } else {
      const templateSize = (node.size ?? sourceSize).map(value => Number(value)) as [number, number, number];
      targetSize = hasSourceSize ? sourceSize : templateSize;
      node.size = [...targetSize];
      if (Array.isArray(node.center)) {
        node.center = (node.center as number[]).map(value => Number(value)) as [number, number, number];
      }
      node.position = [...basePosition];
    }

    const faceTransforms = (PART_FACE_TRANSFORMS[partKey] ?? PART_FACE_TRANSFORMS.torso) as Record<
      FaceName,
      FaceTransform
    >;

    const primitive: TexturedBox = {
      id: `${nodeId}_primitive`,
      kind: 'textured_box',
      size: [...targetSize],
    };

    let primitiveNeedsCutout = false;

    (['up', 'down', 'north', 'south', 'east', 'west'] as FaceName[]).forEach(face => {
      const transform = faceTransforms[face] ?? PART_FACE_TRANSFORMS.torso[face];
      const expectedDimensions = getFaceDimensions(targetSize, face);
      const scaledExpected: [number, number] = [
        Math.max(1, Math.round(expectedDimensions[0] * textureScaleX)),
        Math.max(1, Math.round(expectedDimensions[1] * textureScaleY)),
      ];
      const baseArtifacts = createFaceArtifacts({
        baseId: `${nodeId}_${face}`,
        face,
        source: part.base,
        transform,
        expectedSize: scaledExpected,
        textureWidth: source.textureWidth,
        textureHeight: source.textureHeight,
        texturePixels: source.texturePixels,
        ensureMaterial,
      });
      if (!baseArtifacts.pattern || !baseArtifacts.texture) {
        throw new Error(`Base layer for "${nodeId}" face "${face}" produced no visible pixels`);
      }
      patterns.push(baseArtifacts.pattern);
      textures.push(baseArtifacts.texture);
      if (baseArtifacts.hasTransparency) {
        primitiveNeedsCutout = true;
      }
      switch (face) {
        case 'up':
          primitive.top = baseArtifacts.texture.id;
          break;
        case 'down':
          primitive.bottom = baseArtifacts.texture.id;
          break;
        case 'north':
          primitive.north = baseArtifacts.texture.id;
          break;
        case 'south':
          primitive.south = baseArtifacts.texture.id;
          break;
        case 'east':
          primitive.east = baseArtifacts.texture.id;
          break;
        case 'west':
          primitive.west = baseArtifacts.texture.id;
          break;
      }

      if (part.overlay) {
        const overlayArtifacts = createFaceArtifacts({
          baseId: `${nodeId}_${face}`,
          face,
          source: part.overlay,
          transform,
          expectedSize: scaledExpected,
          textureWidth: source.textureWidth,
          textureHeight: source.textureHeight,
          texturePixels: source.texturePixels,
          ensureMaterial,
          variant: 'overlay',
        });
        if (overlayArtifacts.pattern && overlayArtifacts.texture && overlayArtifacts.hasVisiblePixels) {
          patterns.push(overlayArtifacts.pattern);
          textures.push(overlayArtifacts.texture);
          switch (face) {
            case 'up':
              primitive.topOverlay = overlayArtifacts.texture.id;
              break;
            case 'down':
              primitive.bottomOverlay = overlayArtifacts.texture.id;
              break;
            case 'north':
              primitive.northOverlay = overlayArtifacts.texture.id;
              break;
            case 'south':
              primitive.southOverlay = overlayArtifacts.texture.id;
              break;
            case 'east':
              primitive.eastOverlay = overlayArtifacts.texture.id;
              break;
            case 'west':
              primitive.westOverlay = overlayArtifacts.texture.id;
              break;
          }
        }
      }
    });

    if (primitiveNeedsCutout) {
      primitive.renderMode = 'cutout';
    }

    registerPrimitive(nodeId, primitive);
  });

  entity.primitives = primitives;
  entity.materials = materials;
  entity.patterns = patterns;
  entity.textures = textures;

  return entity;
}
