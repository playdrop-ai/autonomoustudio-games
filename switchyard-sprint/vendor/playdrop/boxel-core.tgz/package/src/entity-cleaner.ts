import { cloneEntity } from './entity-utils';
import type {
  ComboBox,
  BoxelDefinition,
  Material,
  Pattern,
  Primitive,
  TexturedBox,
  Texture,
  VoxelBox,
} from './types';

type PrimitiveId = Primitive['id'];
type TextureId = Texture['id'];
type PatternId = Pattern['id'];
type MaterialId = Material['id'];

interface CleanEntityReport {
  primitives: string[];
  textures: string[];
  patterns: string[];
  materials: string[];
}

export interface CleanEntityResult {
  entity: BoxelDefinition;
  removed: CleanEntityReport;
}

const TEXTURE_FIELDS: Array<keyof TexturedBox> = [
  'top',
  'bottom',
  'north',
  'south',
  'east',
  'west',
  'sides',
  'all',
  'topOverlay',
  'bottomOverlay',
  'northOverlay',
  'southOverlay',
  'eastOverlay',
  'westOverlay',
  'sidesOverlay',
  'allOverlay',
];

const collectGeometryPrimitives = (entity: BoxelDefinition, target: Set<PrimitiveId>): void => {
  const visitNode = (node: BoxelDefinition['geometry']['root']): void => {
    if (!node) {
      return;
    }
    if (typeof node.mesh === 'string' && node.mesh.trim().length > 0) {
      target.add(node.mesh);
    }
    (node.children ?? []).forEach(visitNode);
  };

  if (entity.geometry?.root) {
    visitNode(entity.geometry.root);
  }
};

const collectComboPrimitiveRefs = (primitive: ComboBox, target: Set<PrimitiveId>): void => {
  primitive.slots?.forEach(slot => {
    if (slot?.primitive) {
      target.add(slot.primitive);
    }
  });
};

const collectPrimitiveResources = (
  primitive: Primitive,
  textures: Set<TextureId>,
  materials: Set<MaterialId>
): void => {
  switch (primitive.kind) {
    case 'plain_box':
      if (primitive.material) {
        materials.add(primitive.material);
      }
      break;
    case 'textured_box': {
      const box = primitive as TexturedBox;
      TEXTURE_FIELDS.forEach(field => {
        const textureId = box[field as keyof TexturedBox];
        if (typeof textureId === 'string') {
          textures.add(textureId);
        }
      });
      break;
    }
    case 'voxel_box':
      (primitive as VoxelBox).palette?.forEach(materialId => {
        if (typeof materialId === 'string') {
          materials.add(materialId);
        }
      });
      break;
    default:
      break;
  }
};

const expandPrimitiveGraph = (entity: BoxelDefinition, roots: Set<PrimitiveId>): Set<PrimitiveId> => {
  const primitives = new Map(entity.primitives.map(primitive => [primitive.id, primitive] as const));
  const queue: PrimitiveId[] = Array.from(roots);

  while (queue.length > 0) {
    const id = queue.pop();
    if (!id) {
      continue;
    }
    const primitive = primitives.get(id);
    if (!primitive) {
      continue;
    }
    if (primitive.kind === 'combo_box') {
      (primitive.slots ?? []).forEach(slot => {
        if (slot?.primitive && !roots.has(slot.primitive)) {
          roots.add(slot.primitive);
          queue.push(slot.primitive);
        }
      });
    }
  }

  return roots;
};

export function cleanEntity(entity: BoxelDefinition): CleanEntityResult {
  const clone = cloneEntity(entity);

  const usedPrimitiveIds = expandPrimitiveGraph(clone, (() => {
    const ids = new Set<PrimitiveId>();
    collectGeometryPrimitives(clone, ids);
    return ids;
  })());

  const usedTextureIds = new Set<TextureId>();
  const usedPatternIds = new Set<PatternId>();
  const usedMaterialIds = new Set<MaterialId>();

  const primitiveLookup = new Map(clone.primitives.map(primitive => [primitive.id, primitive] as const));
  const textureLookup = new Map(clone.textures.map(texture => [texture.id, texture] as const));

  usedPrimitiveIds.forEach(id => {
    const primitive = primitiveLookup.get(id);
    if (!primitive) {
      return;
    }
    collectPrimitiveResources(primitive, usedTextureIds, usedMaterialIds);
  });

  usedTextureIds.forEach(textureId => {
    const texture = textureLookup.get(textureId);
    if (!texture) {
      return;
    }
    if (typeof texture.pattern === 'string') {
      usedPatternIds.add(texture.pattern);
    }
    texture.materials?.forEach(materialId => {
      if (typeof materialId === 'string') {
        usedMaterialIds.add(materialId);
      }
    });
  });

  const originalPrimitives = clone.primitives.map(primitive => primitive.id);
  const originalTextures = clone.textures.map(texture => texture.id);
  const originalPatterns = clone.patterns.map(pattern => pattern.id);
  const originalMaterials = clone.materials.map(material => material.id);

  clone.primitives = clone.primitives.filter(primitive => usedPrimitiveIds.has(primitive.id));
  clone.textures = clone.textures.filter(texture => usedTextureIds.has(texture.id));
  clone.patterns = clone.patterns.filter(pattern => usedPatternIds.has(pattern.id));
  clone.materials = clone.materials.filter(material => usedMaterialIds.has(material.id));

  return {
    entity: clone,
    removed: {
      primitives: originalPrimitives.filter(id => !usedPrimitiveIds.has(id)),
      textures: originalTextures.filter(id => !usedTextureIds.has(id)),
      patterns: originalPatterns.filter(id => !usedPatternIds.has(id)),
      materials: originalMaterials.filter(id => !usedMaterialIds.has(id)),
    },
  };
}
