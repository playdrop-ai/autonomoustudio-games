# @playdrop/api-client

TypeScript fetch client for the Playdrop REST API with sensible defaults for tokens, headers, and host resolution.

## Responsibilities
- Exposes `createApiClient` plus convenience helpers (login, `fetchHome`, avatar/app CRUD, app logs, admin endpoints).
- Resolves the API base URL automatically from `window.location`, `NEXT_PUBLIC_API_BASE`, or an explicit config.
- Injects client/platform metadata headers expected by the API guard; runtime state is configurable via `configureWebClientRuntime`.
- Persists and reads bearer tokens from `localStorage` by default, but allows a custom `tokenProvider` and `fetchImpl` for SSR or CLI use.
- Normalises error handling, surfacing `UnsupportedClientError` when the server rejects outdated builds.

## Usage
```ts
import { createApiClient, login } from '@playdrop/api-client';

const client = createApiClient({
  baseUrl: 'http://localhost:4000',
  tokenProvider: () => process.env.ACCESS_TOKEN,
});

const { accessToken } = await login('playdrop', 'changeme');
const apps = await client.fetchApps();
```

## Environment
- Optional `NEXT_PUBLIC_API_BASE` to override host detection in browser environments.
- Default client headers use `configureWebClientRuntime` from this package (called by web/admin apps on boot).

## Implementation Notes
- Requests return `{ status, body, headers }` so callers can inspect metadata without reparsing responses.
- Upload helpers accept a `File` object and stream via `fetch` using multipart/form-data.
- Guard helpers (`attemptMe`, `fetchHome`, etc.) reuse a shared singleton client to avoid redundant configuration.
- Types are sourced from `@playdrop/types`, guaranteeing alignment with server payloads.

## Related Workspaces
- Used by the web, admin, and CLI workspaces; also underpins `@playdrop/assets-client`.
