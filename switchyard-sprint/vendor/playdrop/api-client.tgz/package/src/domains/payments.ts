import type {
  AssetPurchaseRequest,
  CreditPackCheckoutSessionResponse,
  CreditPackCheckoutStatusResponse,
  IapPurchaseRequest,
  IapPurchaseResponse,
  IapReceiptListParams,
  IapReceiptResponse,
  IapReceiptsResponse,
  PurchaseResponse,
  ShopResponse,
  TransactionsResponse,
} from '@playdrop/types';

type ApiResponseLike<T> = {
  status: number;
  body: T;
  headers: Headers;
};

type RequestExecutor = <T>(input: {
  method: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
  path: string;
  body?: unknown;
  headers?: Record<string, string>;
  signal?: AbortSignal;
}) => Promise<ApiResponseLike<T>>;

type ErrorHandler = (response: ApiResponseLike<unknown>, defaultMessage: string) => never;

export function buildPaymentsApiClientMethods(input: {
  request: RequestExecutor;
  handleApiError: ErrorHandler;
  buildIapQuery: (params?: IapReceiptListParams) => string | null;
}) {
  const { request, handleApiError, buildIapQuery } = input;

  return {
    async fetchCreditShop(): Promise<ShopResponse> {
      const response = await request<ShopResponse>({
        method: 'GET',
        path: '/shop',
      });
      if (response.status !== 200) {
        handleApiError(response, 'fetch_shop');
      }
      return response.body;
    },

    async createCreditPackCheckoutSession(sku: string): Promise<CreditPackCheckoutSessionResponse> {
      const normalizedSku = sku.trim();
      if (!normalizedSku) {
        throw new Error('invalid_credit_pack_sku');
      }
      const response = await request<CreditPackCheckoutSessionResponse>({
        method: 'POST',
        path: `/shop/credit-packs/${encodeURIComponent(normalizedSku)}/checkout-session`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'create_credit_pack_checkout_session');
      }
      return response.body;
    },

    async fetchCreditPackCheckoutStatus(sessionId: string): Promise<CreditPackCheckoutStatusResponse> {
      const normalizedSessionId = sessionId.trim();
      if (!normalizedSessionId) {
        throw new Error('invalid_checkout_session_id');
      }
      const response = await request<CreditPackCheckoutStatusResponse>({
        method: 'GET',
        path: `/shop/credit-packs/checkout-session/${encodeURIComponent(normalizedSessionId)}`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'fetch_credit_pack_checkout_status');
      }
      return response.body;
    },

    async purchaseAsset(body: AssetPurchaseRequest): Promise<PurchaseResponse> {
      const response = await request<PurchaseResponse>({
        method: 'POST',
        path: '/purchase',
        body,
      });
      if (response.status !== 200) {
        handleApiError(response, 'purchase_asset');
      }
      return response.body;
    },

    async purchaseIap(body: IapPurchaseRequest): Promise<IapPurchaseResponse> {
      const response = await request<IapPurchaseResponse>({
        method: 'POST',
        path: '/iap/purchase',
        body,
      });
      if (response.status !== 200) {
        handleApiError(response, 'purchase_iap');
      }
      return response.body;
    },

    async fetchIapReceipts(params?: IapReceiptListParams): Promise<IapReceiptsResponse> {
      const query = buildIapQuery(params);
      const path = query ? `/iap/receipts?${query}` : '/iap/receipts';
      const response = await request<IapReceiptsResponse>({
        method: 'GET',
        path,
      });
      if (response.status !== 200) {
        handleApiError(response, 'fetch_iap_receipts');
      }
      return response.body;
    },

    async cancelIapReceipt(receiptId: number): Promise<IapReceiptResponse> {
      const response = await request<IapReceiptResponse>({
        method: 'POST',
        path: `/iap/receipts/${encodeURIComponent(String(receiptId))}/cancel`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'cancel_iap_receipt');
      }
      return response.body;
    },

    async fetchAppIapReceipts(params?: Omit<IapReceiptListParams, 'appId'>): Promise<IapReceiptsResponse> {
      const query = buildIapQuery(params as IapReceiptListParams | undefined);
      const path = query ? `/app/iap/receipts?${query}` : '/app/iap/receipts';
      const response = await request<IapReceiptsResponse>({
        method: 'GET',
        path,
      });
      if (response.status !== 200) {
        handleApiError(response, 'fetch_app_iap_receipts');
      }
      return response.body;
    },

    async consumeAppIapReceipt(receiptId: number): Promise<IapReceiptResponse> {
      const response = await request<IapReceiptResponse>({
        method: 'POST',
        path: `/app/iap/receipts/${encodeURIComponent(String(receiptId))}/consume`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'consume_app_iap_receipt');
      }
      return response.body;
    },

    async grantAppIapReceipt(receiptId: number): Promise<IapReceiptResponse> {
      const response = await request<IapReceiptResponse>({
        method: 'POST',
        path: `/app/iap/receipts/${encodeURIComponent(String(receiptId))}/grant`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'grant_app_iap_receipt');
      }
      return response.body;
    },

    async cancelAppIapReceipt(receiptId: number): Promise<IapReceiptResponse> {
      const response = await request<IapReceiptResponse>({
        method: 'POST',
        path: `/app/iap/receipts/${encodeURIComponent(String(receiptId))}/cancel`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'cancel_app_iap_receipt');
      }
      return response.body;
    },

    async fetchCreditTransactions(options?: { limit?: number; offset?: number }): Promise<TransactionsResponse> {
      const params = new URLSearchParams();
      if (options?.limit !== undefined) {
        params.set('limit', String(options.limit));
      }
      if (options?.offset !== undefined) {
        params.set('offset', String(options.offset));
      }
      const query = params.toString();
      const path = query ? `/transactions?${query}` : '/transactions';
      const response = await request<TransactionsResponse>({
        method: 'GET',
        path,
      });
      if (response.status !== 200) {
        handleApiError(response, 'fetch_credit_transactions');
      }
      return response.body;
    },
  };
}
