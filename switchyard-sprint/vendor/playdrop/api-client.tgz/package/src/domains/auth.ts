import type {
  CompleteGoogleSignupRequest,
  CompleteGoogleSignupResponse,
  GooglePendingSignupResponse,
  LoginRequest,
  LoginResponse,
  RegisterRequest,
  RegisterResponse,
  UnlinkGoogleResponse,
  UnlinkXResponse,
  UsernameAvailableResponse,
} from '@playdrop/types';

type ApiResponseLike<T> = {
  status: number;
  body: T;
  headers: Headers;
};

type RequestExecutor = <T>(input: {
  method: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
  path: string;
  body?: unknown;
  headers?: Record<string, string>;
  signal?: AbortSignal;
}) => Promise<ApiResponseLike<T>>;

type ErrorHandler = (response: ApiResponseLike<unknown>, defaultMessage: string) => never;

export function buildAuthApiClientMethods(input: {
  request: RequestExecutor;
  handleApiError: ErrorHandler;
}) {
  const { request, handleApiError } = input;

  return {
    async login(loginRequest: LoginRequest): Promise<LoginResponse> {
      const response = await request<LoginResponse>({
        method: 'POST',
        path: '/auth/login',
        body: loginRequest,
      });

      if (response.status !== 200) {
        handleApiError(response, 'login');
      }

      return response.body;
    },

    async register(registerRequest: RegisterRequest): Promise<RegisterResponse> {
      const response = await request<RegisterResponse>({
        method: 'POST',
        path: '/auth/register',
        body: registerRequest,
      });

      if (response.status !== 201) {
        handleApiError(response, 'register');
      }

      return response.body;
    },

    async unlinkX(): Promise<UnlinkXResponse> {
      const response = await request<UnlinkXResponse>({
        method: 'POST',
        path: '/auth/x/unlink',
      });

      if (response.status !== 200) {
        handleApiError(response, 'unlink_x');
      }

      return response.body;
    },

    async unlinkGoogle(): Promise<UnlinkGoogleResponse> {
      const response = await request<UnlinkGoogleResponse>({
        method: 'POST',
        path: '/auth/google/unlink',
      });

      if (response.status !== 200) {
        handleApiError(response, 'unlink_google');
      }

      return response.body;
    },

    async fetchGooglePendingSignup(token: string): Promise<GooglePendingSignupResponse> {
      const response = await request<GooglePendingSignupResponse>({
        method: 'GET',
        path: `/auth/google/pending/${encodeURIComponent(token)}`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'fetch_google_pending_signup');
      }

      return response.body;
    },

    async checkUsernameAvailable(username: string): Promise<UsernameAvailableResponse> {
      const response = await request<UsernameAvailableResponse>({
        method: 'GET',
        path: `/auth/username-available/${encodeURIComponent(username)}`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'check_username_available');
      }

      return response.body;
    },

    async completeGoogleSignup(signupRequest: CompleteGoogleSignupRequest): Promise<CompleteGoogleSignupResponse> {
      const response = await request<CompleteGoogleSignupResponse>({
        method: 'POST',
        path: '/auth/google/complete-signup',
        body: signupRequest,
      });

      if (response.status !== 201) {
        handleApiError(response, 'complete_google_signup');
      }

      return response.body;
    },
  };
}
