import type {
  AssetCategory,
  AssetPackDetailResponse,
  AssetPackListResponse,
  AssetPackSourceBundleResponse,
  AssetPackVersionsListResponse,
  ContentRemixRelationsResponse,
  CreateAssetPackVersionRequest,
  CreateAssetPackVersionResponse,
  DeleteAssetPackResponse,
  DeleteAssetPackVersionResponse,
  UpdateAssetPackRequest,
  UpdateAssetPackResponse,
  UpdateAssetPackVersionRequest,
  UpdateAssetPackVersionResponse,
} from '@playdrop/types';
import type { UploadAssetPackVersionOptions } from '../client.js';

type ApiResponseLike<T> = {
  status: number;
  body: T;
  headers: Headers;
};

type RequestExecutor = <T>(input: {
  method: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
  path: string;
  body?: unknown;
  headers?: Record<string, string>;
  signal?: AbortSignal;
}) => Promise<ApiResponseLike<T>>;

type ErrorHandler = (response: ApiResponseLike<unknown>, defaultMessage: string) => never;

type ParseResponseBody = <T>(response: Response) => Promise<T>;

export function buildAssetPacksApiClientMethods(input: {
  request: RequestExecutor;
  handleApiError: ErrorHandler;
  fetchImpl: typeof fetch;
  resolveBaseUrl: () => string;
  resolveUrl: (base: string, path: string) => string;
  parseResponseBody: ParseResponseBody;
  resolveToken: () => Promise<string | null>;
  getClientHeaders: () => Record<string, string>;
  buildCreatorAssetPackMutationPath: (creatorUsername: string, packName?: string, suffix?: string) => string;
  normalizeCreatorItemSlug: (value: string, field: 'creator' | 'name') => string;
  normalizeSemverInput: (version: string) => string;
  parseContentDispositionFilename: (headerValue: string | null) => string | null;
}) {
  const {
    request,
    handleApiError,
    fetchImpl,
    resolveBaseUrl,
    resolveUrl,
    parseResponseBody,
    resolveToken,
    getClientHeaders,
    buildCreatorAssetPackMutationPath,
    normalizeCreatorItemSlug,
    normalizeSemverInput,
    parseContentDispositionFilename,
  } = input;

  function buildPublicAssetPackPath(creatorUsername: string, packName: string, suffix = '') {
    const creator = normalizeCreatorItemSlug(creatorUsername, 'creator');
    const name = normalizeCreatorItemSlug(packName, 'name');
    return `/asset-packs/${encodeURIComponent(creator)}/${encodeURIComponent(name)}${suffix}`;
  }

  return {
    async createAssetPackVersion(
      creatorUsername: string,
      name: string,
      body: CreateAssetPackVersionRequest,
    ): Promise<CreateAssetPackVersionResponse> {
      const packName = typeof name === 'string' ? name.trim() : '';
      if (!packName) {
        throw new Error('invalid_pack_name');
      }
      const response = await request<CreateAssetPackVersionResponse>({
        method: 'POST',
        path: `${buildCreatorAssetPackMutationPath(creatorUsername, packName)}/versions`,
        body,
      });
      if (response.status !== 201 && response.status !== 200) {
        handleApiError(response, 'create_asset_pack_version');
      }
      return response.body;
    },

    async uploadAssetPackVersion(
      creatorUsername: string,
      name: string,
      options: UploadAssetPackVersionOptions,
    ): Promise<CreateAssetPackVersionResponse> {
      const packName = typeof name === 'string' ? name.trim() : '';
      if (!packName) {
        throw new Error('invalid_pack_name');
      }
      if (!options || !options.request) {
        throw new Error('invalid_pack_upload_request');
      }

      const requestBody = options.request;
      const form = new FormData();
      form.append('version', requestBody.version);
      if (requestBody.visibility !== undefined) {
        form.append('visibility', requestBody.visibility);
      }
      if (requestBody.hostingMode !== undefined) {
        form.append('hostingMode', requestBody.hostingMode);
      }
      if (requestBody.externalUrl !== undefined) {
        form.append('externalUrl', requestBody.externalUrl);
      }
      if (requestBody.downloadUrl !== undefined) {
        form.append('downloadUrl', requestBody.downloadUrl);
      }
      if (requestBody.releaseNotes !== undefined) {
        form.append('releaseNotes', requestBody.releaseNotes);
      }
      if (requestBody.displayName !== undefined) {
        form.append('displayName', requestBody.displayName);
      }
      if (requestBody.description !== undefined) {
        form.append('description', requestBody.description);
      }
      if (requestBody.previewAppVersionId !== undefined) {
        form.append('previewAppVersionId', String(requestBody.previewAppVersionId));
      }
      if (requestBody.remixRef !== undefined) {
        form.append('remixRef', requestBody.remixRef);
      }
      form.append('assets', JSON.stringify(requestBody.assets ?? []));
      const relations = (requestBody as any).relations;
      if (Array.isArray(relations) && relations.length > 0) {
        form.append('relations', JSON.stringify(relations));
      }

      if (options.icon) {
        form.append('icon', options.icon);
      }
      if (options.heroPortrait) {
        form.append('heroPortrait', options.heroPortrait);
      }
      if (options.heroLandscape) {
        form.append('heroLandscape', options.heroLandscape);
      }
      if (options.screenshotsPortrait) {
        for (const screenshot of options.screenshotsPortrait) {
          form.append('screenshotsPortrait', screenshot);
        }
      }
      if (options.screenshotsLandscape) {
        for (const screenshot of options.screenshotsLandscape) {
          form.append('screenshotsLandscape', screenshot);
        }
      }
      if (options.videosPortrait) {
        for (const video of options.videosPortrait) {
          form.append('videosPortrait', video);
        }
      }
      if (options.videosLandscape) {
        for (const video of options.videosLandscape) {
          form.append('videosLandscape', video);
        }
      }

      const path = `${buildCreatorAssetPackMutationPath(creatorUsername, packName)}/versions`;
      const base = resolveBaseUrl();
      const headers = new Headers();
      for (const [key, value] of Object.entries(getClientHeaders())) {
        headers.set(key, value);
      }
      const token = await resolveToken();
      if (token) {
        headers.set('authorization', `Bearer ${token}`);
      }

      const response = await fetchImpl(resolveUrl(base, path), {
        method: 'POST',
        headers,
        body: form,
      });
      const parsed = await parseResponseBody<CreateAssetPackVersionResponse>(response);
      const apiResponse = { status: response.status, body: parsed, headers: response.headers };
      if (response.status !== 201 && response.status !== 200) {
        handleApiError(apiResponse, 'upload_asset_pack_version');
      }
      return parsed;
    },

    async fetchAssetPackRelated(
      creatorUsername: string,
      packName: string,
    ): Promise<ContentRemixRelationsResponse> {
      const response = await request<ContentRemixRelationsResponse>({
        method: 'GET',
        path: buildPublicAssetPackPath(creatorUsername, packName, '/related'),
      });
      if (response.status !== 200) {
        handleApiError(response, 'get_pack_related');
      }
      return response.body;
    },

    async listAssetPacks(
      options: { limit?: number; offset?: number; containsCategory?: AssetCategory; containsSubcategory?: string } = {},
    ): Promise<AssetPackListResponse> {
      const params = new URLSearchParams();
      if (typeof options.limit === 'number') {
        params.set('limit', String(options.limit));
      }
      if (typeof options.offset === 'number') {
        params.set('offset', String(options.offset));
      }
      if (typeof options.containsCategory === 'string' && options.containsCategory.trim().length > 0) {
        params.set('containsCategory', options.containsCategory.trim());
      }
      if (typeof options.containsSubcategory === 'string' && options.containsSubcategory.trim().length > 0) {
        params.set('containsSubcategory', options.containsSubcategory.trim());
      }
      const query = params.toString();
      const path = `/asset-packs${query ? `?${query}` : ''}`;
      const response = await request<AssetPackListResponse>({
        method: 'GET',
        path,
      });
      if (response.status !== 200) {
        handleApiError(response, 'list_asset_packs');
      }
      return response.body;
    },

    async listAssetPacksForCreator(
      creatorUsername: string,
      options: { limit?: number; offset?: number; containsCategory?: AssetCategory; containsSubcategory?: string } = {},
    ): Promise<AssetPackListResponse> {
      const params = new URLSearchParams();
      if (typeof options.limit === 'number') {
        params.set('limit', String(options.limit));
      }
      if (typeof options.offset === 'number') {
        params.set('offset', String(options.offset));
      }
      if (typeof options.containsCategory === 'string' && options.containsCategory.trim().length > 0) {
        params.set('containsCategory', options.containsCategory.trim());
      }
      if (typeof options.containsSubcategory === 'string' && options.containsSubcategory.trim().length > 0) {
        params.set('containsSubcategory', options.containsSubcategory.trim());
      }
      const query = params.toString();
      const path = `/creators/${encodeURIComponent(creatorUsername)}/asset-packs${query ? `?${query}` : ''}`;
      const response = await request<AssetPackListResponse>({
        method: 'GET',
        path,
      });
      if (response.status !== 200) {
        handleApiError(response, 'list_asset_packs_for_creator');
      }
      return response.body;
    },

    async fetchAssetPackBySlug(creatorUsername: string, packName: string): Promise<AssetPackDetailResponse> {
      const path = `/asset-packs/${encodeURIComponent(creatorUsername)}/${encodeURIComponent(packName)}`;
      const response = await request<AssetPackDetailResponse>({
        method: 'GET',
        path,
      });
      if (response.status !== 200) {
        handleApiError(response, 'fetch_asset_pack_by_slug');
      }
      return response.body;
    },

    async downloadAssetPackSource(
      creatorUsername: string,
      packName: string,
      version: string,
    ): Promise<{ blob: Blob; metadata: AssetPackSourceBundleResponse }> {
      const creator = typeof creatorUsername === 'string' ? creatorUsername.trim() : '';
      const name = typeof packName === 'string' ? packName.trim() : '';
      if (!creator || !name) {
        throw new Error('invalid_pack_key');
      }
      const normalizedVersion = normalizeSemverInput(version);
      const path = `/asset-packs/${encodeURIComponent(creator)}/${encodeURIComponent(name)}/versions/${encodeURIComponent(normalizedVersion)}/source`;
      const base = resolveBaseUrl();
      const headers = new Headers();
      for (const [key, value] of Object.entries(getClientHeaders())) {
        headers.set(key, value);
      }
      const token = await resolveToken();
      if (token) {
        headers.set('authorization', `Bearer ${token}`);
      }
      const response = await fetchImpl(resolveUrl(base, path), {
        method: 'GET',
        headers,
      });
      if (!response.ok) {
        const parsed = await parseResponseBody<any>(response);
        handleApiError({ status: response.status, body: parsed, headers: response.headers }, 'download_asset_pack_source');
      }

      const blob = await response.blob();
      const filename = parseContentDispositionFilename(response.headers.get('content-disposition'))
        ?? `${name}-${normalizedVersion}-source.zip`;
      const headerSize = response.headers.get('content-length');
      const parsedSize = headerSize ? Number.parseInt(headerSize, 10) : Number.NaN;
      const checksumHeader = response.headers.get('x-pack-source-checksum');
      return {
        blob,
        metadata: {
          filename,
          sizeBytes: Number.isFinite(parsedSize) && parsedSize >= 0 ? parsedSize : blob.size,
          checksum: checksumHeader ?? null,
        },
      };
    },

    async listAssetPackVersions(
      creatorUsername: string,
      packName: string,
      options: { limit?: number; offset?: number } = {},
    ): Promise<AssetPackVersionsListResponse> {
      const params = new URLSearchParams();
      if (typeof options.limit === 'number') {
        params.set('limit', String(options.limit));
      }
      if (typeof options.offset === 'number') {
        params.set('offset', String(options.offset));
      }
      const query = params.toString();
      const path = `/asset-packs/${encodeURIComponent(creatorUsername)}/${encodeURIComponent(packName)}/versions${query ? `?${query}` : ''}`;
      const response = await request<AssetPackVersionsListResponse>({
        method: 'GET',
        path,
      });
      if (response.status !== 200) {
        handleApiError(response, 'list_asset_pack_versions');
      }
      return response.body;
    },

    async updateAssetPack(
      creatorUsername: string,
      name: string,
      requestBody: UpdateAssetPackRequest,
    ): Promise<UpdateAssetPackResponse> {
      const packName = typeof name === 'string' ? name.trim() : '';
      if (!packName) {
        throw new Error('invalid_pack_name');
      }
      const response = await request<UpdateAssetPackResponse>({
        method: 'PATCH',
        path: buildCreatorAssetPackMutationPath(creatorUsername, packName),
        body: requestBody,
      });
      if (response.status !== 200) {
        handleApiError(response, 'update_asset_pack');
      }
      return response.body;
    },

    async updateAssetPackVersion(
      creatorUsername: string,
      name: string,
      version: string,
      requestBody: UpdateAssetPackVersionRequest,
    ): Promise<UpdateAssetPackVersionResponse> {
      const packName = typeof name === 'string' ? name.trim() : '';
      const versionValue = typeof version === 'string' ? version.trim() : '';
      if (!packName) {
        throw new Error('invalid_pack_name');
      }
      if (!versionValue) {
        throw new Error('invalid_pack_version');
      }
      const response = await request<UpdateAssetPackVersionResponse>({
        method: 'PATCH',
        path: `${buildCreatorAssetPackMutationPath(creatorUsername, packName)}/versions/${encodeURIComponent(versionValue)}`,
        body: requestBody,
      });
      if (response.status !== 200) {
        handleApiError(response, 'update_asset_pack_version');
      }
      return response.body;
    },

    async deleteAssetPackVersion(
      creatorUsername: string,
      name: string,
      version: string,
    ): Promise<DeleteAssetPackVersionResponse> {
      const packName = typeof name === 'string' ? name.trim() : '';
      const versionValue = typeof version === 'string' ? version.trim() : '';
      if (!packName) {
        throw new Error('invalid_pack_name');
      }
      if (!versionValue) {
        throw new Error('invalid_pack_version');
      }
      const response = await request<DeleteAssetPackVersionResponse>({
        method: 'DELETE',
        path: `${buildCreatorAssetPackMutationPath(creatorUsername, packName)}/versions/${encodeURIComponent(versionValue)}`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'delete_asset_pack_version');
      }
      return response.body;
    },

    async deleteAssetPack(
      creatorUsername: string,
      name: string,
    ): Promise<DeleteAssetPackResponse> {
      const packName = typeof name === 'string' ? name.trim() : '';
      if (!packName) {
        throw new Error('invalid_pack_name');
      }
      const response = await request<DeleteAssetPackResponse>({
        method: 'DELETE',
        path: buildCreatorAssetPackMutationPath(creatorUsername, packName),
      });
      if (response.status !== 200) {
        handleApiError(response, 'delete_asset_pack');
      }
      return response.body;
    },
  };
}
