import type {
  BootstrapResponse,
  MyAppsResponse,
  TemplateScaffoldResponse,
} from '@playdrop/types';

type ApiResponseLike<T> = {
  status: number;
  body: T;
  headers: Headers;
};

type RequestExecutor = <T>(input: {
  method: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
  path: string;
  body?: unknown;
  headers?: Record<string, string>;
  signal?: AbortSignal;
}) => Promise<ApiResponseLike<T>>;

type ErrorHandler = (response: ApiResponseLike<unknown>, defaultMessage: string) => never;

export function buildMeApiClientMethods(input: {
  request: RequestExecutor;
  handleApiError: ErrorHandler;
}) {
  const { request, handleApiError } = input;

  return {
    async fetchMyApps(): Promise<MyAppsResponse> {
      const response = await request<MyAppsResponse>({
        method: 'GET',
        path: '/me/apps',
      });
      if (response.status !== 200) {
        handleApiError(response, 'fetch_my_apps');
      }
      return response.body;
    },

    async fetchBootstrap(): Promise<BootstrapResponse> {
      const response = await request<BootstrapResponse>({
        method: 'GET',
        path: '/me/bootstrap',
      });
      if (response.status !== 200) {
        handleApiError(response, 'fetch_bootstrap');
      }
      return response.body;
    },

    async fetchTemplateScaffold(namespace: string, slug: string): Promise<TemplateScaffoldResponse> {
      const response = await request<TemplateScaffoldResponse>({
        method: 'GET',
        path: `/me/templates/${encodeURIComponent(namespace)}/${encodeURIComponent(slug)}`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'fetch_template_scaffold');
      }
      return response.body;
    },
  };
}
