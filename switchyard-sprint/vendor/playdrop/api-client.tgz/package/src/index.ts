export { createApiClient } from './client.js';
export type {
  ApiClient,
  ApiClientConfig,
  ApiRequest,
  ApiResponse,
  UploadAppVersionOptions,
  UploadAssetPackVersionOptions,
  UploadAssetVersionOptions,
} from './client.js';

import { createApiClient } from './client.js';
import type { ApiClient } from './client.js';
import { ApiError, UnsupportedClientError } from '@playdrop/types';
import type {
  AppDetailResponse,
  AppLogEntryRequest,
  AppVersionVisibility,
  AssetCategory,
  CompleteGoogleSignupRequest,
  CreateAppRequest,
  CreatorFollowMutationResponse,
  LikedItemMutationResponse,
  IapPurchaseRequest,
  IapReceiptListParams,
  LibraryCategory,
  LibrarySort,
  TrackEngagementEventRequest,
  TrackEngagementEventResponse,
  NotificationStatus,
  UpsertWebPushSubscriptionRequest,
  SearchRequest,
  SearchSuggestRequest,
  SavedItemKind,
  SetProfileAssetRequest,
  UpdateAppRequest,
  UpdateProfileRequest,
  ChangePasswordRequest,
  CreateContentCommentRequest,
} from '@playdrop/types';

const CLIENT_HEADER_NAMES = {
  client: 'x-playdrop-client',
  clientVersion: 'x-playdrop-client-version',
  clientBuild: 'x-playdrop-client-build',
  platform: 'x-playdrop-platform',
  platformVersion: 'x-playdrop-platform-version',
} as const;

const ENGAGEMENT_HEADER_NAMES = {
  anonymousId: 'x-playdrop-anon-id',
  sessionId: 'x-playdrop-session-id',
} as const;

let defaultClient: ApiClient | null = null;

type PlatformInfo = {
  name: string;
  version: string;
};

type ClientInfo = {
  version: string;
  build: string;
};

const runtimeState: {
  platform: PlatformInfo | null;
  client: ClientInfo | null;
} = {
  platform: null,
  client: null,
};

const WEB_ANONYMOUS_ID_STORAGE_KEY = 'playdrop.anonymousId';
const WEB_SESSION_ID_STORAGE_KEY = 'playdrop.sessionId';

function generateUuid(): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID();
  }
  return `${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function readOrCreateStorageValue(storage: Storage, key: string): string {
  const existing = storage.getItem(key)?.trim();
  if (existing) {
    return existing;
  }
  const generated = generateUuid();
  storage.setItem(key, generated);
  return generated;
}

function getBrowserEngagementHeaders(): Record<string, string> {
  if (typeof window === 'undefined') {
    return {};
  }
  const anonymousId = readOrCreateStorageValue(window.localStorage, WEB_ANONYMOUS_ID_STORAGE_KEY);
  const sessionId = readOrCreateStorageValue(window.sessionStorage, WEB_SESSION_ID_STORAGE_KEY);
  return {
    [ENGAGEMENT_HEADER_NAMES.anonymousId]: anonymousId,
    [ENGAGEMENT_HEADER_NAMES.sessionId]: sessionId,
  };
}

function getDefaultClient(): ApiClient {
  if (!defaultClient) {
    defaultClient = createApiClient({
      clientHeaders: (): Record<string, string> => {
        const state = getRuntimeState();
        if (!state.platform || !state.client) {
          return {};
        }

        return {
          [CLIENT_HEADER_NAMES.client]: 'web',
          [CLIENT_HEADER_NAMES.clientVersion]: state.client.version,
          [CLIENT_HEADER_NAMES.clientBuild]: state.client.build,
          [CLIENT_HEADER_NAMES.platform]: state.platform.name,
          [CLIENT_HEADER_NAMES.platformVersion]: state.platform.version,
          ...getBrowserEngagementHeaders(),
        };
      },
    });
  }
  return defaultClient;
}

export async function apiFetch(path: string, init: RequestInit = {}) {
  const state = getRuntimeState();
  if (!state.platform || !state.client) {
    throw new Error(
      'apiFetch called before client runtime was configured. Call ensureWebClientRuntimeConfigured() or use createApiClient().',
    );
  }

  const clientHeaders: Record<string, string> = {
    [CLIENT_HEADER_NAMES.client]: 'web',
    [CLIENT_HEADER_NAMES.clientVersion]: state.client.version,
    [CLIENT_HEADER_NAMES.clientBuild]: state.client.build,
    [CLIENT_HEADER_NAMES.platform]: state.platform.name,
    [CLIENT_HEADER_NAMES.platformVersion]: state.platform.version,
    ...getBrowserEngagementHeaders(),
  };

  const authHeader: Record<string, string> = {};
  if (typeof window !== 'undefined') {
    const token = window.localStorage.getItem('playdrop.accessToken');
    if (token) {
      authHeader.Authorization = `Bearer ${token}`;
    }
  }

  return await fetch(path, {
    ...init,
    headers: {
      'Content-Type': 'application/json',
      ...clientHeaders,
      ...authHeader,
      ...init.headers,
    },
  });
}

export async function attemptMe() {
  try {
    const client = getDefaultClient();
    return await client.me();
  } catch (error) {
    if (error instanceof UnsupportedClientError) {
      throw error;
    }
    if (error instanceof ApiError) {
      if (error.status === 401) {
        return null;
      }
      throw error;
    }
    throw error instanceof Error ? error : new Error(String(error));
  }
}

export async function login(username: string, password: string) {
  return await getDefaultClient().login({ username, password });
}

export async function register(username: string, password: string) {
  return await getDefaultClient().register({ username, password });
}

export async function updateProfile(request: UpdateProfileRequest) {
  return await getDefaultClient().updateProfile(request);
}

export async function changePassword(newPassword: string, currentPassword?: string) {
  const request: ChangePasswordRequest = { newPassword, currentPassword };
  return await getDefaultClient().changePassword(request);
}

export async function upgradeToCreator() {
  return await getDefaultClient().upgradeToCreator();
}

export async function unlinkX() {
  return await getDefaultClient().unlinkX();
}

export async function unlinkGoogle() {
  return await getDefaultClient().unlinkGoogle();
}

export async function fetchGooglePendingSignup(token: string) {
  return await getDefaultClient().fetchGooglePendingSignup(token);
}

export async function checkUsernameAvailable(username: string) {
  return await getDefaultClient().checkUsernameAvailable(username);
}

export async function completeGoogleSignup(request: CompleteGoogleSignupRequest) {
  return await getDefaultClient().completeGoogleSignup(request);
}

export async function fetchApps() {
  const response = await getDefaultClient().fetchApps();
  return response.apps;
}

export async function fetchAppsByType(type: import('@playdrop/types').AppType, options: { limit?: number } = {}) {
  const response = await getDefaultClient().fetchAppsByType(type, options);
  return response.apps;
}

export async function fetchAppsByCreator(creatorUsername: string, options: { limit?: number } = {}) {
  const response = await getDefaultClient().fetchAppsByCreator(creatorUsername, options);
  return response.apps;
}

export async function fetchMyApps() {
  const response = await getDefaultClient().fetchMyApps();
  return response.apps;
}

export async function fetchUserById(userId: number) {
  const response = await getDefaultClient().fetchUserById(userId);
  return response.user;
}

export async function fetchUserByUsername(username: string) {
  const response = await getDefaultClient().fetchUserByUsername(username);
  return response.user;
}

export async function fetchAppBySlug(creatorUsername: string, appName: string) {
  const response = await getDefaultClient().fetchAppBySlug(creatorUsername, appName);
  return response.app;
}

export async function fetchAppRelated(creatorUsername: string, appName: string) {
  return await getDefaultClient().fetchAppRelated(creatorUsername, appName);
}

export async function requestAppAccessToken(appId: number) {
  return await getDefaultClient().requestAppAccessToken(appId);
}

export async function sendAppLog(appId: number, entry: AppLogEntryRequest) {
  return await getDefaultClient().sendAppLog(appId, entry);
}

export async function fetchOwnedProfileAssets() {
  const response = await getDefaultClient().fetchOwnedProfileAssets();
  return response.assets;
}

export async function saveItem(kind: SavedItemKind, creatorUsername: string, itemName: string) {
  return await getDefaultClient().saveItem(kind, creatorUsername, itemName);
}

export async function unsaveItem(kind: SavedItemKind, creatorUsername: string, itemName: string) {
  return await getDefaultClient().unsaveItem(kind, creatorUsername, itemName);
}

export async function likeItem(kind: SavedItemKind, creatorUsername: string, itemName: string): Promise<LikedItemMutationResponse> {
  return await getDefaultClient().likeItem(kind, creatorUsername, itemName);
}

export async function unlikeItem(kind: SavedItemKind, creatorUsername: string, itemName: string): Promise<LikedItemMutationResponse> {
  return await getDefaultClient().unlikeItem(kind, creatorUsername, itemName);
}

export async function fetchContentComments(kind: SavedItemKind, creatorUsername: string, itemName: string) {
  return await getDefaultClient().fetchContentComments(kind, creatorUsername, itemName);
}

export async function createContentComment(
  kind: SavedItemKind,
  creatorUsername: string,
  itemName: string,
  request: CreateContentCommentRequest,
) {
  return await getDefaultClient().createContentComment(kind, creatorUsername, itemName, request);
}

export async function likeContentComment(commentId: number): Promise<LikedItemMutationResponse> {
  return await getDefaultClient().likeContentComment(commentId);
}

export async function unlikeContentComment(commentId: number): Promise<LikedItemMutationResponse> {
  return await getDefaultClient().unlikeContentComment(commentId);
}

export async function deleteContentComment(commentId: number) {
  return await getDefaultClient().deleteContentComment(commentId);
}

export async function trackEngagementEvent(request: TrackEngagementEventRequest): Promise<TrackEngagementEventResponse> {
  return await getDefaultClient().trackEngagementEvent(request);
}

export async function fetchLibrary(options: { category?: LibraryCategory; sort?: LibrarySort } = {}) {
  return await getDefaultClient().fetchLibrary(options);
}

export async function followCreator(creatorUsername: string): Promise<CreatorFollowMutationResponse> {
  return await getDefaultClient().followCreator(creatorUsername);
}

export async function unfollowCreator(creatorUsername: string): Promise<CreatorFollowMutationResponse> {
  return await getDefaultClient().unfollowCreator(creatorUsername);
}

export async function fetchFollowingCreators(options: { sort?: import('@playdrop/types').FollowingSort } = {}) {
  return await getDefaultClient().fetchFollowingCreators(options);
}

export async function fetchFollowingFeed(options: { section: import('@playdrop/types').FollowingFeedSection; limit?: number }) {
  return await getDefaultClient().fetchFollowingFeed(options);
}

export async function fetchNotifications(options: { status?: NotificationStatus; limit?: number; offset?: number } = {}) {
  return await getDefaultClient().fetchNotifications(options);
}

export async function markNotificationRead(notificationId: number) {
  return await getDefaultClient().markNotificationRead(notificationId);
}

export async function markAllNotificationsRead() {
  return await getDefaultClient().markAllNotificationsRead();
}

export async function fetchWebPushConfig() {
  return await getDefaultClient().fetchWebPushConfig();
}

export async function fetchWebPushSubscriptionStatus(request: UpsertWebPushSubscriptionRequest) {
  return await getDefaultClient().fetchWebPushSubscriptionStatus(request);
}

export async function upsertWebPushSubscription(request: UpsertWebPushSubscriptionRequest) {
  return await getDefaultClient().upsertWebPushSubscription(request);
}

export async function deleteWebPushSubscription(request: UpsertWebPushSubscriptionRequest) {
  return await getDefaultClient().deleteWebPushSubscription(request);
}

export async function search(request: SearchRequest) {
  return await getDefaultClient().search(request);
}

export async function suggestSearch(request: SearchSuggestRequest) {
  return await getDefaultClient().suggestSearch(request);
}

export async function setSelectedProfileAsset(assetRef: string) {
  const request: SetProfileAssetRequest = { assetRef };
  return await getDefaultClient().setSelectedProfileAsset(request);
}

export async function fetchHome(options?: import('@playdrop/types').FetchHomeOptions) {
  return await getDefaultClient().fetchHome(options);
}

export async function fetchShop() {
  return await getDefaultClient().fetchCreditShop();
}

export async function createCreditPackCheckoutSession(sku: string) {
  return await getDefaultClient().createCreditPackCheckoutSession(sku);
}

export async function fetchCreditPackCheckoutStatus(sessionId: string) {
  return await getDefaultClient().fetchCreditPackCheckoutStatus(sessionId);
}

export async function purchaseAsset(assetRef: string) {
  return await getDefaultClient().purchaseAsset({ type: 'asset', assetRef });
}

export async function purchaseIap(request: IapPurchaseRequest) {
  return await getDefaultClient().purchaseIap(request);
}

export async function fetchIapReceipts(params?: IapReceiptListParams) {
  return await getDefaultClient().fetchIapReceipts(params);
}

export async function cancelIapReceipt(receiptId: number) {
  return await getDefaultClient().cancelIapReceipt(receiptId);
}

export async function fetchAppIapReceipts(params?: Omit<IapReceiptListParams, 'appId'>) {
  return await getDefaultClient().fetchAppIapReceipts(params);
}

export async function consumeAppIapReceipt(receiptId: number) {
  return await getDefaultClient().consumeAppIapReceipt(receiptId);
}

export async function grantAppIapReceipt(receiptId: number) {
  return await getDefaultClient().grantAppIapReceipt(receiptId);
}

export async function cancelAppIapReceipt(receiptId: number) {
  return await getDefaultClient().cancelAppIapReceipt(receiptId);
}

export async function fetchCreditTransactions(options?: { limit?: number; offset?: number }) {
  return await getDefaultClient().fetchCreditTransactions(options);
}

export async function fetchAiGeneration(id: string) {
  return await getDefaultClient().fetchAiGeneration(id);
}

export async function fetchAdminAiGeneration(id: string) {
  return await getDefaultClient().fetchAdminAiGeneration(id);
}

export async function listAssetCategories() {
  const response = await getDefaultClient().listAssetCategories();
  return response.categories;
}

export async function listAssets(
  options: { limit?: number; offset?: number; category?: AssetCategory; subcategory?: string } = {},
) {
  const response = await getDefaultClient().listAssets(options);
  return response.assets;
}

export async function fetchAssetBySlug(creatorUsername: string, assetName: string) {
  const response = await getDefaultClient().fetchAssetBySlug(creatorUsername, assetName);
  return response.asset;
}

export async function fetchAssetRelated(creatorUsername: string, assetName: string) {
  return await getDefaultClient().fetchAssetRelated(creatorUsername, assetName);
}

export async function listAssetVersions(
  creatorUsername: string,
  assetName: string,
  options: { limit?: number; offset?: number } = {},
) {
  const response = await getDefaultClient().listAssetVersions(creatorUsername, assetName, options);
  return response.versions;
}

export async function listAssetsForCreator(
  creatorUsername: string,
  options: { limit?: number; offset?: number; category?: AssetCategory; subcategory?: string } = {},
) {
  const response = await getDefaultClient().listAssetsForCreator(creatorUsername, options);
  return response.assets;
}

export async function updateAsset(
  creatorUsername: string,
  name: string,
  request: import('@playdrop/types').UpdateAssetRequest,
) {
  return await getDefaultClient().updateAsset(creatorUsername, name, request);
}

export async function updateAssetVersion(
  creatorUsername: string,
  name: string,
  revision: string | number,
  request: import('@playdrop/types').UpdateAssetVersionRequest,
) {
  return await getDefaultClient().updateAssetVersion(creatorUsername, name, revision, request);
}

export async function deleteAssetVersion(
  creatorUsername: string,
  name: string,
  revision: string | number,
) {
  return await getDefaultClient().deleteAssetVersion(creatorUsername, name, revision);
}

export async function deleteAsset(creatorUsername: string, name: string) {
  return await getDefaultClient().deleteAsset(creatorUsername, name);
}

export async function downloadAssetFile(
  creatorUsername: string,
  assetName: string,
  revision: string | number,
  options: { role?: string } = {},
) {
  return await getDefaultClient().downloadAssetFile(creatorUsername, assetName, revision, options);
}

export async function downloadAssetSource(
  creatorUsername: string,
  assetName: string,
  revision: string | number,
) {
  return await getDefaultClient().downloadAssetSource(creatorUsername, assetName, revision);
}

export async function listAssetPacks(
  options: { limit?: number; offset?: number; containsCategory?: AssetCategory; containsSubcategory?: string } = {},
) {
  const response = await getDefaultClient().listAssetPacks(options);
  return response.packs;
}

export async function fetchAssetPackBySlug(creatorUsername: string, packName: string) {
  const response = await getDefaultClient().fetchAssetPackBySlug(creatorUsername, packName);
  return response.pack;
}

export async function fetchAssetPackRelated(creatorUsername: string, packName: string) {
  return await getDefaultClient().fetchAssetPackRelated(creatorUsername, packName);
}

export async function downloadAssetPackSource(
  creatorUsername: string,
  packName: string,
  version: string,
) {
  return await getDefaultClient().downloadAssetPackSource(creatorUsername, packName, version);
}

export async function listAssetPackVersions(
  creatorUsername: string,
  packName: string,
  options: { limit?: number; offset?: number } = {},
) {
  const response = await getDefaultClient().listAssetPackVersions(creatorUsername, packName, options);
  return response.versions;
}

export async function listAssetPacksForCreator(
  creatorUsername: string,
  options: { limit?: number; offset?: number; containsCategory?: AssetCategory; containsSubcategory?: string } = {},
) {
  const response = await getDefaultClient().listAssetPacksForCreator(creatorUsername, options);
  return response.packs;
}

export async function updateAssetPack(
  creatorUsername: string,
  name: string,
  request: import('@playdrop/types').UpdateAssetPackRequest,
) {
  return await getDefaultClient().updateAssetPack(creatorUsername, name, request);
}

export async function updateAssetPackVersion(
  creatorUsername: string,
  name: string,
  version: string,
  request: import('@playdrop/types').UpdateAssetPackVersionRequest,
) {
  return await getDefaultClient().updateAssetPackVersion(creatorUsername, name, version, request);
}

export async function deleteAssetPackVersion(
  creatorUsername: string,
  name: string,
  version: string,
) {
  return await getDefaultClient().deleteAssetPackVersion(creatorUsername, name, version);
}

export async function deleteAssetPack(creatorUsername: string, name: string) {
  return await getDefaultClient().deleteAssetPack(creatorUsername, name);
}

export async function getAppVersion(creatorUsername: string, appName: string, version: string) {
  return await getDefaultClient().getAppVersion(creatorUsername, appName, version);
}

export async function listAppVersions(creatorUsername: string, appName: string) {
  return await getDefaultClient().listAppVersions(creatorUsername, appName);
}

export async function updateAppVersion(
  creatorUsername: string,
  appName: string,
  version: string,
  updates: { releaseNotes?: string | null; visibility?: AppVersionVisibility; setAsCurrent?: boolean },
) {
  return await getDefaultClient().updateAppVersion(creatorUsername, appName, version, updates);
}

export async function deleteAppVersion(creatorUsername: string, appName: string, version: string) {
  return await getDefaultClient().deleteAppVersion(creatorUsername, appName, version);
}

export async function fetchAdminApps() {
  return await getDefaultClient().fetchAdminApps();
}

export async function fetchAppDetail(creatorUsername: string, appName: string): Promise<AppDetailResponse> {
  return await getDefaultClient().fetchAppBySlug(creatorUsername, appName);
}

export async function downloadAppSource(creatorUsername: string, appName: string, version: string) {
  return await getDefaultClient().downloadAppSource(creatorUsername, appName, version);
}

export function configureWebClientRuntime(config: { platform: PlatformInfo; client: ClientInfo }): void {
  runtimeState.platform = {
    name: config.platform.name.trim().toLowerCase(),
    version: config.platform.version.trim(),
  };
  runtimeState.client = {
    version: config.client.version.trim(),
    build: config.client.build.trim(),
  };
}

export function getRuntimeState() {
  return runtimeState;
}

export function getClientVersionLabel(): string {
  const client = runtimeState.client;
  if (!client) {
    return '0.0.0 (build 0)';
  }
  return `${client.version} (build ${client.build})`;
}

export {
  APP_TYPE_VALUES,
  DEFAULT_APP_TYPE,
  APP_TYPE_DEFAULT_DISPLAY,
  APP_SURFACE_VALUES,
  DEFAULT_APP_SURFACE_TARGETS,
  normalizeAppType,
} from '@playdrop/types';

export { ApiError, UnsupportedClientError } from '@playdrop/types';

export type * from '@playdrop/types';

export type App = import('@playdrop/types').AppResponse;
export type Asset = import('@playdrop/types').AssetResponse;
export type AssetPack = import('@playdrop/types').AssetPackResponse;
