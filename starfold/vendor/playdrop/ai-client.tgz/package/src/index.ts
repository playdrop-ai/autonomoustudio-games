import type {
  AssetEmbeddedMetadata,
  AssetMetadataEmbeddingStatus,
} from '@playdrop/types';

export type TextGenerationMode = 'text';
export type TextGenerationSize = 'small' | 'medium' | 'large';
export type ImageAttachment = {
  data?: string;
  mimeType?: string;
  url?: string;
};

export type AiImageAspectRatio = '1:1' | '3:4' | '9:16' | '4:3' | '16:9';

export type GenerationBilling = {
  amount: number;
  paidBy: 'USER' | 'CREATOR';
  generationId: string;
  transactionId: number;
  creditBalance: number;
};

export type GeneratedAssetRef = {
  creatorUsername: string;
  assetName: string;
  revision: number;
  versionId: number;
  subcategory: string;
  ref: string;
};

export type GenerateTextResponse = {
  input: string;
  output: string;
  model: string;
  totalTokenCount: number | null;
  promptTokenCount: number | null;
  responseTokenCount: number | null;
  maxOutputTokens: number | null;
  size: TextGenerationSize;
  mode: TextGenerationMode;
  cost: number;
  createdAt: string;
  billing: GenerationBilling;
};

export type GenerateTextOptions = {
  signal?: AbortSignal;
  size?: TextGenerationSize;
  mode?: TextGenerationMode;
  system?: string;
};

export type GenerateImageResponse = {
  input: string;
  imageUrl: string;
  imageMimeType: string;
  inputImageUrls: string[];
  aspectRatio: AiImageAspectRatio;
  metadata?: unknown;
  embeddedMetadata?: AssetEmbeddedMetadata;
  embeddingStatus?: AssetMetadataEmbeddingStatus;
  metadataUrl?: string | null;
  generatedAssetDisplayName?: string | null;
  generatedAssetDescription?: string | null;
  model: string;
  mode: 'image';
  cost: number;
  totalTokenCount: number | null;
  promptTokenCount: number | null;
  responseTokenCount: number | null;
  generatedAsset?: GeneratedAssetRef;
  createdAt: string;
  billing: GenerationBilling;
};

export type GenerateJsonResponse = {
  input: string;
  system: string | null;
  output: unknown;
  raw: string;
  size: TextGenerationSize;
  model: string;
  mode: 'json';
  cost: number;
  totalTokenCount: number | null;
  promptTokenCount: number | null;
  responseTokenCount: number | null;
  responseSchemaProvided: boolean;
  responseSchema: unknown;
  createdAt: string;
  billing: GenerationBilling;
};

export type GenerateMusicResponse = {
  input: string;
  durationMs: number | null;
  forceInstrumental: boolean;
  audioUrl: string;
  audioMimeType: string;
  coverUrl: string | null;
  coverMimeType: string | null;
  providerSongMetadata: ElevenLabsSongMetadata | null;
  providerCompositionPlan: ElevenLabsCompositionPlan | null;
  providerWordTimestamps: ElevenLabsWordTimestamp[] | null;
  embeddedMetadata?: AssetEmbeddedMetadata;
  embeddingStatus?: AssetMetadataEmbeddingStatus;
  metadataUrl?: string | null;
  model: string;
  mode: 'music';
  cost: number;
  generatedAsset?: GeneratedAssetRef;
  createdAt: string;
  billing: GenerationBilling;
};

export type GenerateSfxResponse = {
  input: string;
  durationSeconds: number | null;
  loop: boolean;
  audioUrl: string;
  audioMimeType: string;
  coverUrl: string | null;
  coverMimeType: string | null;
  embeddedMetadata?: AssetEmbeddedMetadata;
  embeddingStatus?: AssetMetadataEmbeddingStatus;
  metadataUrl?: string | null;
  model: string;
  mode: 'sfx';
  cost: number;
  generatedAsset?: GeneratedAssetRef;
  createdAt: string;
  billing: GenerationBilling;
};

export type GenerateVideoResponse = {
  input: string;
  durationSeconds: 4 | 8;
  aspectRatio: '16:9' | '9:16';
  resolution: '720p';
  videoUrl: string;
  videoMimeType: string;
  thumbnailUrl: string | null;
  embeddedMetadata?: AssetEmbeddedMetadata;
  embeddingStatus?: AssetMetadataEmbeddingStatus;
  metadataUrl?: string | null;
  generatedAssetDisplayName?: string | null;
  generatedAssetDescription?: string | null;
  model: string;
  mode: 'video';
  cost: number;
  generatedAsset?: GeneratedAssetRef;
  createdAt: string;
  billing: GenerationBilling;
};

export type GenerateModel3DResponse = {
  input: string;
  sourceMode: 'TEXT' | 'IMAGE';
  topology: 'triangle' | 'quad';
  targetPolycount: number;
  shouldRemesh: boolean;
  shouldTexture: boolean;
  modelUrl: string;
  modelMimeType: string;
  thumbnailUrl: string | null;
  modelSizeBytes?: number | null;
  metadata?: unknown;
  embeddedMetadata?: AssetEmbeddedMetadata;
  embeddingStatus?: AssetMetadataEmbeddingStatus;
  metadataUrl?: string | null;
  generatedAssetDisplayName?: string | null;
  generatedAssetDescription?: string | null;
  model: string;
  mode: 'model_3d';
  cost: number;
  generatedAsset?: GeneratedAssetRef;
  createdAt: string;
  billing: GenerationBilling;
};

export type GenerateAssetModality = 'IMAGE' | 'MUSIC' | 'SFX' | 'VIDEO' | 'MODEL_3D';

export type GenerateAssetRequest = {
  modality: GenerateAssetModality;
  input: string;
  signal?: AbortSignal;
  assetName?: string;
  assetDisplayName?: string;
  assetDescription?: string;
  assetVisibility?: 'PRIVATE' | 'PUBLIC';
  assetSubcategory?: string;
  attachAppVersionId?: number;
  remixAssetVersionRef?: string;
  image1?: ImageAttachment | null;
  image2?: ImageAttachment | null;
  durationMs?: number;
  forceInstrumental?: boolean;
  durationSeconds?: number;
  loop?: boolean;
  coverPrompt?: string;
  aspectRatio?: AiImageAspectRatio;
  resolution?: '720p';
  sourceMode?: 'TEXT' | 'IMAGE';
  topology?: 'triangle' | 'quad';
  targetPolycount?: number;
  shouldRemesh?: boolean;
  shouldTexture?: boolean;
};

export type GenerationJobStatus = 'PENDING' | 'RUNNING' | 'SUCCESS' | 'FAILURE';

export const GENERATION_JOB_ETA_BASELINE_SECONDS: Record<GenerateAssetModality, number> = {
  IMAGE: 20,
  MUSIC: 40,
  SFX: 15,
  VIDEO: 90,
  MODEL_3D: 420,
};

export type GenerationJobRecord = {
  id: string;
  modality: GenerateAssetModality;
  status: GenerationJobStatus;
  requestPrompt: string;
  requestPayload: unknown;
  resultData: unknown | null;
  errorCode: string | null;
  errorMessage: string | null;
  linkedGenerationId: string | null;
  createdAt: string;
  updatedAt: string;
  startedAt: string | null;
  completedAt: string | null;
  failedAt: string | null;
  progressPercent: number | null;
  etaSecondsRemaining: number | null;
};

export type CreateGenerationJobRequest = GenerateAssetRequest;

export type CreateGenerationJobResponse = {
  job: GenerationJobRecord;
};

export type GetGenerationJobResponse = {
  job: GenerationJobRecord;
};

type PaginationMeta = {
  limit: number;
  offset: number;
  count: number;
  hasMore: boolean;
};

type GenerationRecordBase = {
  id: string;
  type: 'text' | 'json' | 'image' | 'music' | 'sfx' | 'video' | 'model_3d';
  cost: number;
  createdAt: string;
};

export type ElevenLabsSongMetadata = {
  title?: string | null;
  description?: string | null;
  genres: string[];
  languages: string[];
  isExplicit?: boolean | null;
};

export type ElevenLabsWordTimestamp = {
  word: string;
  startMs: number;
  endMs: number;
};

export type ElevenLabsCompositionPlanSection = {
  sectionName?: string;
  durationMs?: number;
  positiveLocalStyles?: string[];
  negativeLocalStyles?: string[];
  lines?: string[];
};

export type ElevenLabsCompositionPlan = {
  durationMs?: number;
  positiveGlobalStyles?: string[];
  negativeGlobalStyles?: string[];
  sections?: ElevenLabsCompositionPlanSection[];
};

export type ListTextGenerationRecord = GenerationRecordBase & {
  type: 'text';
  systemPrompt: string | null;
  inputPrompt: string;
  outputText: string;
  modelSize: TextGenerationSize;
};

export type ListJsonGenerationRecord = GenerationRecordBase & {
  type: 'json';
  systemPrompt: string | null;
  inputPrompt: string;
  outputSchema: unknown;
  outputJSON: unknown;
};

export type ListImageGenerationRecord = GenerationRecordBase & {
  type: 'image';
  inputPrompt: string;
  inputImages: string[];
  outputImage: string | null;
  aspectRatio: AiImageAspectRatio | null;
  metadata?: unknown;
  embeddedMetadata?: AssetEmbeddedMetadata | null;
  embeddingStatus?: AssetMetadataEmbeddingStatus | null;
  metadataUrl?: string | null;
  generatedAssetDisplayName?: string | null;
  generatedAssetDescription?: string | null;
  generatedAsset?: GeneratedAssetRef;
};

export type ListMusicGenerationRecord = GenerationRecordBase & {
  type: 'music';
  inputPrompt: string;
  durationMs: number | null;
  forceInstrumental: boolean;
  audioUrl: string | null;
  audioMimeType: string | null;
  coverUrl: string | null;
  coverMimeType: string | null;
  providerSongMetadata: ElevenLabsSongMetadata | null;
  providerCompositionPlan: ElevenLabsCompositionPlan | null;
  providerWordTimestamps: ElevenLabsWordTimestamp[] | null;
  embeddedMetadata?: AssetEmbeddedMetadata | null;
  embeddingStatus?: AssetMetadataEmbeddingStatus | null;
  metadataUrl?: string | null;
  generatedAsset?: GeneratedAssetRef;
};

export type ListSfxGenerationRecord = GenerationRecordBase & {
  type: 'sfx';
  inputPrompt: string;
  durationSeconds: number | null;
  loop: boolean;
  audioUrl: string | null;
  audioMimeType: string | null;
  coverUrl: string | null;
  coverMimeType: string | null;
  embeddedMetadata?: AssetEmbeddedMetadata | null;
  embeddingStatus?: AssetMetadataEmbeddingStatus | null;
  metadataUrl?: string | null;
  generatedAsset?: GeneratedAssetRef;
};

export type ListVideoGenerationRecord = GenerationRecordBase & {
  type: 'video';
  inputPrompt: string;
  durationSeconds: number | null;
  aspectRatio: string | null;
  resolution: string | null;
  videoUrl: string | null;
  videoMimeType: string | null;
  thumbnailUrl: string | null;
  metadata?: unknown;
  embeddedMetadata?: AssetEmbeddedMetadata | null;
  embeddingStatus?: AssetMetadataEmbeddingStatus | null;
  metadataUrl?: string | null;
  generatedAssetDisplayName?: string | null;
  generatedAssetDescription?: string | null;
  generatedAsset?: GeneratedAssetRef;
};

export type ListModel3DGenerationRecord = GenerationRecordBase & {
  type: 'model_3d';
  inputPrompt: string;
  sourceMode: 'TEXT' | 'IMAGE' | null;
  topology: 'triangle' | 'quad' | null;
  targetPolycount: number | null;
  shouldRemesh: boolean;
  shouldTexture: boolean;
  modelUrl: string | null;
  modelMimeType: string | null;
  thumbnailUrl: string | null;
  modelSizeBytes?: number | null;
  metadata?: unknown;
  embeddedMetadata?: AssetEmbeddedMetadata | null;
  embeddingStatus?: AssetMetadataEmbeddingStatus | null;
  metadataUrl?: string | null;
  generatedAssetDisplayName?: string | null;
  generatedAssetDescription?: string | null;
  generatedAsset?: GeneratedAssetRef;
};

export type GenerationRecord =
  | ListTextGenerationRecord
  | ListJsonGenerationRecord
  | ListImageGenerationRecord
  | ListMusicGenerationRecord
  | ListSfxGenerationRecord
  | ListVideoGenerationRecord
  | ListModel3DGenerationRecord;

export type ListGenerationsOptions = {
  signal?: AbortSignal;
  type?: 'text' | 'json' | 'image' | 'music' | 'sfx' | 'video' | 'model_3d';
  limit?: number;
  offset?: number;
};

export type ListGenerationsResponse = {
  generations: GenerationRecord[];
  pagination: PaginationMeta;
};

export type ListGenerationJobsOptions = {
  signal?: AbortSignal;
  modality?: GenerateAssetModality;
  status?: GenerationJobStatus;
  limit?: number;
  offset?: number;
};

export type ListGenerationJobsResponse = {
  jobs: GenerationJobRecord[];
  pagination: PaginationMeta;
};

export type GenerateJsonOptions = {
  signal?: AbortSignal;
  size?: TextGenerationSize;
  system?: string;
  responseJsonSchema?: string;
};

export type AiClientConfig = {
  baseUrl?: string;
  fetchImpl?: typeof fetch;
  tokenProvider?: () => string | null | Promise<string | null>;
  clientHeaders?: () => Record<string, string> | Promise<Record<string, string>>;
};

export interface AiClient {
  generateText(input: string, options?: GenerateTextOptions): Promise<GenerateTextResponse>;
  createGenerationJob(request: CreateGenerationJobRequest): Promise<CreateGenerationJobResponse>;
  getGenerationJob(id: string, options?: { signal?: AbortSignal }): Promise<GetGenerationJobResponse>;
  listGenerationJobs(options?: ListGenerationJobsOptions): Promise<ListGenerationJobsResponse>;
  deleteGenerationJob(id: string, options?: { signal?: AbortSignal }): Promise<void>;
  generateJson(input: string, options?: GenerateJsonOptions): Promise<GenerateJsonResponse>;
  listGenerations(options?: ListGenerationsOptions): Promise<ListGenerationsResponse>;
  listDiscoverGenerations(options?: ListGenerationsOptions): Promise<ListGenerationsResponse>;
}

const DEFAULT_LOCAL_BASE = 'http://localhost:8083';

function stripTrailingSlash(value: string): string {
  return value.endsWith('/') ? value.slice(0, -1) : value;
}

function normalizeProtocol(protocol: string | null | undefined): string {
  if (!protocol) {
    return 'http';
  }
  return protocol.replace(/:$/, '') || 'http';
}

function inferBaseFromHostname(hostname: string, protocol: string): string {
  if (hostname.includes('.')) {
    const domain = hostname
      .replace(/^www\./, '')
      .replace(/^api\./, '')
      .replace(/^play\./, '')
      .replace(/^admin\./, '')
      .replace(/^ai\./, '')
      .replace(/^assets\./, '');
    return `${protocol}://ai.${domain}`;
  }

  const host = hostname || 'localhost';
  return `${protocol}://${host}:8083`;
}

function inferBaseUrl(): string {
  if (typeof process !== 'undefined' && process.env.NEXT_PUBLIC_AI_BASE) {
    return process.env.NEXT_PUBLIC_AI_BASE;
  }

  if (typeof window !== 'undefined' && window.location) {
    const { hostname, protocol } = window.location;
    return inferBaseFromHostname(hostname, normalizeProtocol(protocol));
  }

  return DEFAULT_LOCAL_BASE;
}

export function createAiClient(config: AiClientConfig = {}): AiClient {
  const fetchImpl = config.fetchImpl ?? globalThis.fetch?.bind(globalThis);
  if (!fetchImpl) {
    throw new Error('ai_client_missing_fetch');
  }

  const baseUrl = stripTrailingSlash(config.baseUrl ?? inferBaseUrl());

  async function resolveToken(): Promise<string | null> {
    if (config.tokenProvider) {
      const token = await config.tokenProvider();
      return token ?? null;
    }
    if (typeof window !== 'undefined' && window.localStorage) {
      try {
        return window.localStorage.getItem('playdrop.accessToken');
      } catch {
        return null;
      }
    }
    return null;
  }

  async function resolveClientHeaders(): Promise<Record<string, string>> {
    if (config.clientHeaders) {
      try {
        const headers = await config.clientHeaders();
        return headers && typeof headers === 'object' ? { ...headers } : {};
      } catch {
        return {};
      }
    }
    return {};
  }

  async function buildHeaders(): Promise<Record<string, string>> {
    const headers: Record<string, string> = {
      ...(await resolveClientHeaders()),
    };
    const token = await resolveToken();
    if (token && !headers.Authorization) {
      headers.Authorization = `Bearer ${token}`;
    }
    return headers;
  }

  async function buildRequestInit(payload: unknown, signal?: AbortSignal): Promise<RequestInit> {
    const headers = await buildHeaders();
    headers['Content-Type'] = 'application/json';
    return {
      method: 'POST',
      headers,
      body: JSON.stringify(payload),
      signal,
    };
  }

  async function throwHttpError(response: Response): Promise<never> {
    let payload: any = null;
    try {
      const text = await response.text();
      if (text) {
        try {
          payload = JSON.parse(text);
        } catch {
          payload = { message: text };
        }
      }
    } catch {
      payload = null;
    }
    const code = payload?.error ?? `http_${response.status}`;
    const message = payload?.message ?? response.statusText ?? 'Request failed';
    const error = new Error(`${code}: ${message}`);
    (error as any).status = response.status;
    (error as any).code = code;
    (error as any).details = payload;
    throw error;
  }

  async function ensureOk(response: Response): Promise<void> {
    if (!response.ok) {
      await throwHttpError(response);
    }
  }

  async function generateText(input: string, options?: GenerateTextOptions): Promise<GenerateTextResponse> {
    const normalizedInput = input?.trim();
    if (!normalizedInput) {
      throw new Error('ai_client_missing_input');
    }
    const size = options?.size ?? 'small';
    const mode = options?.mode ?? 'text';
    const rawSystem = options?.system?.trim();
    const system = rawSystem && rawSystem.length ? rawSystem : undefined;

    const response = await fetchImpl(
      `${baseUrl}/text/generate`,
      await buildRequestInit(
        {
          input: normalizedInput,
          size,
          mode,
          system,
        },
        options?.signal,
      ),
    );

    await ensureOk(response);

    const data = (await response.json()) as GenerateTextResponse;
    return data;
  }

  function buildGenerateAssetPayload(request: GenerateAssetRequest): Record<string, unknown> {
    const normalizedInput = request.input?.trim();
    if (!normalizedInput) {
      throw new Error('ai_client_missing_input');
    }
    const payload: Record<string, unknown> = {
      modality: request.modality,
      input: normalizedInput,
      assetName: request.assetName,
      assetDisplayName: request.assetDisplayName,
      assetDescription: request.assetDescription,
      assetVisibility: request.assetVisibility,
      assetSubcategory: request.assetSubcategory,
      attachAppVersionId: request.attachAppVersionId,
      remixAssetVersionRef: request.remixAssetVersionRef,
    };

    if (request.modality === 'IMAGE') {
      payload.mode = 'image';
      payload.image1 = request.image1 ?? undefined;
      payload.image2 = request.image2 ?? undefined;
      payload.aspectRatio = request.aspectRatio;
    } else if (request.modality === 'MUSIC') {
      payload.durationMs = typeof request.durationMs === 'number' ? request.durationMs : undefined;
      payload.forceInstrumental = typeof request.forceInstrumental === 'boolean' ? request.forceInstrumental : undefined;
      payload.coverPrompt = typeof request.coverPrompt === 'string' ? request.coverPrompt : undefined;
    } else if (request.modality === 'SFX') {
      payload.durationSeconds = typeof request.durationSeconds === 'number' ? request.durationSeconds : undefined;
      payload.loop = typeof request.loop === 'boolean' ? request.loop : undefined;
      payload.coverPrompt = typeof request.coverPrompt === 'string' ? request.coverPrompt : undefined;
    } else if (request.modality === 'VIDEO') {
      payload.durationSeconds = typeof request.durationSeconds === 'number' ? request.durationSeconds : undefined;
      payload.aspectRatio = request.aspectRatio;
      payload.resolution = '720p';
      payload.image1 = request.image1 ?? undefined;
      payload.image2 = request.image2 ?? undefined;
    } else if (request.modality === 'MODEL_3D') {
      payload.sourceMode = request.sourceMode;
      payload.image1 = request.image1 ?? undefined;
      payload.image2 = request.image2 ?? undefined;
      payload.topology = request.topology;
      payload.targetPolycount = typeof request.targetPolycount === 'number' ? request.targetPolycount : undefined;
      payload.shouldRemesh = typeof request.shouldRemesh === 'boolean' ? request.shouldRemesh : undefined;
      payload.shouldTexture = typeof request.shouldTexture === 'boolean' ? request.shouldTexture : undefined;
    }
    return payload;
  }

  async function createGenerationJob(request: CreateGenerationJobRequest): Promise<CreateGenerationJobResponse> {
    const payload = buildGenerateAssetPayload(request);
    const response = await fetchImpl(
      `${baseUrl}/ai/assets/jobs`,
      await buildRequestInit(payload, request.signal),
    );
    await ensureOk(response);
    return (await response.json()) as CreateGenerationJobResponse;
  }

  async function getGenerationJob(id: string, options: { signal?: AbortSignal } = {}): Promise<GetGenerationJobResponse> {
    const normalizedId = id?.trim();
    if (!normalizedId) {
      throw new Error('ai_client_missing_job_id');
    }
    const response = await fetchImpl(`${baseUrl}/ai/assets/jobs/${encodeURIComponent(normalizedId)}`, {
      method: 'GET',
      headers: await buildHeaders(),
      signal: options.signal,
    });
    await ensureOk(response);
    return (await response.json()) as GetGenerationJobResponse;
  }

  async function listGenerationJobs(options: ListGenerationJobsOptions = {}): Promise<ListGenerationJobsResponse> {
    const params = new URLSearchParams();
    if (options.modality) {
      params.set('modality', options.modality);
    }
    if (options.status) {
      params.set('status', options.status);
    }
    if (typeof options.limit === 'number' && Number.isFinite(options.limit)) {
      params.set('limit', String(options.limit));
    }
    if (typeof options.offset === 'number' && Number.isFinite(options.offset)) {
      params.set('offset', String(options.offset));
    }
    const queryString = params.toString();
    const query = queryString ? `?${queryString}` : '';
    const response = await fetchImpl(`${baseUrl}/ai/assets/jobs${query}`, {
      method: 'GET',
      headers: await buildHeaders(),
      signal: options.signal,
    });
    await ensureOk(response);
    return (await response.json()) as ListGenerationJobsResponse;
  }

  async function deleteGenerationJob(id: string, options: { signal?: AbortSignal } = {}): Promise<void> {
    const normalizedId = id?.trim();
    if (!normalizedId) {
      throw new Error('ai_client_missing_job_id');
    }
    const response = await fetchImpl(`${baseUrl}/ai/assets/jobs/${encodeURIComponent(normalizedId)}`, {
      method: 'DELETE',
      headers: await buildHeaders(),
      signal: options.signal,
    });
    await ensureOk(response);
  }

  async function generateJson(input: string, options?: GenerateJsonOptions): Promise<GenerateJsonResponse> {
    const normalizedInput = input?.trim();
    if (!normalizedInput) {
      throw new Error('ai_client_missing_input');
    }
    const normalizedSystem = options?.system?.trim();
    const response = await fetchImpl(
      `${baseUrl}/json/generate`,
      await buildRequestInit(
        {
          input: normalizedInput,
          size: options?.size ?? 'small',
          system: normalizedSystem && normalizedSystem.length ? normalizedSystem : undefined,
          responseJsonSchema: options?.responseJsonSchema,
        },
        options?.signal,
      ),
    );

    await ensureOk(response);

    const data = (await response.json()) as GenerateJsonResponse;
    return data;
  }

  async function listGenerations(options: ListGenerationsOptions = {}): Promise<ListGenerationsResponse> {
    const params = new URLSearchParams();
    if (options.type) {
      params.set('type', options.type);
    }
    if (typeof options.limit === 'number' && Number.isFinite(options.limit)) {
      params.set('limit', String(options.limit));
    }
    if (typeof options.offset === 'number' && Number.isFinite(options.offset)) {
      params.set('offset', String(options.offset));
    }
    const queryString = params.toString();
    const query = queryString ? `?${queryString}` : '';
    const response = await fetchImpl(`${baseUrl}/generations${query}`, {
      method: 'GET',
      headers: await buildHeaders(),
      signal: options.signal,
    });

    await ensureOk(response);

    const data = (await response.json()) as ListGenerationsResponse;
    return data;
  }

  async function listDiscoverGenerations(options: ListGenerationsOptions = {}): Promise<ListGenerationsResponse> {
    const params = new URLSearchParams();
    if (options.type) {
      params.set('type', options.type);
    }
    if (typeof options.limit === 'number' && Number.isFinite(options.limit)) {
      params.set('limit', String(options.limit));
    }
    if (typeof options.offset === 'number' && Number.isFinite(options.offset)) {
      params.set('offset', String(options.offset));
    }
    const queryString = params.toString();
    const query = queryString ? `?${queryString}` : '';
    const response = await fetchImpl(`${baseUrl}/generations/discover${query}`, {
      method: 'GET',
      headers: await buildHeaders(),
      signal: options.signal,
    });

    await ensureOk(response);

    const data = (await response.json()) as ListGenerationsResponse;
    return data;
  }

  return {
    generateText,
    createGenerationJob,
    getGenerationJob,
    listGenerationJobs,
    deleteGenerationJob,
    generateJson,
    listGenerations,
    listDiscoverGenerations,
  };
}
