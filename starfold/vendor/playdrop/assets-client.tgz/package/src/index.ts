import { createApiClient, type ApiClient, type ApiRequest, type ApiResponse } from './api-client.js';

export type AssetAction = 'download' | 'upload' | 'resolve';

export interface AssetRequest {
  action: AssetAction;
  assetType: string;
  key: string;
  file?: string;
  body?: unknown;
}

export interface DownloadResponse {
  ok: boolean;
  mimeType?: string;
  data?: ArrayBuffer;
}

export interface ResolveResponse<T = unknown> {
  ok: boolean;
  asset?: T;
}

export interface UploadResponse<T = unknown> {
  ok: boolean;
  asset?: T;
}

export interface AssetsClientConfig {
  apiClient?: ApiClient;
  basePath?: string;
}

export class AssetsClient {
  private readonly api: ApiClient;
  private readonly basePath: string;

  constructor(config: AssetsClientConfig = {}) {
    this.api = config.apiClient ?? createApiClient();
    this.basePath = config.basePath ?? '/assets';
  }

  async resolve<T = unknown>(type: string, key: string): Promise<ResolveResponse<T>> {
    const request: ApiRequest = {
      method: 'GET',
      path: `${this.basePath}/${encodeURIComponent(type)}/${encodeURIComponent(key)}`,
    };
    const response = await this.api.request<T>(request);
    if (!isOk(response)) {
      return { ok: false };
    }
    return { ok: true, asset: response.body };
  }

  async download(type: string, key: string, file: string): Promise<DownloadResponse> {
    const request: ApiRequest = {
      method: 'GET',
      path: `${this.basePath}/${encodeURIComponent(type)}/${encodeURIComponent(key)}/${encodeURIComponent(file)}`,
    };
    const response = await this.api.request<string | ArrayBuffer>(request);
    if (!isOk(response)) {
      return { ok: false };
    }
    if (response.body instanceof ArrayBuffer) {
      return { ok: true, mimeType: response.headers.get('content-type') ?? undefined, data: response.body };
    }
    if (typeof response.body === 'string') {
      const data = base64ToArrayBuffer(response.body);
      return { ok: true, mimeType: response.headers.get('content-type') ?? undefined, data };
    }
    return { ok: false };
  }

  async upload(type: string, key: string, payload: Record<string, any>): Promise<UploadResponse> {
    const request: ApiRequest = {
      method: 'POST',
      path: `${this.basePath}/${encodeURIComponent(type)}/${encodeURIComponent(key)}`,
      body: payload,
    };
    const response = await this.api.request(request);
    if (!isOk(response)) {
      return { ok: false };
    }
    return { ok: true, asset: response.body };
  }
}

export function createAssetsClient(config: AssetsClientConfig = {}): AssetsClient {
  return new AssetsClient(config);
}

function isOk<T>(response: ApiResponse<T>): response is ApiResponse<T> {
  return response.status >= 200 && response.status < 300;
}

function base64ToArrayBuffer(base64: string): ArrayBuffer {
  if (typeof atob === 'function') {
    const binaryString = atob(base64);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i += 1) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes.buffer;
  }
  const buffer = Buffer.from(base64, 'base64');
  return buffer.buffer.slice(buffer.byteOffset, buffer.byteOffset + buffer.byteLength);
}