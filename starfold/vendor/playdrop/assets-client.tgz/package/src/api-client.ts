export type HttpMethod = 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';

export interface ApiRequest {
  method: HttpMethod;
  path: string;
  body?: unknown;
  headers?: Record<string, string>;
}

export interface ApiResponse<T = unknown> {
  status: number;
  body: T;
  headers: Headers;
}

export interface ApiClientConfig {
  baseUrl?: string;
  headers?: Record<string, string>;
}

export interface ApiClient {
  request<T = unknown>(request: ApiRequest): Promise<ApiResponse<T>>;
}

export function createApiClient(config: ApiClientConfig = {}): ApiClient {
  const baseUrl = config.baseUrl ?? '';
  const defaultHeaders = config.headers ?? {};

  return {
    async request<T>(request: ApiRequest): Promise<ApiResponse<T>> {
      const url = `${baseUrl}${request.path}`;
      const headers = {
        'Content-Type': 'application/json',
        ...defaultHeaders,
        ...request.headers,
      };

      const fetchOptions: RequestInit = {
        method: request.method,
        headers,
      };

      if (request.body !== undefined) {
        if (request.body instanceof ArrayBuffer || request.body instanceof Uint8Array) {
          fetchOptions.body = request.body;
          delete (headers as any)['Content-Type'];
        } else {
          fetchOptions.body = JSON.stringify(request.body);
        }
      }

      const response = await fetch(url, fetchOptions);
      
      let body: T;
      const contentType = response.headers.get('content-type');
      if (contentType?.includes('application/json')) {
        body = await response.json() as T;
      } else if (contentType?.includes('text/')) {
        body = (await response.text()) as T;
      } else {
        body = (await response.arrayBuffer()) as T;
      }

      return {
        status: response.status,
        body,
        headers: response.headers,
      };
    },
  };
}

export function configureWebClientRuntime(config: {
  platform: { name: string; version: string };
  client: { version: string; build: string };
}): void {
  // This is a no-op for the assets-client package
  // The runtime configuration is handled by the api-client
}
