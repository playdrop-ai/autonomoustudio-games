# @playdrop/assets-client

Small helper around the API client for resolving, downloading, and uploading assets stored by the platform.

## Responsibilities
- Wraps `createApiClient` to hit the `/assets` namespace without duplicating HTTP plumbing.
- Provides `resolve`, `download`, and `upload` helpers that report `ok` status and return decoded payloads or `ArrayBuffer` data.
- Converts base64 strings into binary buffers when the server responds with inline payloads (matching the assets server behaviour).

## Usage
```ts
import { createAssetsClient } from '@playdrop/assets-client';

const assets = createAssetsClient({ basePath: '/assets' });
const mesh = await assets.download('avatars', 'playdrop/clonex', 'body.glb');
if (mesh.ok && mesh.data) {
  // consume ArrayBuffer
}
```

## Configuration
- Accepts an optional `apiClient` (defaults to a shared singleton) and `basePath` (defaults to `/assets`).
- Inherits token handling and client headers from the underlying `@playdrop/api-client` instance.

## Implementation Notes
- `download` automatically inspects the response body type: large binaries use `ArrayBuffer`, smaller payloads fall back to base64 text.
- `upload` sends JSON payloads; multipart uploads should be performed via `@playdrop/api-client` game/avatar helpers.
- Works in browser and Node environments (falls back to `Buffer` utilities when `atob` is unavailable).

## Related Workspaces
- Used by the web app to fetch avatar previews and by creator tooling when importing asset metadata.
