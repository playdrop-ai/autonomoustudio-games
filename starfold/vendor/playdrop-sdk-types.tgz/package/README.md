# Playdrop SDK Types

This package contains the self-contained public TypeScript declarations for the Playdrop SDK CDN bundle.

- Runtime code ships exclusively via the CDN loader `playdrop.js`.
- Install these types locally with:

  ```bash
  npm install https://assets.playdrop.ai/sdk/playdrop-sdk-types-0.13.12.tgz
  ```

