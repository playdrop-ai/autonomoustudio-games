import { type ClientBridge } from '@playdrop/web-bridge';
import type { AcquisitionAPI } from './types.js';
export declare const acquisition: AcquisitionAPI;
export declare const __test__: {
    setBridgeResolver(resolver: () => ClientBridge | null): void;
    resetBridgeResolver(): void;
};
