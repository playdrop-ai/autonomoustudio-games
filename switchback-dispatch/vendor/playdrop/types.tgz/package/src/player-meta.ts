import type { AppType } from './app.js';

export const PLAYER_META_KEY_REGEX = /^[a-z][a-z0-9_.-]{2,63}$/;

export const PLAYER_META_DEFINITION_STATUS_VALUES = ['ACTIVE', 'RETIRED'] as const;
export type PlayerMetaDefinitionStatus = (typeof PLAYER_META_DEFINITION_STATUS_VALUES)[number];

export const APP_ACHIEVEMENT_KIND_VALUES = ['STANDARD', 'INCREMENTAL'] as const;
export type AppAchievementKind = (typeof APP_ACHIEVEMENT_KIND_VALUES)[number];

export const APP_LEADERBOARD_SCORE_TYPE_VALUES = ['INTEGER', 'TIME_MS'] as const;
export type AppLeaderboardScoreType = (typeof APP_LEADERBOARD_SCORE_TYPE_VALUES)[number];

export const APP_LEADERBOARD_SORT_VALUES = ['DESC', 'ASC'] as const;
export type AppLeaderboardSort = (typeof APP_LEADERBOARD_SORT_VALUES)[number];

export const PLAYER_META_ERROR_CODE_VALUES = [
  'E_AUTH_REQUIRED',
  'E_RUNTIME_AUTH_REQUIRED',
  'E_META_NOT_FOUND',
  'E_META_RETIRED',
  'E_META_INVALID_KEY',
  'E_META_INVALID_DEFINITION',
  'E_INVALID_ARGUMENT',
  'E_SCORE_INVALID',
  'E_PROGRESS_INVALID',
  'E_FEATURE_KIND_MISMATCH',
  'E_RATE_LIMITED',
] as const;
export type PlayerMetaErrorCode = (typeof PLAYER_META_ERROR_CODE_VALUES)[number];

export interface AppAchievementCatalogueDefinition {
  key: string;
  displayName: string;
  description: string;
  kind: AppAchievementKind;
  hidden?: boolean;
  maxProgress?: number;
  icon: string;
  status?: PlayerMetaDefinitionStatus;
}

export interface AppLeaderboardCatalogueDefinition {
  key: string;
  displayName: string;
  description: string;
  scoreType: AppLeaderboardScoreType;
  sort: AppLeaderboardSort;
  unitLabel?: string;
  status?: PlayerMetaDefinitionStatus;
}

export interface AppAchievementDefinition {
  key: string;
  displayName: string;
  description: string;
  kind: AppAchievementKind;
  hidden: boolean;
  maxProgress: number | null;
  iconUrl: string;
  status: PlayerMetaDefinitionStatus;
}

export interface AppLeaderboardDefinition {
  key: string;
  displayName: string;
  description: string;
  scoreType: AppLeaderboardScoreType;
  sort: AppLeaderboardSort;
  unitLabel?: string;
  status: PlayerMetaDefinitionStatus;
}

export interface AppAchievementPlayerState {
  progress: number;
  unlocked: boolean;
  unlockedAt: string | null;
}

export interface AppLeaderboardPlayerSummary {
  hasScore: boolean;
  bestScore: number | null;
  rank: number | null;
  bestScoreAt: string | null;
}

export interface AchievementView {
  definition: AppAchievementDefinition;
  player: AppAchievementPlayerState | null;
}

export interface LeaderboardSummary {
  definition: AppLeaderboardDefinition;
  player: AppLeaderboardPlayerSummary | null;
}

export interface LeaderboardEntryUser {
  publicPlayerId: string;
  username?: string;
  displayName: string;
  avatarUrl?: string;
  profilePath?: string;
}

export interface LeaderboardEntry {
  rank: number;
  score: number;
  bestScoreAt: string;
  isCurrentPlayer?: boolean;
  user: LeaderboardEntryUser;
}

export interface LeaderboardView {
  definition: AppLeaderboardDefinition;
  top: LeaderboardEntry[];
  player: AppLeaderboardPlayerSummary | null;
  playerEntry: LeaderboardEntry | null;
  aroundPlayer: LeaderboardEntry[];
}

export interface ListAchievementsRequest {
  includeHiddenDefinitions?: boolean;
  includeRetired?: boolean;
}

export interface ListAchievementsResponse {
  achievements: AchievementView[];
}

export interface GetAchievementResponse {
  achievement: AchievementView;
}

export interface UnlockAchievementResponse {
  accepted: true;
  changed: boolean;
  unlocked: boolean;
  progress: number;
  unlockedAt: string | null;
}

export interface SetAchievementProgressRequest {
  progress: number;
}

export interface SetAchievementProgressResponse {
  accepted: true;
  changed: boolean;
  unlocked: boolean;
  progress: number;
  unlockedAt: string | null;
}

export interface ListLeaderboardsRequest {
  includeRetired?: boolean;
}

export interface ListLeaderboardsResponse {
  leaderboards: LeaderboardSummary[];
}

export interface GetLeaderboardRequest {
  top?: number;
  aroundMe?: number;
  includeRetired?: boolean;
}

export interface GetLeaderboardResponse {
  leaderboard: LeaderboardView;
}

export interface SubmitLeaderboardScoreRequest {
  score: number;
}

export interface SubmitLeaderboardScoreResponse {
  accepted: true;
  improved: boolean;
  previousBestScore: number | null;
  bestScore: number;
  rank: number | null;
  bestScoreAt: string;
}

export interface PlayerMetaAppSummary {
  id: number;
  name: string;
  displayName: string;
  creatorUsername: string;
  type: AppType;
  iconUrl: string | null;
}

export interface MyAchievementAppSection {
  app: PlayerMetaAppSummary;
  achievements: AchievementView[];
}

export interface MyLeaderboardAppSection {
  app: PlayerMetaAppSummary;
  leaderboards: LeaderboardSummary[];
}

export interface MyAchievementsResponse {
  apps: MyAchievementAppSection[];
}

export interface MyLeaderboardsResponse {
  apps: MyLeaderboardAppSection[];
}

export interface AdminPlayerMetaUserSummary {
  id: number;
  username: string;
  displayName: string;
}

export interface AdminAppPlayerMetaResponse {
  app: PlayerMetaAppSummary;
  achievements: AchievementView[];
  leaderboards: LeaderboardSummary[];
}

export interface AdminAppPlayerMetaUserResponse {
  app: PlayerMetaAppSummary;
  user: AdminPlayerMetaUserSummary;
  achievements: AchievementView[];
  leaderboards: LeaderboardSummary[];
}

export const ADMIN_ACHIEVEMENT_MUTATION_ACTION_VALUES = ['grant', 'revoke', 'reset'] as const;
export type AdminAchievementMutationAction = (typeof ADMIN_ACHIEVEMENT_MUTATION_ACTION_VALUES)[number];

export interface AdminMutateAchievementStateRequest {
  action: AdminAchievementMutationAction;
}

export interface AdminMutateAchievementStateResponse {
  achievement: AchievementView;
}

export const ADMIN_LEADERBOARD_MUTATION_ACTION_VALUES = ['reset', 'remove'] as const;
export type AdminLeaderboardMutationAction = (typeof ADMIN_LEADERBOARD_MUTATION_ACTION_VALUES)[number];

export interface AdminMutateLeaderboardScoreRequest {
  action: AdminLeaderboardMutationAction;
}

export interface AdminMutateLeaderboardScoreResponse {
  leaderboard: LeaderboardSummary;
}

export interface AdminRetirePlayerMetaDefinitionResponse {
  success: true;
}

export function isPlayerMetaKey(value: unknown): value is string {
  return typeof value === 'string' && PLAYER_META_KEY_REGEX.test(value.trim());
}

export function parsePlayerMetaDefinitionStatus(value: unknown): PlayerMetaDefinitionStatus | null {
  if (typeof value !== 'string') {
    return null;
  }
  const normalized = value.trim().toUpperCase();
  return (PLAYER_META_DEFINITION_STATUS_VALUES as readonly string[]).includes(normalized)
    ? (normalized as PlayerMetaDefinitionStatus)
    : null;
}

export function parseAppAchievementKind(value: unknown): AppAchievementKind | null {
  if (typeof value !== 'string') {
    return null;
  }
  const normalized = value.trim().toUpperCase();
  return (APP_ACHIEVEMENT_KIND_VALUES as readonly string[]).includes(normalized)
    ? (normalized as AppAchievementKind)
    : null;
}

export function parseAppLeaderboardScoreType(value: unknown): AppLeaderboardScoreType | null {
  if (typeof value !== 'string') {
    return null;
  }
  const normalized = value.trim().toUpperCase();
  return (APP_LEADERBOARD_SCORE_TYPE_VALUES as readonly string[]).includes(normalized)
    ? (normalized as AppLeaderboardScoreType)
    : null;
}

export function parseAppLeaderboardSort(value: unknown): AppLeaderboardSort | null {
  if (typeof value !== 'string') {
    return null;
  }
  const normalized = value.trim().toUpperCase();
  return (APP_LEADERBOARD_SORT_VALUES as readonly string[]).includes(normalized)
    ? (normalized as AppLeaderboardSort)
    : null;
}

export function parseAdminAchievementMutationAction(value: unknown): AdminAchievementMutationAction | null {
  if (typeof value !== 'string') {
    return null;
  }
  const normalized = value.trim().toLowerCase();
  return (ADMIN_ACHIEVEMENT_MUTATION_ACTION_VALUES as readonly string[]).includes(normalized)
    ? (normalized as AdminAchievementMutationAction)
    : null;
}

export function parseAdminLeaderboardMutationAction(value: unknown): AdminLeaderboardMutationAction | null {
  if (typeof value !== 'string') {
    return null;
  }
  const normalized = value.trim().toLowerCase();
  return (ADMIN_LEADERBOARD_MUTATION_ACTION_VALUES as readonly string[]).includes(normalized)
    ? (normalized as AdminLeaderboardMutationAction)
    : null;
}

export function isSafeNonNegativeInteger(value: unknown): value is number {
  return Number.isSafeInteger(value) && Number(value) >= 0;
}

export function isSafePositiveInteger(value: unknown): value is number {
  return Number.isSafeInteger(value) && Number(value) > 0;
}

export function isValidLeaderboardDefinitionCombination(
  scoreType: AppLeaderboardScoreType,
  sort: AppLeaderboardSort,
): boolean {
  return (
    (scoreType === 'INTEGER' && sort === 'DESC')
    || (scoreType === 'TIME_MS' && sort === 'ASC')
  );
}

export function computeAchievementProgressPercent(progress: number, maxProgress: number): number {
  if (!Number.isSafeInteger(progress) || progress < 0) {
    throw new Error('invalid_progress_value');
  }
  if (!Number.isSafeInteger(maxProgress) || maxProgress <= 0) {
    throw new Error('invalid_max_progress_value');
  }
  const clamped = Math.min(progress, maxProgress);
  return Math.floor((clamped / maxProgress) * 100);
}

export function formatLeaderboardScore(
  score: number,
  scoreType: AppLeaderboardScoreType,
  unitLabel?: string,
): string {
  if (!Number.isSafeInteger(score) || score < 0) {
    throw new Error('invalid_score_value');
  }
  if (scoreType === 'TIME_MS') {
    if (score <= 0) {
      throw new Error('invalid_time_score_value');
    }
    const totalMilliseconds = score;
    const minutes = Math.floor(totalMilliseconds / 60_000);
    const seconds = Math.floor((totalMilliseconds % 60_000) / 1_000);
    const milliseconds = totalMilliseconds % 1_000;
    return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}.${String(milliseconds).padStart(3, '0')}`;
  }
  const formatted = new Intl.NumberFormat('en-US').format(score);
  return unitLabel && unitLabel.trim().length > 0 ? `${formatted} ${unitLabel.trim()}` : formatted;
}
