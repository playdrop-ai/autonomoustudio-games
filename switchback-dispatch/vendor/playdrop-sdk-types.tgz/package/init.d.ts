import type { AppMetadata, Deployment, Platform } from './types.js';
export interface InitResponse {
    appScopedAuthToken: string | null;
    runtimeSessionId?: string | null;
    host: {
        deployment: Deployment;
        platform: Platform;
        sdkVersion: string;
    };
    appMetadata: AppMetadata;
}
export interface InitConfig {
    appId: number | null;
    appName: string;
    creatorUsername: string;
    apiServerUrl: string;
    realtimeServerUrl: string;
    assetsServerUrl: string;
    webAppUrl: string;
    localAssetStoreUrl: string | null;
}
export declare function resetInitState(): void;
export declare function setInitConfig(config: InitConfig): void;
export declare function getInitConfig(): InitConfig | null;
export declare function setInitResponse(response: InitResponse): void;
export declare function getInitResponse(): InitResponse | null;
export declare function getAppId(): number | null;
