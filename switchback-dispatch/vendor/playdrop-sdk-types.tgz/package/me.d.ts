import type { MeInfo } from '@playdrop/web-bridge';
import type { MeAPI } from './types.js';
export declare function applyHostMeSnapshot(meInfo: MeInfo): void;
export declare function hydrateAuthenticatedMeState(): Promise<void>;
export declare const me: MeAPI;
export declare function resetMe(): void;
