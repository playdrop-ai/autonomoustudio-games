import { createApiClient } from '@playdrop/api-client';
import type { AchievementsAPI, LeaderboardsAPI } from './types.js';
export declare const achievements: AchievementsAPI;
export declare const leaderboards: LeaderboardsAPI;
export declare const __test__: {
    setApiClientFactory(fn: typeof createApiClient): void;
    resetApiClientFactory(): void;
    resetState(): void;
};
