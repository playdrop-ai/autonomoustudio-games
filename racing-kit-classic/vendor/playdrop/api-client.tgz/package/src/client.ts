/* eslint-disable max-lines -- Central API client surface stays aggregated in one factory module by design. */
import type {
  AppleOAuthHandoffExchangeRequest,
  AppleOAuthHandoffExchangeResponse,
  AppleOAuthLinkStartRequest,
  AppleOAuthLinkStartResponse,
  ApplePushDeviceRequest,
  ApplePushDeviceStatusResponse,
  ApiKeyLoginRequest,
  CliApiKeyStatusResponse,
  CliLoginApproveRequest,
  CliLoginApproveResponse,
  CliLoginPollRequest,
  CliLoginPollResponse,
  CliLoginStartResponse,
  CliLoginStatusResponse,
  CliWebLaunchStartRequest,
  CliWebLaunchStartResponse,
  CompleteXSignupRequest,
  CompleteXSignupResponse,
  DeleteMyAccountRequest,
  DeleteMyAccountResponse,
  LoginRequest,
  LoginResponse,
  LogoutResponse,
  PrivacyExportResponse,
  RegisterRequest,
  RegisterResponse,
  StarterProfileAssetsResponse,
  CreateAppRequest,
  CreateAppResponse,
  UpdateAppRequest,
  AdminUpdateAppRequest,
  UpdateAppResponse,
  AppsListResponse,
  AppListSort,
  AppBrowseRequest,
  AppDetailRequest,
  AppDetailResponse,
  AppMoreCollectionKey,
  AppMoreCollectionPage,
  AppMoreCollectionRequest,
  AppMoreCollectionsRequest,
  AppMoreCollectionsResponse,
  CreatorAppsBrowseRequest,
  AppRuntimeAssetsResponse,
  InitializeAppUploadRequest,
  InitializeAppUploadResponse,
  UploadAppSessionFileResponse,
  UploadAppSessionOwnedAssetResponse,
  FinalizeAppUploadResponse,
  AbortAppUploadResponse,
  MyAppsResponse,
  BootstrapResponse,
  SetProfileAssetRequest,
  SetProfileAssetResponse,
  MeResponse,
  UserDetailResponse,
  UsersListResponse,
  CreateUserRequest,
  CreateUserResponse,
  UpdateAdminUserRequest,
  RemixScaffoldResponse,
  TemplateScaffoldResponse,
  HomeResponse,
  HomeCollectionPageResponse,
  FetchHomeOptions,
  DeleteAppResponse,
  AppType,
  AppAccessTokenResponse,
  DevAppAccessTokenResponse,
  DevPlayerResetResponse,
  AppLogEntryRequest,
  AppLogEntryResponse,
  AppAchievementCatalogueDefinition,
  ClaimFreeCreditRewardResponse,
  SubmitFeedbackRequest,
  SubmitFeedbackResponse,
  FeedbackListResponse,
  DeleteFeedbackResponse,
  ShopResponse,
  AdInterstitialShowResponse,
  AdLoadResponse,
  AdShowRequest,
  AdRewardedShowResponse,
  AssetPurchaseRequest,
  BoostActivationRequest,
  BoostBalanceResponse,
  BoostHistoryResponse,
  BoostPurchaseRequest,
  BoostPurchaseResponse,
  BoostReportQuery,
  BoostReportResponse,
  BoostStatusResponse,
  AdLoadRequest,
  CreditPackCheckoutSessionRequest,
  PurchaseResponse,
  CreditPackCheckoutSessionResponse,
  CreditPackCheckoutStatusResponse,
  CreatorEarningsResponse,
  TransactionsResponse,
  CreditPacksResponse,
  CreditPackResponse,
  PaymentProvider,
  PaymentStatus,
  AdminPaymentsListResponse,
  AdminPaymentDetailResponse,
  AdminRefundPaymentRequest,
  IapPurchaseRequest,
  IapPurchaseResponse,
  IapReceiptsResponse,
  IapReceiptListParams,
  IapReceiptResponse,
  AdminCreditTransactionsResponse,
  AiGenerationsResponse,
  AiGenerationDetailResponse,
  OwnedProfileAssetsResponse,
  SavedItemKind,
  LikedItemMutationResponse,
  SavedItemMutationResponse,
  LibraryCategory,
  LibrarySort,
  LibraryResponse,
  EngagementEventType,
  EngagementTargetKind,
  TrackEngagementEventRequest,
  TrackEngagementEventResponse,
  CreatorFollowMutationResponse,
  ContentCommentsResponse,
  CreateContentCommentRequest,
  CreateContentCommentResponse,
  FollowingSort,
  FollowingCreatorsResponse,
  FollowingFeedSection,
  FollowingFeedResponse,
  DeleteContentCommentResponse,
  NotificationStatus,
  NotificationsResponse,
  NotificationReadResponse,
  PushSubscriptionMutationResponse,
  AdminUserResponse,
  DeleteAdminUserResponse,
  BatchCreateUsersResponse,
  UpsertWebPushSubscriptionRequest,
  UpdateProfileRequest,
  UpdateProfileResponse,
  WebPushConfigResponse,
  WebPushSubscriptionStatusResponse,
  ChangePasswordRequest,
  ChangePasswordResponse,
  UpgradeToCreatorResponse,
  UnlinkXResponse,
  UnlinkGoogleResponse,
  GooglePendingSignupResponse,
  XPendingSignupResponse,
  GoogleOneTapExchangeRequest,
  GoogleOneTapExchangeResponse,
  UsernameAvailableResponse,
  CompleteGoogleSignupRequest,
  CompleteGoogleSignupResponse,
  GoogleAppleLinkRequest,
  GoogleAppleLinkResponse,
  GoogleAppleSignInRequest,
  GoogleAppleSignInResponse,
  AdminAppPlayerMetaResponse,
  AdminAppPlayerMetaUserResponse,
  AdminAppVersionReviewsListResponse,
  AdminClaimNextAppVersionReviewResponse,
  AdminCreateAppVersionReviewPublicCommentRequest,
  AdminCreateAppVersionReviewPublicCommentResponse,
  AdminMutateAchievementStateRequest,
  AdminMutateAchievementStateResponse,
  AdminMutateLeaderboardScoreRequest,
  AdminMutateLeaderboardScoreResponse,
  AdminRetirePlayerMetaDefinitionResponse,
  AdminUpdateAppVersionReviewRequest,
  AdminUpdateAppVersionReviewResponse,
  CreateCliApiKeyResponse,
  GetAchievementResponse,
  GetLeaderboardResponse,
  ListAchievementsResponse,
  ListLeaderboardsResponse,
  MyAchievementsResponse,
  MyLeaderboardsResponse,
  SetAchievementProgressRequest,
  SetAchievementProgressResponse,
  SubmitLeaderboardScoreRequest,
  SubmitLeaderboardScoreResponse,
  UnlockAchievementResponse,
  ReviewState,
  AppVersionVisibility,
  AppAuthMode,
  AppControllerMode,
  AppVersionsListResponse,
  AppVersionDetailResponse,
  AppSourceBundleResponse,
  UpdateVersionResponse,
  DeleteVersionResponse,
  AppSurface,
  AssetSpecCapability,
  AdminAppsListResponse,
  AdminUpdateAppResponse,
  AssetBrowseKind,
  AssetCategory,
  AssetFormat,
  AssetVisibility,
  AssetSourceKind,
  AssetResponse,
  AssetListSort,
  AssetListResponse,
  AssetCategoriesResponse,
  AssetVersionResponse,
  AssetDetailResponse,
  AssetVersionsListResponse,
  CreateAssetVersionResponse,
  DeleteOwnedCustomAssetResponse,
  CreateAssetSpecVersionResponse,
  ListOwnedCustomAssetsResponse,
  LoadOwnedCustomAssetResponse,
  MutateOwnedCustomAssetRequest,
  MutateOwnedCustomAssetResponse,
  UpdateAssetRequest,
  UpdateAssetResponse,
  UpdateAssetVersionRequest,
  UpdateAssetVersionResponse,
  UpdateAssetSpecVersionResponse,
  DeleteAssetVersionResponse,
  DeleteAssetResponse,
  DeleteAssetSpecVersionResponse,
  DeleteAssetSpecResponse,
  AssetSourceBundleResponse,
  AssetPackResponse,
  AssetSpecAssetsListResponse,
  AssetSpecAppsListResponse,
  AssetSpecDetailResponse,
  AssetSpecListSort,
  AssetSpecListResponse,
  AssetSpecResponse,
  AssetSpecVersionResponseEnvelope,
  AssetSpecVersionResponse,
  AssetSpecVersionsListResponse,
  AppLeaderboardCatalogueDefinition,
  AssetPackSourceBundleResponse,
  AssetPackListResponse,
  AssetPackVersionResponse,
  AssetPackDetailResponse,
  AssetPackVersionsListResponse,
  InitializeAssetPackUploadRequest,
  InitializeAssetPackUploadResponse,
  UploadAssetPackSessionAssetResponse,
  UploadAssetPackSessionMediaResponse,
  FinalizeAssetPackUploadResponse,
  AbortAssetPackUploadResponse,
  UpdateAssetPackRequest,
  UpdateAssetPackResponse,
  UpdateAssetPackVersionRequest,
  UpdateAssetPackVersionResponse,
  DeleteAssetPackVersionResponse,
  DeleteAssetPackResponse,
  BatchUpsertNodeRelationsRequest,
  BatchUpsertNodeRelationsResponse,
  ContentRemixRelationsResponse,
  SearchRequest,
  SearchResponse,
  SearchSuggestRequest,
  SearchSuggestResponse,
  SearchAssetType,
  SearchKind,
  SearchMode,
  AdminTagGroupResponse,
  AdminTagGroupsResponse,
  AdminTagResponse,
  CreateTagGroupRequest,
  CreateTagRequest,
  TagDirectoryResponse,
  TagDetailResponse,
  TagGroupDetailResponse,
  TagGroupSort,
  TagListResponse,
  UpdateTagGroupRequest,
  UpdateTagRequest,
  FreeCreditsResponse,
  InvitePreviewResponse,
  MyInviteCodeResponse,
} from '@playdrop/types';
import {
  APP_LAUNCH_CONTEXT_VALUES,
  FOLLOWING_FEED_SECTION_VALUES,
  FOLLOWING_SORT_VALUES,
  ENGAGEMENT_EVENT_TYPE_VALUES,
  ENGAGEMENT_TARGET_KIND_VALUES,
  LIBRARY_CATEGORY_VALUES,
  LIBRARY_SORT_VALUES,
  NOTIFICATION_STATUS_VALUES,
  SAVED_ITEM_KIND_VALUES,
  SEARCH_ASSET_TYPE_VALUES,
  SEARCH_KIND_VALUES,
  SEARCH_MODE_VALUES,
} from '@playdrop/types';
import { buildMeApiClientMethods } from './domains/me.js';
import { buildSearchApiClientMethods } from './domains/search.js';
import { buildTagsApiClientMethods } from './domains/tags.js';
import { buildAppsApiClientMethods } from './domains/apps.js';
import { buildAssetsApiClientMethods } from './domains/assets.js';
import { buildAssetPacksApiClientMethods } from './domains/asset-packs.js';
import { buildAuthApiClientMethods } from './domains/auth.js';
import { buildCommentsApiClientMethods } from './domains/comments.js';
import { buildPaymentsApiClientMethods } from './domains/payments.js';
import { buildAdminApiClientMethods } from './domains/admin.js';
import { buildAiApiClientMethods } from './domains/ai.js';
import { buildFreeCreditsApiClientMethods } from './domains/free-credits.js';
import { buildPlayerMetaApiClientMethods } from './domains/player-meta.js';
import {
  createBaseUrlResolver,
  createRequestExecutor,
  parseResponseBody,
  resolveRequestTimeoutMs,
  resolveUrl,
} from './core/request.js';
import { handleApiError } from './core/errors.js';

export interface HttpMethod {
  GET: 'GET';
  POST: 'POST';
  PUT: 'PUT';
  PATCH: 'PATCH';
  DELETE: 'DELETE';
}

export interface ApiRequest {
  method: keyof HttpMethod;
  path: string;
  body?: unknown;
  headers?: Record<string, string>;
}

export interface ApiResponse<T = unknown> {
  status: number;
  body: T;
  headers: Headers;
}

export interface ApiClientConfig {
  baseUrl?: string;
  tokenProvider?: () => string | null | Promise<string | null>;
  fetchImpl?: typeof fetch;
  clientHeaders?: () => Record<string, string>;
  requestTimeoutMs?: number;
  includeBrowserCredentials?: boolean;
}

type UploadAssetVersionFile = {
  file: File | Blob;
  fieldName?: string;
  filename?: string;
};

type UploadAssetVersionBaseOptions = {
  visibility?: AssetVisibility;
  sourceKind?: AssetSourceKind;
  sourceAppVersionId?: number;
  runtimeKey?: string;
  sourceGenerationId?: string;
  remixRef?: string;
  tags?: string[];
  clearTags?: boolean;
  shopListed?: boolean;
  shopPriceCredits?: number;
  displayName?: string;
  description?: string;
  files: UploadAssetVersionFile[];
};

export type UploadBuiltInAssetVersionOptions = UploadAssetVersionBaseOptions & {
  category: AssetCategory;
  subcategory: string;
  format: AssetFormat;
  assetSpec?: never;
};

export type UploadCustomAssetVersionOptions = UploadAssetVersionBaseOptions & {
  assetSpec: string;
  category?: never;
  subcategory?: never;
  format?: never;
};

export type UploadAssetVersionOptions =
  | UploadBuiltInAssetVersionOptions
  | UploadCustomAssetVersionOptions;

export interface UploadAssetSpecVersionOptions {
  version: string;
  displayName?: string;
  description?: string;
  visibility?: 'PUBLIC' | 'PRIVATE';
  validationKind?: 'NONE' | 'JSON_SCHEMA';
  status?: 'ACTIVE' | 'DEPRECATED' | 'RETRACTED';
  releaseNotes?: string;
  successorVersion?: string;
  symbol: File | Blob;
  contract: File | Blob;
  documentation?: File | Blob;
}

export interface UploadAssetPackSessionAssetOptions {
  files: Array<{
    file: File | Blob;
    fieldName?: string;
    filename?: string;
  }>;
}

export interface UploadAssetPackSessionMediaOptions {
  file: File | Blob;
  filename?: string;
}

export interface UploadAppSessionFileOptions {
  file: File | Blob;
  filename?: string;
}

export interface UploadAppSessionOwnedAssetOptions {
  files: Array<{
    file: File | Blob;
    fieldName?: string;
    filename?: string;
  }>;
}

export interface ApiClient {
  // Core methods
  request<T = unknown>(request: ApiRequest): Promise<ApiResponse<T>>;

  // Authentication
  login(request: LoginRequest): Promise<LoginResponse>;
  loginWithApiKey(request: ApiKeyLoginRequest): Promise<LoginResponse>;
  startCliLogin(): Promise<CliLoginStartResponse>;
  pollCliLogin(request: CliLoginPollRequest): Promise<CliLoginPollResponse>;
  fetchCliLoginStatus(requestId: string): Promise<CliLoginStatusResponse>;
  approveCliLogin(request: CliLoginApproveRequest): Promise<CliLoginApproveResponse>;
  startCliWebLaunch(request: CliWebLaunchStartRequest): Promise<CliWebLaunchStartResponse>;
  register(request: RegisterRequest): Promise<RegisterResponse>;
  fetchStarterProfileAssets(): Promise<StarterProfileAssetsResponse>;
  logout(): Promise<LogoutResponse>;
  me(): Promise<MeResponse>;
  updateProfile(request: UpdateProfileRequest): Promise<UpdateProfileResponse>;
  changePassword(request: ChangePasswordRequest): Promise<ChangePasswordResponse>;
  exportPrivacyData(): Promise<PrivacyExportResponse>;
  deleteAccount(request: DeleteMyAccountRequest): Promise<DeleteMyAccountResponse>;
  upgradeToCreator(): Promise<UpgradeToCreatorResponse>;
  unlinkX(): Promise<UnlinkXResponse>;
  unlinkGoogle(): Promise<UnlinkGoogleResponse>;
  createAppleOAuthLinkStart(request: AppleOAuthLinkStartRequest): Promise<AppleOAuthLinkStartResponse>;
  exchangeAppleOAuthHandoff(request: AppleOAuthHandoffExchangeRequest): Promise<AppleOAuthHandoffExchangeResponse>;
  signInWithGoogleApple(request: GoogleAppleSignInRequest): Promise<GoogleAppleSignInResponse>;
  linkGoogleApple(request: GoogleAppleLinkRequest): Promise<GoogleAppleLinkResponse>;
  fetchGooglePendingSignup(token: string): Promise<GooglePendingSignupResponse>;
  fetchXPendingSignup(token: string): Promise<XPendingSignupResponse>;
  fetchPublicFreeCredits(): Promise<FreeCreditsResponse>;
  fetchFreeCredits(): Promise<FreeCreditsResponse>;
  claimFreeCreditReward(rewardId: number): Promise<ClaimFreeCreditRewardResponse>;
  fetchInvitePreview(inviteCode: string): Promise<InvitePreviewResponse>;
  fetchMyInviteCode(): Promise<MyInviteCodeResponse>;
  submitMyInviteCode(inviteCode: string): Promise<MyInviteCodeResponse>;
  checkUsernameAvailable(username: string): Promise<UsernameAvailableResponse>;
  completeGoogleSignup(request: CompleteGoogleSignupRequest): Promise<CompleteGoogleSignupResponse>;
  completeXSignup(request: CompleteXSignupRequest): Promise<CompleteXSignupResponse>;
  exchangeGoogleOneTapCredential(request: GoogleOneTapExchangeRequest): Promise<GoogleOneTapExchangeResponse>;
  fetchCliApiKeyStatus(): Promise<CliApiKeyStatusResponse>;
  createCliApiKey(): Promise<CreateCliApiKeyResponse>;
  fetchUserById(userId: number): Promise<UserDetailResponse>;
  fetchUserByUsername(username: string): Promise<UserDetailResponse>;
  fetchOwnedProfileAssets(): Promise<OwnedProfileAssetsResponse>;
  saveItem(kind: SavedItemKind, creatorUsername: string, itemName: string): Promise<SavedItemMutationResponse>;
  unsaveItem(kind: SavedItemKind, creatorUsername: string, itemName: string): Promise<SavedItemMutationResponse>;
  likeItem(kind: SavedItemKind, creatorUsername: string, itemName: string): Promise<LikedItemMutationResponse>;
  unlikeItem(kind: SavedItemKind, creatorUsername: string, itemName: string): Promise<LikedItemMutationResponse>;
  fetchContentComments(kind: SavedItemKind, creatorUsername: string, itemName: string): Promise<ContentCommentsResponse>;
  fetchAppRelated(creatorUsername: string, appName: string): Promise<ContentRemixRelationsResponse>;
  fetchAssetRelated(creatorUsername: string, assetName: string): Promise<ContentRemixRelationsResponse>;
  fetchAssetPackRelated(creatorUsername: string, packName: string): Promise<ContentRemixRelationsResponse>;
  createContentComment(
    kind: SavedItemKind,
    creatorUsername: string,
    itemName: string,
    request: CreateContentCommentRequest,
  ): Promise<CreateContentCommentResponse>;
  likeContentComment(commentId: number): Promise<LikedItemMutationResponse>;
  unlikeContentComment(commentId: number): Promise<LikedItemMutationResponse>;
  deleteContentComment(commentId: number): Promise<DeleteContentCommentResponse>;
  trackEngagementEvent(request: TrackEngagementEventRequest): Promise<TrackEngagementEventResponse>;
  fetchLibrary(options?: { category?: LibraryCategory; sort?: LibrarySort }): Promise<LibraryResponse>;
  followCreator(creatorUsername: string): Promise<CreatorFollowMutationResponse>;
  unfollowCreator(creatorUsername: string): Promise<CreatorFollowMutationResponse>;
  fetchFollowingCreators(options?: { sort?: FollowingSort }): Promise<FollowingCreatorsResponse>;
  fetchFollowingFeed(options: { section: FollowingFeedSection; limit?: number }): Promise<FollowingFeedResponse>;
  fetchNotifications(options?: { status?: NotificationStatus; limit?: number; offset?: number }): Promise<NotificationsResponse>;
  markNotificationRead(notificationId: number): Promise<NotificationReadResponse>;
  markAllNotificationsRead(): Promise<NotificationReadResponse>;
  fetchWebPushConfig(): Promise<WebPushConfigResponse>;
  fetchWebPushSubscriptionStatus(request: UpsertWebPushSubscriptionRequest): Promise<WebPushSubscriptionStatusResponse>;
  upsertWebPushSubscription(request: UpsertWebPushSubscriptionRequest): Promise<PushSubscriptionMutationResponse>;
  deleteWebPushSubscription(request: UpsertWebPushSubscriptionRequest): Promise<PushSubscriptionMutationResponse>;
  fetchApplePushDeviceStatus(request: ApplePushDeviceRequest): Promise<ApplePushDeviceStatusResponse>;
  upsertApplePushDevice(request: ApplePushDeviceRequest): Promise<PushSubscriptionMutationResponse>;
  deleteApplePushDevice(request: ApplePushDeviceRequest): Promise<PushSubscriptionMutationResponse>;
  search(request: SearchRequest): Promise<SearchResponse>;
  suggestSearch(request: SearchSuggestRequest): Promise<SearchSuggestResponse>;
  fetchTagDirectory(options?: {
    limit?: number;
    offset?: number;
    tagLimit?: number;
  }): Promise<TagDirectoryResponse>;
  fetchTags(options?: {
    targetKind?: SavedItemKind;
    groupSlug?: string;
    limit?: number;
    offset?: number;
  }): Promise<TagListResponse>;
  fetchTag(groupSlug: string, tagSlug: string): Promise<TagDetailResponse>;
  fetchTagGroup(
    groupSlug: string,
    options?: {
      targetKind?: SavedItemKind;
      appType?: string;
      sort?: TagGroupSort;
      limit?: number;
      offset?: number;
    },
  ): Promise<TagGroupDetailResponse>;
  fetchAdminTagGroups(): Promise<AdminTagGroupsResponse>;
  createAdminTagGroup(request: CreateTagGroupRequest): Promise<AdminTagGroupResponse>;
  updateAdminTagGroup(groupSlug: string, request: UpdateTagGroupRequest): Promise<AdminTagGroupResponse>;
  createAdminTag(groupSlug: string, request: CreateTagRequest): Promise<AdminTagResponse>;
  updateAdminTag(groupSlug: string, tagSlug: string, request: UpdateTagRequest): Promise<AdminTagResponse>;

  // Apps
  fetchApps(options?: AppBrowseRequest): Promise<AppsListResponse>;
  fetchAppsByType(type: AppType, options?: AppBrowseRequest): Promise<AppsListResponse>;
  fetchAppsByCreator(
    creatorUsername: string,
    options?: CreatorAppsBrowseRequest,
  ): Promise<AppsListResponse>;
  fetchAppBySlug(
    creatorUsername: string,
    appName: string,
    options?: AppDetailRequest,
  ): Promise<AppDetailResponse>;
  fetchAppMoreCollections(
    creatorUsername: string,
    appName: string,
    options?: AppMoreCollectionsRequest,
  ): Promise<AppMoreCollectionsResponse>;
  fetchAppMoreCollectionPage(
    creatorUsername: string,
    appName: string,
    collectionKey: AppMoreCollectionKey,
    options?: AppMoreCollectionRequest,
  ): Promise<AppMoreCollectionPage>;
  requestAppAccessToken(appId: number): Promise<AppAccessTokenResponse>;
  requestDevAppAccessToken(appId: number, slot: number): Promise<DevAppAccessTokenResponse>;
  resetDevPlayer(appId: number, slot: number): Promise<DevPlayerResetResponse>;
  resetAllDevPlayers(appId: number): Promise<DevPlayerResetResponse>;
  sendAppLog(appId: number, entry: AppLogEntryRequest): Promise<AppLogEntryResponse>;
  listAchievements(
    appId: number,
    options?: { includeHiddenDefinitions?: boolean; includeRetired?: boolean },
  ): Promise<ListAchievementsResponse>;
  getAchievement(
    appId: number,
    key: string,
    options?: { includeHiddenDefinitions?: boolean; includeRetired?: boolean },
  ): Promise<GetAchievementResponse>;
  unlockAchievement(appId: number, key: string): Promise<UnlockAchievementResponse>;
  setAchievementProgressAtLeast(
    appId: number,
    key: string,
    request: SetAchievementProgressRequest,
  ): Promise<SetAchievementProgressResponse>;
  listLeaderboards(appId: number, options?: { includeRetired?: boolean }): Promise<ListLeaderboardsResponse>;
  getLeaderboard(
    appId: number,
    key: string,
    options?: { top?: number; aroundMe?: number; includeRetired?: boolean },
  ): Promise<GetLeaderboardResponse>;
  submitLeaderboardScore(
    appId: number,
    key: string,
    request: SubmitLeaderboardScoreRequest,
  ): Promise<SubmitLeaderboardScoreResponse>;
  fetchMyAchievements(): Promise<MyAchievementsResponse>;
  fetchMyLeaderboards(): Promise<MyLeaderboardsResponse>;
  fetchMyApps(options?: { limit?: number; offset?: number; type?: AppType }): Promise<MyAppsResponse>;
  createApp(creatorUsername: string, request: CreateAppRequest): Promise<CreateAppResponse>;
  updateApp(creatorUsername: string, name: string, request: UpdateAppRequest): Promise<UpdateAppResponse>;
  createAssetVersion(
    creatorUsername: string,
    name: string,
    options: UploadAssetVersionOptions,
  ): Promise<CreateAssetVersionResponse>;
  listOwnedCustomAssets(
    appId: number,
    options: { assetSpecRef: string; limit?: number; offset?: number },
  ): Promise<ListOwnedCustomAssetsResponse>;
  loadOwnedCustomAsset(
    appId: number,
    assetName: string,
    revision: string | number,
    options: { assetSpecRef: string },
  ): Promise<LoadOwnedCustomAssetResponse>;
  saveOwnedCustomAsset(
    appId: number,
    request: MutateOwnedCustomAssetRequest,
  ): Promise<MutateOwnedCustomAssetResponse>;
  deleteOwnedCustomAsset(
    appId: number,
    assetName: string,
    options: { assetSpecRef: string; revision?: string | number },
  ): Promise<DeleteOwnedCustomAssetResponse>;
  createAssetSpecVersion(
    creatorUsername: string,
    name: string,
    options: UploadAssetSpecVersionOptions,
  ): Promise<CreateAssetSpecVersionResponse>;
  listAssetCategories(): Promise<AssetCategoriesResponse>;
  listAssets(options?: {
    limit?: number;
    offset?: number;
    category?: AssetCategory;
    subcategory?: string;
    kind?: AssetBrowseKind;
    assetSpec?: string;
    assetSpecOwner?: string;
    assetSpecName?: string;
    sort?: AssetListSort;
    tags?: string[];
  }): Promise<AssetListResponse>;
  listAssetsForCreator(
    creatorUsername: string,
    options?: {
      limit?: number;
      offset?: number;
      category?: AssetCategory;
      subcategory?: string;
      kind?: AssetBrowseKind;
      assetSpec?: string;
      assetSpecOwner?: string;
      assetSpecName?: string;
      sort?: AssetListSort;
      tags?: string[];
    }
  ): Promise<AssetListResponse>;
  listAssetSpecs(options?: { limit?: number; offset?: number; sort?: AssetSpecListSort }): Promise<AssetSpecListResponse>;
  listAssetSpecsForCreator(
    creatorUsername: string,
    options?: { limit?: number; offset?: number; sort?: AssetSpecListSort },
  ): Promise<AssetSpecListResponse>;
  fetchAssetSpecBySlug(creatorUsername: string, name: string): Promise<AssetSpecDetailResponse>;
  listAssetSpecVersions(
    creatorUsername: string,
    name: string,
    options?: { limit?: number; offset?: number },
  ): Promise<AssetSpecVersionsListResponse>;
  fetchAssetSpecVersion(
    creatorUsername: string,
    name: string,
    version: string,
  ): Promise<AssetSpecVersionResponseEnvelope>;
  listAssetsByAssetSpec(
    creatorUsername: string,
    name: string,
    options?: { limit?: number; offset?: number; sort?: AssetListSort },
  ): Promise<AssetSpecAssetsListResponse>;
  listAppsByAssetSpec(
    creatorUsername: string,
    name: string,
    options?: { limit?: number; offset?: number },
  ): Promise<AssetSpecAppsListResponse>;
  updateAssetSpecVersion(
    creatorUsername: string,
    name: string,
    version: string,
    request: { visibility?: 'PUBLIC' | 'PRIVATE'; status?: 'ACTIVE' | 'DEPRECATED' | 'RETRACTED'; successorVersion?: string | null },
  ): Promise<UpdateAssetSpecVersionResponse>;
  deleteAssetSpecVersion(creatorUsername: string, name: string, version: string): Promise<DeleteAssetSpecVersionResponse>;
  deleteAssetSpec(creatorUsername: string, name: string): Promise<DeleteAssetSpecResponse>;
  fetchAssetBySlug(creatorUsername: string, assetName: string): Promise<AssetDetailResponse>;
  listAssetVersions(
    creatorUsername: string,
    assetName: string,
    options?: { limit?: number; offset?: number }
  ): Promise<AssetVersionsListResponse>;
  updateAsset(creatorUsername: string, name: string, request: UpdateAssetRequest): Promise<UpdateAssetResponse>;
  updateAssetVersion(
    creatorUsername: string,
    name: string,
    revision: string | number,
    request: UpdateAssetVersionRequest,
  ): Promise<UpdateAssetVersionResponse>;
  deleteAssetVersion(
    creatorUsername: string,
    name: string,
    revision: string | number,
  ): Promise<DeleteAssetVersionResponse>;
  deleteAsset(creatorUsername: string, name: string): Promise<DeleteAssetResponse>;
  downloadAssetFile(
    creatorUsername: string,
    assetName: string,
    revision: string | number,
    options?: { role?: string },
  ): Promise<Blob>;
  downloadAssetSource(
    creatorUsername: string,
    assetName: string,
    revision: string | number,
  ): Promise<{ blob: Blob; metadata: AssetSourceBundleResponse }>;
  initializeAssetPackUpload(
    creatorUsername: string,
    name: string,
    request: InitializeAssetPackUploadRequest,
  ): Promise<InitializeAssetPackUploadResponse>;
  uploadAssetPackSessionAsset(
    creatorUsername: string,
    name: string,
    sessionId: string,
    uploadKey: string,
    options: UploadAssetPackSessionAssetOptions,
  ): Promise<UploadAssetPackSessionAssetResponse>;
  uploadAssetPackSessionMedia(
    creatorUsername: string,
    name: string,
    sessionId: string,
    mediaKey: string,
    options: UploadAssetPackSessionMediaOptions,
  ): Promise<UploadAssetPackSessionMediaResponse>;
  finalizeAssetPackUpload(
    creatorUsername: string,
    name: string,
    sessionId: string,
  ): Promise<FinalizeAssetPackUploadResponse>;
  abortAssetPackUpload(
    creatorUsername: string,
    name: string,
    sessionId: string,
  ): Promise<AbortAssetPackUploadResponse>;
  listAssetPacks(
    options?: { limit?: number; offset?: number; containsCategory?: AssetCategory; containsSubcategory?: string; tags?: string[] }
  ): Promise<AssetPackListResponse>;
  listAssetPacksForCreator(
    creatorUsername: string,
    options?: { limit?: number; offset?: number; containsCategory?: AssetCategory; containsSubcategory?: string; tags?: string[] }
  ): Promise<AssetPackListResponse>;
  fetchAssetPackBySlug(creatorUsername: string, packName: string): Promise<AssetPackDetailResponse>;
  downloadAssetPackSource(
    creatorUsername: string,
    packName: string,
    version: string,
  ): Promise<{ blob: Blob; metadata: AssetPackSourceBundleResponse }>;
  downloadAssetPack(
    creatorUsername: string,
    packName: string,
    version: string,
  ): Promise<{ blob: Blob; metadata: AssetPackSourceBundleResponse }>;
  listAssetPackVersions(
    creatorUsername: string,
    packName: string,
    options?: { limit?: number; offset?: number }
  ): Promise<AssetPackVersionsListResponse>;
  updateAssetPack(creatorUsername: string, name: string, request: UpdateAssetPackRequest): Promise<UpdateAssetPackResponse>;
  updateAssetPackVersion(
    creatorUsername: string,
    name: string,
    version: string,
    request: UpdateAssetPackVersionRequest,
  ): Promise<UpdateAssetPackVersionResponse>;
  deleteAssetPackVersion(
    creatorUsername: string,
    name: string,
    version: string,
  ): Promise<DeleteAssetPackVersionResponse>;
  deleteAssetPack(creatorUsername: string, name: string): Promise<DeleteAssetPackResponse>;
  batchUpsertGraphRelations(request: BatchUpsertNodeRelationsRequest): Promise<BatchUpsertNodeRelationsResponse>;
  deleteApp(creatorUsername: string, name: string): Promise<DeleteAppResponse>;
  submitFeedback(request: SubmitFeedbackRequest): Promise<SubmitFeedbackResponse>;
  listFeedback(options?: { limit?: number; offset?: number; source?: string; userId?: number }): Promise<FeedbackListResponse>;
  deleteFeedback(id: number): Promise<DeleteFeedbackResponse>;

  // App Versions
  initializeAppUpload(
    creatorUsername: string,
    appName: string,
    request: InitializeAppUploadRequest,
  ): Promise<InitializeAppUploadResponse>;
  uploadAppSessionFile(
    creatorUsername: string,
    appName: string,
    sessionId: string,
    fileKey: string,
    options: UploadAppSessionFileOptions,
  ): Promise<UploadAppSessionFileResponse>;
  uploadAppSessionOwnedAsset(
    creatorUsername: string,
    appName: string,
    sessionId: string,
    uploadKey: string,
    options: UploadAppSessionOwnedAssetOptions,
  ): Promise<UploadAppSessionOwnedAssetResponse>;
  finalizeAppUpload(
    creatorUsername: string,
    appName: string,
    sessionId: string,
  ): Promise<FinalizeAppUploadResponse>;
  abortAppUpload(
    creatorUsername: string,
    appName: string,
    sessionId: string,
  ): Promise<AbortAppUploadResponse>;
  listAppVersions(creatorUsername: string, appName: string): Promise<AppVersionsListResponse>;
  getAppVersion(creatorUsername: string, appName: string, version: string): Promise<AppVersionDetailResponse>;
  fetchAppRuntimeAssets(creatorUsername: string, appName: string, version: string): Promise<AppRuntimeAssetsResponse>;
  downloadAppSource(
    creatorUsername: string,
    appName: string,
    version: string,
  ): Promise<{ blob: Blob; metadata: AppSourceBundleResponse }>;
  updateAppVersion(
    creatorUsername: string,
    appName: string,
    version: string,
    updates: { releaseNotes?: string | null; visibility?: AppVersionVisibility; setAsCurrent?: boolean },
  ): Promise<UpdateVersionResponse>;
  deleteAppVersion(creatorUsername: string, appName: string, version: string): Promise<DeleteVersionResponse>;

  // Credit + shop
  fetchPublicCreditShop(): Promise<ShopResponse>;
  fetchCreditShop(): Promise<ShopResponse>;
  createCreditPackCheckoutSession(
    sku: string,
    request?: CreditPackCheckoutSessionRequest,
  ): Promise<CreditPackCheckoutSessionResponse>;
  fetchCreditPackCheckoutStatus(sessionId: string): Promise<CreditPackCheckoutStatusResponse>;
  purchaseAsset(request: AssetPurchaseRequest): Promise<PurchaseResponse>;
  purchaseIap(request: IapPurchaseRequest): Promise<IapPurchaseResponse>;
  purchaseDevIap(appId: number, slot: number, request: IapPurchaseRequest): Promise<IapPurchaseResponse>;
  fetchIapReceipts(params?: IapReceiptListParams): Promise<IapReceiptsResponse>;
  cancelIapReceipt(receiptId: number): Promise<IapReceiptResponse>;
  fetchAppIapReceipts(params?: Omit<IapReceiptListParams, 'appId'>): Promise<IapReceiptsResponse>;
  consumeAppIapReceipt(receiptId: number): Promise<IapReceiptResponse>;
  grantAppIapReceipt(receiptId: number): Promise<IapReceiptResponse>;
  cancelAppIapReceipt(receiptId: number): Promise<IapReceiptResponse>;
  fetchCreditTransactions(options?: { limit?: number; offset?: number }): Promise<TransactionsResponse>;
  fetchBoostBalance(): Promise<BoostBalanceResponse>;
  purchaseBoostPack(request: BoostPurchaseRequest): Promise<BoostPurchaseResponse>;
  activateAppBoost(appId: number, request?: BoostActivationRequest): Promise<BoostStatusResponse>;
  fetchAppBoostStatus(appId: number): Promise<BoostStatusResponse>;
  fetchAppBoostHistory(appId: number, options?: { limit?: number }): Promise<BoostHistoryResponse>;
  fetchAppBoostReport(appId: number, options?: BoostReportQuery): Promise<BoostReportResponse>;
  fetchCreatorEarnings(options?: { days?: number; appId?: number }): Promise<CreatorEarningsResponse>;
  loadInterstitialAd(request: AdLoadRequest): Promise<AdLoadResponse>;
  showInterstitialAd(request: AdShowRequest): Promise<AdInterstitialShowResponse>;
  loadDevInterstitialAd(appId: number, slot: number, request: Pick<AdLoadRequest, 'viewerSurface'>): Promise<AdLoadResponse>;
  showDevInterstitialAd(appId: number, slot: number, request: AdShowRequest): Promise<AdInterstitialShowResponse>;
  loadRewardedAd(request: AdLoadRequest): Promise<AdLoadResponse>;
  showRewardedAd(request: AdShowRequest): Promise<AdRewardedShowResponse>;
  loadDevRewardedAd(appId: number, slot: number, request: Pick<AdLoadRequest, 'viewerSurface'>): Promise<AdLoadResponse>;
  showDevRewardedAd(appId: number, slot: number, request: AdShowRequest): Promise<AdRewardedShowResponse>;
  fetchAiGeneration(id: string): Promise<AiGenerationDetailResponse>;

  setSelectedProfileAsset(request: SetProfileAssetRequest): Promise<SetProfileAssetResponse>;

  // Home
  fetchHome(options?: FetchHomeOptions): Promise<HomeResponse>;
  fetchHomeGamesCollectionPage(
    collectionId: string,
    options?: { limit?: number; offset?: number },
  ): Promise<HomeCollectionPageResponse>;

  // Admin
  fetchUsers(): Promise<UsersListResponse>;
  createUser(request: CreateUserRequest): Promise<CreateUserResponse>;
  batchCreateUsersFromCsv(formData: FormData): Promise<BatchCreateUsersResponse>;
  fetchAdminUser(userId: number): Promise<AdminUserResponse>;
  updateAdminUser(userId: number, request: UpdateAdminUserRequest): Promise<AdminUserResponse>;
  deleteAdminUser(userId: number): Promise<DeleteAdminUserResponse>;
  fetchAdminApps(): Promise<AdminAppsListResponse>;
  updateAdminApp(id: number, request: AdminUpdateAppRequest): Promise<AdminUpdateAppResponse>;
  deleteAdminApp(id: number): Promise<DeleteAppResponse>;
  fetchAdminAppVersionReviews(options?: { state?: ReviewState; limit?: number; offset?: number }): Promise<AdminAppVersionReviewsListResponse>;
  claimNextAdminAppVersionReview(): Promise<AdminClaimNextAppVersionReviewResponse>;
  updateAdminAppVersionReview(versionId: number, request: AdminUpdateAppVersionReviewRequest): Promise<AdminUpdateAppVersionReviewResponse>;
  createAdminAppVersionReviewPublicComment(
    versionId: number,
    request: AdminCreateAppVersionReviewPublicCommentRequest,
  ): Promise<AdminCreateAppVersionReviewPublicCommentResponse>;
  fetchAdminAppPlayerMeta(appId: number): Promise<AdminAppPlayerMetaResponse>;
  fetchAdminAppPlayerMetaUser(appId: number, userId: number): Promise<AdminAppPlayerMetaUserResponse>;
  retireAdminAchievement(appId: number, key: string): Promise<AdminRetirePlayerMetaDefinitionResponse>;
  retireAdminLeaderboard(appId: number, key: string): Promise<AdminRetirePlayerMetaDefinitionResponse>;
  mutateAdminAchievementState(
    appId: number,
    userId: number,
    key: string,
    request: AdminMutateAchievementStateRequest,
  ): Promise<AdminMutateAchievementStateResponse>;
  mutateAdminLeaderboardScore(
    appId: number,
    userId: number,
    key: string,
    request: AdminMutateLeaderboardScoreRequest,
  ): Promise<AdminMutateLeaderboardScoreResponse>;
  fetchAdminCreditPacks(): Promise<CreditPacksResponse>;
  createAdminCreditPack(request: { sku: string; displayName: string; amount: number; costCents: number }): Promise<CreditPackResponse>;
  updateAdminCreditPack(sku: string, request: { displayName?: string; amount?: number; costCents?: number }): Promise<CreditPackResponse>;
  deleteAdminCreditPack(sku: string): Promise<{ success: boolean }>;
  syncAdminCreditPacksStripe(): Promise<CreditPacksResponse>;
  fetchAdminPayments(options?: {
    provider?: PaymentProvider;
    status?: PaymentStatus | PaymentStatus[];
    userId?: number;
    creditPackSku?: string;
    from?: string | Date;
    to?: string | Date;
    limit?: number;
    offset?: number;
  }): Promise<AdminPaymentsListResponse>;
  fetchAdminPayment(paymentId: number): Promise<AdminPaymentDetailResponse>;
  refundAdminPayment(paymentId: number, request: AdminRefundPaymentRequest): Promise<AdminPaymentDetailResponse>;
  reconcileAdminPayment(paymentId: number): Promise<AdminPaymentDetailResponse>;
  fetchAdminCreditTransactions(options?: { limit?: number; offset?: number }): Promise<AdminCreditTransactionsResponse>;
  fetchAdminAiGenerations(options?: { limit?: number; offset?: number }): Promise<AiGenerationsResponse>;
  fetchAdminAiGeneration(id: string): Promise<AiGenerationDetailResponse>;

  // Creator bootstrap & scaffolds
  fetchBootstrap(): Promise<BootstrapResponse>;
  fetchRemixScaffold(creatorUsername: string, appName: string, version?: string): Promise<RemixScaffoldResponse>;
  fetchTemplateScaffold(namespace: string, slug: string): Promise<TemplateScaffoldResponse>;
}

// eslint-disable-next-line max-lines-per-function -- The client factory intentionally exposes the full platform surface from one entry point.
export function createApiClient(config: ApiClientConfig = {}): ApiClient {
  const fetchImpl = config.fetchImpl ?? globalThis.fetch?.bind(globalThis);
  if (!fetchImpl) {
    throw new Error('api_client_missing_fetch');
  }
  const requestTimeoutMs = resolveRequestTimeoutMs(config.requestTimeoutMs);
  const includeBrowserCredentials = config.includeBrowserCredentials ?? true;
  const resolveBaseUrl = createBaseUrlResolver(config.baseUrl);
  const getClientHeaders = () => (config.clientHeaders ? config.clientHeaders() : {});

  async function resolveToken(): Promise<string | null> {
    if (config.tokenProvider) {
      const token = await config.tokenProvider();
      return token ?? null;
    }
    return null;
  }

  function buildIapQuery(params?: IapReceiptListParams): string {
    if (!params) {
      return '';
    }
    const search = new URLSearchParams();
    if (params.kind) {
      search.set('kind', params.kind);
    }
    if (params.status) {
      const statuses = Array.isArray(params.status) ? params.status : [params.status];
      if (statuses.length > 0) {
        search.set('status', statuses.join(','));
      }
    }
    if (params.from) {
      const fromValue = params.from instanceof Date ? params.from.toISOString() : params.from;
      search.set('from', fromValue);
    }
    if (params.to) {
      const toValue = params.to instanceof Date ? params.to.toISOString() : params.to;
      search.set('to', toValue);
    }
    if (typeof params.appId === 'number') {
      search.set('appId', String(params.appId));
    }
    if (typeof params.limit === 'number') {
      search.set('limit', String(params.limit));
    }
    if (typeof params.offset === 'number') {
      search.set('offset', String(params.offset));
    }
    const query = search.toString();
    return query;
  }

  function normalizeAssetRevisionInput(revision: string | number): string {
    if (typeof revision === 'number') {
      if (!Number.isInteger(revision) || revision <= 0) {
        throw new Error('invalid_asset_revision');
      }
      return String(revision);
    }
    const trimmed = revision.trim().toLowerCase();
    if (!trimmed) {
      throw new Error('invalid_asset_revision');
    }
    const numeric = trimmed.startsWith('r') ? trimmed.slice(1) : trimmed;
    const parsed = Number.parseInt(numeric, 10);
    if (!Number.isInteger(parsed) || parsed <= 0) {
      throw new Error('invalid_asset_revision');
    }
    return String(parsed);
  }

  function normalizeSemverInput(version: string): string {
    const trimmed = typeof version === 'string' ? version.trim() : '';
    if (!trimmed) {
      throw new Error('invalid_version_format');
    }
    const semverRegex = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$/;
    if (!semverRegex.test(trimmed)) {
      throw new Error('invalid_version_format');
    }
    return trimmed;
  }

  function normalizeEnumInput<T extends string>(value: string, allowed: readonly T[], errorCode: string): T {
    if (!allowed.includes(value as T)) {
      throw new Error(errorCode);
    }
    return value as T;
  }

  function normalizeSavedItemKindInput(kind: SavedItemKind): SavedItemKind {
    return normalizeEnumInput(kind, SAVED_ITEM_KIND_VALUES, 'invalid_saved_item_kind');
  }

  function normalizeEngagementEventTypeInput(eventType: EngagementEventType): EngagementEventType {
    return normalizeEnumInput(eventType, ENGAGEMENT_EVENT_TYPE_VALUES, 'invalid_engagement_event_type');
  }

  function normalizeEngagementTargetKindInput(targetKind: EngagementTargetKind): EngagementTargetKind {
    return normalizeEnumInput(targetKind, ENGAGEMENT_TARGET_KIND_VALUES, 'invalid_engagement_target_kind');
  }

  function normalizeLibraryCategoryInput(category: LibraryCategory): LibraryCategory {
    return normalizeEnumInput(category, LIBRARY_CATEGORY_VALUES, 'invalid_library_category');
  }

  function normalizeLibrarySortInput(sort: LibrarySort): LibrarySort {
    return normalizeEnumInput(sort, LIBRARY_SORT_VALUES, 'invalid_library_sort');
  }

  function normalizeFollowingSortInput(sort: FollowingSort): FollowingSort {
    return normalizeEnumInput(sort, FOLLOWING_SORT_VALUES, 'invalid_following_sort');
  }

  function normalizeFollowingFeedSectionInput(section: FollowingFeedSection): FollowingFeedSection {
    return normalizeEnumInput(section, FOLLOWING_FEED_SECTION_VALUES, 'invalid_following_feed_section');
  }

  function normalizeNotificationStatusInput(status: NotificationStatus): NotificationStatus {
    return normalizeEnumInput(status, NOTIFICATION_STATUS_VALUES, 'invalid_notification_status');
  }

  function normalizeSearchKindInput(kind: SearchKind): SearchKind {
    return normalizeEnumInput(kind, SEARCH_KIND_VALUES, 'invalid_search_kind');
  }

  function normalizeSearchModeInput(mode: SearchMode): SearchMode {
    return normalizeEnumInput(mode, SEARCH_MODE_VALUES, 'invalid_search_mode');
  }

  function normalizeSearchAssetTypeInput(assetType: SearchAssetType): SearchAssetType {
    return normalizeEnumInput(assetType, SEARCH_ASSET_TYPE_VALUES, 'invalid_search_asset_type');
  }

  function normalizePositiveIntegerInput(value: number, errorCode: string): number {
    if (!Number.isInteger(value) || value <= 0) {
      throw new Error(errorCode);
    }
    return value;
  }

  function normalizeNonNegativeIntegerInput(value: number, errorCode: string): number {
    if (!Number.isInteger(value) || value < 0) {
      throw new Error(errorCode);
    }
    return value;
  }

  function normalizeCreatorItemSlug(value: string, field: 'creator' | 'name'): string {
    const trimmed = typeof value === 'string' ? value.trim() : '';
    if (!trimmed) {
      throw new Error(field === 'creator' ? 'invalid_creator_username' : 'invalid_item_name');
    }
    return trimmed;
  }

  function normalizeWebPushSubscriptionRequest(
    requestBody: UpsertWebPushSubscriptionRequest,
  ): UpsertWebPushSubscriptionRequest {
    const subscription = requestBody?.subscription;
    const endpoint = typeof subscription?.endpoint === 'string' ? subscription.endpoint.trim() : '';
    const expirationTime = subscription?.expirationTime;
    const p256dh = typeof subscription?.keys?.p256dh === 'string' ? subscription.keys.p256dh.trim() : '';
    const auth = typeof subscription?.keys?.auth === 'string' ? subscription.keys.auth.trim() : '';

    if (!endpoint || !endpoint.startsWith('https://')) {
      throw new Error('invalid_web_push_subscription');
    }
    if (expirationTime !== null && expirationTime !== undefined && !Number.isFinite(expirationTime)) {
      throw new Error('invalid_web_push_subscription');
    }
    if (!p256dh || !auth) {
      throw new Error('invalid_web_push_subscription');
    }

    return {
      subscription: {
        endpoint,
        expirationTime: expirationTime === undefined ? null : expirationTime,
        keys: {
          p256dh,
          auth,
        },
      },
    };
  }

  function normalizeApplePushDeviceRequest(
    requestBody: ApplePushDeviceRequest,
  ): ApplePushDeviceRequest {
    const deviceToken = typeof requestBody?.deviceToken === 'string' ? requestBody.deviceToken.trim().toLowerCase() : '';
    const apnsEnvironment = requestBody?.apnsEnvironment;

    if (!/^[0-9a-f]+$/.test(deviceToken) || deviceToken.length < 16) {
      throw new Error('invalid_apple_push_device_token');
    }
    if (apnsEnvironment !== 'development' && apnsEnvironment !== 'production') {
      throw new Error('invalid_apple_push_environment');
    }

    return {
      deviceToken,
      apnsEnvironment,
    };
  }

  function buildCreatorAppMutationPath(
    creatorUsername: string,
    appName?: string,
    suffix = '',
  ): string {
    const creator = normalizeCreatorItemSlug(creatorUsername, 'creator');
    if (!appName) {
      return `/creators/${encodeURIComponent(creator)}/apps${suffix}`;
    }
    const name = normalizeCreatorItemSlug(appName, 'name');
    return `/creators/${encodeURIComponent(creator)}/apps/${encodeURIComponent(name)}${suffix}`;
  }

  function buildCreatorAssetMutationPath(
    creatorUsername: string,
    assetName?: string,
    suffix = '',
  ): string {
    const creator = normalizeCreatorItemSlug(creatorUsername, 'creator');
    if (!assetName) {
      return `/creators/${encodeURIComponent(creator)}/assets${suffix}`;
    }
    const name = normalizeCreatorItemSlug(assetName, 'name');
    return `/creators/${encodeURIComponent(creator)}/assets/${encodeURIComponent(name)}${suffix}`;
  }

  function buildCreatorAssetPackMutationPath(
    creatorUsername: string,
    packName?: string,
    suffix = '',
  ): string {
    const creator = normalizeCreatorItemSlug(creatorUsername, 'creator');
    if (!packName) {
      return `/creators/${encodeURIComponent(creator)}/asset-packs${suffix}`;
    }
    const name = normalizeCreatorItemSlug(packName, 'name');
    return `/creators/${encodeURIComponent(creator)}/asset-packs/${encodeURIComponent(name)}${suffix}`;
  }

  function parseContentDispositionFilename(headerValue: string | null): string | null {
    if (!headerValue) {
      return null;
    }
    const utf8Match = /filename\*=UTF-8''([^;]+)/i.exec(headerValue);
    if (utf8Match && utf8Match[1]) {
      try {
        return decodeURIComponent(utf8Match[1]);
      } catch {
        return utf8Match[1];
      }
    }
    const plainMatch = /filename="?([^";]+)"?/i.exec(headerValue);
    return plainMatch?.[1] ?? null;
  }

  const request = createRequestExecutor({
    fetchImpl,
    resolveBaseUrl,
    resolveUrl,
    parseResponseBody,
    resolveToken,
    getClientHeaders,
    requestTimeoutMs,
    includeBrowserCredentials,
  });

  // Implementation of all API methods
  return {
    request,
    ...buildAuthApiClientMethods({
      request,
      handleApiError,
    }),
    ...buildFreeCreditsApiClientMethods({
      request,
      handleApiError,
    }),

    async me(): Promise<MeResponse> {
      const response = await request<MeResponse>({
        method: 'GET',
        path: '/me',
      });

      if (response.status !== 200) {
        handleApiError(response, 'me');
      }

      return response.body;
    },

    async updateProfile(updateRequest: UpdateProfileRequest): Promise<UpdateProfileResponse> {
      const response = await request<UpdateProfileResponse>({
        method: 'PATCH',
        path: '/me',
        body: updateRequest,
      });

      if (response.status !== 200) {
        handleApiError(response, 'update_profile');
      }

      return response.body;
    },

    async changePassword(changeRequest: ChangePasswordRequest): Promise<ChangePasswordResponse> {
      const response = await request<ChangePasswordResponse>({
        method: 'POST',
        path: '/me/password',
        body: changeRequest,
      });

      if (response.status !== 200) {
        handleApiError(response, 'change_password');
      }

      return response.body;
    },

    async exportPrivacyData(): Promise<PrivacyExportResponse> {
      const response = await request<PrivacyExportResponse>({
        method: 'GET',
        path: '/me/privacy-export',
      });

      if (response.status !== 200) {
        handleApiError(response, 'export_privacy_data');
      }

      return response.body;
    },

    async deleteAccount(deleteRequest: DeleteMyAccountRequest): Promise<DeleteMyAccountResponse> {
      const response = await request<DeleteMyAccountResponse>({
        method: 'DELETE',
        path: '/me',
        body: deleteRequest,
      });

      if (response.status !== 200) {
        handleApiError(response, 'delete_account');
      }

      return response.body;
    },

    async upgradeToCreator(): Promise<UpgradeToCreatorResponse> {
      const response = await request<UpgradeToCreatorResponse>({
        method: 'POST',
        path: '/me/upgrade-to-creator',
      });

      if (response.status !== 200) {
        handleApiError(response, 'upgrade_to_creator');
      }

      return response.body;
    },

    async fetchUserById(userId: number): Promise<UserDetailResponse> {
      if (!Number.isFinite(userId) || userId <= 0) {
        throw new Error('invalid_user_id');
      }
      const response = await request<UserDetailResponse>({
        method: 'GET',
        path: `/users/${encodeURIComponent(String(userId))}`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'fetch_user_by_id');
      }

      return response.body;
    },

    async fetchUserByUsername(username: string): Promise<UserDetailResponse> {
      const trimmed = typeof username === 'string' ? username.trim() : '';
      if (!trimmed) {
        throw new Error('invalid_username');
      }
      const response = await request<UserDetailResponse>({
        method: 'GET',
        path: `/users/by-username/${encodeURIComponent(trimmed)}`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'fetch_user_by_username');
      }

      return response.body;
    },

    async fetchOwnedProfileAssets(): Promise<OwnedProfileAssetsResponse> {
      const response = await request<OwnedProfileAssetsResponse>({
        method: 'GET',
        path: '/me/profile-assets',
      });

      if (response.status !== 200) {
        handleApiError(response, 'fetch_owned_profile_assets');
      }

      return response.body;
    },

    async saveItem(kind: SavedItemKind, creatorUsername: string, itemName: string): Promise<SavedItemMutationResponse> {
      const normalizedKind = normalizeSavedItemKindInput(kind);
      const creator = normalizeCreatorItemSlug(creatorUsername, 'creator');
      const name = normalizeCreatorItemSlug(itemName, 'name');
      const response = await request<SavedItemMutationResponse>({
        method: 'PUT',
        path: `/me/saved-items/${encodeURIComponent(normalizedKind)}/${encodeURIComponent(creator)}/${encodeURIComponent(name)}`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'save_item');
      }

      return response.body;
    },

    async unsaveItem(kind: SavedItemKind, creatorUsername: string, itemName: string): Promise<SavedItemMutationResponse> {
      const normalizedKind = normalizeSavedItemKindInput(kind);
      const creator = normalizeCreatorItemSlug(creatorUsername, 'creator');
      const name = normalizeCreatorItemSlug(itemName, 'name');
      const response = await request<SavedItemMutationResponse>({
        method: 'DELETE',
        path: `/me/saved-items/${encodeURIComponent(normalizedKind)}/${encodeURIComponent(creator)}/${encodeURIComponent(name)}`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'unsave_item');
      }

      return response.body;
    },

    async likeItem(kind: SavedItemKind, creatorUsername: string, itemName: string): Promise<LikedItemMutationResponse> {
      const normalizedKind = normalizeSavedItemKindInput(kind);
      const creator = normalizeCreatorItemSlug(creatorUsername, 'creator');
      const name = normalizeCreatorItemSlug(itemName, 'name');
      const response = await request<LikedItemMutationResponse>({
        method: 'PUT',
        path: `/me/likes/${encodeURIComponent(normalizedKind)}/${encodeURIComponent(creator)}/${encodeURIComponent(name)}`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'like_item');
      }

      return response.body;
    },

    async unlikeItem(kind: SavedItemKind, creatorUsername: string, itemName: string): Promise<LikedItemMutationResponse> {
      const normalizedKind = normalizeSavedItemKindInput(kind);
      const creator = normalizeCreatorItemSlug(creatorUsername, 'creator');
      const name = normalizeCreatorItemSlug(itemName, 'name');
      const response = await request<LikedItemMutationResponse>({
        method: 'DELETE',
        path: `/me/likes/${encodeURIComponent(normalizedKind)}/${encodeURIComponent(creator)}/${encodeURIComponent(name)}`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'unlike_item');
      }

      return response.body;
    },

    async trackEngagementEvent(payload: TrackEngagementEventRequest): Promise<TrackEngagementEventResponse> {
      const eventType = normalizeEngagementEventTypeInput(payload.eventType);
      const targetKind = normalizeEngagementTargetKindInput(payload.targetKind);
      const creatorUsername = normalizeCreatorItemSlug(payload.creatorUsername, 'creator');
      const itemName = payload.itemName === undefined ? undefined : normalizeCreatorItemSlug(payload.itemName, 'name');
      const launchContext = APP_LAUNCH_CONTEXT_VALUES.includes(payload.launchContext as any)
        ? payload.launchContext
        : undefined;
      const response = await request<TrackEngagementEventResponse>({
        method: 'POST',
        path: '/engagement-events',
        body: {
          eventType,
          targetKind,
          creatorUsername,
          ...(itemName !== undefined ? { itemName } : {}),
          ...(launchContext ? { launchContext } : {}),
        },
      });

      if (response.status !== 200) {
        handleApiError(response, 'track_engagement_event');
      }

      return response.body;
    },

    async fetchLibrary(options: { category?: LibraryCategory; sort?: LibrarySort } = {}): Promise<LibraryResponse> {
      const params = new URLSearchParams();
      if (options.category) {
        params.set('category', normalizeLibraryCategoryInput(options.category));
      }
      if (options.sort) {
        params.set('sort', normalizeLibrarySortInput(options.sort));
      }
      const query = params.toString();
      const response = await request<LibraryResponse>({
        method: 'GET',
        path: `/me/library${query ? `?${query}` : ''}`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'fetch_library');
      }

      return response.body;
    },

    async followCreator(creatorUsername: string): Promise<CreatorFollowMutationResponse> {
      const creator = normalizeCreatorItemSlug(creatorUsername, 'creator');
      const response = await request<CreatorFollowMutationResponse>({
        method: 'PUT',
        path: `/me/following/${encodeURIComponent(creator)}`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'follow_creator');
      }

      return response.body;
    },

    async unfollowCreator(creatorUsername: string): Promise<CreatorFollowMutationResponse> {
      const creator = normalizeCreatorItemSlug(creatorUsername, 'creator');
      const response = await request<CreatorFollowMutationResponse>({
        method: 'DELETE',
        path: `/me/following/${encodeURIComponent(creator)}`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'unfollow_creator');
      }

      return response.body;
    },

    async fetchFollowingCreators(options: { sort?: FollowingSort } = {}): Promise<FollowingCreatorsResponse> {
      const params = new URLSearchParams();
      if (options.sort) {
        params.set('sort', normalizeFollowingSortInput(options.sort));
      }
      const query = params.toString();
      const response = await request<FollowingCreatorsResponse>({
        method: 'GET',
        path: `/me/following${query ? `?${query}` : ''}`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'fetch_following_creators');
      }

      return response.body;
    },

    async fetchFollowingFeed(options: { section: FollowingFeedSection; limit?: number }): Promise<FollowingFeedResponse> {
      const params = new URLSearchParams();
      params.set('section', normalizeFollowingFeedSectionInput(options.section));
      if (options.limit !== undefined) {
        params.set('limit', String(normalizePositiveIntegerInput(options.limit, 'invalid_following_feed_limit')));
      }
      const response = await request<FollowingFeedResponse>({
        method: 'GET',
        path: `/me/following/feed?${params.toString()}`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'fetch_following_feed');
      }

      return response.body;
    },

    async fetchNotifications(options: { status?: NotificationStatus; limit?: number; offset?: number } = {}): Promise<NotificationsResponse> {
      const params = new URLSearchParams();
      if (options.status) {
        params.set('status', normalizeNotificationStatusInput(options.status));
      }
      if (options.limit !== undefined) {
        params.set('limit', String(normalizePositiveIntegerInput(options.limit, 'invalid_notification_limit')));
      }
      if (options.offset !== undefined) {
        params.set('offset', String(normalizeNonNegativeIntegerInput(options.offset, 'invalid_notification_offset')));
      }
      const query = params.toString();
      const response = await request<NotificationsResponse>({
        method: 'GET',
        path: `/me/notifications${query ? `?${query}` : ''}`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'fetch_notifications');
      }

      return response.body;
    },

    async markNotificationRead(notificationId: number): Promise<NotificationReadResponse> {
      if (!Number.isInteger(notificationId) || notificationId <= 0) {
        throw new Error('invalid_notification_id');
      }
      const response = await request<NotificationReadResponse>({
        method: 'POST',
        path: `/me/notifications/${encodeURIComponent(String(notificationId))}/read`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'mark_notification_read');
      }

      return response.body;
    },

    async markAllNotificationsRead(): Promise<NotificationReadResponse> {
      const response = await request<NotificationReadResponse>({
        method: 'POST',
        path: '/me/notifications/read-all',
      });

      if (response.status !== 200) {
        handleApiError(response, 'mark_all_notifications_read');
      }

      return response.body;
    },

    async fetchWebPushConfig(): Promise<WebPushConfigResponse> {
      const response = await request<WebPushConfigResponse>({
        method: 'GET',
        path: '/me/push/web/config',
      });

      if (response.status !== 200) {
        handleApiError(response, 'fetch_web_push_config');
      }

      return response.body;
    },

    async fetchWebPushSubscriptionStatus(
      requestBody: UpsertWebPushSubscriptionRequest,
    ): Promise<WebPushSubscriptionStatusResponse> {
      const response = await request<WebPushSubscriptionStatusResponse>({
        method: 'POST',
        path: '/me/push/web/subscription/status',
        body: normalizeWebPushSubscriptionRequest(requestBody),
      });

      if (response.status !== 200) {
        handleApiError(response, 'fetch_web_push_subscription_status');
      }

      return response.body;
    },

    async upsertWebPushSubscription(requestBody: UpsertWebPushSubscriptionRequest): Promise<PushSubscriptionMutationResponse> {
      const response = await request<PushSubscriptionMutationResponse>({
        method: 'PUT',
        path: '/me/push/web/subscription',
        body: normalizeWebPushSubscriptionRequest(requestBody),
      });

      if (response.status !== 200) {
        handleApiError(response, 'upsert_web_push_subscription');
      }

      return response.body;
    },

    async deleteWebPushSubscription(requestBody: UpsertWebPushSubscriptionRequest): Promise<PushSubscriptionMutationResponse> {
      const response = await request<PushSubscriptionMutationResponse>({
        method: 'DELETE',
        path: '/me/push/web/subscription',
        body: normalizeWebPushSubscriptionRequest(requestBody),
      });

      if (response.status !== 200) {
        handleApiError(response, 'delete_web_push_subscription');
      }

      return response.body;
    },

    async fetchApplePushDeviceStatus(
      requestBody: ApplePushDeviceRequest,
    ): Promise<ApplePushDeviceStatusResponse> {
      const response = await request<ApplePushDeviceStatusResponse>({
        method: 'POST',
        path: '/me/push/apple/device/status',
        body: normalizeApplePushDeviceRequest(requestBody),
      });

      if (response.status !== 200) {
        handleApiError(response, 'fetch_apple_push_device_status');
      }

      return response.body;
    },

    async upsertApplePushDevice(requestBody: ApplePushDeviceRequest): Promise<PushSubscriptionMutationResponse> {
      const response = await request<PushSubscriptionMutationResponse>({
        method: 'PUT',
        path: '/me/push/apple/device',
        body: normalizeApplePushDeviceRequest(requestBody),
      });

      if (response.status !== 200) {
        handleApiError(response, 'upsert_apple_push_device');
      }

      return response.body;
    },

    async deleteApplePushDevice(requestBody: ApplePushDeviceRequest): Promise<PushSubscriptionMutationResponse> {
      const response = await request<PushSubscriptionMutationResponse>({
        method: 'DELETE',
        path: '/me/push/apple/device',
        body: normalizeApplePushDeviceRequest(requestBody),
      });

      if (response.status !== 200) {
        handleApiError(response, 'delete_apple_push_device');
      }

      return response.body;
    },

    ...buildSearchApiClientMethods({
      request,
      handleApiError,
      normalizeSearchModeInput,
      normalizeSearchKindInput,
      normalizeSearchAssetTypeInput,
      normalizePositiveIntegerInput,
    }),
    ...buildTagsApiClientMethods({
      request,
      handleApiError,
      normalizePositiveIntegerInput,
    }),
    ...buildCommentsApiClientMethods({
      request,
      handleApiError,
      normalizeSavedItemKindInput,
      normalizeCreatorItemSlug,
      normalizePositiveIntegerInput,
    }),
    ...buildAppsApiClientMethods({
      request,
      handleApiError,
      fetchImpl,
      includeBrowserCredentials,
      resolveBaseUrl,
      resolveUrl,
      parseResponseBody,
      resolveToken,
      getClientHeaders: () => config.clientHeaders ? config.clientHeaders() : {},
      buildCreatorAppMutationPath,
      normalizeCreatorItemSlug,
      normalizeSemverInput,
      parseContentDispositionFilename,
    }),
    ...buildPlayerMetaApiClientMethods({
      request,
      handleApiError,
    }),
    ...buildAssetsApiClientMethods({
      request,
      handleApiError,
      fetchImpl,
      includeBrowserCredentials,
      resolveBaseUrl,
      resolveUrl,
      parseResponseBody,
      resolveToken,
      getClientHeaders: () => config.clientHeaders ? config.clientHeaders() : {},
      buildCreatorAssetMutationPath,
      normalizeCreatorItemSlug,
      normalizeAssetRevisionInput,
      parseContentDispositionFilename,
    }),
    ...buildAssetPacksApiClientMethods({
      request,
      handleApiError,
      fetchImpl,
      includeBrowserCredentials,
      resolveBaseUrl,
      resolveUrl,
      parseResponseBody,
      resolveToken,
      getClientHeaders: () => config.clientHeaders ? config.clientHeaders() : {},
      buildCreatorAssetPackMutationPath,
      normalizeCreatorItemSlug,
      normalizeSemverInput,
      parseContentDispositionFilename,
    }),
    ...buildMeApiClientMethods({ request, handleApiError }),

    async batchUpsertGraphRelations(body: BatchUpsertNodeRelationsRequest): Promise<BatchUpsertNodeRelationsResponse> {
      const response = await request<BatchUpsertNodeRelationsResponse>({
        method: 'POST',
        path: '/me/graph/relations:batchUpsert',
        body,
      });
      if (response.status !== 200) {
        handleApiError(response, 'batch_upsert_graph_relations');
      }
      return response.body;
    },

    async submitFeedback(feedbackRequest: SubmitFeedbackRequest): Promise<SubmitFeedbackResponse> {
      const response = await request<SubmitFeedbackResponse>({
        method: 'POST',
        path: '/feedback',
        body: feedbackRequest,
      });

      if (response.status !== 201 && response.status !== 200) {
        handleApiError(response, 'submit_feedback');
      }

      return response.body;
    },

    async listFeedback(options: { limit?: number; offset?: number; source?: string; userId?: number } = {}): Promise<FeedbackListResponse> {
      const params = new URLSearchParams();
      if (options.limit !== undefined) {
        params.set('limit', String(options.limit));
      }
      if (options.offset !== undefined) {
        params.set('offset', String(options.offset));
      }
      if (typeof options.source === 'string' && options.source.trim().length > 0) {
        params.set('source', options.source.trim());
      }
      if (options.userId !== undefined) {
        params.set('userId', String(options.userId));
      }
      const query = params.toString();
      const path = `/feedback${query ? `?${query}` : ''}`;

      const response = await request<FeedbackListResponse>({
        method: 'GET',
        path,
      });

      if (response.status !== 200) {
        handleApiError(response, 'list_feedback');
      }

      return response.body;
    },

    async deleteFeedback(id: number): Promise<DeleteFeedbackResponse> {
      const response = await request<DeleteFeedbackResponse>({
        method: 'DELETE',
        path: `/feedback/${encodeURIComponent(String(id))}`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'delete_feedback');
      }

      return response.body;
    },

    async setSelectedProfileAsset(profileAssetRequest: SetProfileAssetRequest): Promise<SetProfileAssetResponse> {
      const response = await request<SetProfileAssetResponse>({
        method: 'POST',
        path: '/me/profile-asset',
        body: profileAssetRequest,
      });

      if (response.status !== 200) {
        handleApiError(response, 'set_profile_asset');
      }

      return response.body;
    },

    async fetchHome(options: FetchHomeOptions = {}): Promise<HomeResponse> {
      const params = new URLSearchParams();
      if (typeof options.section === 'string' && options.section.trim().length > 0) {
        params.set('section', options.section.trim());
      }
      if (typeof options.limit === 'number') {
        params.set('limit', String(options.limit));
      }
      if (typeof options.offset === 'number') {
        params.set('offset', String(options.offset));
      }
      const query = params.toString();
      const response = await request<HomeResponse>({
        method: 'GET',
        path: `/home${query ? `?${query}` : ''}`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'fetch_home');
      }

      return response.body;
    },

    async fetchHomeGamesCollectionPage(
      collectionId: string,
      options: { limit?: number; offset?: number } = {},
    ): Promise<HomeCollectionPageResponse> {
      const normalizedCollectionId = collectionId.trim();
      if (!normalizedCollectionId) {
        throw new Error('invalid_home_collection_id');
      }
      const params = new URLSearchParams();
      if (typeof options.limit === 'number') {
        params.set('limit', String(options.limit));
      }
      if (typeof options.offset === 'number') {
        params.set('offset', String(options.offset));
      }
      const query = params.toString();
      const response = await request<HomeCollectionPageResponse>({
        method: 'GET',
        path: `/home/games/collections/${encodeURIComponent(normalizedCollectionId)}${query ? `?${query}` : ''}`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'fetch_home_games_collection_page');
      }

      return response.body;
    },
    ...buildAdminApiClientMethods({
      request,
      handleApiError,
      fetchImpl,
      includeBrowserCredentials,
      resolveBaseUrl,
      resolveUrl,
      parseResponseBody,
      resolveToken,
      getClientHeaders: () => config.clientHeaders ? config.clientHeaders() : {},
    }),
    ...buildPaymentsApiClientMethods({
      request,
      handleApiError,
      buildIapQuery,
    }),
    ...buildAiApiClientMethods({
      request,
      handleApiError,
    }),
  };
}
