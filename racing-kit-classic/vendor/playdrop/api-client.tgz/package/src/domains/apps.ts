import type {
  AbortAppUploadResponse,
  AppAccessTokenResponse,
  AppBrowseRequest,
  AppDetailRequest,
  AppDetailResponse,
  AppMoreCollectionKey,
  AppMoreCollectionPage,
  AppMoreCollectionRequest,
  AppMoreCollectionsRequest,
  AppMoreCollectionsResponse,
  CreatorAppsBrowseRequest,
  AppRuntimeAssetsResponse,
  DevAppAccessTokenResponse,
  DevPlayerResetResponse,
  FinalizeAppUploadResponse,
  InitializeAppUploadRequest,
  InitializeAppUploadResponse,
  AppLogEntryRequest,
  AppLogEntryResponse,
  AppSourceBundleResponse,
  AppType,
  AppsListResponse,
  AppVersionDetailResponse,
  AppVersionVisibility,
  AppVersionsListResponse,
  CreateAppRequest,
  CreateAppResponse,
  ContentRemixRelationsResponse,
  DeleteAppResponse,
  DeleteVersionResponse,
  RemixScaffoldResponse,
  UploadAppSessionFileResponse,
  UploadAppSessionOwnedAssetResponse,
  UpdateAppRequest,
  UpdateAppResponse,
  UpdateVersionResponse,
} from '@playdrop/types';
import type {
  UploadAppSessionFileOptions,
  UploadAppSessionOwnedAssetOptions,
} from '../client.js';
import { buildBrowserCredentialsInit } from '../core/request.js';

type ApiResponseLike<T> = {
  status: number;
  body: T;
  headers: Headers;
};

type RequestExecutor = <T>(input: {
  method: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
  path: string;
  body?: unknown;
  headers?: Record<string, string>;
  signal?: AbortSignal;
}) => Promise<ApiResponseLike<T>>;

type ErrorHandler = (response: ApiResponseLike<unknown>, defaultMessage: string) => never;

type ParseResponseBody = <T>(response: Response) => Promise<T>;

function buildPublicAppPath(
  normalizeCreatorItemSlug: (value: string, field: 'creator' | 'name') => string,
  creatorUsername: string,
  appName: string,
  suffix = '',
): string {
  const creator = normalizeCreatorItemSlug(creatorUsername, 'creator');
  const name = normalizeCreatorItemSlug(appName, 'name');
  return `/apps/${encodeURIComponent(creator)}/${encodeURIComponent(name)}${suffix}`;
}

function appendNormalizedTagParams(params: URLSearchParams, tags: string[] | undefined): void {
  if (!Array.isArray(tags)) {
    return;
  }
  for (const tag of tags) {
    if (typeof tag !== 'string') {
      continue;
    }
    const normalized = tag.trim();
    if (normalized.length > 0) {
      params.append('tag', normalized);
    }
  }
}

function appendAppCapabilityFilterParams(
  params: URLSearchParams,
  filters: Pick<AppBrowseRequest, 'auth' | 'controller' | 'surface' | 'controllerCompatible'>,
): void {
  if (typeof filters.auth === 'string' && filters.auth.trim().length > 0) {
    params.set('auth', filters.auth.trim());
  }
  if (typeof filters.controller === 'string' && filters.controller.trim().length > 0) {
    params.set('controller', filters.controller.trim());
  }
  if (filters.controllerCompatible === true) {
    params.set('controllerCompatible', '1');
  }
  if (typeof filters.surface === 'string' && filters.surface.trim().length > 0) {
    params.set('surface', filters.surface.trim());
  }
}

function appendFinitePaginationParam(
  params: URLSearchParams,
  key: 'limit' | 'offset',
  value: number | undefined,
): void {
  if (typeof value === 'number' && Number.isFinite(value)) {
    params.set(key, String(value));
  }
}

async function buildAuthorizedHeaders(
  getClientHeaders: () => Record<string, string>,
  resolveToken: () => Promise<string | null>,
): Promise<Headers> {
  const headers = new Headers();
  for (const [key, value] of Object.entries(getClientHeaders())) {
    headers.set(key, value);
  }
  const token = await resolveToken();
  if (token) {
    headers.set('authorization', `Bearer ${token}`);
  }
  return headers;
}

async function fetchAppsByCreatorRequest(
  request: RequestExecutor,
  handleApiError: ErrorHandler,
  creatorUsername: string,
  options: CreatorAppsBrowseRequest = {},
): Promise<AppsListResponse> {
  const normalizedCreator = creatorUsername.trim();
  const params = new URLSearchParams();
  if (typeof options.limit === 'number' && Number.isFinite(options.limit)) {
    params.set('limit', String(options.limit));
  }
  if (typeof options.offset === 'number' && Number.isFinite(options.offset)) {
    params.set('offset', String(options.offset));
  }
  if (typeof options.type === 'string' && options.type.trim().length > 0) {
    params.set('type', options.type.trim());
  }
  if (typeof options.sort === 'string' && options.sort.trim().length > 0) {
    params.set('sort', options.sort.trim());
  }
  appendAppCapabilityFilterParams(params, options);
  appendNormalizedTagParams(params, options.tags);
  const query = params.toString();
  const response = await request<AppsListResponse>({
    method: 'GET',
    path: `/creators/${encodeURIComponent(normalizedCreator)}/apps` + (query ? `?${query}` : ''),
  });
  if (response.status !== 200) {
    handleApiError(response, 'fetch_apps_by_creator');
  }
  return response.body;
}

async function buildAppUploadAuthorizedHeaders(input: {
  getClientHeaders: () => Record<string, string>;
  resolveToken: () => Promise<string | null>;
}): Promise<Headers> {
  return await buildAuthorizedHeaders(input.getClientHeaders, input.resolveToken);
}

// eslint-disable-next-line max-lines-per-function
export function buildAppsApiClientMethods(input: {
  request: RequestExecutor;
  handleApiError: ErrorHandler;
  fetchImpl: typeof fetch;
  includeBrowserCredentials: boolean;
  resolveBaseUrl: () => string;
  resolveUrl: (base: string, path: string) => string;
  parseResponseBody: ParseResponseBody;
  resolveToken: () => Promise<string | null>;
  getClientHeaders: () => Record<string, string>;
  buildCreatorAppMutationPath: (creatorUsername: string, name?: string) => string;
  normalizeCreatorItemSlug: (value: string, field: 'creator' | 'name') => string;
  normalizeSemverInput: (version: string) => string;
  parseContentDispositionFilename: (headerValue: string | null) => string | null;
}) {
  const {
    request,
    handleApiError,
    fetchImpl,
    includeBrowserCredentials,
    resolveBaseUrl,
    resolveUrl,
    parseResponseBody,
    resolveToken,
    getClientHeaders,
    buildCreatorAppMutationPath,
    normalizeCreatorItemSlug,
    normalizeSemverInput,
    parseContentDispositionFilename,
  } = input;

  return {
    async fetchApps(options: AppBrowseRequest = {}): Promise<AppsListResponse> {
      const params = new URLSearchParams();
      if (typeof options.limit === 'number' && Number.isFinite(options.limit)) {
        params.set('limit', String(options.limit));
      }
      if (typeof options.offset === 'number' && Number.isFinite(options.offset)) {
        params.set('offset', String(options.offset));
      }
      if (typeof options.sort === 'string' && options.sort.trim().length > 0) {
        params.set('sort', options.sort.trim());
      }
      appendAppCapabilityFilterParams(params, options);
      appendNormalizedTagParams(params, options.tags);
      const query = params.toString();
      const response = await request<AppsListResponse>({
        method: 'GET',
        path: '/apps' + (query ? `?${query}` : ''),
      });

      if (response.status !== 200) {
        handleApiError(response, 'fetch_apps');
      }

      return response.body;
    },

    async fetchAppsByType(type: AppType, options: AppBrowseRequest = {}): Promise<AppsListResponse> {
      const params = new URLSearchParams();
      if (typeof options.limit === 'number' && Number.isFinite(options.limit)) {
        params.set('limit', String(options.limit));
      }
      if (typeof options.offset === 'number' && Number.isFinite(options.offset)) {
        params.set('offset', String(options.offset));
      }
      if (typeof options.sort === 'string' && options.sort.trim().length > 0) {
        params.set('sort', options.sort.trim());
      }
      appendAppCapabilityFilterParams(params, options);
      appendNormalizedTagParams(params, options.tags);
      const query = params.toString();
      const response = await request<AppsListResponse>({
        method: 'GET',
        path: `/apps/types/${encodeURIComponent(type)}` + (query ? `?${query}` : ''),
      });

      if (response.status !== 200) {
        handleApiError(response, 'fetch_apps_by_type');
      }

      return response.body;
    },

    async fetchAppsByCreator(
      creatorUsername: string,
      options: CreatorAppsBrowseRequest = {},
    ): Promise<AppsListResponse> {
      return fetchAppsByCreatorRequest(request, handleApiError, creatorUsername, options);
    },

    async fetchAppBySlug(
      creatorUsername: string,
      appName: string,
      options: AppDetailRequest = {},
    ): Promise<AppDetailResponse> {
      const params = new URLSearchParams();
      if (options.includeDependencies === true) {
        params.set('includeDependencies', '1');
      }
      const response = await request<AppDetailResponse>({
        method: 'GET',
        path: `/apps/${encodeURIComponent(creatorUsername)}/${encodeURIComponent(appName)}${params.size > 0 ? `?${params.toString()}` : ''}`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'fetch_app');
      }

      return response.body;
    },

    async fetchAppMoreCollections(
      creatorUsername: string,
      appName: string,
      options: AppMoreCollectionsRequest = {},
    ): Promise<AppMoreCollectionsResponse> {
      const params = new URLSearchParams();
      appendFinitePaginationParam(params, 'limit', options.limit);
      const response = await request<AppMoreCollectionsResponse>({
        method: 'GET',
        path: `${buildPublicAppPath(normalizeCreatorItemSlug, creatorUsername, appName, '/more')}${params.size > 0 ? `?${params.toString()}` : ''}`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'fetch_app_more_collections');
      }

      return response.body;
    },

    async fetchAppMoreCollectionPage(
      creatorUsername: string,
      appName: string,
      collectionKey: AppMoreCollectionKey,
      options: AppMoreCollectionRequest = {},
    ): Promise<AppMoreCollectionPage> {
      const params = new URLSearchParams();
      appendFinitePaginationParam(params, 'limit', options.limit);
      appendFinitePaginationParam(params, 'offset', options.offset);
      const response = await request<AppMoreCollectionPage>({
        method: 'GET',
        path: `${buildPublicAppPath(normalizeCreatorItemSlug, creatorUsername, appName, `/more/${encodeURIComponent(collectionKey)}`)}${params.size > 0 ? `?${params.toString()}` : ''}`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'fetch_app_more_collection_page');
      }

      return response.body;
    },

    async requestAppAccessToken(appId: number): Promise<AppAccessTokenResponse> {
      const response = await request<AppAccessTokenResponse>({
        method: 'POST',
        path: `/apps/${encodeURIComponent(String(appId))}/token`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'request_app_access_token');
      }

      return response.body;
    },

    async sendAppLog(appId: number, entry: AppLogEntryRequest): Promise<AppLogEntryResponse> {
      const response = await request<AppLogEntryResponse>({
        method: 'POST',
        path: `/apps/${encodeURIComponent(String(appId))}/logs`,
        body: entry,
      });

      if (response.status !== 200) {
        handleApiError(response, 'send_app_log');
      }

      return response.body;
    },

    async createApp(creatorUsername: string, createRequest: CreateAppRequest): Promise<CreateAppResponse> {
      const response = await request<CreateAppResponse>({
        method: 'POST',
        path: buildCreatorAppMutationPath(creatorUsername),
        body: createRequest,
      });

      if (response.status !== 200) {
        handleApiError(response, 'create_app');
      }

      return response.body;
    },

    async updateApp(
      creatorUsername: string,
      name: string,
      updateRequest: UpdateAppRequest,
    ): Promise<UpdateAppResponse> {
      const response = await request<UpdateAppResponse>({
        method: 'PATCH',
        path: buildCreatorAppMutationPath(creatorUsername, name),
        body: updateRequest,
      });

      if (response.status !== 200) {
        handleApiError(response, 'update_app');
      }

      return response.body;
    },
    async initializeAppUpload(
      creatorUsername: string,
      appName: string,
      requestBody: InitializeAppUploadRequest,
    ): Promise<InitializeAppUploadResponse> {
      const response = await request<InitializeAppUploadResponse>({
        method: 'POST',
        path: `${buildCreatorAppMutationPath(creatorUsername, appName)}/upload-sessions`,
        body: requestBody,
      });
      if (response.status !== 200) {
        handleApiError(response, 'initialize_app_upload');
      }
      return response.body;
    },

    async uploadAppSessionFile(
      creatorUsername: string,
      appName: string,
      sessionId: string,
      fileKey: string,
      options: UploadAppSessionFileOptions,
    ): Promise<UploadAppSessionFileResponse> {
      const form = new FormData();
      const filename = typeof options.filename === 'string' && options.filename.trim().length > 0
        ? options.filename.trim()
        : 'upload.bin';
      form.append('file', options.file, filename);
      const base = resolveBaseUrl();
      const headers = await buildAppUploadAuthorizedHeaders({ getClientHeaders, resolveToken });
      const path = `${buildCreatorAppMutationPath(creatorUsername, appName)}/upload-sessions/${encodeURIComponent(sessionId)}/files/${encodeURIComponent(fileKey)}`;
      const response = await fetchImpl(resolveUrl(base, path), {
        method: 'POST',
        headers,
        body: form,
        ...buildBrowserCredentialsInit(includeBrowserCredentials),
      });
      const parsed = await parseResponseBody<UploadAppSessionFileResponse>(response);
      const apiResponse = { status: response.status, body: parsed, headers: response.headers };
      if (response.status !== 200) {
        handleApiError(apiResponse, 'upload_app_session_file');
      }
      return parsed;
    },

    async uploadAppSessionOwnedAsset(
      creatorUsername: string,
      appName: string,
      sessionId: string,
      uploadKey: string,
      options: UploadAppSessionOwnedAssetOptions,
    ): Promise<UploadAppSessionOwnedAssetResponse> {
      const form = new FormData();
      for (const entry of options.files) {
        const fieldName = typeof entry.fieldName === 'string' && entry.fieldName.trim().length > 0
          ? entry.fieldName.trim()
          : 'file';
        const filename = typeof entry.filename === 'string' && entry.filename.trim().length > 0
          ? entry.filename.trim()
          : 'upload.bin';
        form.append(fieldName, entry.file, filename);
      }
      const base = resolveBaseUrl();
      const headers = await buildAppUploadAuthorizedHeaders({ getClientHeaders, resolveToken });
      const path = `${buildCreatorAppMutationPath(creatorUsername, appName)}/upload-sessions/${encodeURIComponent(sessionId)}/owned-assets/${encodeURIComponent(uploadKey)}`;
      const response = await fetchImpl(resolveUrl(base, path), {
        method: 'POST',
        headers,
        body: form,
        ...buildBrowserCredentialsInit(includeBrowserCredentials),
      });
      const parsed = await parseResponseBody<UploadAppSessionOwnedAssetResponse>(response);
      const apiResponse = { status: response.status, body: parsed, headers: response.headers };
      if (response.status !== 200) {
        handleApiError(apiResponse, 'upload_app_session_owned_asset');
      }
      return parsed;
    },

    async finalizeAppUpload(
      creatorUsername: string,
      appName: string,
      sessionId: string,
    ): Promise<FinalizeAppUploadResponse> {
      const response = await request<FinalizeAppUploadResponse>({
        method: 'POST',
        path: `${buildCreatorAppMutationPath(creatorUsername, appName)}/upload-sessions/${encodeURIComponent(sessionId)}/finalize`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'finalize_app_upload');
      }
      return response.body;
    },

    async abortAppUpload(
      creatorUsername: string,
      appName: string,
      sessionId: string,
    ): Promise<AbortAppUploadResponse> {
      const response = await request<AbortAppUploadResponse>({
        method: 'POST',
        path: `${buildCreatorAppMutationPath(creatorUsername, appName)}/upload-sessions/${encodeURIComponent(sessionId)}/abort`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'abort_app_upload');
      }
      return response.body;
    },

    async fetchAppRelated(
      creatorUsername: string,
      appName: string,
    ): Promise<ContentRemixRelationsResponse> {
      const response = await request<ContentRemixRelationsResponse>({
        method: 'GET',
        path: buildPublicAppPath(normalizeCreatorItemSlug, creatorUsername, appName, '/related'),
      });
      if (response.status !== 200) {
        handleApiError(response, 'get_app_related');
      }
      return response.body;
    },

    async requestDevAppAccessToken(appId: number, slot: number): Promise<DevAppAccessTokenResponse> {
      const response = await request<DevAppAccessTokenResponse>({
        method: 'POST',
        path: `/apps/${encodeURIComponent(String(appId))}/dev/players/${encodeURIComponent(String(slot))}/token`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'request_dev_app_access_token');
      }
      return response.body;
    },

    async resetDevPlayer(appId: number, slot: number): Promise<DevPlayerResetResponse> {
      const response = await request<DevPlayerResetResponse>({
        method: 'POST',
        path: `/apps/${encodeURIComponent(String(appId))}/dev/players/${encodeURIComponent(String(slot))}/reset`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'reset_dev_player');
      }
      return response.body;
    },

    async resetAllDevPlayers(appId: number): Promise<DevPlayerResetResponse> {
      const response = await request<DevPlayerResetResponse>({
        method: 'POST',
        path: `/apps/${encodeURIComponent(String(appId))}/dev/players/reset-all`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'reset_all_dev_players');
      }
      return response.body;
    },

    async listAppVersions(
      creatorUsername: string,
      appName: string,
    ): Promise<AppVersionsListResponse> {
      const path = `/apps/${encodeURIComponent(creatorUsername)}/${encodeURIComponent(appName)}/versions`;
      const response = await request<AppVersionsListResponse>({
        method: 'GET',
        path,
      });

      if (response.status !== 200) {
        handleApiError(response, 'list_app_versions');
      }

      return response.body;
    },

    async getAppVersion(
      creatorUsername: string,
      appName: string,
      version: string,
    ): Promise<AppVersionDetailResponse> {
      const normalizedVersion = normalizeSemverInput(version);
      const path = `/apps/${encodeURIComponent(creatorUsername)}/${encodeURIComponent(appName)}/versions/${encodeURIComponent(normalizedVersion)}`;
      const response = await request<AppVersionDetailResponse>({
        method: 'GET',
        path,
      });

      if (response.status !== 200) {
        handleApiError(response, 'get_app_version');
      }

      return response.body;
    },

    async fetchAppRuntimeAssets(
      creatorUsername: string,
      appName: string,
      version: string,
    ): Promise<AppRuntimeAssetsResponse> {
      const normalizedVersion = normalizeSemverInput(version);
      const path = `/apps/${encodeURIComponent(creatorUsername)}/${encodeURIComponent(appName)}/versions/${encodeURIComponent(normalizedVersion)}/runtime-assets`;
      const response = await request<AppRuntimeAssetsResponse>({
        method: 'GET',
        path,
      });
      if (response.status !== 200) {
        handleApiError(response, 'fetch_app_runtime_assets');
      }
      return response.body;
    },

    async downloadAppSource(
      creatorUsername: string,
      appName: string,
      version: string,
    ): Promise<{ blob: Blob; metadata: AppSourceBundleResponse }> {
      const creator = normalizeCreatorItemSlug(creatorUsername, 'creator');
      const name = normalizeCreatorItemSlug(appName, 'name');
      const normalizedVersion = normalizeSemverInput(version);
      const path = `/apps/${encodeURIComponent(creator)}/${encodeURIComponent(name)}/versions/${encodeURIComponent(normalizedVersion)}/source`;
      const base = resolveBaseUrl();
      const headers = new Headers();
      for (const [key, value] of Object.entries(getClientHeaders())) {
        headers.set(key, value);
      }
      const token = await resolveToken();
      if (token) {
        headers.set('authorization', `Bearer ${token}`);
      }
      const response = await fetchImpl(resolveUrl(base, path), {
        method: 'GET',
        headers,
        ...buildBrowserCredentialsInit(includeBrowserCredentials),
      });
      if (!response.ok) {
        const parsed = await parseResponseBody<any>(response);
        handleApiError({ status: response.status, body: parsed, headers: response.headers }, 'download_app_source');
      }

      const blob = await response.blob();
      const filename = parseContentDispositionFilename(response.headers.get('content-disposition'))
        ?? `${name}-${normalizedVersion}-source.zip`;
      const headerSize = response.headers.get('content-length');
      const parsedSize = headerSize ? Number.parseInt(headerSize, 10) : Number.NaN;
      const checksumHeader = response.headers.get('x-app-source-checksum');
      return {
        blob,
        metadata: {
          filename,
          sizeBytes: Number.isFinite(parsedSize) && parsedSize >= 0 ? parsedSize : blob.size,
          checksum: checksumHeader ?? null,
        },
      };
    },

    async updateAppVersion(
      creatorUsername: string,
      appName: string,
      version: string,
      updates: { releaseNotes?: string | null; visibility?: AppVersionVisibility; setAsCurrent?: boolean },
    ): Promise<UpdateVersionResponse> {
      const path = `${buildCreatorAppMutationPath(creatorUsername, appName)}/versions/${encodeURIComponent(version)}`;
      const response = await request<UpdateVersionResponse>({
        method: 'PATCH',
        path,
        body: updates,
      });

      if (response.status !== 200) {
        handleApiError(response, 'update_app_version');
      }

      return response.body;
    },

    async deleteAppVersion(
      creatorUsername: string,
      appName: string,
      version: string,
    ): Promise<DeleteVersionResponse> {
      const path = `${buildCreatorAppMutationPath(creatorUsername, appName)}/versions/${encodeURIComponent(version)}`;
      const response = await request<DeleteVersionResponse>({
        method: 'DELETE',
        path,
      });

      if (response.status !== 200) {
        handleApiError(response, 'delete_app_version');
      }

      return response.body;
    },

    async deleteApp(creatorUsername: string, name: string): Promise<DeleteAppResponse> {
      const response = await request<DeleteAppResponse>({
        method: 'DELETE',
        path: buildCreatorAppMutationPath(creatorUsername, name),
      });

      if (response.status !== 200) {
        handleApiError(response, 'delete_app');
      }

      return response.body;
    },

    async fetchRemixScaffold(creatorUsername: string, appName: string, version?: string): Promise<RemixScaffoldResponse> {
      const params = new URLSearchParams();
      if (typeof version === 'string' && version.trim().length > 0) {
        params.set('version', version.trim());
      }
      const response = await request<RemixScaffoldResponse>({
        method: 'GET',
        path: `${buildPublicAppPath(normalizeCreatorItemSlug, creatorUsername, appName)}/remix${params.size > 0 ? `?${params.toString()}` : ''}`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'fetch_remix_scaffold');
      }

      return response.body;
    },
  };
}
