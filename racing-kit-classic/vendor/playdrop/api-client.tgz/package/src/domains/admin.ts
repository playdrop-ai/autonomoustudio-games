import type {
  AdminAppPlayerMetaResponse,
  AdminAppPlayerMetaUserResponse,
  AdminAppVersionReviewsListResponse,
  AdminClaimNextAppVersionReviewResponse,
  AdminCreateAppVersionReviewPublicCommentRequest,
  AdminCreateAppVersionReviewPublicCommentResponse,
  AdminAppsListResponse,
  AdminCreditTransactionsResponse,
  AdminMutateAchievementStateRequest,
  AdminMutateAchievementStateResponse,
  AdminMutateLeaderboardScoreRequest,
  AdminMutateLeaderboardScoreResponse,
  AdminPaymentDetailResponse,
  AdminPaymentsListResponse,
  AdminRefundPaymentRequest,
  AdminRetirePlayerMetaDefinitionResponse,
  AdminUpdateAppRequest,
  AdminUpdateAppVersionReviewRequest,
  AdminUpdateAppVersionReviewResponse,
  AdminUpdateAppResponse,
  AdminUserResponse,
  BatchCreateUsersResponse,
  CreateUserRequest,
  CreateUserResponse,
  CreditPackResponse,
  CreditPacksResponse,
  DeleteAdminUserResponse,
  DeleteAppResponse,
  AiGenerationDetailResponse,
  AiGenerationsResponse,
  PaymentProvider,
  PaymentStatus,
  ReviewState,
  UpdateAdminUserRequest,
  UsersListResponse,
} from '@playdrop/types';
import { buildBrowserCredentialsInit } from '../core/request.js';

type ApiResponseLike<T> = {
  status: number;
  body: T;
  headers: Headers;
};

type RequestExecutor = <T>(input: {
  method: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
  path: string;
  body?: unknown;
  headers?: Record<string, string>;
  signal?: AbortSignal;
}) => Promise<ApiResponseLike<T>>;

type ErrorHandler = (response: ApiResponseLike<unknown>, defaultMessage: string) => never;
type ParseResponseBody = <T>(response: Response) => Promise<T>;

type FetchAdminPaymentsOptions = {
  provider?: PaymentProvider;
  status?: PaymentStatus | PaymentStatus[];
  userId?: number;
  creditPackSku?: string;
  from?: string | Date;
  to?: string | Date;
  limit?: number;
  offset?: number;
};

type FetchAdminAppVersionReviewsOptions = {
  state?: ReviewState;
  limit?: number;
  offset?: number;
};

function buildAdminPaymentsQueryString(options?: FetchAdminPaymentsOptions): string {
  const params = new URLSearchParams();
  if (options?.provider) {
    params.set('provider', options.provider);
  }
  if (options?.status) {
    const statuses = Array.isArray(options.status) ? options.status : [options.status];
    params.set('status', statuses.join(','));
  }
  if (typeof options?.userId === 'number') {
    params.set('userId', String(options.userId));
  }
  if (options?.creditPackSku) {
    params.set('creditPackSku', options.creditPackSku);
  }
  if (options?.from) {
    params.set('from', options.from instanceof Date ? options.from.toISOString() : options.from);
  }
  if (options?.to) {
    params.set('to', options.to instanceof Date ? options.to.toISOString() : options.to);
  }
  if (typeof options?.limit === 'number') {
    params.set('limit', String(options.limit));
  }
  if (typeof options?.offset === 'number') {
    params.set('offset', String(options.offset));
  }
  return params.toString();
}

function buildAdminAppVersionReviewsQueryString(options?: FetchAdminAppVersionReviewsOptions): string {
  const params = new URLSearchParams();
  if (options?.state) {
    params.set('state', options.state);
  }
  if (typeof options?.limit === 'number') {
    params.set('limit', String(options.limit));
  }
  if (typeof options?.offset === 'number') {
    params.set('offset', String(options.offset));
  }
  return params.toString();
}

// eslint-disable-next-line max-lines-per-function -- Admin client methods mirror the admin route surface in one place.
export function buildAdminApiClientMethods(input: {
  request: RequestExecutor;
  handleApiError: ErrorHandler;
  fetchImpl: typeof fetch;
  includeBrowserCredentials: boolean;
  resolveBaseUrl: () => string;
  resolveUrl: (base: string, path: string) => string;
  parseResponseBody: ParseResponseBody;
  resolveToken: () => Promise<string | null>;
  getClientHeaders: () => Record<string, string>;
}) {
  const {
    request,
    handleApiError,
    fetchImpl,
    includeBrowserCredentials,
    resolveBaseUrl,
    resolveUrl,
    parseResponseBody,
    resolveToken,
    getClientHeaders,
  } = input;

  return {
    async fetchUsers(): Promise<UsersListResponse> {
      const response = await request<UsersListResponse>({
        method: 'GET',
        path: '/admin/users',
      });

      if (response.status !== 200) {
        handleApiError(response, 'fetch_users');
      }

      return response.body;
    },

    async createUser(userRequest: CreateUserRequest): Promise<CreateUserResponse> {
      const response = await request<CreateUserResponse>({
        method: 'POST',
        path: '/admin/users',
        body: userRequest,
      });

      if (response.status !== 201 && response.status !== 200) {
        handleApiError(response, 'create_user');
      }

      return response.body;
    },

    async batchCreateUsersFromCsv(formData: FormData): Promise<BatchCreateUsersResponse> {
      const base = resolveBaseUrl();
      const headers = new Headers();

      for (const [key, value] of Object.entries(getClientHeaders())) {
        headers.set(key, value);
      }

      const token = await resolveToken();
      if (token) {
        headers.set('authorization', `Bearer ${token}`);
      }

      const path = '/admin/users/batch-create';
      const response = await fetchImpl(resolveUrl(base, path), {
        method: 'POST',
        headers,
        body: formData,
        ...buildBrowserCredentialsInit(includeBrowserCredentials),
      });

      const parsed = await parseResponseBody<BatchCreateUsersResponse>(response);
      const apiResponse = { status: response.status, body: parsed, headers: response.headers };

      if (response.status !== 200 && response.status !== 201) {
        handleApiError(apiResponse, 'batch_create_users');
      }

      return parsed;
    },

    async fetchAdminUser(userId: number): Promise<AdminUserResponse> {
      const response = await request<AdminUserResponse>({
        method: 'GET',
        path: `/admin/users/${encodeURIComponent(String(userId))}`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'fetch_admin_user');
      }

      return response.body;
    },

    async updateAdminUser(userId: number, updateRequest: UpdateAdminUserRequest): Promise<AdminUserResponse> {
      const response = await request<AdminUserResponse>({
        method: 'PATCH',
        path: `/admin/users/${encodeURIComponent(String(userId))}`,
        body: updateRequest,
      });

      if (response.status !== 200) {
        handleApiError(response, 'update_admin_user');
      }

      return response.body;
    },

    async deleteAdminUser(userId: number): Promise<DeleteAdminUserResponse> {
      const response = await request<DeleteAdminUserResponse>({
        method: 'DELETE',
        path: `/admin/users/${encodeURIComponent(String(userId))}`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'delete_admin_user');
      }

      return response.body;
    },

    async fetchAdminApps(): Promise<AdminAppsListResponse> {
      const response = await request<AdminAppsListResponse>({
        method: 'GET',
        path: '/admin/apps',
      });

      if (response.status !== 200) {
        handleApiError(response, 'fetch_admin_apps');
      }

      return response.body;
    },

    async updateAdminApp(id: number, updateRequest: AdminUpdateAppRequest): Promise<AdminUpdateAppResponse> {
      const response = await request<AdminUpdateAppResponse>({
        method: 'PATCH',
        path: `/admin/apps/${encodeURIComponent(String(id))}`,
        body: updateRequest,
      });

      if (response.status !== 200) {
        handleApiError(response, 'update_admin_app');
      }

      return response.body;
    },

    async deleteAdminApp(id: number): Promise<DeleteAppResponse> {
      const response = await request<DeleteAppResponse>({
        method: 'DELETE',
        path: `/admin/apps/${encodeURIComponent(String(id))}`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'delete_admin_app');
      }

      return response.body;
    },

    async fetchAdminAppVersionReviews(
      options?: FetchAdminAppVersionReviewsOptions,
    ): Promise<AdminAppVersionReviewsListResponse> {
      const query = buildAdminAppVersionReviewsQueryString(options);
      const response = await request<AdminAppVersionReviewsListResponse>({
        method: 'GET',
        path: '/admin/app-version-reviews' + (query ? `?${query}` : ''),
      });

      if (response.status !== 200) {
        handleApiError(response, 'fetch_admin_app_version_reviews');
      }

      return response.body;
    },

    async claimNextAdminAppVersionReview(): Promise<AdminClaimNextAppVersionReviewResponse> {
      const response = await request<AdminClaimNextAppVersionReviewResponse>({
        method: 'POST',
        path: '/admin/app-version-reviews/claim-next',
      });

      if (response.status !== 200) {
        handleApiError(response, 'claim_next_admin_app_version_review');
      }

      return response.body;
    },

    async updateAdminAppVersionReview(
      versionId: number,
      requestBody: AdminUpdateAppVersionReviewRequest,
    ): Promise<AdminUpdateAppVersionReviewResponse> {
      const response = await request<AdminUpdateAppVersionReviewResponse>({
        method: 'PATCH',
        path: `/admin/app-version-reviews/${encodeURIComponent(String(versionId))}`,
        body: requestBody,
      });

      if (response.status !== 200) {
        handleApiError(response, 'update_admin_app_version_review');
      }

      return response.body;
    },

    async createAdminAppVersionReviewPublicComment(
      versionId: number,
      requestBody: AdminCreateAppVersionReviewPublicCommentRequest,
    ): Promise<AdminCreateAppVersionReviewPublicCommentResponse> {
      const response = await request<AdminCreateAppVersionReviewPublicCommentResponse>({
        method: 'POST',
        path: `/admin/app-version-reviews/${encodeURIComponent(String(versionId))}/public-comment`,
        body: requestBody,
      });

      if (response.status !== 200) {
        handleApiError(response, 'create_admin_app_version_review_public_comment');
      }

      return response.body;
    },

    async fetchAdminAppPlayerMeta(appId: number): Promise<AdminAppPlayerMetaResponse> {
      const response = await request<AdminAppPlayerMetaResponse>({
        method: 'GET',
        path: `/admin/apps/${encodeURIComponent(String(appId))}/player-meta`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'fetch_admin_app_player_meta');
      }

      return response.body;
    },

    async fetchAdminAppPlayerMetaUser(appId: number, userId: number): Promise<AdminAppPlayerMetaUserResponse> {
      const response = await request<AdminAppPlayerMetaUserResponse>({
        method: 'GET',
        path: `/admin/apps/${encodeURIComponent(String(appId))}/player-meta/users/${encodeURIComponent(String(userId))}`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'fetch_admin_app_player_meta_user');
      }

      return response.body;
    },

    async retireAdminAchievement(appId: number, key: string): Promise<AdminRetirePlayerMetaDefinitionResponse> {
      const response = await request<AdminRetirePlayerMetaDefinitionResponse>({
        method: 'POST',
        path: `/admin/apps/${encodeURIComponent(String(appId))}/player-meta/achievements/${encodeURIComponent(key)}/retire`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'retire_admin_achievement');
      }

      return response.body;
    },

    async retireAdminLeaderboard(appId: number, key: string): Promise<AdminRetirePlayerMetaDefinitionResponse> {
      const response = await request<AdminRetirePlayerMetaDefinitionResponse>({
        method: 'POST',
        path: `/admin/apps/${encodeURIComponent(String(appId))}/player-meta/leaderboards/${encodeURIComponent(key)}/retire`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'retire_admin_leaderboard');
      }

      return response.body;
    },

    async mutateAdminAchievementState(
      appId: number,
      userId: number,
      key: string,
      body: AdminMutateAchievementStateRequest,
    ): Promise<AdminMutateAchievementStateResponse> {
      const response = await request<AdminMutateAchievementStateResponse>({
        method: 'POST',
        path: `/admin/apps/${encodeURIComponent(String(appId))}/player-meta/users/${encodeURIComponent(String(userId))}/achievements/${encodeURIComponent(key)}`,
        body,
      });

      if (response.status !== 200) {
        handleApiError(response, 'mutate_admin_achievement_state');
      }

      return response.body;
    },

    async mutateAdminLeaderboardScore(
      appId: number,
      userId: number,
      key: string,
      body: AdminMutateLeaderboardScoreRequest,
    ): Promise<AdminMutateLeaderboardScoreResponse> {
      const response = await request<AdminMutateLeaderboardScoreResponse>({
        method: 'POST',
        path: `/admin/apps/${encodeURIComponent(String(appId))}/player-meta/users/${encodeURIComponent(String(userId))}/leaderboards/${encodeURIComponent(key)}`,
        body,
      });

      if (response.status !== 200) {
        handleApiError(response, 'mutate_admin_leaderboard_score');
      }

      return response.body;
    },

    async fetchAdminCreditPacks(): Promise<CreditPacksResponse> {
      const response = await request<CreditPacksResponse>({
        method: 'GET',
        path: '/admin/credit-packs',
      });
      if (response.status !== 200) {
        handleApiError(response, 'fetch_admin_credit_packs');
      }
      return response.body;
    },

    async createAdminCreditPack(body: { sku: string; displayName: string; amount: number; costCents: number }): Promise<CreditPackResponse> {
      const response = await request<CreditPackResponse>({
        method: 'POST',
        path: '/admin/credit-packs',
        body,
      });
      if (response.status !== 201) {
        handleApiError(response, 'create_admin_credit_pack');
      }
      return response.body;
    },

    async updateAdminCreditPack(
      sku: string,
      body: { displayName?: string; amount?: number; costCents?: number },
    ): Promise<CreditPackResponse> {
      const response = await request<CreditPackResponse>({
        method: 'PATCH',
        path: `/admin/credit-packs/${encodeURIComponent(sku)}`,
        body,
      });
      if (response.status !== 200) {
        handleApiError(response, 'update_admin_credit_pack');
      }
      return response.body;
    },

    async deleteAdminCreditPack(sku: string): Promise<{ success: boolean }> {
      const response = await request<{ success: boolean }>({
        method: 'DELETE',
        path: `/admin/credit-packs/${encodeURIComponent(sku)}`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'delete_admin_credit_pack');
      }
      return response.body;
    },

    async syncAdminCreditPacksStripe(): Promise<CreditPacksResponse> {
      const response = await request<CreditPacksResponse>({
        method: 'POST',
        path: '/admin/credit-packs/sync-stripe',
      });
      if (response.status !== 200) {
        handleApiError(response, 'sync_admin_credit_packs_stripe');
      }
      return response.body;
    },

    async fetchAdminPayments(options?: FetchAdminPaymentsOptions): Promise<AdminPaymentsListResponse> {
      const query = buildAdminPaymentsQueryString(options);
      const path = query ? `/admin/payments?${query}` : '/admin/payments';
      const response = await request<AdminPaymentsListResponse>({
        method: 'GET',
        path,
      });
      if (response.status !== 200) {
        handleApiError(response, 'fetch_admin_payments');
      }
      return response.body;
    },

    async fetchAdminPayment(paymentId: number): Promise<AdminPaymentDetailResponse> {
      const response = await request<AdminPaymentDetailResponse>({
        method: 'GET',
        path: `/admin/payments/${encodeURIComponent(String(paymentId))}`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'fetch_admin_payment');
      }
      return response.body;
    },

    async refundAdminPayment(paymentId: number, body: AdminRefundPaymentRequest): Promise<AdminPaymentDetailResponse> {
      const response = await request<AdminPaymentDetailResponse>({
        method: 'POST',
        path: `/admin/payments/${encodeURIComponent(String(paymentId))}/refund`,
        body,
      });
      if (response.status !== 200) {
        handleApiError(response, 'refund_admin_payment');
      }
      return response.body;
    },

    async reconcileAdminPayment(paymentId: number): Promise<AdminPaymentDetailResponse> {
      const response = await request<AdminPaymentDetailResponse>({
        method: 'POST',
        path: `/admin/payments/${encodeURIComponent(String(paymentId))}/reconcile`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'reconcile_admin_payment');
      }
      return response.body;
    },

    async fetchAdminCreditTransactions(options?: { limit?: number; offset?: number }): Promise<AdminCreditTransactionsResponse> {
      const params = new URLSearchParams();
      if (options?.limit !== undefined) {
        params.set('limit', String(options.limit));
      }
      if (options?.offset !== undefined) {
        params.set('offset', String(options.offset));
      }
      const query = params.toString();
      const path = query ? `/admin/credit-transactions?${query}` : '/admin/credit-transactions';
      const response = await request<AdminCreditTransactionsResponse>({
        method: 'GET',
        path,
      });
      if (response.status !== 200) {
        handleApiError(response, 'fetch_admin_credit_transactions');
      }
      return response.body;
    },

    async fetchAdminAiGenerations(options?: { limit?: number; offset?: number }): Promise<AiGenerationsResponse> {
      const params = new URLSearchParams();
      if (options?.limit !== undefined) {
        params.set('limit', String(options.limit));
      }
      if (options?.offset !== undefined) {
        params.set('offset', String(options.offset));
      }
      const query = params.toString();
      const path = query ? `/admin/ai-generations?${query}` : '/admin/ai-generations';
      const response = await request<AiGenerationsResponse>({
        method: 'GET',
        path,
      });
      if (response.status !== 200) {
        handleApiError(response, 'fetch_admin_ai_generations');
      }
      return response.body;
    },

    async fetchAdminAiGeneration(id: string): Promise<AiGenerationDetailResponse> {
      const response = await request<AiGenerationDetailResponse>({
        method: 'GET',
        path: `/admin/ai-generations/${id}`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'fetch_admin_ai_generation');
      }
      return response.body;
    },
  };
}
