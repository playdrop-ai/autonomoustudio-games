import type {
  AdLoadRequest,
  AdInterstitialShowResponse,
  AdLoadResponse,
  AdShowRequest,
  AdRewardedShowResponse,
  AssetPurchaseRequest,
  BoostActivationRequest,
  BoostBalanceResponse,
  BoostHistoryResponse,
  BoostPurchaseRequest,
  BoostPurchaseResponse,
  BoostReportQuery,
  BoostReportResponse,
  BoostStatusResponse,
  CreditPackCheckoutSessionRequest,
  CreditPackCheckoutSessionResponse,
  CreditPackCheckoutStatusResponse,
  CreatorEarningsResponse,
  IapPurchaseRequest,
  IapPurchaseResponse,
  IapReceiptListParams,
  IapReceiptResponse,
  IapReceiptsResponse,
  PurchaseResponse,
  ShopResponse,
  TransactionsResponse,
} from '@playdrop/types';

type ApiResponseLike<T> = {
  status: number;
  body: T;
  headers: Headers;
};

type RequestExecutor = <T>(input: {
  method: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
  path: string;
  body?: unknown;
  headers?: Record<string, string>;
  signal?: AbortSignal;
}) => Promise<ApiResponseLike<T>>;

type ErrorHandler = (response: ApiResponseLike<unknown>, defaultMessage: string) => never;

// eslint-disable-next-line max-lines-per-function -- Payments transport methods are intentionally grouped in one factory.
export function buildPaymentsApiClientMethods(input: {
  request: RequestExecutor;
  handleApiError: ErrorHandler;
  buildIapQuery: (params?: IapReceiptListParams) => string | null;
}) {
  const { request, handleApiError, buildIapQuery } = input;

  return {
    async fetchPublicCreditShop(): Promise<ShopResponse> {
      const response = await request<ShopResponse>({
        method: 'GET',
        path: '/shop/public',
      });
      if (response.status !== 200) {
        handleApiError(response, 'fetch_public_shop');
      }
      return response.body;
    },

    async fetchCreditShop(): Promise<ShopResponse> {
      const response = await request<ShopResponse>({
        method: 'GET',
        path: '/shop',
      });
      if (response.status !== 200) {
        handleApiError(response, 'fetch_shop');
      }
      return response.body;
    },

    async createCreditPackCheckoutSession(
      sku: string,
      requestBody?: CreditPackCheckoutSessionRequest,
    ): Promise<CreditPackCheckoutSessionResponse> {
      const normalizedSku = sku.trim();
      if (!normalizedSku) {
        throw new Error('invalid_credit_pack_sku');
      }
      const response = await request<CreditPackCheckoutSessionResponse>({
        method: 'POST',
        path: `/shop/credit-packs/${encodeURIComponent(normalizedSku)}/checkout-session`,
        ...(requestBody ? { body: requestBody } : {}),
      });
      if (response.status !== 200) {
        handleApiError(response, 'create_credit_pack_checkout_session');
      }
      return response.body;
    },

    async fetchCreditPackCheckoutStatus(sessionId: string): Promise<CreditPackCheckoutStatusResponse> {
      const normalizedSessionId = sessionId.trim();
      if (!normalizedSessionId) {
        throw new Error('invalid_checkout_session_id');
      }
      const response = await request<CreditPackCheckoutStatusResponse>({
        method: 'GET',
        path: `/shop/credit-packs/checkout-session/${encodeURIComponent(normalizedSessionId)}`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'fetch_credit_pack_checkout_status');
      }
      return response.body;
    },

    async purchaseAsset(body: AssetPurchaseRequest): Promise<PurchaseResponse> {
      const response = await request<PurchaseResponse>({
        method: 'POST',
        path: '/purchase',
        body,
      });
      if (response.status !== 200) {
        handleApiError(response, 'purchase_asset');
      }
      return response.body;
    },

    async purchaseIap(body: IapPurchaseRequest): Promise<IapPurchaseResponse> {
      const response = await request<IapPurchaseResponse>({
        method: 'POST',
        path: '/iap/purchase',
        body,
      });
      if (response.status !== 200) {
        handleApiError(response, 'purchase_iap');
      }
      return response.body;
    },

    async purchaseDevIap(appId: number, slot: number, body: IapPurchaseRequest): Promise<IapPurchaseResponse> {
      const response = await request<IapPurchaseResponse>({
        method: 'POST',
        path: `/apps/${encodeURIComponent(String(appId))}/dev/players/${encodeURIComponent(String(slot))}/iap/purchase`,
        body,
      });
      if (response.status !== 200) {
        handleApiError(response, 'purchase_dev_iap');
      }
      return response.body;
    },

    async fetchIapReceipts(params?: IapReceiptListParams): Promise<IapReceiptsResponse> {
      const query = buildIapQuery(params);
      const path = query ? `/iap/receipts?${query}` : '/iap/receipts';
      const response = await request<IapReceiptsResponse>({
        method: 'GET',
        path,
      });
      if (response.status !== 200) {
        handleApiError(response, 'fetch_iap_receipts');
      }
      return response.body;
    },

    async cancelIapReceipt(receiptId: number): Promise<IapReceiptResponse> {
      const response = await request<IapReceiptResponse>({
        method: 'POST',
        path: `/iap/receipts/${encodeURIComponent(String(receiptId))}/cancel`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'cancel_iap_receipt');
      }
      return response.body;
    },

    async fetchAppIapReceipts(params?: Omit<IapReceiptListParams, 'appId'>): Promise<IapReceiptsResponse> {
      const query = buildIapQuery(params as IapReceiptListParams | undefined);
      const path = query ? `/app/iap/receipts?${query}` : '/app/iap/receipts';
      const response = await request<IapReceiptsResponse>({
        method: 'GET',
        path,
      });
      if (response.status !== 200) {
        handleApiError(response, 'fetch_app_iap_receipts');
      }
      return response.body;
    },

    async consumeAppIapReceipt(receiptId: number): Promise<IapReceiptResponse> {
      const response = await request<IapReceiptResponse>({
        method: 'POST',
        path: `/app/iap/receipts/${encodeURIComponent(String(receiptId))}/consume`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'consume_app_iap_receipt');
      }
      return response.body;
    },

    async grantAppIapReceipt(receiptId: number): Promise<IapReceiptResponse> {
      const response = await request<IapReceiptResponse>({
        method: 'POST',
        path: `/app/iap/receipts/${encodeURIComponent(String(receiptId))}/grant`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'grant_app_iap_receipt');
      }
      return response.body;
    },

    async cancelAppIapReceipt(receiptId: number): Promise<IapReceiptResponse> {
      const response = await request<IapReceiptResponse>({
        method: 'POST',
        path: `/app/iap/receipts/${encodeURIComponent(String(receiptId))}/cancel`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'cancel_app_iap_receipt');
      }
      return response.body;
    },

    async fetchCreditTransactions(options?: { limit?: number; offset?: number }): Promise<TransactionsResponse> {
      const params = new URLSearchParams();
      if (options?.limit !== undefined) {
        params.set('limit', String(options.limit));
      }
      if (options?.offset !== undefined) {
        params.set('offset', String(options.offset));
      }
      const query = params.toString();
      const path = query ? `/transactions?${query}` : '/transactions';
      const response = await request<TransactionsResponse>({
        method: 'GET',
        path,
      });
      if (response.status !== 200) {
        handleApiError(response, 'fetch_credit_transactions');
      }
      return response.body;
    },

    async fetchBoostBalance(): Promise<BoostBalanceResponse> {
      const response = await request<BoostBalanceResponse>({
        method: 'GET',
        path: '/boosts/balance',
      });
      if (response.status !== 200) {
        handleApiError(response, 'fetch_boost_balance');
      }
      return response.body;
    },

    async purchaseBoostPack(body: BoostPurchaseRequest): Promise<BoostPurchaseResponse> {
      const normalizedQuantity = body.quantity;
      if (normalizedQuantity !== undefined) {
        if (!Number.isInteger(normalizedQuantity) || normalizedQuantity <= 0) {
          throw new Error('invalid_boost_quantity');
        }
      }
      const response = await request<BoostPurchaseResponse>({
        method: 'POST',
        path: '/boosts/purchase',
        body,
      });
      if (response.status !== 200) {
        handleApiError(response, 'purchase_boost_pack');
      }
      return response.body;
    },

    async activateAppBoost(appId: number, body?: BoostActivationRequest): Promise<BoostStatusResponse> {
      const normalizedAppId = Number(appId);
      if (!Number.isInteger(normalizedAppId) || normalizedAppId <= 0) {
        throw new Error('invalid_app_id');
      }
      const response = await request<BoostStatusResponse>({
        method: 'POST',
        path: `/apps/${encodeURIComponent(String(normalizedAppId))}/boosts/activate`,
        ...(body ? { body } : {}),
      });
      if (response.status !== 200) {
        handleApiError(response, 'activate_app_boost');
      }
      return response.body;
    },

    async fetchAppBoostStatus(appId: number): Promise<BoostStatusResponse> {
      const normalizedAppId = Number(appId);
      if (!Number.isInteger(normalizedAppId) || normalizedAppId <= 0) {
        throw new Error('invalid_app_id');
      }
      const response = await request<BoostStatusResponse>({
        method: 'GET',
        path: `/apps/${encodeURIComponent(String(normalizedAppId))}/boosts/status`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'fetch_app_boost_status');
      }
      return response.body;
    },

    async fetchAppBoostHistory(appId: number, options?: { limit?: number }): Promise<BoostHistoryResponse> {
      const normalizedAppId = Number(appId);
      if (!Number.isInteger(normalizedAppId) || normalizedAppId <= 0) {
        throw new Error('invalid_app_id');
      }
      const params = new URLSearchParams();
      if (typeof options?.limit === 'number') {
        if (!Number.isInteger(options.limit) || options.limit <= 0) {
          throw new Error('invalid_boost_history_limit');
        }
        params.set('limit', String(options.limit));
      }
      const query = params.toString();
      const response = await request<BoostHistoryResponse>({
        method: 'GET',
        path: query
          ? `/apps/${encodeURIComponent(String(normalizedAppId))}/boosts/history?${query}`
          : `/apps/${encodeURIComponent(String(normalizedAppId))}/boosts/history`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'fetch_app_boost_history');
      }
      return response.body;
    },

    async fetchAppBoostReport(appId: number, options?: BoostReportQuery): Promise<BoostReportResponse> {
      const normalizedAppId = Number(appId);
      if (!Number.isInteger(normalizedAppId) || normalizedAppId <= 0) {
        throw new Error('invalid_app_id');
      }
      const params = new URLSearchParams();
      if (typeof options?.days === 'number') {
        if (options.startDateUtc || options.endDateUtc) {
          throw new Error('invalid_boost_report_range');
        }
        params.set('days', String(options.days));
      }
      if (typeof options?.startDateUtc === 'string') {
        params.set('startDateUtc', options.startDateUtc);
      }
      if (typeof options?.endDateUtc === 'string') {
        params.set('endDateUtc', options.endDateUtc);
      }
      const query = params.toString();
      const response = await request<BoostReportResponse>({
        method: 'GET',
        path: query
          ? `/apps/${encodeURIComponent(String(normalizedAppId))}/boosts/report?${query}`
          : `/apps/${encodeURIComponent(String(normalizedAppId))}/boosts/report`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'fetch_app_boost_report');
      }
      return response.body;
    },

    async fetchCreatorEarnings(options?: { days?: number; appId?: number }): Promise<CreatorEarningsResponse> {
      const params = new URLSearchParams();
      if (typeof options?.days === 'number') {
        params.set('days', String(options.days));
      }
      if (typeof options?.appId === 'number') {
        params.set('appId', String(options.appId));
      }
      const query = params.toString();
      const response = await request<CreatorEarningsResponse>({
        method: 'GET',
        path: query ? `/creator/earnings?${query}` : '/creator/earnings',
      });
      if (response.status !== 200) {
        handleApiError(response, 'fetch_creator_earnings');
      }
      return response.body;
    },

    async loadInterstitialAd(body: AdLoadRequest): Promise<AdLoadResponse> {
      const response = await request<AdLoadResponse>({
        method: 'POST',
        path: '/ads/interstitial/load',
        body,
      });
      if (response.status !== 200) {
        handleApiError(response, 'load_interstitial_ad');
      }
      return response.body;
    },

    async loadDevInterstitialAd(appId: number, slot: number, body: Pick<AdLoadRequest, 'viewerSurface'>): Promise<AdLoadResponse> {
      const response = await request<AdLoadResponse>({
        method: 'POST',
        path: `/apps/${encodeURIComponent(String(appId))}/dev/players/${encodeURIComponent(String(slot))}/ads/interstitial/load`,
        body,
      });
      if (response.status !== 200) {
        handleApiError(response, 'load_dev_interstitial_ad');
      }
      return response.body;
    },

    async showInterstitialAd(body: AdShowRequest): Promise<AdInterstitialShowResponse> {
      const response = await request<AdInterstitialShowResponse>({
        method: 'POST',
        path: '/ads/interstitial/show',
        body,
      });
      if (response.status !== 200) {
        handleApiError(response, 'show_interstitial_ad');
      }
      return response.body;
    },

    async showDevInterstitialAd(appId: number, slot: number, body: AdShowRequest): Promise<AdInterstitialShowResponse> {
      const response = await request<AdInterstitialShowResponse>({
        method: 'POST',
        path: `/apps/${encodeURIComponent(String(appId))}/dev/players/${encodeURIComponent(String(slot))}/ads/interstitial/show`,
        body,
      });
      if (response.status !== 200) {
        handleApiError(response, 'show_dev_interstitial_ad');
      }
      return response.body;
    },

    async loadRewardedAd(body: AdLoadRequest): Promise<AdLoadResponse> {
      const response = await request<AdLoadResponse>({
        method: 'POST',
        path: '/ads/rewarded/load',
        body,
      });
      if (response.status !== 200) {
        handleApiError(response, 'load_rewarded_ad');
      }
      return response.body;
    },

    async loadDevRewardedAd(appId: number, slot: number, body: Pick<AdLoadRequest, 'viewerSurface'>): Promise<AdLoadResponse> {
      const response = await request<AdLoadResponse>({
        method: 'POST',
        path: `/apps/${encodeURIComponent(String(appId))}/dev/players/${encodeURIComponent(String(slot))}/ads/rewarded/load`,
        body,
      });
      if (response.status !== 200) {
        handleApiError(response, 'load_dev_rewarded_ad');
      }
      return response.body;
    },

    async showRewardedAd(body: AdShowRequest): Promise<AdRewardedShowResponse> {
      const response = await request<AdRewardedShowResponse>({
        method: 'POST',
        path: '/ads/rewarded/show',
        body,
      });
      if (response.status !== 200) {
        handleApiError(response, 'show_rewarded_ad');
      }
      return response.body;
    },

    async showDevRewardedAd(appId: number, slot: number, body: AdShowRequest): Promise<AdRewardedShowResponse> {
      const response = await request<AdRewardedShowResponse>({
        method: 'POST',
        path: `/apps/${encodeURIComponent(String(appId))}/dev/players/${encodeURIComponent(String(slot))}/ads/rewarded/show`,
        body,
      });
      if (response.status !== 200) {
        handleApiError(response, 'show_dev_rewarded_ad');
      }
      return response.body;
    },
  };
}
