import type {
  SearchAssetType,
  SearchKind,
  SearchMode,
  SearchRequest,
  SearchResponse,
  SearchSuggestRequest,
  SearchSuggestResponse,
} from '@playdrop/types';

type ApiResponseLike<T> = {
  status: number;
  body: T;
  headers: Headers;
};

type RequestExecutor = <T>(input: {
  method: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
  path: string;
  body?: unknown;
  headers?: Record<string, string>;
  signal?: AbortSignal;
}) => Promise<ApiResponseLike<T>>;

type ErrorHandler = (response: ApiResponseLike<unknown>, defaultMessage: string) => never;

function setNormalizedStringParam(params: URLSearchParams, key: string, value: unknown): void {
  if (typeof value !== 'string') {
    return;
  }
  const normalized = value.trim();
  if (normalized.length > 0) {
    params.set(key, normalized);
  }
}

function setNormalizedPositiveIntegerParam(
  params: URLSearchParams,
  key: string,
  value: number | undefined,
  normalizePositiveIntegerInput: (value: number, errorCode: string) => number,
  errorCode: string,
): void {
  if (value === undefined) {
    return;
  }
  params.set(key, String(normalizePositiveIntegerInput(value, errorCode)));
}

function appendNormalizedTagParams(params: URLSearchParams, tags: string[] | undefined): void {
  if (!Array.isArray(tags)) {
    return;
  }
  for (const tag of tags) {
    if (typeof tag !== 'string') {
      continue;
    }
    const normalized = tag.trim();
    if (normalized.length > 0) {
      params.append('tag', normalized);
    }
  }
}

function hasSearchScopeFilters(searchRequest: SearchRequest): boolean {
  return typeof searchRequest.creatorUsername === 'string' && searchRequest.creatorUsername.trim().length > 0
    || Array.isArray(searchRequest.tags) && searchRequest.tags.length > 0
    || searchRequest.appType !== undefined
    || searchRequest.auth !== undefined
    || searchRequest.controller !== undefined
    || searchRequest.surface !== undefined
    || searchRequest.assetType !== undefined
    || searchRequest.assetCategory !== undefined
    || typeof searchRequest.assetSubcategory === 'string'
    || typeof searchRequest.assetSpec === 'string'
    || typeof searchRequest.assetSpecOwner === 'string'
    || typeof searchRequest.assetSpecName === 'string'
    || searchRequest.packContainsCategory !== undefined
    || typeof searchRequest.packContainsSubcategory === 'string';
}

export function buildSearchApiClientMethods(input: {
  request: RequestExecutor;
  handleApiError: ErrorHandler;
  normalizeSearchModeInput: (mode: SearchMode) => SearchMode;
  normalizeSearchKindInput: (kind: SearchKind) => SearchKind;
  normalizeSearchAssetTypeInput: (assetType: SearchAssetType) => SearchAssetType;
  normalizePositiveIntegerInput: (value: number, errorCode: string) => number;
}) {
  const {
    request,
    handleApiError,
    normalizeSearchModeInput,
    normalizeSearchKindInput,
    normalizeSearchAssetTypeInput,
    normalizePositiveIntegerInput,
  } = input;

  return {
    async search(searchRequest: SearchRequest): Promise<SearchResponse> {
      const query = typeof searchRequest.q === 'string' ? searchRequest.q.trim() : '';
      if (!query && !hasSearchScopeFilters(searchRequest)) {
        throw new Error('invalid_search_query');
      }

      const params = new URLSearchParams();
      if (query) {
        params.set('q', query);
      }
      if (searchRequest.mode) {
        params.set('mode', normalizeSearchModeInput(searchRequest.mode));
      }
      if (searchRequest.kind) {
        params.set('kind', normalizeSearchKindInput(searchRequest.kind));
      }
      if (searchRequest.sort) {
        params.set('sort', searchRequest.sort);
      }
      setNormalizedStringParam(params, 'creator', searchRequest.creatorUsername);
      setNormalizedPositiveIntegerParam(params, 'page', searchRequest.page, normalizePositiveIntegerInput, 'invalid_search_page');
      setNormalizedPositiveIntegerParam(
        params,
        'pageSize',
        searchRequest.pageSize,
        normalizePositiveIntegerInput,
        'invalid_search_page_size',
      );
      if (searchRequest.appType) {
        params.set('appType', searchRequest.appType);
      }
      setNormalizedStringParam(params, 'auth', searchRequest.auth);
      setNormalizedStringParam(params, 'controller', searchRequest.controller);
      setNormalizedStringParam(params, 'surface', searchRequest.surface);
      if (searchRequest.assetType) {
        params.set('assetType', normalizeSearchAssetTypeInput(searchRequest.assetType));
      }
      if (searchRequest.assetCategory) {
        params.set('assetCategory', searchRequest.assetCategory);
      }
      setNormalizedStringParam(params, 'assetSubcategory', searchRequest.assetSubcategory);
      setNormalizedStringParam(params, 'assetSpec', searchRequest.assetSpec);
      setNormalizedStringParam(params, 'assetSpecOwner', searchRequest.assetSpecOwner);
      setNormalizedStringParam(params, 'assetSpecName', searchRequest.assetSpecName);
      if (searchRequest.packContainsCategory) {
        params.set('packContainsCategory', searchRequest.packContainsCategory);
      }
      setNormalizedStringParam(params, 'packContainsSubcategory', searchRequest.packContainsSubcategory);
      appendNormalizedTagParams(params, searchRequest.tags);

      const response = await request<SearchResponse>({
        method: 'GET',
        path: `/search?${params.toString()}`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'search');
      }

      return response.body;
    },

    async suggestSearch(searchRequest: SearchSuggestRequest): Promise<SearchSuggestResponse> {
      const query = typeof searchRequest.q === 'string' ? searchRequest.q.trim() : '';
      if (!query) {
        throw new Error('invalid_search_query');
      }

      const response = await request<SearchSuggestResponse>({
        method: 'GET',
        path: `/search/suggest?q=${encodeURIComponent(query)}`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'suggest_search');
      }

      return response.body;
    },
  };
}
