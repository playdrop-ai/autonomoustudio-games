import type {
  AdFormat,
  AdLoadResult,
  AdInterstitialShowStatus,
  AdRewardedShowStatus,
  AppRuntimeAssetSummary,
  AppAuthMode,
  AppControllerMode,
  AppSurface,
  RuntimePlayerMetaNotificationPayload,
} from '@playdrop/types';

export type Deployment = 'dev' | 'live';
export type Platform = 'web' | 'native';
export type HostRuntime = 'web' | 'native';
export type HostChannel = 'local' | 'dev' | 'prod';
export type DeviceCategory = 'desktop' | 'tablet' | 'phone';
export type DeviceOrientation = 'portrait' | 'landscape';
export type HostPauseReason =
  | 'tab_hidden'
  | 'auth_prompt'
  | 'purchase_flow'
  | 'host_overlay'
  | 'detail_hidden'
  | 'route_change'
  | 'native_background';
export type HostAudioPolicyReason = HostPauseReason | 'user_preference';
export type ControllerAvailability = 'ready' | 'blocked' | 'unsupported';
export type HostLifecyclePhase = 'preview' | 'play';

export type LoadingState =
  | { status: 'loading'; progress?: number; message?: string }
  | { status: 'ready' }
  | { status: 'error'; message?: string };

export interface ClientInitPayload {
  sdkVersion: string;
  sdkBuild: number;
}

export type LogSeverity = 'debug' | 'info' | 'warn' | 'error';

export interface LogEntry {
  severity: LogSeverity;
  message: string;
  payload?: unknown;
}

export interface HostInfo {
  deployment: Deployment;
  platform: Platform;
  sdkVersion: string;
  runtime: HostRuntime;
  appVersion: string;
  channel: HostChannel;
  apiServerUrl?: string;
  realtimeServerUrl?: string;
  assetsServerUrl?: string;
  webAppUrl?: string;
  localAssetStoreUrl?: string | null;
}

export interface DeviceInfo {
  category: DeviceCategory;
  orientation: DeviceOrientation;
  inputs: {
    keyboard: boolean;
    mouse: boolean;
    touch: boolean;
  };
}

export interface SessionInfo {
  mode: 'dev' | 'play';
  authToken: string | null;
  authState: 'anonymous' | 'authenticated';
  sessionId?: string | null;
}

export interface HostLifecycleInfo {
  phase: HostLifecyclePhase;
}

export interface MeInfo {
  id: number | null;
  isLoggedIn: boolean;
  username: string | null;
  selectedProfileAssetRef: string | null;
}

export interface ControllerGamepadInfo {
  key: string;
  index: number;
  id: string;
  mapping: string;
}

export interface HostControllerStatePayload {
  availability: ControllerAvailability;
  gamepads: ControllerGamepadInfo[];
}

export interface HostPausePayload {
  reason: HostPauseReason;
}

export interface HostResumePayload {
  reason: HostPauseReason;
}

export interface HostAudioPolicyPayload {
  enabled: boolean;
  reason: HostAudioPolicyReason;
}

export interface HostPhaseChangePayload {
  phase: HostLifecyclePhase;
}

export interface HostSessionUpdatePayload {
  session: SessionInfo;
  me: MeInfo;
}

export interface ClientAdLoadPayload {
  requestId: string;
  format: AdFormat;
}

export interface HostAdLoadResultPayload {
  requestId: string;
  format: AdFormat;
  status: AdLoadResult['status'];
  retryAfterSeconds?: number;
  reason?: string;
}

export interface ClientAdShowPayload {
  requestId: string;
  format: AdFormat;
}

export interface HostAdShowResultPayload {
  requestId: string;
  format: AdFormat;
  status: AdInterstitialShowStatus | AdRewardedShowStatus;
}

export interface AppInfo {
  id: number | null;
  name: string;
  creatorUsername: string;
  displayName: string | null;
  description: string | null;
  emoji: string | null;
  color: string | null;
  type: string | null;
  surfaceTargets: AppSurface[];
  authMode: AppAuthMode;
  controllerMode: AppControllerMode;
  previewable: boolean;
  /** Semantic version string (e.g., "1.2.3") for multiplayer room isolation */
  version: string | null;
  routes?: {
    detailUrl: string;
    playUrl: string;
    previewUrl: string;
    devUrl: string;
    devPreviewUrl: string;
  };
}

export interface HostInitPayload {
  host: HostInfo;
  device: DeviceInfo;
  session: SessionInfo;
  lifecycle: HostLifecycleInfo;
  me: MeInfo;
  app: AppInfo;
  appAssets?: AppRuntimeAssetSummary[];
  services: {
    apiBaseUrl: string;
    realtimeWebsocketUrl: string;
    assetsBaseUrl: string;
    webAppUrl: string;
    localAssetStoreUrl?: string;
  };
}

export interface BridgeEnvelope<T = unknown> {
  type: string;
  payload?: T;
}

export const BridgeEvent = {
  ClientInit: 'client:init',
  ClientAuthPrompt: 'client:auth:prompt',
  HostInit: 'host:init',
  HostStart: 'host:start',
  HostPause: 'host:pause',
  HostResume: 'host:resume',
  HostAudioPolicy: 'host:audio-policy',
  HostPhaseChange: 'host:phase-change',
  HostSessionUpdated: 'host:session-updated',
  HostControllerState: 'host:controller-state',
  ClientLoading: 'client:loading',
  ClientLog: 'client:log',
  ClientShopPurchase: 'client:shop:purchase',
  ClientAdLoad: 'client:ad:load',
  ClientAdShow: 'client:ad:show',
  ClientRuntimePlayerMetaNotification: 'client:runtime-player-meta-notification',
  HostShopPurchaseResult: 'host:shop:purchase-result',
  HostAdLoadResult: 'host:ad:load-result',
  HostAdShowResult: 'host:ad:show-result',
} as const;

export type ClientRuntimePlayerMetaNotificationPayload = RuntimePlayerMetaNotificationPayload;

export type BridgeEventName = (typeof BridgeEvent)[keyof typeof BridgeEvent];

export type BridgeMessageHandler<T = unknown> = (payload: T, envelope: BridgeEnvelope<T>) => void;

export interface BridgeTransport {
  send(envelope: BridgeEnvelope): void;
  subscribe(handler: (envelope: BridgeEnvelope) => void): () => void;
  close?(): void;
}

export interface HostBridgeOptions {
  transport?: BridgeTransport;
  iframe?: { contentWindow: Window | null } | null;
  targetOrigin?: string;
  hostWindow?: Window;
  maxQueue?: number;
}

export interface ClientBridgeOptions {
  transport?: BridgeTransport;
  mode?: 'iframe' | 'native';
  parentOrigin?: string;
  window?: Window;
  nativeHandlerName?: string;
  nativeCallbackName?: string;
  maxQueue?: number;
}
