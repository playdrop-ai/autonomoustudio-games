import type { AssetCategory, AssetFormat, AssetRef, AssetVisibility } from './asset.js';
import type { ContentTagSummary } from './api.js';
import type { AppHostingMode } from './version.js';

export const VERSION_VISIBILITY_VALUES = ['PRIVATE', 'PUBLIC'] as const;
export type VersionVisibility = (typeof VERSION_VISIBILITY_VALUES)[number];
export type AssetCategoryBreakdown = Partial<Record<AssetCategory, number>>;
export type AssetSubcategoryBreakdown = Partial<Record<string, number>>;
export const ASSET_PACK_UPLOAD_SESSION_STATUS_VALUES = ['OPEN', 'FINALIZED', 'ABORTED', 'EXPIRED'] as const;
export type AssetPackUploadSessionStatus = (typeof ASSET_PACK_UPLOAD_SESSION_STATUS_VALUES)[number];
export const ASSET_PACK_UPLOAD_INIT_STATUS_VALUES = ['created', 'resume', 'finalized'] as const;
export type AssetPackUploadInitStatus = (typeof ASSET_PACK_UPLOAD_INIT_STATUS_VALUES)[number];

export interface AssetPackVersionResponse {
  id: number;
  version: string;
  major: number;
  minor: number;
  patch: number;
  visibility: VersionVisibility;
  hostingMode: AppHostingMode;
  externalUrl?: string | null;
  downloadUrl?: string | null;
  releaseNotes?: string | null;
  assets: AssetRef[];
  assetCategoryBreakdown?: AssetCategoryBreakdown;
  assetSubcategoryBreakdown?: AssetSubcategoryBreakdown;
  iconUrl?: string | null;
  heroPortraitUrl?: string | null;
  heroLandscapeUrl?: string | null;
  screenshotPortraitUrls?: string[];
  screenshotLandscapeUrls?: string[];
  videoPortraitUrls?: string[];
  videoLandscapeUrls?: string[];
  createdAt: string;
  updatedAt: string;
}

export interface AssetPackResponse {
  id: number;
  name: string;
  displayName: string;
  description?: string | null;
  creatorId: number;
  creatorUsername: string;
  previewAppVersionId?: number | null;
  createdAt: string;
  updatedAt: string;
  currentVersion?: AssetPackVersionResponse | null;
  viewerSaved?: boolean;
  viewerLiked?: boolean;
  likeCount?: number;
  viewCount?: number;
  downloadCount?: number;
  commentCount?: number;
  remixCount?: number;
  tags: ContentTagSummary[];
}

export interface AssetPackUploadManifestFileEntry {
  role: string;
  filename: string;
  contentType: string;
  sizeBytes: number;
  sha256: string;
}

export interface AssetPackUploadOwnedAssetEntry {
  uploadKey: string;
  name: string;
  displayName?: string;
  description?: string | null;
  category: AssetCategory;
  subcategory: string | null;
  format: AssetFormat;
  assetSpec?: string;
  visibility?: AssetVisibility;
  remixRef?: string;
  tags?: string[];
  shopListed?: boolean;
  shopPriceCredits?: number;
  files: AssetPackUploadManifestFileEntry[];
}

export type AssetPackUploadLocalAssetEntry = AssetPackUploadOwnedAssetEntry;

export interface AssetPackUploadExistingAssetEntry {
  assetRef: string;
  role?: string | null;
}

export interface AssetPackUploadMemberEntry {
  uploadKey?: string;
  assetRef?: string;
  role?: string | null;
}

export interface AssetPackUploadMediaEntry {
  mediaKey: string;
  relativePath: string;
  contentType: string;
  sizeBytes: number;
  sha256: string;
}

export interface AssetPackUploadListingEntrySet {
  icon?: AssetPackUploadMediaEntry;
  heroPortrait?: AssetPackUploadMediaEntry;
  heroLandscape?: AssetPackUploadMediaEntry;
  screenshotsPortrait?: AssetPackUploadMediaEntry[];
  screenshotsLandscape?: AssetPackUploadMediaEntry[];
  videosPortrait?: AssetPackUploadMediaEntry[];
  videosLandscape?: AssetPackUploadMediaEntry[];
}

export interface InitializeAssetPackUploadRequest {
  version: string;
  visibility?: VersionVisibility;
  remixRef?: string;
  hostingMode?: AppHostingMode;
  externalUrl?: string;
  downloadUrl?: string;
  releaseNotes?: string;
  displayName?: string;
  description?: string;
  previewAppVersionId?: number;
  tags?: string[];
  clearTags?: boolean;
  ownedAssets?: AssetPackUploadOwnedAssetEntry[];
  existingAssets?: AssetPackUploadExistingAssetEntry[];
  members?: AssetPackUploadMemberEntry[];
  listing?: AssetPackUploadListingEntrySet;
}

export interface AssetPackUploadSessionState {
  id: string;
  creatorUsername: string;
  packName: string;
  version: string;
  manifestHash: string;
  status: AssetPackUploadSessionStatus;
  expiresAt?: string | null;
  uploadedAssetKeys: string[];
  uploadedMediaKeys: string[];
}

export interface AssetPackUploadedLocalAsset {
  uploadKey: string;
  creatorUsername: string;
  name: string;
  revision: number;
  versionNodeId: string;
}

export interface InitializeAssetPackUploadResponse {
  status: AssetPackUploadInitStatus;
  session: AssetPackUploadSessionState;
  pack?: AssetPackResponse;
  version?: AssetPackVersionResponse;
  versionNodeId?: string;
  uploadedLocalAssets?: AssetPackUploadedLocalAsset[];
}

export interface UploadAssetPackSessionAssetResponse {
  sessionId: string;
  uploadKey: string;
  uploaded: true;
}

export interface UploadAssetPackSessionMediaResponse {
  sessionId: string;
  mediaKey: string;
  uploaded: true;
}

export interface FinalizeAssetPackUploadResponse {
  status: 'finalized';
  session: AssetPackUploadSessionState;
  pack: AssetPackResponse;
  version: AssetPackVersionResponse;
  versionNodeId: string;
  uploadedLocalAssets: AssetPackUploadedLocalAsset[];
}

export interface AbortAssetPackUploadResponse {
  success: boolean;
  sessionId: string;
  status: AssetPackUploadSessionStatus;
}

export interface UpdateAssetPackRequest {
  name?: string;
  displayName?: string;
  description?: string | null;
  previewAppVersionId?: number | null;
}

export interface UpdateAssetPackVersionRequest {
  visibility?: VersionVisibility;
  releaseNotes?: string | null;
  setAsCurrent?: boolean;
}

export interface AssetPackListResponse {
  packs: AssetPackResponse[];
  pagination: {
    limit: number;
    offset: number;
    count: number;
    hasMore: boolean;
  };
}

export interface AssetPackDetailResponse {
  pack: AssetPackResponse;
}

export interface AssetPackVersionsListResponse {
  versions: AssetPackVersionResponse[];
  pagination?: {
    limit: number;
    offset: number;
    count: number;
    hasMore: boolean;
  };
}

export interface UpdateAssetPackResponse {
  pack: AssetPackResponse;
}

export interface UpdateAssetPackVersionResponse {
  version: AssetPackVersionResponse;
}

export interface DeleteAssetPackVersionResponse {
  success: boolean;
}

export interface DeleteAssetPackResponse {
  success: boolean;
}

export interface AssetPackSourceBundleResponse {
  filename: string;
  sizeBytes: number;
  checksum?: string | null;
}

export function isVersionVisibility(value: unknown): value is VersionVisibility {
  return typeof value === 'string' && (VERSION_VISIBILITY_VALUES as readonly string[]).includes(value);
}
