import type {
  AssetCategory,
  AssetFormat,
  AssetSourceKind,
  AssetVisibility,
} from './asset.js';

export interface OwnedAssetFingerprintFileEntry {
  role: string;
  contentType: string;
  sizeBytes: number;
  sha256: string;
}

export interface OwnedAssetFingerprintInput {
  category: AssetCategory;
  subcategory: string | null;
  format: AssetFormat;
  visibility: AssetVisibility;
  sourceKind: AssetSourceKind;
  assetSpecVersionId?: number | null;
  remixTargetNodeId?: string | null;
  validationStatus?: string | null;
  validationReportJson?: unknown;
  files: OwnedAssetFingerprintFileEntry[];
}

function sortObjectKeys(value: unknown): unknown {
  if (Array.isArray(value)) {
    return value.map((entry) => sortObjectKeys(entry));
  }
  if (!value || typeof value !== 'object') {
    return value;
  }
  return Object.keys(value as Record<string, unknown>)
    .sort((left, right) => left.localeCompare(right))
    .reduce<Record<string, unknown>>((acc, key) => {
      acc[key] = sortObjectKeys((value as Record<string, unknown>)[key]);
      return acc;
    }, {});
}

export function canonicalizeOwnedAssetFingerprintInput(input: OwnedAssetFingerprintInput): string {
  return JSON.stringify(sortObjectKeys({
    category: input.category,
    subcategory: input.subcategory ?? null,
    format: input.format,
    visibility: input.visibility,
    sourceKind: input.sourceKind,
    assetSpecVersionId: input.assetSpecVersionId ?? null,
    remixTargetNodeId: input.remixTargetNodeId ?? null,
    validationStatus: input.validationStatus ?? null,
    validationReportJson: input.validationReportJson ?? null,
    files: [...input.files]
      .map((file) => ({
        role: file.role.trim().toLowerCase(),
        contentType: file.contentType.trim().toLowerCase(),
        sizeBytes: file.sizeBytes,
        sha256: file.sha256.trim().toLowerCase(),
      }))
      .sort((left, right) => left.role.localeCompare(right.role)),
  }));
}
