import type { AppSurface } from './app.js';
import type { AssetCategory, AssetFormat, AssetVisibility } from './asset.js';
import type { AppMetadataAssetSpecSupport } from './asset-spec.js';
import type {
  AppAchievementCatalogueDefinition,
  AppLeaderboardCatalogueDefinition,
} from './player-meta.js';

// ============================================================================
// Versioning Enums
// ============================================================================

export const APP_HOSTING_MODE_VALUES = ['HOSTED', 'EXTERNAL'] as const;

export type AppHostingMode = (typeof APP_HOSTING_MODE_VALUES)[number];

export const DEFAULT_APP_HOSTING_MODE: AppHostingMode = 'HOSTED';

export function isAppHostingMode(value: unknown): value is AppHostingMode {
  if (typeof value !== 'string') {
    return false;
  }
  return (APP_HOSTING_MODE_VALUES as readonly string[]).includes(value.trim().toUpperCase());
}

export function parseAppHostingMode(value: unknown): AppHostingMode | null {
  if (typeof value !== 'string') {
    return null;
  }
  const normalized = value.trim().toUpperCase();
  return isAppHostingMode(normalized) ? (normalized as AppHostingMode) : null;
}

export const APP_VERSION_VISIBILITY_VALUES = ['PRIVATE', 'PUBLIC'] as const;

export type AppVersionVisibility = (typeof APP_VERSION_VISIBILITY_VALUES)[number];

export const DEFAULT_APP_VERSION_VISIBILITY: AppVersionVisibility = 'PUBLIC';

export function isAppVersionVisibility(value: unknown): value is AppVersionVisibility {
  if (typeof value !== 'string') {
    return false;
  }
  return (APP_VERSION_VISIBILITY_VALUES as readonly string[]).includes(value.trim().toUpperCase());
}

export function parseAppVersionVisibility(value: unknown): AppVersionVisibility | null {
  if (typeof value !== 'string') {
    return null;
  }
  const normalized = value.trim().toUpperCase();
  return isAppVersionVisibility(normalized) ? (normalized as AppVersionVisibility) : null;
}

export const REVIEW_STATE_VALUES = [
  'NOT_REQUIRED',
  'QUEUED',
  'RUNNING',
  'SUPERSEDED',
  'LOW_QUALITY',
  'PASSED',
  'FAILED',
  'ERROR',
] as const;

export type ReviewState = (typeof REVIEW_STATE_VALUES)[number];

export function isReviewState(value: unknown): value is ReviewState {
  if (typeof value !== 'string') {
    return false;
  }
  return (REVIEW_STATE_VALUES as readonly string[]).includes(value.trim().toUpperCase());
}

export function parseReviewState(value: unknown): ReviewState | null {
  if (typeof value !== 'string') {
    return null;
  }
  const normalized = value.trim().toUpperCase();
  return isReviewState(normalized) ? (normalized as ReviewState) : null;
}

export const APP_AUTH_MODE_VALUES = ['REQUIRED', 'OPTIONAL', 'NONE'] as const;

export type AppAuthMode = (typeof APP_AUTH_MODE_VALUES)[number];

export const DEFAULT_APP_AUTH_MODE: AppAuthMode = 'REQUIRED';

export function isAppAuthMode(value: unknown): value is AppAuthMode {
  if (typeof value !== 'string') {
    return false;
  }
  return (APP_AUTH_MODE_VALUES as readonly string[]).includes(value.trim().toUpperCase());
}

export function parseAppAuthMode(value: unknown): AppAuthMode | null {
  if (typeof value !== 'string') {
    return null;
  }
  const normalized = value.trim().toUpperCase();
  return isAppAuthMode(normalized) ? (normalized as AppAuthMode) : null;
}

export const APP_CONTROLLER_MODE_VALUES = ['UNSUPPORTED', 'SUPPORTED', 'REQUIRED'] as const;

export type AppControllerMode = (typeof APP_CONTROLLER_MODE_VALUES)[number];

export const DEFAULT_APP_CONTROLLER_MODE: AppControllerMode = 'UNSUPPORTED';

export function isAppControllerMode(value: unknown): value is AppControllerMode {
  if (typeof value !== 'string') {
    return false;
  }
  return (APP_CONTROLLER_MODE_VALUES as readonly string[]).includes(value.trim().toUpperCase());
}

export function parseAppControllerMode(value: unknown): AppControllerMode | null {
  if (typeof value !== 'string') {
    return null;
  }
  const normalized = value.trim().toUpperCase();
  return isAppControllerMode(normalized) ? (normalized as AppControllerMode) : null;
}

export const DEFAULT_APP_PREVIEWABLE = false;

// ============================================================================
// Semantic Versioning
// ============================================================================

export interface SemVer {
  major: number;
  minor: number;
  patch: number;
}

/**
 * Regex for validating semantic version strings.
 * Format: Major.Minor.Patch where each is a non-negative integer.
 * Leading zeros are not allowed except for 0 itself.
 */
export const SEMVER_REGEX = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$/;

/**
 * Format a SemVer object as a string (e.g., "1.2.3").
 */
export function formatVersion(v: SemVer): string {
  return `${v.major}.${v.minor}.${v.patch}`;
}

/**
 * Parse a version string into a SemVer object.
 * Returns null if the string is not a valid semantic version.
 */
export function parseVersion(s: string): SemVer | null {
  const match = s.match(SEMVER_REGEX);
  if (!match) return null;
  const [, major, minor, patch] = match;
  if (!major || !minor || !patch) {
    return null;
  }
  return {
    major: parseInt(major, 10),
    minor: parseInt(minor, 10),
    patch: parseInt(patch, 10),
  };
}

/**
 * Check if a string is a valid semantic version.
 */
export function isValidVersion(s: string): boolean {
  return SEMVER_REGEX.test(s);
}

/**
 * Compare two SemVer objects.
 * Returns negative if a < b, positive if a > b, zero if equal.
 */
export function compareVersions(a: SemVer, b: SemVer): number {
  if (a.major !== b.major) return a.major - b.major;
  if (a.minor !== b.minor) return a.minor - b.minor;
  return a.patch - b.patch;
}

// ============================================================================
// Version API Types
// ============================================================================

/**
 * Response type for an app version.
 */
export interface AppVersionResponse {
  id: number;
  /** Formatted version string (e.g., "1.2.3") */
  version: string;
  major: number;
  minor: number;
  patch: number;
  /** Version-specific description */
  description?: string | null;
  /** Version-specific emoji */
  emoji?: string | null;
  /** Version-specific color */
  color?: string | null;
  releaseNotes?: string | null;
  visibility: AppVersionVisibility;
  hostingMode: AppHostingMode;
  authMode: AppAuthMode;
  controllerMode: AppControllerMode;
  previewable: boolean;
  createdAt: string;
  updatedAt: string;
  reviewState: ReviewState;
  reviewStartedAt?: string | null;
  reviewCompletedAt?: string | null;
  /** Base URL for the version (folder URL for HOSTED, externalUrl for EXTERNAL) */
  assetUrl: string;
  /** Entry point file within assetUrl (HOSTED only) */
  entryPoint: string;
  surfaceTargets: AppSurface[];
  assetSpecSupport: AppMetadataAssetSpecSupport[];

  // HOSTED mode only
  bundleSize?: number | null;
  sourceUrl?: string | null;
  hasEcs?: boolean;
  hasServer?: boolean;

  // Listing asset URLs (computed from paths)
  iconUrl?: string | null;
  heroPortraitUrl?: string | null;
  heroLandscapeUrl?: string | null;
  socialLandscapeUrl?: string | null;
  screenshotPortraitUrls?: string[];
  screenshotLandscapeUrls?: string[];
  videoPortraitUrls?: string[];
  videoLandscapeUrls?: string[];
}

/**
 * Minimal version info for list views.
 */
export interface AppVersionSummary {
  id: number;
  version: string;
  major: number;
  minor: number;
  patch: number;
  visibility: AppVersionVisibility;
  hostingMode: AppHostingMode;
  authMode: AppAuthMode;
  controllerMode: AppControllerMode;
  previewable: boolean;
  releaseNotes?: string | null;
  reviewState: ReviewState;
  reviewStartedAt?: string | null;
  reviewCompletedAt?: string | null;
  createdAt: string;
  /** Whether this is the current (live) version */
  isCurrent?: boolean;
}

/**
 * Request type for creating a new version.
 */
export interface CreateVersionRequest {
  /** Version string in Major.Minor.Patch format */
  version: string;
  releaseNotes?: string | null;
  assetSpecSupport?: AppMetadataAssetSpecSupport[];
  visibility?: AppVersionVisibility;
  remixRef?: string;
  surfaceTargets?: AppSurface[];
  entryPoint?: string;
  authMode?: AppAuthMode;
  controllerMode?: AppControllerMode;
  previewable?: boolean;
  /** Set this version as the current version (default: true) */
  setAsCurrent?: boolean;

  // HOSTED mode (default)
  // bundle, source, ecs, server are sent as multipart files

  // EXTERNAL mode
  externalUrl?: string;
}

/**
 * Request type for updating a version.
 */
export interface UpdateVersionRequest {
  releaseNotes?: string | null;
  visibility?: AppVersionVisibility;
  /** Set this version as the current version (requires visibility: PUBLIC) */
  setAsCurrent?: boolean;
}

/**
 * Response wrapper for version list.
 */
export interface AppVersionsListResponse {
  versions: AppVersionSummary[];
}

/**
 * Response wrapper for version detail.
 */
export interface AppVersionDetailResponse {
  version: AppVersionResponse;
}

export interface AppSourceBundleResponse {
  filename: string;
  sizeBytes: number;
  checksum?: string | null;
}

/**
 * Response wrapper for version creation.
 */
export interface CreateVersionResponse {
  version: AppVersionResponse;
  versionNodeId: string;
}

export const APP_UPLOAD_SESSION_STATUS_VALUES = ['OPEN', 'FINALIZED', 'ABORTED', 'EXPIRED'] as const;
export type AppUploadSessionStatus = (typeof APP_UPLOAD_SESSION_STATUS_VALUES)[number];

export const APP_UPLOAD_INIT_STATUS_VALUES = ['created', 'resume', 'finalized'] as const;
export type AppUploadInitStatus = (typeof APP_UPLOAD_INIT_STATUS_VALUES)[number];

export interface AppUploadManifestFileEntry {
  fileKey: string;
  filename: string;
  contentType: string;
  sizeBytes: number;
  sha256: string;
}

export interface AppUploadOwnedAssetEntry {
  uploadKey: string;
  name: string;
  runtimeKey?: string;
  displayName?: string;
  description?: string | null;
  category: AssetCategory;
  subcategory: string | null;
  format: AssetFormat;
  assetSpec?: string;
  visibility?: AssetVisibility;
  remixRef?: string;
  tags?: string[];
  shopListed?: boolean;
  shopPriceCredits?: number;
  files: Array<{
    role: string;
    filename: string;
    contentType: string;
    sizeBytes: number;
    sha256: string;
  }>;
}

export interface InitializeAppUploadRequest {
  version: string;
  releaseNotes?: string;
  visibility?: AppVersionVisibility;
  surfaceTargets?: AppSurface[];
  assetSpecSupport?: AppMetadataAssetSpecSupport[];
  entryPoint?: string;
  authMode?: AppAuthMode;
  controllerMode?: AppControllerMode;
  previewable?: boolean;
  setAsCurrent?: boolean;
  skipReview?: boolean;
  tags?: string[];
  clearTags?: boolean;
  remixRef?: string;
  usesAssets?: AppUploadAssetDependencyEntry[];
  usesPacks?: string[];
  displayName?: string;
  description?: string;
  type?: string;
  emoji?: string;
  color?: string;
  achievements?: AppAchievementCatalogueDefinition[];
  leaderboards?: AppLeaderboardCatalogueDefinition[];
  externalUrl?: string;
  ownedAssets?: AppUploadOwnedAssetEntry[];
  files?: AppUploadManifestFileEntry[];
}

export type AppUploadAssetDependencyEntry =
  | string
  | {
      ref: string;
      runtimeKey?: string | null;
    };

export interface AppUploadSessionState {
  id: string;
  creatorUsername: string;
  appName: string;
  version: string;
  manifestHash: string;
  status: AppUploadSessionStatus;
  expiresAt?: string | null;
  uploadedFileKeys: string[];
  uploadedOwnedAssetKeys: string[];
}

export interface AppUploadInitFinalizedVersion {
  version: AppVersionResponse;
  versionNodeId: string;
}

export interface InitializeAppUploadResponse {
  status: AppUploadInitStatus;
  session: AppUploadSessionState;
  finalized?: AppUploadInitFinalizedVersion;
}

export interface UploadAppSessionFileResponse {
  sessionId: string;
  fileKey: string;
  uploaded: true;
}

export interface UploadAppSessionOwnedAssetResponse {
  sessionId: string;
  uploadKey: string;
  uploaded: true;
}

export interface FinalizeAppUploadResponse {
  status: 'finalized';
  session: AppUploadSessionState;
  version: AppVersionResponse;
  versionNodeId: string;
}

export interface AbortAppUploadResponse {
  success: boolean;
  sessionId: string;
  status: AppUploadSessionStatus;
}

/**
 * Response wrapper for version update.
 */
export interface UpdateVersionResponse {
  version: AppVersionResponse;
}

/**
 * Response for version deletion.
 */
export interface DeleteVersionResponse {
  success: boolean;
}
