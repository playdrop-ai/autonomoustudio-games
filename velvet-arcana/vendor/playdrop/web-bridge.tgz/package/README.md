# @playdrop/web-bridge

Iframe messaging bridge that connects the platform host (web app) with embedded games or tools.

## Responsibilities
- Provides `HostBridge` and `ClientBridge` classes that wrap postMessage transport with queueing, lifecycle hooks, and type-safe events.
- Normalises bridge events (`HostInit`, `ClientInit`, `HostStart`, etc.) shared by the web app and game SDK.
- Supports custom transports so tests or alternative embedding scenarios can inject their own message bus.

## Usage
```ts
import { createHostBridge } from '@playdrop/web-bridge';

const hostBridge = createHostBridge({ iframe, targetOrigin: 'https://www.localhost' });
hostBridge.sendInit({ gameId: 42, deployment: 'development' });
```

## Implementation Notes
- Queues outbound messages until the client signals readiness to avoid dropping early payloads.
- Debug logging is gated behind a constant so production bundles can disable it during build-time tree shaking.
- Host transports validate origins unless wildcard mode (`*`) is explicitly requested.

## Related Workspaces
- Underpins the communication layer in `apps/web` and `@playdrop/sdk`; games interact with the bridge indirectly via the SDK.
