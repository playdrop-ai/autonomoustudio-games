import type {
  ClaimFreeCreditRewardResponse,
  FreeCreditsResponse,
  InvitePreviewResponse,
  MyInviteCodeResponse,
} from '@playdrop/types';

type ApiResponseLike<T> = {
  status: number;
  body: T;
  headers: Headers;
};

type RequestExecutor = <T>(input: {
  method: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
  path: string;
  body?: unknown;
  headers?: Record<string, string>;
  signal?: AbortSignal;
}) => Promise<ApiResponseLike<T>>;

type ErrorHandler = (response: ApiResponseLike<unknown>, defaultMessage: string) => never;

export function buildFreeCreditsApiClientMethods(input: {
  request: RequestExecutor;
  handleApiError: ErrorHandler;
}) {
  const { request, handleApiError } = input;

  return {
    async fetchPublicFreeCredits(): Promise<FreeCreditsResponse> {
      const response = await request<FreeCreditsResponse>({
        method: 'GET',
        path: '/free-credits/public',
      });
      if (response.status !== 200) {
        handleApiError(response, 'fetch_public_free_credits');
      }
      return response.body;
    },

    async fetchFreeCredits(): Promise<FreeCreditsResponse> {
      const response = await request<FreeCreditsResponse>({
        method: 'GET',
        path: '/free-credits',
      });
      if (response.status !== 200) {
        handleApiError(response, 'fetch_free_credits');
      }
      return response.body;
    },

    async claimFreeCreditReward(rewardId: number): Promise<ClaimFreeCreditRewardResponse> {
      const response = await request<ClaimFreeCreditRewardResponse>({
        method: 'POST',
        path: `/free-credits/rewards/${encodeURIComponent(String(rewardId))}/claim`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'claim_free_credit_reward');
      }
      return response.body;
    },

    async fetchInvitePreview(inviteCode: string): Promise<InvitePreviewResponse> {
      const response = await request<InvitePreviewResponse>({
        method: 'GET',
        path: `/invite/${encodeURIComponent(inviteCode)}/preview`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'fetch_invite_preview');
      }
      return response.body;
    },

    async fetchMyInviteCode(): Promise<MyInviteCodeResponse> {
      const response = await request<MyInviteCodeResponse>({
        method: 'GET',
        path: '/me/invite-code',
      });
      if (response.status !== 200) {
        handleApiError(response, 'fetch_my_invite_code');
      }
      return response.body;
    },

    async submitMyInviteCode(inviteCode: string): Promise<MyInviteCodeResponse> {
      const response = await request<MyInviteCodeResponse>({
        method: 'POST',
        path: '/me/invite-code',
        body: { inviteCode },
      });
      if (response.status !== 200) {
        handleApiError(response, 'submit_my_invite_code');
      }
      return response.body;
    },
  };
}
