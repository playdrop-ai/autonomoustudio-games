import type {
  GetAchievementResponse,
  GetLeaderboardResponse,
  ListAchievementsResponse,
  ListLeaderboardsResponse,
  MyAchievementsResponse,
  MyLeaderboardsResponse,
  SetAchievementProgressRequest,
  SetAchievementProgressResponse,
  SubmitLeaderboardScoreRequest,
  SubmitLeaderboardScoreResponse,
  UnlockAchievementResponse,
} from '@playdrop/types';

type ApiResponseLike<T> = {
  status: number;
  body: T;
  headers: Headers;
};

type RequestExecutor = <T>(input: {
  method: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
  path: string;
  body?: unknown;
  headers?: Record<string, string>;
  signal?: AbortSignal;
}) => Promise<ApiResponseLike<T>>;

type ErrorHandler = (response: ApiResponseLike<unknown>, defaultMessage: string) => never;

function appendBooleanQuery(params: URLSearchParams, key: string, value: boolean | undefined): void {
  if (value === true) {
    params.set(key, 'true');
  }
}

function appendIntegerQuery(params: URLSearchParams, key: string, value: number | undefined): void {
  if (Number.isInteger(value) && Number(value) >= 0) {
    params.set(key, String(value));
  }
}

export function buildPlayerMetaApiClientMethods(input: {
  request: RequestExecutor;
  handleApiError: ErrorHandler;
}) {
  const { request, handleApiError } = input;

  return {
    async listAchievements(
      appId: number,
      options: { includeHiddenDefinitions?: boolean; includeRetired?: boolean } = {},
    ): Promise<ListAchievementsResponse> {
      const params = new URLSearchParams();
      appendBooleanQuery(params, 'includeHiddenDefinitions', options.includeHiddenDefinitions);
      appendBooleanQuery(params, 'includeRetired', options.includeRetired);
      const query = params.toString();
      const response = await request<ListAchievementsResponse>({
        method: 'GET',
        path: `/v1/apps/${encodeURIComponent(String(appId))}/achievements${query ? `?${query}` : ''}`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'list_achievements');
      }
      return response.body;
    },

    async getAchievement(
      appId: number,
      key: string,
      options: { includeHiddenDefinitions?: boolean; includeRetired?: boolean } = {},
    ): Promise<GetAchievementResponse> {
      const params = new URLSearchParams();
      appendBooleanQuery(params, 'includeHiddenDefinitions', options.includeHiddenDefinitions);
      appendBooleanQuery(params, 'includeRetired', options.includeRetired);
      const query = params.toString();
      const response = await request<GetAchievementResponse>({
        method: 'GET',
        path: `/v1/apps/${encodeURIComponent(String(appId))}/achievements/${encodeURIComponent(key)}${query ? `?${query}` : ''}`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'get_achievement');
      }
      return response.body;
    },

    async unlockAchievement(appId: number, key: string): Promise<UnlockAchievementResponse> {
      const response = await request<UnlockAchievementResponse>({
        method: 'POST',
        path: `/v1/apps/${encodeURIComponent(String(appId))}/achievements/${encodeURIComponent(key)}/unlock`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'unlock_achievement');
      }
      return response.body;
    },

    async setAchievementProgressAtLeast(
      appId: number,
      key: string,
      payload: SetAchievementProgressRequest,
    ): Promise<SetAchievementProgressResponse> {
      const response = await request<SetAchievementProgressResponse>({
        method: 'PUT',
        path: `/v1/apps/${encodeURIComponent(String(appId))}/achievements/${encodeURIComponent(key)}/progress`,
        body: payload,
      });
      if (response.status !== 200) {
        handleApiError(response, 'set_achievement_progress');
      }
      return response.body;
    },

    async listLeaderboards(
      appId: number,
      options: { includeRetired?: boolean } = {},
    ): Promise<ListLeaderboardsResponse> {
      const params = new URLSearchParams();
      appendBooleanQuery(params, 'includeRetired', options.includeRetired);
      const query = params.toString();
      const response = await request<ListLeaderboardsResponse>({
        method: 'GET',
        path: `/v1/apps/${encodeURIComponent(String(appId))}/leaderboards${query ? `?${query}` : ''}`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'list_leaderboards');
      }
      return response.body;
    },

    async getLeaderboard(
      appId: number,
      key: string,
      options: { top?: number; aroundMe?: number; includeRetired?: boolean } = {},
    ): Promise<GetLeaderboardResponse> {
      const params = new URLSearchParams();
      appendIntegerQuery(params, 'top', options.top);
      appendIntegerQuery(params, 'aroundMe', options.aroundMe);
      appendBooleanQuery(params, 'includeRetired', options.includeRetired);
      const query = params.toString();
      const response = await request<GetLeaderboardResponse>({
        method: 'GET',
        path: `/v1/apps/${encodeURIComponent(String(appId))}/leaderboards/${encodeURIComponent(key)}${query ? `?${query}` : ''}`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'get_leaderboard');
      }
      return response.body;
    },

    async submitLeaderboardScore(
      appId: number,
      key: string,
      payload: SubmitLeaderboardScoreRequest,
    ): Promise<SubmitLeaderboardScoreResponse> {
      const response = await request<SubmitLeaderboardScoreResponse>({
        method: 'POST',
        path: `/v1/apps/${encodeURIComponent(String(appId))}/leaderboards/${encodeURIComponent(key)}/submissions`,
        body: payload,
      });
      if (response.status !== 200) {
        handleApiError(response, 'submit_leaderboard_score');
      }
      return response.body;
    },

    async fetchMyAchievements(): Promise<MyAchievementsResponse> {
      const response = await request<MyAchievementsResponse>({
        method: 'GET',
        path: '/v1/me/achievements',
      });
      if (response.status !== 200) {
        handleApiError(response, 'fetch_my_achievements');
      }
      return response.body;
    },

    async fetchMyLeaderboards(): Promise<MyLeaderboardsResponse> {
      const response = await request<MyLeaderboardsResponse>({
        method: 'GET',
        path: '/v1/me/leaderboards',
      });
      if (response.status !== 200) {
        handleApiError(response, 'fetch_my_leaderboards');
      }
      return response.body;
    },
  };
}
