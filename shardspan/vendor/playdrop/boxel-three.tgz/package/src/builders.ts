import type * as THREEType from 'three';
import type { Primitive, PlainBox, TexturedBox, VoxelBox, ComboBox } from '@playdrop/boxel-core';
import { resolveFaceTextureId, resolveOverlayFaceTextureId } from '@playdrop/boxel-core';
import { createBoxGeometry } from './primitives.js';
import { createTextureMaterial, toThreeColorRGB } from './textures.js';
import type { PrimitiveBuilderContext } from './context.js';
import { buildVoxelMesh } from './voxels/mesher.js';

export const DEFAULT_COLOR = 0x3b82f6;
export const DEFAULT_OPACITY = 0.45;
export const DEFAULT_WIREFRAME_COLOR = 0x60a5fa;
const BOX_FACES = ['east', 'west', 'top', 'bottom', 'north', 'south'] as const;
const OVERLAY_THICKNESS = 0.25;

export function createBoundingBoxMesh(
  context: PrimitiveBuilderContext,
  size: [number, number, number]
): THREEType.Mesh {
  const geometry = createBoxGeometry(context.THREE, size);
  const material = new context.THREE.MeshStandardMaterial({
    color: DEFAULT_COLOR,
    transparent: true,
    opacity: DEFAULT_OPACITY,
    metalness: 0,
    roughness: 0.75,
  });
  const mesh = new context.THREE.Mesh(geometry, material);

  const edges = new context.THREE.EdgesGeometry(geometry);
  const lineMaterial = new context.THREE.LineBasicMaterial({ color: DEFAULT_WIREFRAME_COLOR });
  const wireframe = new context.THREE.LineSegments(edges, lineMaterial);
  mesh.add(wireframe);

  mesh.userData = {
    ...(mesh.userData ?? {}),
    size: [...size] as [number, number, number],
    placeholder: true,
  };

  return mesh;
}

function createPlainBoxObject(
  context: PrimitiveBuilderContext,
  primitive: PlainBox,
  alignment: 'centered' | 'grounded'
): THREEType.Mesh {
  const materialDef = context.materialsById.get(primitive.material);
  const color = materialDef?.baseColor ?? [59, 130, 246];
  const geometry = createBoxGeometry(context.THREE, primitive.size);
  const meshMaterial = new context.THREE.MeshStandardMaterial({
    color: toThreeColorRGB(context, color),
    metalness: 0,
    roughness: 1,
    transparent: materialDef?.opacity !== undefined && materialDef.opacity < 1,
    opacity: materialDef?.opacity !== undefined ? materialDef.opacity : 1,
  });

  if (materialDef?.emissiveColor) {
    meshMaterial.emissive.copy(toThreeColorRGB(context, materialDef.emissiveColor));
    meshMaterial.emissiveIntensity = 1;
  }
  meshMaterial.needsUpdate = true;

  const mesh = new context.THREE.Mesh(geometry, meshMaterial);
  mesh.name = primitive.id;
  mesh.userData = {
    ...(mesh.userData ?? {}),
    primitiveId: primitive.id,
    size: [...primitive.size] as [number, number, number],
  };
  if (alignment === 'grounded') {
    mesh.position.y = primitive.size[1] / 2;
  }
  return mesh;
}

function createTexturedBoxObject(
  context: PrimitiveBuilderContext,
  primitive: TexturedBox,
  alignment: 'centered' | 'grounded'
): THREEType.Mesh {
  const geometry = createBoxGeometry(context.THREE, primitive.size);
  const materials = BOX_FACES.map(face => createTextureMaterial(context, resolveFaceTextureId(primitive, face)));
  const renderMode = primitive.renderMode === 'cutout' ? 'cutout' : 'plain';
  materials.forEach(material => {
    if (renderMode === 'cutout') {
      material.transparent = false;
      material.alphaTest = 0.5;
      material.side = context.THREE.DoubleSide;
    } else {
      material.transparent = true;
      material.alphaTest = 0;
      material.side = context.THREE.FrontSide;
    }
    material.depthWrite = true;
    material.needsUpdate = true;
  });
  const mesh = new context.THREE.Mesh(geometry, materials);
  mesh.name = primitive.id;
  mesh.userData = {
    ...(mesh.userData ?? {}),
    primitiveId: primitive.id,
    size: [...primitive.size] as [number, number, number],
  };
  if (alignment === 'grounded') {
    mesh.position.y = primitive.size[1] / 2;
  }

  const overlayTextureIds = BOX_FACES.map(face => resolveOverlayFaceTextureId(primitive, face));
  const hasOverlay = overlayTextureIds.some(id => typeof id === 'string' && id.trim().length > 0);

  if (hasOverlay) {
    const overlaySize: [number, number, number] = [
      primitive.size[0] + OVERLAY_THICKNESS * 2,
      primitive.size[1] + OVERLAY_THICKNESS * 2,
      primitive.size[2] + OVERLAY_THICKNESS * 2,
    ];
    const overlayGeometry = createBoxGeometry(context.THREE, overlaySize);
    const overlayMaterials = overlayTextureIds.map(textureId => {
      if (!textureId) {
        const emptyMaterial = new context.THREE.MeshStandardMaterial({
          transparent: true,
          opacity: 0,
          depthWrite: false,
          metalness: 0,
          roughness: 1,
        });
        emptyMaterial.visible = false;
        emptyMaterial.needsUpdate = true;
        return emptyMaterial;
      }
      const material = createTextureMaterial(context, textureId);
      material.transparent = true;
      material.alphaTest = 0.5;
      material.side = context.THREE.DoubleSide;
      material.depthWrite = false;
      material.needsUpdate = true;
      return material;
    });

    const overlayMesh = new context.THREE.Mesh(overlayGeometry, overlayMaterials);
    overlayMesh.name = `${primitive.id}_overlay`;
    overlayMesh.renderOrder = mesh.renderOrder + 1;
    overlayMesh.userData = {
      ...(mesh.userData ?? {}),
      primitiveId: primitive.id,
      overlay: true,
      size: [...overlaySize] as [number, number, number],
    };
    mesh.add(overlayMesh);
  }

  return mesh;
}

function createVoxelObject(
  context: PrimitiveBuilderContext,
  primitive: VoxelBox,
  alignment: 'centered' | 'grounded'
): THREEType.Object3D {
  const hasData = Array.isArray(primitive.voxels) && primitive.voxels.length > 0;
  const size = primitive.size ?? [1, 1, 1];
  const dims: [number, number, number] = [
    Math.max(1, Math.round(size[0])),
    Math.max(1, Math.round(size[1])),
    Math.max(1, Math.round(size[2])),
  ];
  const worldSize: [number, number, number] = [dims[0], dims[1], dims[2]];

  if (!hasData) {
    const mesh = createBoundingBoxMesh(context, worldSize);
    mesh.userData = {
      ...(mesh.userData ?? {}),
      primitiveId: primitive.id,
      size: [...worldSize] as [number, number, number],
    };
    if (alignment === 'grounded') {
      mesh.position.y = worldSize[1] / 2;
    }
    return mesh;
  }

  const meshResult = buildVoxelMesh({
    voxels: primitive.voxels,
    dimensions: dims,
    size: worldSize,
  });

  if (meshResult.indices.length === 0 || meshResult.positions.length === 0) {
    const mesh = createBoundingBoxMesh(context, worldSize);
    mesh.userData = {
      ...(mesh.userData ?? {}),
      primitiveId: primitive.id,
      size: [...worldSize] as [number, number, number],
    };
    if (alignment === 'grounded') {
      mesh.position.y = worldSize[1] / 2;
    }
    return mesh;
  }

  const paletteIds = primitive.palette ?? [];
  const materialCache = new Map<number, THREEType.MeshStandardMaterial>();
  const materialIndexMap = new Map<number, number>();
  const materials: THREEType.MeshStandardMaterial[] = [];

  const geometry = new context.THREE.BufferGeometry();
  geometry.setAttribute('position', new context.THREE.Float32BufferAttribute(meshResult.positions, 3));
  geometry.setAttribute('normal', new context.THREE.Float32BufferAttribute(meshResult.normals, 3));
  geometry.setAttribute('uv', new context.THREE.Float32BufferAttribute(meshResult.uvs, 2));
  if (meshResult.indices.length > 0) {
    const vertexCount = meshResult.positions.length / 3;
    const useUint32 = vertexCount > 65535;
    const indexArray = useUint32 ? meshResult.indices : new Uint16Array(meshResult.indices);
    geometry.setIndex(new context.THREE.BufferAttribute(indexArray, 1));
  }
  geometry.computeBoundingBox();
  geometry.computeBoundingSphere();

  meshResult.groups.forEach(groupData => {
    const paletteIndex = groupData.material;
    let material = materialCache.get(paletteIndex);
    if (!material) {
      const materialId = paletteIds[paletteIndex - 1];
      const materialDef = materialId ? context.materialsById.get(materialId) : undefined;
      const baseColor = materialDef?.baseColor ?? [59, 130, 246];
      const emissive = materialDef?.emissiveColor;
      const opacity = materialDef?.opacity ?? 1;
      material = new context.THREE.MeshStandardMaterial({
        color: toThreeColorRGB(context, baseColor),
        metalness: 0,
        roughness: 1,
        transparent: opacity < 1,
        opacity,
      });
      if (emissive) {
        material.emissive.copy(toThreeColorRGB(context, emissive));
        material.emissiveIntensity = 1;
      }
      material.needsUpdate = true;
      materialCache.set(paletteIndex, material);
    }

    let materialIndex = materialIndexMap.get(paletteIndex);
    if (materialIndex === undefined) {
      materialIndex = materials.length;
      materials.push(material);
      materialIndexMap.set(paletteIndex, materialIndex);
    }
    geometry.addGroup(groupData.start, groupData.count, materialIndex);
  });

  const meshMaterial = materials.length === 1 ? materials[0]! : materials;
  const mesh = new context.THREE.Mesh(geometry, meshMaterial);
  mesh.name = primitive.id;
  mesh.userData = {
    ...(mesh.userData ?? {}),
    primitiveId: primitive.id,
    size: [...worldSize] as [number, number, number],
  };

  if (alignment === 'grounded') {
    mesh.position.y = size[1] / 2;
  }

  return mesh;
}

function createComboObject(
  context: PrimitiveBuilderContext,
  primitive: ComboBox,
  alignment: 'centered' | 'grounded',
  visited: Set<string>
): THREEType.Object3D {
  const group = new context.THREE.Group();
  group.name = primitive.id;
  const sockets: Array<[number, number, number]> = [];
  const slotEntries: Array<{ slot: ComboBox['slots'][number]; object: THREEType.Object3D; size: [number, number, number] }> = [];

  primitive.slots.forEach(slot => {
    const childPrimitive = context.primitivesById.get(slot.primitive);
    if (!childPrimitive) {
      console.warn('[boxel-three] combo slot references missing primitive', slot.primitive);
      return;
    }
    const object = createPrimitiveObject(context, childPrimitive, alignment, new Set(visited));
    if (!object) return;
    const childSize: [number, number, number] = [
      childPrimitive.size?.[0] ?? 0,
      childPrimitive.size?.[1] ?? 0,
      childPrimitive.size?.[2] ?? 0,
    ];
    slotEntries.push({ slot, object, size: childSize });
  });

  if (slotEntries.length === 0) {
    const fallbackSize: [number, number, number] = [
      primitive.size?.[0] ?? 1,
      primitive.size?.[1] ?? 1,
      primitive.size?.[2] ?? 1,
    ];
    const bounding = createBoundingBoxMesh(context, fallbackSize);
    bounding.userData = {
      ...(bounding.userData ?? {}),
      primitiveId: primitive.id,
      size: [...fallbackSize] as [number, number, number],
    };
    if (alignment === 'grounded') {
      bounding.position.y = fallbackSize[1] / 2;
    }
    return bounding;
  }

  let minX = Infinity;
  let minY = Infinity;
  let minZ = Infinity;
  let maxX = -Infinity;
  let maxY = -Infinity;
  let maxZ = -Infinity;

  slotEntries.forEach(({ slot, size }) => {
    const halfSize: [number, number, number] = [size[0] / 2, size[1] / 2, size[2] / 2];
    minX = Math.min(minX, slot.offset[0] - halfSize[0]);
    minY = Math.min(minY, slot.offset[1] - halfSize[1]);
    minZ = Math.min(minZ, slot.offset[2] - halfSize[2]);
    maxX = Math.max(maxX, slot.offset[0] + halfSize[0]);
    maxY = Math.max(maxY, slot.offset[1] + halfSize[1]);
    maxZ = Math.max(maxZ, slot.offset[2] + halfSize[2]);
  });

  const derivedSize: [number, number, number] = [
    Math.max(0, maxX - minX),
    Math.max(0, maxY - minY),
    Math.max(0, maxZ - minZ),
  ];

  slotEntries.forEach(({ slot, object }) => {
    object.position.set(slot.offset[0], slot.offset[1], slot.offset[2]);
    object.userData = {
      ...(object.userData ?? {}),
      comboSlotId: slot.id,
      comboParentId: primitive.id,
    };
    group.add(object);
    sockets.push([slot.offset[0], slot.offset[1], slot.offset[2]]);
  });

  const comboSize: [number, number, number] = [
    primitive.size?.[0] ?? derivedSize[0],
    primitive.size?.[1] ?? derivedSize[1],
    primitive.size?.[2] ?? derivedSize[2],
  ];

  group.userData = {
    ...(group.userData ?? {}),
    primitiveId: primitive.id,
    size: [...comboSize] as [number, number, number],
    sockets,
  };

  if (alignment === 'grounded') {
    group.position.y = comboSize[1] / 2;
  }

  return group;
}

export function createPrimitiveObject(
  context: PrimitiveBuilderContext,
  primitive: Primitive,
  alignment: 'centered' | 'grounded',
  visited = new Set<string>()
): THREEType.Object3D | null {
  if (visited.has(primitive.id)) {
    console.warn('[boxel-three] detected recursive primitive reference', primitive.id);
    return null;
  }

  visited.add(primitive.id);

  switch (primitive.kind) {
    case 'plain_box':
      return createPlainBoxObject(context, primitive as PlainBox, alignment);
    case 'textured_box':
      return createTexturedBoxObject(context, primitive as TexturedBox, alignment);
    case 'voxel_box':
      return createVoxelObject(context, primitive as VoxelBox, alignment);
    case 'combo_box':
      return createComboObject(context, primitive as ComboBox, alignment, visited);
    default:
      return null;
  }
}
