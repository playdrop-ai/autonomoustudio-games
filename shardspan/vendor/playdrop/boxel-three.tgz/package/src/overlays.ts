import type * as THREEType from 'three';
import type { BoxelOverlayOptions, BoxelOverlayHandles } from './types.js';

export interface CreateOverlayContext {
  THREE: typeof THREEType;
  target: THREEType.Object3D;
}

function createOriginHelper(THREE: typeof THREEType, options: BoxelOverlayOptions): THREEType.Object3D {
  const axes = new THREE.AxesHelper(0.5);
  if (options.opacity !== undefined) {
    const axesMaterial = axes.material as THREEType.Material & {
      opacity?: number;
      transparent?: boolean;
    };
    axesMaterial.opacity = options.opacity;
    axesMaterial.transparent = options.opacity < 1;
  }
  return axes;
}

function createBoundsHelper(
  THREE: typeof THREEType,
  size: [number, number, number],
  options: BoxelOverlayOptions
): THREEType.Object3D {
  const geometry = new THREE.BoxGeometry(size[0], size[1], size[2]);
  const material = new THREE.LineDashedMaterial({
    color: options.color ?? 0xffffff,
    dashSize: options.dashed ? 0.1 : 1,
    gapSize: options.dashed ? 0.05 : 0,
    transparent: options.opacity !== undefined,
    opacity: options.opacity ?? 1,
  });
  const edges = new THREE.EdgesGeometry(geometry);
  const line = new THREE.LineSegments(edges, material);
  line.computeLineDistances();
  return line;
}

function createSocketHelper(THREE: typeof THREEType, options: BoxelOverlayOptions): THREEType.Object3D {
  const geometry = new THREE.SphereGeometry(0.05, 8, 8);
  const material = new THREE.MeshBasicMaterial({
    color: options.color ?? 0xffff00,
    transparent: options.opacity !== undefined,
    opacity: options.opacity ?? 1,
    wireframe: true,
  });
  return new THREE.Mesh(geometry, material);
}

function disposeObjectResources(object: THREEType.Object3D): void {
  object.traverse(entry => {
    const mesh = entry as THREEType.Mesh;
    if ('geometry' in mesh && mesh.geometry) {
      const geometry = mesh.geometry as THREEType.BufferGeometry | undefined;
      geometry?.dispose?.();
    }
    if ('material' in mesh && mesh.material) {
      const material = mesh.material as THREEType.Material | THREEType.Material[];
      const disposeMaterial = (mat: THREEType.Material) => {
        const typedMaterial = mat as THREEType.Material & {
          map?: { dispose?: () => void } | null;
          emissiveMap?: { dispose?: () => void } | null;
        };
        typedMaterial.map?.dispose?.();
        typedMaterial.emissiveMap?.dispose?.();
        typedMaterial.dispose?.();
      };
      if (Array.isArray(material)) material.forEach(disposeMaterial);
      else disposeMaterial(material);
    }
  });
}

export function attachBoxelOverlays(
  context: CreateOverlayContext,
  options: BoxelOverlayOptions = {}
): BoxelOverlayHandles {
  const { THREE, target } = context;
  const overlays: BoxelOverlayHandles = {
    dispose: () => {
      if (overlays.origin) {
        target.remove(overlays.origin);
        disposeObjectResources(overlays.origin);
      }
      overlays.bounds?.forEach(bound => {
        target.remove(bound);
        disposeObjectResources(bound);
      });
      overlays.sockets?.forEach(socket => {
        target.remove(socket);
        disposeObjectResources(socket);
      });
      overlays.origin = undefined;
      overlays.bounds = undefined;
      overlays.sockets = undefined;
    },
  };

  if (options.origin) {
    const origin = createOriginHelper(THREE, options);
    overlays.origin = origin;
    target.add(origin);
  }

  if (options.bounds && target.userData?.size) {
    const bound = createBoundsHelper(THREE, target.userData.size, options);
    overlays.bounds = [bound];
    target.add(bound);
  }

  if (options.sockets && target.userData?.sockets) {
    const sockets = (target.userData.sockets as Array<[number, number, number]>).map(position => {
      const helper = createSocketHelper(THREE, options);
      helper.position.set(position[0], position[1], position[2]);
      target.add(helper);
      return helper;
    });
    overlays.sockets = sockets;
  }

  return overlays;
}
