import type * as THREEType from 'three';
import type { ConnectMode, BoxelDefinition } from '@playdrop/boxel-core';

export type { ConnectMode } from '@playdrop/boxel-core';

export interface BoxelThreeContext {
  THREE: typeof THREEType;
  entity: BoxelDefinition;
}

export interface BoxelSceneOptions {
  /**
   * Optional node identifier (or list of identifiers) to render instead of the full entity.
   * When omitted, the entire entity geometry tree is emitted.
   */
  nodes?: string | string[];
  /**
   * Configure optional overlay helpers (origin, bounds, sockets) to render alongside the scene.
   */
  overlays?: BoxelOverlayOptions;
}

export interface BoxelSceneNodeMeta {
  /**
   * Original entity node identifier.
   */
  id: string;
  /**
   * Three.js object representing the node transform.
   */
  object: THREEType.Object3D;
  /**
   * Optional primitive identifier bound to the node.
   */
  primitiveId?: string;
  /**
   * Requested parent-connect behaviour for this node.
   */
  connectMode: ConnectMode;
}

export interface BoxelSceneAnimationChannel {
  nodeId: string;
  property: 'position' | 'rotation' | 'scale';
  track: THREEType.KeyframeTrack;
}

export interface BoxelSceneAnimation {
  id: string;
  duration: number;
  channels: BoxelSceneAnimationChannel[];
  clip: THREEType.AnimationClip;
}

export interface BoxelSceneResult {
  /**
   * Root object containing the full entity mesh hierarchy.
   */
  root: THREEType.Group;
  /**
   * Lookup for every node emitted into the scene.
   */
  nodes: Map<string, BoxelSceneNodeMeta>;
  /**
   * Animation payload pre-bound to Three.js tracks.
   */
  animations: BoxelSceneAnimation[];
  /**
   * Ready-to-use AnimationClip objects derived from the animation payload.
   */
  clips: THREEType.AnimationClip[];
  /**
   * Three.js resources that should be disposed when the scene is torn down.
   */
  resources: {
    materials: THREEType.Material[];
    textures: THREEType.Texture[];
    geometries: THREEType.BufferGeometry[];
  };
  /**
   * Destroy helper to free underlying GPU buffers.
   */
  dispose: () => void;
}

/**
 * Controls which overlay helpers should be rendered for a target along with basic styling hints.
 */
export interface BoxelOverlayOptions {
  /**
   * Render the entity/world origin helper.
   */
  origin?: boolean;
  /**
   * Render bounding boxes for nodes or primitives that declare a size.
   */
  bounds?: boolean;
  /**
   * Render sphere markers for socket locations (combo slots, node centers).
   */
  sockets?: boolean;
  /**
   * Optional tint for line/mesh helpers.
   */
  color?: number;
  /**
   * Optional opacity override for helpers; defaults to fully opaque.
   */
  opacity?: number;
  /**
   * When true, draw dashed bounding boxes instead of solid lines.
   */
  dashed?: boolean;
}

export interface BoxelOverlayHandles {
  origin?: THREEType.Object3D;
  bounds?: THREEType.Object3D[];
  sockets?: THREEType.Object3D[];
  dispose: () => void;
}
