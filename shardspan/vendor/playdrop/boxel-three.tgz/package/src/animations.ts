import type * as THREEType from 'three';
import type { BoxelDefinition, Animation, AnimationChannel } from '@playdrop/boxel-core';
import type { BoxelSceneAnimation, BoxelSceneAnimationChannel } from './types.js';

function createKeyframeTrack(
  THREE: typeof THREEType,
  channel: AnimationChannel,
  nodeLookup: Map<string, THREEType.Object3D>
): THREEType.KeyframeTrack | null {
  const object = nodeLookup.get(channel.node);
  if (!object) {
    console.warn('[boxel-three] animation channel references missing node', channel.node);
    return null;
  }

  const times = channel.keyframes.map(keyframe => keyframe.time);
  const targetName = object.name && object.name.length > 0 ? object.name : object.uuid;

  switch (channel.property) {
    case 'position': {
      const values = channel.keyframes.flatMap(keyframe => keyframe.value);
      return new THREE.VectorKeyframeTrack(`${targetName}.position`, times, values);
    }
    case 'rotation': {
      const values: number[] = [];
      channel.keyframes.forEach(keyframe => {
        const radX = THREE.MathUtils.degToRad(keyframe.value[0]);
        const radY = THREE.MathUtils.degToRad(keyframe.value[1]);
        const radZ = THREE.MathUtils.degToRad(keyframe.value[2]);
        const quaternion = new THREE.Quaternion().setFromEuler(new THREE.Euler(radX, radY, radZ));
        values.push(quaternion.x, quaternion.y, quaternion.z, quaternion.w);
      });
      return new THREE.QuaternionKeyframeTrack(`${targetName}.quaternion`, times, values);
    }
    case 'scale': {
      const values = channel.keyframes.flatMap(keyframe => keyframe.value);
      return new THREE.VectorKeyframeTrack(`${targetName}.scale`, times, values);
    }
    default:
      return null;
  }
}

function buildAnimation(
  THREE: typeof THREEType,
  animation: Animation,
  nodeLookup: Map<string, THREEType.Object3D>
): BoxelSceneAnimation | null {
  const tracks: BoxelSceneAnimationChannel[] = [];

  animation.channels.forEach(channel => {
    const track = createKeyframeTrack(THREE, channel, nodeLookup);
    if (!track) return;
    tracks.push({
      nodeId: channel.node,
      property: channel.property,
      track,
    });
  });

  if (tracks.length === 0) {
    return null;
  }

  const threeTracks = tracks.map(channel => channel.track);
  const inferredDuration = threeTracks.reduce((max, track) => {
    const times = track.times;
    if (!times || times.length === 0) return max;
    return Math.max(max, times[times.length - 1]);
  }, 0);

  const duration = typeof animation.duration === 'number' && animation.duration > 0
    ? animation.duration
    : inferredDuration;

  const clip = new THREE.AnimationClip(animation.id, duration, threeTracks);

  return {
    id: animation.id,
    duration,
    channels: tracks,
    clip,
  };
}

export function buildAnimations(
  THREE: typeof THREEType,
  entity: BoxelDefinition,
  nodeLookup: Map<string, THREEType.Object3D>
): BoxelSceneAnimation[] {
  return (entity.animations ?? [])
    .map(animation => buildAnimation(THREE, animation, nodeLookup))
    .filter((value): value is BoxelSceneAnimation => Boolean(value));
}
