import { generateGreedyQuads, type GreedyQuad, type VoxelBox } from '@playdrop/boxel-core';

export interface BuildVoxelMeshOptions {
  voxels: number[];
  dimensions: [number, number, number];
  size: [number, number, number];
}

export interface VoxelMaterialGroup {
  material: number;
  start: number;
  count: number;
}

export interface VoxelMeshResult {
  positions: Float32Array;
  normals: Float32Array;
  uvs: Float32Array;
  indices: Uint32Array;
  groups: VoxelMaterialGroup[];
  stats: {
    voxels: number;
    faces: number;
  };
}

export function buildVoxelMesh(options: BuildVoxelMeshOptions): VoxelMeshResult {
  const { voxels, dimensions, size } = options;
  const quads = generateGreedyQuads(voxels, dimensions);
  const halfSize: [number, number, number] = [size[0] / 2, size[1] / 2, size[2] / 2];

  const cellSizes: [number, number, number] = [
    dimensions[0] > 0 ? size[0] / dimensions[0] : 1,
    dimensions[1] > 0 ? size[1] / dimensions[1] : 1,
    dimensions[2] > 0 ? size[2] / dimensions[2] : 1,
  ];

  if (quads.length === 0) {
    return {
      positions: new Float32Array(0),
      normals: new Float32Array(0),
      uvs: new Float32Array(0),
      indices: new Uint32Array(0),
      groups: [],
      stats: {
        voxels: voxels.filter(value => value !== 0).length,
        faces: 0,
      },
    };
  }

  const positions: number[] = [];
  const normals: number[] = [];
  const uvs: number[] = [];
  const indices: number[] = [];
  const groups: VoxelMaterialGroup[] = [];

  const pushQuad = (quad: GreedyQuad) => {
    const baseIndex = positions.length / 3;
    const axis = quad.axis;
    const uAxis = ((axis + 1) % 3) as 0 | 1 | 2;
    const vAxis = ((axis + 2) % 3) as 0 | 1 | 2;
    const width = quad.size[0];
    const height = quad.size[1];

    const base: [number, number, number] = [quad.origin[0], quad.origin[1], quad.origin[2]];
    base[axis] = quad.plane;

    const corners: Array<[number, number]> = quad.normal === 1
      ? [
          [0, 0],
          [width, 0],
          [width, height],
          [0, height],
        ]
      : [
          [0, 0],
          [0, height],
          [width, height],
          [width, 0],
        ];

    const normalVector: [number, number, number] = [0, 0, 0];
    normalVector[axis] = quad.normal;

    corners.forEach(([uOffset, vOffset]) => {
      const vertex: [number, number, number] = [base[0], base[1], base[2]];
      vertex[uAxis] = base[uAxis] + uOffset;
      vertex[vAxis] = base[vAxis] + vOffset;

      positions.push(
        vertex[0] * cellSizes[0] - halfSize[0],
        vertex[1] * cellSizes[1] - halfSize[1],
        vertex[2] * cellSizes[2] - halfSize[2]
      );

      normals.push(normalVector[0], normalVector[1], normalVector[2]);

      const u = width > 0 ? uOffset / width : 0;
      const v = height > 0 ? vOffset / height : 0;
      uvs.push(u, v);
    });

    const startIndex = indices.length;
    indices.push(
      baseIndex,
      baseIndex + 1,
      baseIndex + 2,
      baseIndex,
      baseIndex + 2,
      baseIndex + 3
    );

    const lastGroup = groups[groups.length - 1];
    if (lastGroup && lastGroup.material === quad.material && lastGroup.start + lastGroup.count === startIndex) {
      lastGroup.count += 6;
    } else {
      groups.push({ material: quad.material, start: startIndex, count: 6 });
    }
  };

  quads.forEach(pushQuad);

  return {
    positions: Float32Array.from(positions),
    normals: Float32Array.from(normals),
    uvs: Float32Array.from(uvs),
    indices: Uint32Array.from(indices),
    groups,
    stats: {
      voxels: voxels.filter(value => value !== 0).length,
      faces: quads.length,
    },
  };
}

export function hasVoxelData(primitive: VoxelBox): boolean {
  return Array.isArray(primitive.voxels) && primitive.voxels.length > 0;
}
