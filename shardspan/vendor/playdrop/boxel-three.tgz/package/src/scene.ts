import type * as THREEType from 'three';
import type {
  BoxelThreeContext,
  BoxelSceneOptions,
  BoxelSceneResult,
  BoxelSceneNodeMeta,
  BoxelOverlayOptions,
  BoxelOverlayHandles,
} from './types.js';
import { createBuilderContext, updateBuilderContext } from './context.js';
import { buildNodeObject } from './nodes.js';
import { buildAnimations } from './animations.js';
import { attachBoxelOverlays } from './overlays.js';

function normalizeNodeFilter(nodes?: string | string[]): Set<string> | null {
  if (!nodes) return null;
  if (Array.isArray(nodes)) {
    return new Set(nodes);
  }
  return new Set([nodes]);
}

export function createBoxelScene(
  context: BoxelThreeContext,
  options: BoxelSceneOptions = {}
): BoxelSceneResult {
  const { THREE, entity } = context;
  const nodeFilter = normalizeNodeFilter(options.nodes);

  const builderContext = createBuilderContext({
    THREE,
    settings: { enableShadows: false },
  });
  updateBuilderContext(builderContext, { entity });

  const root = new THREE.Group();
  const nodeObjects = new Map<string, BoxelSceneNodeMeta>();
  const overlayHandles: BoxelOverlayHandles[] = [];

  const gatherNode = (nodeId: string): THREEType.Object3D | null => {
    const node = entity.geometry.root.id === nodeId
      ? entity.geometry.root
      : (function find(current: typeof entity.geometry.root): typeof entity.geometry.root | null {
          if (current.id === nodeId) return current;
          for (const child of current.children) {
            const result = find(child);
            if (result) return result;
          }
          return null;
        })(entity.geometry.root);

    if (!node) {
      console.warn('[boxel-three] node not found', nodeId);
      return null;
    }

    const { object, nodes } = buildNodeObject(builderContext, node);
    nodes.forEach((nodeObject, id) => {
      nodeObjects.set(id, {
        id,
        object: nodeObject,
        primitiveId: nodeObject.userData?.primitiveId,
        connectMode: (nodeObject.userData?.connectMode ?? 'none') as BoxelSceneNodeMeta['connectMode'],
      });
    });
    return object;
  };

  if (nodeFilter) {
    nodeFilter.forEach(nodeId => {
      const object = gatherNode(nodeId);
      if (object) {
        root.add(object);
      }
    });
  } else {
    const { object, nodes } = buildNodeObject(builderContext, entity.geometry.root);
    root.add(object);
    nodes.forEach((nodeObject, id) => {
      nodeObjects.set(id, {
        id,
        object: nodeObject,
        primitiveId: nodeObject.userData?.primitiveId,
        connectMode: (nodeObject.userData?.connectMode ?? 'none') as BoxelSceneNodeMeta['connectMode'],
      });
    });
  }

  const applyOverlays = (overlayOptions?: BoxelOverlayOptions) => {
    if (!overlayOptions) return;
    const style: BoxelOverlayOptions = {
      color: overlayOptions.color,
      opacity: overlayOptions.opacity,
      dashed: overlayOptions.dashed,
    };
    const rootId = entity.geometry.root.id;

    nodeObjects.forEach(meta => {
      const request: BoxelOverlayOptions = {
        ...style,
        origin: overlayOptions.origin && meta.id === rootId,
        bounds: overlayOptions.bounds && Boolean(meta.object.userData?.size),
        sockets: overlayOptions.sockets && Boolean(meta.object.userData?.sockets),
      };

      if (!request.origin && !request.bounds && !request.sockets) {
        return;
      }

      const handles = attachBoxelOverlays({ THREE, target: meta.object }, request);
      overlayHandles.push(handles);
    });
  };

  applyOverlays(options.overlays);

  const animationMeta = buildAnimations(THREE, entity, new Map(Array.from(nodeObjects.entries()).map(([id, meta]) => [id, meta.object])));
  const clips = animationMeta.map(animation => animation.clip);

  const resources = {
    materials: [] as THREEType.Material[],
    textures: [] as THREEType.Texture[],
    geometries: [] as THREEType.BufferGeometry[],
  };

  root.traverse(object => {
    if (object instanceof THREE.Mesh) {
      const mesh = object as THREEType.Mesh;
      const material = mesh.material;
      const collectMaterial = (mat: THREEType.Material) => {
        resources.materials.push(mat);
        if ('map' in mat && mat.map) resources.textures.push(mat.map as THREEType.Texture);
        if ('emissiveMap' in mat && mat.emissiveMap) resources.textures.push(mat.emissiveMap as THREEType.Texture);
      };
      if (Array.isArray(material)) {
        material.forEach(mat => collectMaterial(mat));
      } else if (material) {
        collectMaterial(material);
      }
      if (mesh.geometry) {
        resources.geometries.push(mesh.geometry as THREEType.BufferGeometry);
      }
    }
  });

  const dispose = () => {
    overlayHandles.splice(0).forEach(handles => handles.dispose());
    resources.geometries.forEach(geometry => geometry.dispose?.());
    resources.materials.forEach(material => material.dispose?.());
    resources.textures.forEach(texture => texture.dispose?.());
    nodeObjects.clear();
    root.clear();
  };

  return {
    root,
    nodes: nodeObjects,
    animations: animationMeta,
    clips,
    resources,
    dispose,
  };
}

export function createBoxelNodeScene(
  context: BoxelThreeContext,
  nodeId: string,
  options: BoxelSceneOptions = {}
): BoxelSceneResult {
  return createBoxelScene(context, { ...options, nodes: nodeId });
}
