import type * as THREEType from 'three';

export type AtlasTransform = {
  offset: [number, number];
  scale: [number, number];
};

export interface TextureAtlasResult {
  texture: THREEType.DataTexture;
  transforms: Map<THREEType.DataTexture, AtlasTransform>;
  width: number;
  height: number;
}

const toPowerOfTwo = (value: number): number => {
  return 2 ** Math.ceil(Math.log2(Math.max(1, value)));
};

export function buildTextureAtlas(
  THREE: typeof THREEType,
  textures: readonly THREEType.DataTexture[]
): TextureAtlasResult | null {
  const uniqueTextures = Array.from(new Set(textures));
  if (uniqueTextures.length === 0) {
    return null;
  }

  const maxWidth = uniqueTextures.reduce((acc, tex) => Math.max(acc, tex.image?.width ?? 0), 0);
  const totalHeight = uniqueTextures.reduce((acc, tex) => acc + (tex.image?.height ?? 0), 0);

  if (maxWidth === 0 || totalHeight === 0) {
    return null;
  }

  const atlasWidth = toPowerOfTwo(maxWidth);
  const atlasHeight = toPowerOfTwo(totalHeight);
  const atlasData = new Uint8Array(atlasWidth * atlasHeight * 4);

  const transforms = new Map<THREEType.DataTexture, AtlasTransform>();
  let offsetY = 0;

  uniqueTextures.forEach(texture => {
    const image: any = texture.image;
    if (!image) {
      return;
    }
    const width = image.width as number;
    const height = image.height as number;
    const data = image.data as Uint8Array;

    const startY = offsetY;
    for (let row = 0; row < height; row += 1) {
      const srcStart = row * width * 4;
      const dstStart = ((startY + row) * atlasWidth) * 4;
      atlasData.set(data.subarray(srcStart, srcStart + width * 4), dstStart);
    }

    transforms.set(texture, {
      offset: [0, startY / atlasHeight],
      scale: [width / atlasWidth, height / atlasHeight],
    });

    offsetY += height;
  });

  const template = uniqueTextures[0]!;
  const templateTexture = template as THREEType.Texture;
  const atlasTexture = new THREE.DataTexture(atlasData, atlasWidth, atlasHeight);
  atlasTexture.needsUpdate = true;
  atlasTexture.magFilter = templateTexture.magFilter;
  atlasTexture.minFilter = templateTexture.minFilter;
  atlasTexture.wrapS = templateTexture.wrapS;
  atlasTexture.wrapT = templateTexture.wrapT;
  atlasTexture.flipY = false;
  if ('colorSpace' in atlasTexture && 'colorSpace' in templateTexture) {
    (atlasTexture as any).colorSpace = (templateTexture as any).colorSpace;
  } else if ('encoding' in atlasTexture && 'encoding' in templateTexture) {
    (atlasTexture as any).encoding = (templateTexture as any).encoding;
  }

  return {
    texture: atlasTexture,
    transforms,
    width: atlasWidth,
    height: atlasHeight,
  };
}

export function buildEmissiveAtlas(
  THREE: typeof THREEType,
  width: number,
  height: number,
  transforms: Map<THREEType.DataTexture, AtlasTransform>,
  pairs: Map<THREEType.DataTexture, THREEType.DataTexture>
): THREEType.DataTexture | null {
  if (pairs.size === 0) {
    return null;
  }

  const atlasData = new Uint8Array(width * height * 4);
  let template: THREEType.DataTexture | null = null;

  pairs.forEach((emissive, reference) => {
    const transform = transforms.get(reference);
    if (!transform) {
      return;
    }
    const image: any = emissive.image;
    const refImage: any = reference.image;
    if (!image || !refImage) {
      return;
    }
    const texWidth = refImage.width as number;
    const texHeight = refImage.height as number;
    const data = image.data as Uint8Array;

    const offsetX = Math.round(transform.offset[0] * width);
    const offsetY = Math.round(transform.offset[1] * height);

    for (let row = 0; row < texHeight; row += 1) {
      const srcStart = row * texWidth * 4;
      const dstStart = ((offsetY + row) * width + offsetX) * 4;
      atlasData.set(data.subarray(srcStart, srcStart + texWidth * 4), dstStart);
    }

    template = emissive;
  });

  if (!template) {
    return null;
  }

  const templateTexture = template! as THREEType.Texture;
  const atlasTexture = new THREE.DataTexture(atlasData, width, height);
  atlasTexture.needsUpdate = true;
  atlasTexture.magFilter = templateTexture.magFilter;
  atlasTexture.minFilter = templateTexture.minFilter;
  atlasTexture.wrapS = templateTexture.wrapS;
  atlasTexture.wrapT = templateTexture.wrapT;
  atlasTexture.flipY = false;
  if ('colorSpace' in atlasTexture && 'colorSpace' in templateTexture) {
    (atlasTexture as any).colorSpace = (templateTexture as any).colorSpace;
  } else if ('encoding' in atlasTexture && 'encoding' in templateTexture) {
    (atlasTexture as any).encoding = (templateTexture as any).encoding;
  }

  return atlasTexture;
}
