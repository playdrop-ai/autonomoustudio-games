import type * as THREEType from 'three';

export type BoxSize = [number, number, number];

export function createBoxGeometry(THREE: typeof THREEType, size: BoxSize): THREEType.BoxGeometry {
  return new THREE.BoxGeometry(size[0], size[1], size[2]);
}

export function collectGroupVertexIndices(geometry: THREEType.BufferGeometry): Array<Set<number>> {
  const indexAttr = geometry.index;
  const groups = geometry.groups;
  if (!indexAttr || !groups || groups.length === 0) {
    return [];
  }

  const indices = indexAttr.array as ArrayLike<number>;
  const result: Array<Set<number>> = [];

  groups.forEach(group => {
    const set = new Set<number>();
    for (let i = 0; i < group.count; i += 1) {
      set.add(indices[group.start + i] as number);
    }
    result.push(set);
  });

  return result;
}
