import type * as THREEType from 'three';
import type { Material, Pattern, Texture } from '@playdrop/boxel-core';
import type { PrimitiveBuilderContext } from './context.js';

type TextureArray = Uint8Array<ArrayBuffer>;

export interface TextureBundle {
  color: THREEType.DataTexture;
  emissive?: THREEType.DataTexture;
}

function toThreeColor(THREE: typeof THREEType, rgb: number[]): THREEType.Color {
  const color = new THREE.Color(rgb[0] / 255, rgb[1] / 255, rgb[2] / 255);
  if (typeof (color as THREEType.Color & { convertSRGBToLinear?: () => THREEType.Color }).convertSRGBToLinear === 'function') {
    (color as THREEType.Color & { convertSRGBToLinear: () => THREEType.Color }).convertSRGBToLinear();
  } else if (
    typeof (color as THREEType.Color & { convertGammaToLinear?: (gammaFactor: number) => THREEType.Color })
      .convertGammaToLinear === 'function'
  ) {
    (color as THREEType.Color & { convertGammaToLinear: (gammaFactor: number) => THREEType.Color }).convertGammaToLinear(2.2);
  }
  return color;
}

export function buildTexturePixels(
  context: PrimitiveBuilderContext,
  textureDef: Texture,
  pattern: Pattern,
  materialsById: Map<string, Material>
): { color: TextureArray; emissive: TextureArray | null } {
  const [width, height] = pattern.size;
  const colorBuffer = new Uint8Array(width * height * 4) as unknown as TextureArray;
  const emissiveBuffer = new Uint8Array(width * height * 4) as unknown as TextureArray;
  let hasEmissive = false;

  for (let y = 0; y < height; y += 1) {
    for (let x = 0; x < width; x += 1) {
      const sourceIndex = y * width + x;
      const paletteIndex = pattern.data[sourceIndex];
      const materialId = textureDef.materials[paletteIndex];
      const material = materialId ? materialsById.get(materialId) : undefined;
      const color = material?.baseColor ?? [59, 130, 246];
      const opacityValue = material?.opacity !== undefined ? Number(material.opacity) : 1;
      const clampedOpacity = Number.isFinite(opacityValue)
        ? Math.max(0, Math.min(1, opacityValue))
        : 1;
      const targetY = height - 1 - y;
      const targetIndex = (targetY * width + x) * 4;
      colorBuffer[targetIndex] = color[0];
      colorBuffer[targetIndex + 1] = color[1];
      colorBuffer[targetIndex + 2] = color[2];
      colorBuffer[targetIndex + 3] = Math.round(clampedOpacity * 255);

      const emissive = material?.emissiveColor ?? null;
      if (emissive) {
        emissiveBuffer[targetIndex] = emissive[0];
        emissiveBuffer[targetIndex + 1] = emissive[1];
        emissiveBuffer[targetIndex + 2] = emissive[2];
        emissiveBuffer[targetIndex + 3] = 255;
        if (!hasEmissive) {
          hasEmissive = emissive.some(component => component !== 0);
        }
      } else {
        emissiveBuffer[targetIndex] = 0;
        emissiveBuffer[targetIndex + 1] = 0;
        emissiveBuffer[targetIndex + 2] = 0;
        emissiveBuffer[targetIndex + 3] = 0;
      }
    }
  }

  return {
    color: colorBuffer,
    emissive: hasEmissive ? emissiveBuffer : null,
  };
}

export function ensureTextureInstance(
  context: PrimitiveBuilderContext,
  textureDef: Texture
): TextureBundle | null {
  const cached = context.textureCache.get(textureDef.id);
  if (cached) {
    return cached;
  }

  if (!context.entity) {
    return null;
  }

  const pattern = context.entity.patterns.find(entry => entry.id === textureDef.pattern);
  if (!pattern) {
    console.warn('[boxel-three] pattern not found for texture', textureDef.id);
    return null;
  }

  const { color, emissive } = buildTexturePixels(context, textureDef, pattern, context.materialsById);

  const colorTexture = new context.THREE.DataTexture(color, pattern.size[0], pattern.size[1]);
  colorTexture.needsUpdate = true;
  colorTexture.magFilter = context.THREE.NearestFilter;
  colorTexture.minFilter = context.THREE.NearestFilter;
  colorTexture.wrapS = context.THREE.ClampToEdgeWrapping;
  colorTexture.wrapT = context.THREE.ClampToEdgeWrapping;
  colorTexture.flipY = false;

  if ('colorSpace' in colorTexture) {
    (colorTexture as any).colorSpace = (context.THREE as any).SRGBColorSpace ?? (colorTexture as any).colorSpace;
  } else if ('encoding' in colorTexture) {
    (colorTexture as any).encoding = (context.THREE as any).sRGBEncoding ?? (colorTexture as any).encoding;
  }

  let emissiveTexture: THREEType.DataTexture | undefined;
  if (emissive) {
    emissiveTexture = new context.THREE.DataTexture(emissive, pattern.size[0], pattern.size[1]);
    emissiveTexture.needsUpdate = true;
    emissiveTexture.magFilter = context.THREE.NearestFilter;
    emissiveTexture.minFilter = context.THREE.NearestFilter;
    emissiveTexture.wrapS = context.THREE.ClampToEdgeWrapping;
    emissiveTexture.wrapT = context.THREE.ClampToEdgeWrapping;
    emissiveTexture.flipY = false;
    if ('colorSpace' in emissiveTexture) {
      (emissiveTexture as any).colorSpace = (context.THREE as any).SRGBColorSpace ?? (emissiveTexture as any).colorSpace;
    } else if ('encoding' in emissiveTexture) {
      (emissiveTexture as any).encoding = (context.THREE as any).sRGBEncoding ?? (emissiveTexture as any).encoding;
    }
  }

  const bundle: TextureBundle = {
    color: colorTexture,
    emissive: emissiveTexture,
  };

  context.textureCache.set(textureDef.id, bundle);
  return bundle;
}

export function createPatternPlaceholderTexture(
  context: PrimitiveBuilderContext,
  pattern: Pattern
): THREEType.DataTexture {
  const [width, height] = pattern.size;
  const buffer = new Uint8Array(width * height * 4) as unknown as TextureArray;
  const maxValue = pattern.data.reduce((acc, value) => Math.max(acc, value), 0);
  const normalizer = maxValue > 0 ? maxValue : 1;

  for (let y = 0; y < height; y += 1) {
    for (let x = 0; x < width; x += 1) {
      const sourceIndex = y * width + x;
      const value = pattern.data[sourceIndex];
      const shade = Math.round((value / normalizer) * 255);
      const targetY = height - 1 - y;
      const targetIndex = (targetY * width + x) * 4;
      buffer[targetIndex] = shade;
      buffer[targetIndex + 1] = shade;
      buffer[targetIndex + 2] = shade;
      buffer[targetIndex + 3] = 255;
    }
  }

  const texture = new context.THREE.DataTexture(buffer, width, height);
  texture.needsUpdate = true;
  texture.magFilter = context.THREE.NearestFilter;
  texture.minFilter = context.THREE.NearestFilter;
  texture.wrapS = context.THREE.ClampToEdgeWrapping;
  texture.wrapT = context.THREE.ClampToEdgeWrapping;
  texture.flipY = false;

  if ('colorSpace' in texture) {
    (texture as any).colorSpace = (context.THREE as any).SRGBColorSpace ?? (texture as any).colorSpace;
  } else if ('encoding' in texture) {
    (texture as any).encoding = (context.THREE as any).sRGBEncoding ?? (texture as any).encoding;
  }

  return texture;
}

export function createTextureMaterial(
  context: PrimitiveBuilderContext,
  textureId: string | undefined
): THREEType.MeshStandardMaterial {
  if (!textureId || !context.entity) {
    return new context.THREE.MeshStandardMaterial({
      color: 0x3b82f6,
      opacity: 0.45,
      transparent: true,
      metalness: 0,
      roughness: 1,
    });
  }

  const textureDef = context.entity.textures.find(entry => entry.id === textureId);
  if (!textureDef) {
    console.warn('[boxel-three] texture not found', textureId);
    return new context.THREE.MeshStandardMaterial({
      color: 0x3b82f6,
      opacity: 0.45,
      transparent: true,
      metalness: 0,
      roughness: 1,
    });
  }

  const bundle = ensureTextureInstance(context, textureDef);
  if (!bundle) {
    return new context.THREE.MeshStandardMaterial({
      color: 0x3b82f6,
      opacity: 0.45,
      transparent: true,
      metalness: 0,
      roughness: 1,
    });
  }

  const material = new context.THREE.MeshStandardMaterial({
    map: bundle.color,
    transparent: true,
    metalness: 0,
    roughness: 1,
  });

  if (bundle.emissive) {
    material.emissiveMap = bundle.emissive;
    material.emissive = new context.THREE.Color(1, 1, 1);
    material.emissiveIntensity = 1;
  } else {
    material.emissive.setRGB(0, 0, 0);
    material.emissiveIntensity = 1;
  }

  material.needsUpdate = true;
  return material;
}

export function toThreeColorRGB(context: PrimitiveBuilderContext, rgb: number[]): THREEType.Color {
  return toThreeColor(context.THREE, rgb);
}
