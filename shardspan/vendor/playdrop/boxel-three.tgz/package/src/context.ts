import type * as THREEType from 'three';
import type { BoxelDefinition, Material, Primitive } from '@playdrop/boxel-core';
import type { TextureBundle } from './textures.js';

export interface BuilderSettings {
  enableShadows: boolean;
}

export interface PrimitiveBuilderContext {
  THREE: typeof THREEType;
  settings: BuilderSettings;
  entity: BoxelDefinition | null;
  materialsById: Map<string, Material>;
  primitivesById: Map<string, Primitive>;
  textureCache: Map<string, TextureBundle>;
}

export interface BuilderUpdate {
  entity?: BoxelDefinition | null;
  settings?: Partial<BuilderSettings>;
}

export function createBuilderContext(options: {
  THREE: typeof THREEType;
  settings: BuilderSettings;
}): PrimitiveBuilderContext {
  return {
    THREE: options.THREE,
    settings: { ...options.settings },
    entity: null,
    materialsById: new Map(),
    primitivesById: new Map(),
    textureCache: new Map(),
  };
}

export function updateBuilderContext(context: PrimitiveBuilderContext, update: BuilderUpdate): void {
  if (update.settings) {
    context.settings = { ...context.settings, ...update.settings };
  }

  if (update.entity !== undefined) {
    context.entity = update.entity;
    context.materialsById = update.entity
      ? new Map(update.entity.materials.map(material => [material.id, material] as const))
      : new Map();
    context.primitivesById = update.entity
      ? new Map(update.entity.primitives.map(primitive => [primitive.id, primitive] as const))
      : new Map();
    clearTextureCache(context);
  }
}

export function clearTextureCache(context: PrimitiveBuilderContext): void {
  context.textureCache.forEach(bundle => {
    bundle.color.dispose();
    bundle.emissive?.dispose();
  });
  context.textureCache.clear();
}
