import type * as THREEType from 'three';
import type { BoxelDefinition } from '@playdrop/boxel-core';
import { createBoxelScene } from './scene.js';
import { createBoxelSceneGraph } from './exporters/glb.js';
import { buildEntitySkinnedMesh } from './skinned-mesh.js';
import { buildAnimations } from './animations.js';
import type { BoxelSceneResult } from './types.js';
import type { BuildSkinnedMeshResult } from './skinned-mesh.js';

export type InstantiateEntityObject3DMode = 'hierarchy' | 'merged' | 'skinned';

interface InstantiateBaseResult {
  mode: InstantiateEntityObject3DMode;
  dispose(): void;
}

export interface InstantiateHierarchyResult extends InstantiateBaseResult {
  mode: 'hierarchy';
  object: THREEType.Group;
  scene: BoxelSceneResult;
  clips: THREEType.AnimationClip[];
  findNode(nodeId: string): THREEType.Object3D | undefined;
  forEachNode(visitor: (node: THREEType.Object3D, nodeId: string) => void): void;
}

export interface InstantiateMergedResult extends InstantiateBaseResult {
  mode: 'merged';
  object: THREEType.Group;
}

export interface InstantiateSkinnedResult extends InstantiateBaseResult {
  mode: 'skinned';
  object: THREEType.SkinnedMesh;
  skeleton: THREEType.Skeleton;
  boneMap: Map<string, THREEType.Bone>;
  clips: THREEType.AnimationClip[];
  stats: BuildSkinnedMeshResult['stats'];
  warnings: string[];
  findBone(nodeId: string): THREEType.Bone | undefined;
  forEachBone(visitor: (bone: THREEType.Bone, nodeId: string) => void): void;
}

export type InstantiateEntityObject3DResult =
  | InstantiateHierarchyResult
  | InstantiateMergedResult
  | InstantiateSkinnedResult;

export interface InstantiateEntityObject3DOptions {
  THREE: typeof THREEType;
  entity: BoxelDefinition;
  mode?: InstantiateEntityObject3DMode;
}

function instantiateHierarchy(options: InstantiateEntityObject3DOptions): InstantiateHierarchyResult {
  const { THREE, entity } = options;
  const scene = createBoxelScene({ THREE, entity });
  const clips = scene.animations.map(animation => animation.clip);

  return {
    mode: 'hierarchy',
    object: scene.root,
    scene,
    clips,
    findNode: (nodeId: string) => scene.nodes.get(nodeId)?.object,
    forEachNode: (visitor: (node: THREEType.Object3D, nodeId: string) => void) => {
      scene.nodes.forEach(meta => visitor(meta.object, meta.id));
    },
    dispose: () => {
      scene.dispose();
    },
  };
}

function instantiateMerged(options: InstantiateEntityObject3DOptions): InstantiateMergedResult {
  const { THREE, entity } = options;
  const graph = createBoxelSceneGraph({ THREE, model: entity, mode: 'merged' });
  const { root } = graph;

  return {
    mode: 'merged',
    object: root as THREEType.Group,
    dispose: () => {
      graph.dispose();
    },
  };
}

function instantiateSkinned(options: InstantiateEntityObject3DOptions): InstantiateSkinnedResult {
  const { THREE, entity } = options;
  const result = buildEntitySkinnedMesh({ THREE, entity });
  const boneMap = result.boneMap;
  const animations = buildAnimations(THREE, entity, boneMap);
  const clips = animations.map(animation => animation.clip);

  return {
    mode: 'skinned',
    object: result.mesh,
    skeleton: result.skeleton,
    boneMap,
    clips,
    stats: result.stats,
    warnings: result.warnings,
    findBone: (nodeId: string) => boneMap.get(nodeId),
    forEachBone: (visitor: (bone: THREEType.Bone, nodeId: string) => void) => {
      boneMap.forEach((bone, nodeId) => visitor(bone, nodeId));
    },
    dispose: () => {
      result.dispose();
    },
  };
}

export function instantiateEntityObject3D(
  options: InstantiateEntityObject3DOptions
): InstantiateEntityObject3DResult {
  const mode = options.mode ?? 'hierarchy';
  switch (mode) {
    case 'hierarchy':
      return instantiateHierarchy(options);
    case 'merged':
      return instantiateMerged(options);
    case 'skinned':
      return instantiateSkinned(options);
    default:
      throw new Error(`Unknown entity instantiation mode: ${String(mode)}`);
  }
}
