import type * as THREEType from 'three';
import type { Node } from '@playdrop/boxel-core';
import type { PrimitiveBuilderContext } from './context.js';
import { createPrimitiveObject, createBoundingBoxMesh } from './builders.js';

export interface NodeBuildResult {
  object: THREEType.Object3D;
  nodes: Map<string, THREEType.Object3D>;
}

function applyNodeTransforms(context: PrimitiveBuilderContext, object: THREEType.Object3D, node: Node) {
  object.position.set(node.position[0], node.position[1], node.position[2]);

  if (node.rotation) {
    object.rotation.set(
      context.THREE.MathUtils.degToRad(node.rotation[0]),
      context.THREE.MathUtils.degToRad(node.rotation[1]),
      context.THREE.MathUtils.degToRad(node.rotation[2])
    );
  }

  if (node.scale) {
    object.scale.set(node.scale[0], node.scale[1], node.scale[2]);
  }
}

export function buildNodeObject(
  context: PrimitiveBuilderContext,
  node: Node,
  visitedPrimitives = new Set<string>()
): NodeBuildResult {
  const connectMode = node.connect ?? 'none';
  const object = new context.THREE.Object3D();
  object.name = node.id;
  object.userData = {
    ...(object.userData ?? {}),
    kind: 'entity-node',
    nodeId: node.id,
    primitiveId: node.mesh ?? (object.userData?.primitiveId ?? undefined),
    connectMode,
  };
  if (node.size) {
    object.userData.size = [...node.size] as [number, number, number];
  }
  if (node.center) {
    object.userData.center = [...node.center] as [number, number, number];
  }
  applyNodeTransforms(context, object, node);

  const nodes = new Map<string, THREEType.Object3D>();
  nodes.set(node.id, object);

  if (node.mesh) {
    const primitive = context.primitivesById.get(node.mesh);
    if (primitive) {
      const mesh = createPrimitiveObject(context, primitive, 'centered', visitedPrimitives);
      if (mesh) {
        if (node.center) {
          mesh.position.set(node.center[0], node.center[1], node.center[2]);
        }
        object.add(mesh);
        if (mesh.userData?.size && !object.userData.size) {
          object.userData.size = mesh.userData.size;
        }
        if (mesh.userData?.sockets) {
          object.userData.sockets = mesh.userData.sockets;
        }
      }
    }
  } else if (node.size) {
    const mesh = createBoundingBoxMesh(context, node.size);
    mesh.name = `${node.id}__placeholder`;
    if (node.center) {
      mesh.position.set(node.center[0], node.center[1], node.center[2]);
    }
    object.add(mesh);
  }

  node.children.forEach(child => {
    const childResult = buildNodeObject(context, child, new Set(visitedPrimitives));
    object.add(childResult.object);
    childResult.nodes.forEach((value, key) => nodes.set(key, value));
  });

  return { object, nodes };
}
