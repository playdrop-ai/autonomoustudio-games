# @playdrop/boxel-three

Renderer-focused utilities built on Three.js. This layer sits on top of `@playdrop/boxel-core` and provides:

- Scene graph construction (`createBoxelScene`, node filters, overlays).
- Export helpers such as GLB generation and PNG rendering utilities that accept injected Three.js renderers/cameras.
- Automatic handling of humanoid-style textured box overlays, including inflated outer shells and transparent materials when overlay textures are provided.

It contains no UI or Playwright code and can run anywhere Three.js is available (browser, Node + headless GL). Consumers should import from the package root (`@playdrop/boxel-three`).
