export const ASSET_CATEGORY_VALUES = ['IMAGE', 'VIDEO', 'AUDIO', 'SPRITESHEET', 'MODEL_3D'] as const;
export type AssetCategory = (typeof ASSET_CATEGORY_VALUES)[number];

export const ASSET_FORMAT_VALUES = [
  'PNG',
  'JPEG',
  'WEBP',
  'GIF',
  'ASEPRITE',
  'MP4',
  'WEBM',
  'MP3',
  'WAV',
  'OGG',
  'GLTF',
  'GLB',
  'PLAYDROP_BOXEL_JSON',
  'VOX',
] as const;
export type AssetFormat = (typeof ASSET_FORMAT_VALUES)[number];

export const ASSET_VISIBILITY_VALUES = ['PRIVATE', 'PUBLIC'] as const;
export type AssetVisibility = (typeof ASSET_VISIBILITY_VALUES)[number];

export const ASSET_SOURCE_KIND_VALUES = ['UPLOAD', 'AI', 'APP_EMBEDDED', 'IMPORT'] as const;
export type AssetSourceKind = (typeof ASSET_SOURCE_KIND_VALUES)[number];

export interface AssetSubcategoryDefinition {
  category: AssetCategory;
  subcategory: string;
  formats: AssetFormat[];
  label: string;
}

const MODEL_3D_FORMATS: AssetFormat[] = ['GLB', 'GLTF', 'PLAYDROP_BOXEL_JSON', 'VOX'];
const BOXEL_REQUIRED_FILE_ROLES = ['primary', 'mesh', 'preview'] as const;
const VOX_REQUIRED_FILE_ROLES = ['primary', 'boxel', 'mesh', 'preview'] as const;
const GLTF_REQUIRED_FILE_ROLES = ['primary'] as const;

export const ASSET_SUBCATEGORY_DEFINITIONS: AssetSubcategoryDefinition[] = [
  { category: 'IMAGE', subcategory: 'generic', formats: ['PNG', 'JPEG', 'WEBP', 'GIF'], label: 'Image' },
  { category: 'SPRITESHEET', subcategory: 'generic', formats: ['ASEPRITE', 'PNG'], label: 'Spritesheet' },
  { category: 'VIDEO', subcategory: 'generic', formats: ['MP4', 'WEBM'], label: 'Video' },
  { category: 'AUDIO', subcategory: 'music', formats: ['MP3', 'WAV', 'OGG'], label: 'Music' },
  { category: 'AUDIO', subcategory: 'sfx', formats: ['MP3', 'WAV', 'OGG'], label: 'SFX' },
  { category: 'AUDIO', subcategory: 'generic', formats: ['MP3', 'WAV', 'OGG'], label: 'Audio' },
  { category: 'MODEL_3D', subcategory: 'generic', formats: MODEL_3D_FORMATS, label: '3D Model' },
  { category: 'MODEL_3D', subcategory: 'avatar', formats: MODEL_3D_FORMATS, label: 'Avatar' },
  { category: 'MODEL_3D', subcategory: 'humanoid', formats: MODEL_3D_FORMATS, label: 'Humanoid' },
  { category: 'MODEL_3D', subcategory: 'creature', formats: MODEL_3D_FORMATS, label: 'Creature' },
  { category: 'MODEL_3D', subcategory: 'block', formats: MODEL_3D_FORMATS, label: 'Block' },
];

export const ASSET_SUBCATEGORY_SLUG_REGEX = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;
export const MODEL_3D_ASSET_SUBCATEGORY_VALUES = ['generic', 'avatar', 'humanoid', 'creature', 'block'] as const;
export type Model3DAssetSubcategory = (typeof MODEL_3D_ASSET_SUBCATEGORY_VALUES)[number];

const MODEL_3D_ASSET_SUBCATEGORY_SET = new Set<string>(MODEL_3D_ASSET_SUBCATEGORY_VALUES);

export function isModel3DAssetSubcategory(category: AssetCategory, subcategory: string): boolean {
  return category === 'MODEL_3D' && MODEL_3D_ASSET_SUBCATEGORY_SET.has(normalizeAssetSubcategory(subcategory));
}

export function isBoxelAssetFormat(format: AssetFormat): boolean {
  return format === 'PLAYDROP_BOXEL_JSON';
}

export function isVoxAssetFormat(format: AssetFormat): boolean {
  return format === 'VOX';
}

export function getRequiredModel3DFileRoles(format: AssetFormat): readonly string[] {
  if (format === 'PLAYDROP_BOXEL_JSON') {
    return BOXEL_REQUIRED_FILE_ROLES;
  }
  if (format === 'VOX') {
    return VOX_REQUIRED_FILE_ROLES;
  }
  if (format === 'GLB' || format === 'GLTF') {
    return GLTF_REQUIRED_FILE_ROLES;
  }
  return [];
}

export function getBoxelManifestRole(format: AssetFormat): 'primary' | 'boxel' | null {
  if (format === 'PLAYDROP_BOXEL_JSON') {
    return 'primary';
  }
  if (format === 'VOX') {
    return 'boxel';
  }
  return null;
}

export const ASSET_SUBCATEGORY_DEFINITIONS_BY_KEY: Record<string, AssetSubcategoryDefinition> = Object.fromEntries(
  ASSET_SUBCATEGORY_DEFINITIONS.map((definition) => [`${definition.category}:${definition.subcategory}`, definition]),
);

export const ASSET_SUBCATEGORIES_BY_CATEGORY: Record<AssetCategory, string[]> = ASSET_CATEGORY_VALUES.reduce(
  (acc, category) => {
    acc[category] = ASSET_SUBCATEGORY_DEFINITIONS
      .filter((definition) => definition.category === category)
      .map((definition) => definition.subcategory);
    return acc;
  },
  {
    IMAGE: [],
    VIDEO: [],
    AUDIO: [],
    SPRITESHEET: [],
    MODEL_3D: [],
  } as Record<AssetCategory, string[]>,
);

export type AssetMetadataEmbeddingStatus = 'embedded' | 'unsupported_format' | 'failed';

export interface AssetAudioWaveformV1 {
  schemaVersion: 'playdrop.audio-waveform.v1';
  durationSeconds: number;
  sampleRateHz: number;
  bins: number[];
}

export interface AssetSongWordTimestampV1 {
  word: string;
  startMs: number;
  endMs: number;
}

export interface AssetSongSectionV1 {
  name?: string;
  durationMs?: number;
  lines: string[];
  styles?: string[];
}

export interface AssetSongLyricsV1 {
  text: string;
  sections?: AssetSongSectionV1[];
  wordTimestamps?: AssetSongWordTimestampV1[];
}

export interface AssetSongMetadataV1 {
  genres?: string[];
  languages?: string[];
  styles?: string[];
  isExplicit?: boolean;
  lyrics?: AssetSongLyricsV1;
}

export interface AssetEmbeddedMetadataV1 {
  schemaVersion: 'playdrop.asset-metadata.v1';
  modality: 'IMAGE' | 'MUSIC' | 'SFX' | 'VIDEO' | 'MODEL_3D';
  generationId: string;
  creatorUsername: string;
  creatorDisplayName: string;
  displayName: string;
  description: string;
  createdAt: string;
  provider: {
    name: string;
    model: string;
  };
  embeddedInPrimary: boolean;
  embeddingStatus: AssetMetadataEmbeddingStatus;
  lyrics?: string;
  durationMs?: number;
  durationSeconds?: number;
  aspectRatio?: string;
  resolution?: string;
  sourceMode?: string;
  topology?: string;
  targetPolycount?: number;
  shouldRemesh?: boolean;
  shouldTexture?: boolean;
  coverAssetUrl?: string;
  thumbnailUrl?: string;
  audio?: {
    waveform?: AssetAudioWaveformV1;
  };
  providerMetadataSubset?: Record<string, unknown>;
}

export interface AssetEmbeddedMetadataV2 {
  schemaVersion: 'playdrop.asset-metadata.v2';
  modality: 'IMAGE' | 'MUSIC' | 'SFX' | 'VIDEO' | 'MODEL_3D';
  generationId: string;
  creatorUsername: string;
  creatorDisplayName: string;
  displayName: string;
  description: string;
  createdAt: string;
  provider: {
    name: string;
    model: string;
  };
  embeddedInPrimary: boolean;
  embeddingStatus: AssetMetadataEmbeddingStatus;
  durationMs?: number;
  durationSeconds?: number;
  aspectRatio?: string;
  resolution?: string;
  sourceMode?: string;
  topology?: string;
  targetPolycount?: number;
  shouldRemesh?: boolean;
  shouldTexture?: boolean;
  coverAssetUrl?: string;
  thumbnailUrl?: string;
  audio?: {
    waveform?: AssetAudioWaveformV1;
  };
  song?: AssetSongMetadataV1;
  providerMetadataSubset?: {
    filename?: string | null;
    durationMs?: number | null;
    forceInstrumental?: boolean | null;
    coverModel?: string | null;
    embeddingStatus?: string | null;
  };
}

export type AssetEmbeddedMetadata = AssetEmbeddedMetadataV1 | AssetEmbeddedMetadataV2;

export interface AssetFileManifestEntry {
  // Common roles include primary, preview, cover, mesh, and metadata.
  role: string;
  key: string;
  url?: string;
  contentType?: string | null;
  sizeBytes?: number | null;
}

export interface AssetFileManifest {
  files: AssetFileManifestEntry[];
}

export interface AssetGenerationInputAttachmentResponse {
  key: string;
  label: string;
  url: string;
}

export interface AssetGenerationInputParamResponse {
  key: string;
  label: string;
  value: string | number | boolean | null;
}

export interface AssetGenerationInputSummaryResponse {
  modality: string | null;
  prompt: string | null;
  attachments: AssetGenerationInputAttachmentResponse[];
  params: AssetGenerationInputParamResponse[];
}

export interface AssetGenerationReplayAttachmentResponse {
  key: 'image1' | 'image2';
  label: string;
  url: string;
  mimeType?: string | null;
}

export interface AssetGenerationReplayResponse {
  modality: 'IMAGE' | 'MUSIC' | 'SFX' | 'VIDEO' | 'MODEL_3D';
  prompt: string;
  image1?: AssetGenerationReplayAttachmentResponse | null;
  image2?: AssetGenerationReplayAttachmentResponse | null;
  durationMs?: number | null;
  forceInstrumental?: boolean | null;
  durationSeconds?: number | null;
  loop?: boolean | null;
  coverPrompt?: string | null;
  aspectRatio?: string | null;
  resolution?: string | null;
  sourceMode?: string | null;
  topology?: string | null;
  targetPolycount?: number | null;
  shouldRemesh?: boolean | null;
  shouldTexture?: boolean | null;
  assetSubcategory?: string | null;
}

export interface AssetVersionResponse {
  id: number;
  revision: number;
  revisionLabel: string;
  subcategory: string;
  visibility: AssetVisibility;
  format: AssetFormat;
  storageKey: string;
  fileManifest: AssetFileManifest | Record<string, unknown>;
  sourceKind: AssetSourceKind;
  sourceAppVersionId?: number | null;
  sourceGenerationId?: string | null;
  sourcePrompt?: string | null;
  sourceGenerationInput?: AssetGenerationInputSummaryResponse | null;
  sourceGenerationReplay?: AssetGenerationReplayResponse | null;
  shopListed: boolean;
  shopPriceCredits: number;
  createdAt: string;
  updatedAt: string;
}

export interface AssetResponse {
  id: number;
  name: string;
  displayName: string;
  description?: string | null;
  category: AssetCategory;
  creatorId: number;
  creatorUsername: string;
  createdAt: string;
  updatedAt: string;
  currentVersion?: AssetVersionResponse | null;
  viewerSaved?: boolean;
  viewerLiked?: boolean;
  likeCount?: number;
  viewCount?: number;
}

export interface AssetRef {
  creatorUsername: string;
  name: string;
  revision: number;
}

export interface CreateAssetVersionRequest {
  displayName?: string;
  description?: string;
  category: AssetCategory;
  subcategory: string;
  visibility?: AssetVisibility;
  format: AssetFormat;
  sourceKind?: AssetSourceKind;
  sourceAppVersionId?: number;
  sourceGenerationId?: string;
  remixRef?: string;
  shopListed?: boolean;
  shopPriceCredits?: number;
}

export interface UpdateAssetRequest {
  name?: string;
  displayName?: string;
  description?: string | null;
}

export interface UpdateAssetVersionRequest {
  visibility?: AssetVisibility;
  setAsCurrent?: boolean;
}

export interface AssetCategoriesResponse {
  categories: AssetSubcategoryDefinition[];
}

export interface AssetListResponse {
  assets: AssetResponse[];
  pagination: {
    limit: number;
    offset: number;
    count: number;
    hasMore: boolean;
  };
}

export interface AssetDetailResponse {
  asset: AssetResponse;
}

export interface AssetVersionsListResponse {
  versions: AssetVersionResponse[];
  pagination?: {
    limit: number;
    offset: number;
    count: number;
    hasMore: boolean;
  };
}

export interface CreateAssetVersionResponse {
  asset: AssetResponse;
  version: AssetVersionResponse;
  versionNodeId: string;
}

export interface UpdateAssetResponse {
  asset: AssetResponse;
}

export interface UpdateAssetVersionResponse {
  version: AssetVersionResponse;
}

export interface DeleteAssetVersionResponse {
  success: boolean;
}

export interface DeleteAssetResponse {
  success: boolean;
}

export interface AssetSourceBundleResponse {
  filename: string;
  sizeBytes: number;
  checksum?: string | null;
}

export function isAssetCategory(value: unknown): value is AssetCategory {
  return typeof value === 'string' && (ASSET_CATEGORY_VALUES as readonly string[]).includes(value);
}

export function isAssetFormat(value: unknown): value is AssetFormat {
  return typeof value === 'string' && (ASSET_FORMAT_VALUES as readonly string[]).includes(value);
}

export function isAssetVisibility(value: unknown): value is AssetVisibility {
  return typeof value === 'string' && (ASSET_VISIBILITY_VALUES as readonly string[]).includes(value);
}

export function isAssetSourceKind(value: unknown): value is AssetSourceKind {
  return typeof value === 'string' && (ASSET_SOURCE_KIND_VALUES as readonly string[]).includes(value);
}

export function isValidAssetSubcategorySlug(value: unknown): value is string {
  return typeof value === 'string' && ASSET_SUBCATEGORY_SLUG_REGEX.test(value.trim());
}

export function normalizeAssetSubcategory(value: string): string {
  return value.trim().toLowerCase();
}

export function isKnownAssetSubcategory(category: AssetCategory, subcategory: string): boolean {
  return ASSET_SUBCATEGORIES_BY_CATEGORY[category].includes(subcategory);
}

export function getAssetSubcategoryDefinition(
  category: AssetCategory,
  subcategory: string,
): AssetSubcategoryDefinition | null {
  return ASSET_SUBCATEGORY_DEFINITIONS_BY_KEY[`${category}:${subcategory}`] ?? null;
}
