export const ENTITY_TYPE_VALUES = ['AVATAR', 'HUMANOID', 'CREATURE', 'BLOCK'] as const;
export type EntityType = (typeof ENTITY_TYPE_VALUES)[number];

export const AVATAR_VISIBILITY_VALUES = ['DEFAULT', 'SHOP', 'HIDDEN'] as const;
export type AvatarVisibility = (typeof AVATAR_VISIBILITY_VALUES)[number];

export interface EntityMetadataBase {
  id: number;
  name: string;
  displayName: string;
  description: string;
  creatorId: number;
  creatorUsername: string;
  createdAt: string;
  updatedAt: string;
  meshUrl: string;
  previewUrl: string;
  boxelUrl: string;
  meshSizeBytes?: number | null;
  previewSizeBytes?: number | null;
  definitionSizeBytes?: number | null;
  type: EntityType;
  priceCredits?: number | null;
  avatarVisibility?: AvatarVisibility | null;
}

export interface EntityMetadata extends EntityMetadataBase {}

export interface CreatureMetadata extends EntityMetadata {}

export interface HumanoidMetadata extends CreatureMetadata {}

export interface AvatarMetadata extends HumanoidMetadata {}

export interface BlockMetadata extends EntityMetadata {}

function isNullableNumber(value: unknown): value is number | null | undefined {
  return value === null || value === undefined || (typeof value === 'number' && Number.isFinite(value));
}

export function isEntityType(value: unknown): value is EntityType {
  if (typeof value !== 'string') {
    return false;
  }
  return (ENTITY_TYPE_VALUES as readonly string[]).includes(value);
}

export function isEntityMetadata(value: unknown): value is EntityMetadata {
  if (typeof value !== 'object' || value === null) {
    return false;
  }
  const metadata = value as Record<string, unknown>;
  return (
    typeof metadata.id === 'number'
    && Number.isInteger(metadata.id)
    && typeof metadata.name === 'string'
    && metadata.name.length > 0
    && typeof metadata.displayName === 'string'
    && typeof metadata.description === 'string'
    && typeof metadata.creatorId === 'number'
    && Number.isInteger(metadata.creatorId)
    && typeof metadata.creatorUsername === 'string'
    && typeof metadata.createdAt === 'string'
    && typeof metadata.updatedAt === 'string'
    && typeof metadata.meshUrl === 'string'
    && typeof metadata.previewUrl === 'string'
    && typeof metadata.boxelUrl === 'string'
    && isNullableNumber(metadata.meshSizeBytes)
    && isNullableNumber(metadata.previewSizeBytes)
    && isNullableNumber(metadata.definitionSizeBytes)
    && isEntityType(metadata.type)
    && (metadata.priceCredits === undefined || metadata.priceCredits === null || typeof metadata.priceCredits === 'number')
    && (metadata.avatarVisibility === undefined
      || metadata.avatarVisibility === null
      || (typeof metadata.avatarVisibility === 'string'
        && (AVATAR_VISIBILITY_VALUES as readonly string[]).includes(metadata.avatarVisibility)))
  );
}
