export const VERSION_NODE_KIND_VALUES = ['APP_VERSION', 'ASSET_VERSION', 'PACK_VERSION'] as const;
export type VersionNodeKind = (typeof VERSION_NODE_KIND_VALUES)[number];

export const RELATION_TYPE_VALUES = ['USES', 'CONTAINS', 'REMIXES'] as const;
export type RelationType = (typeof RELATION_TYPE_VALUES)[number];

export interface VersionNodeRef {
  id: string;
  kind: VersionNodeKind;
  appVersionId?: number | null;
  assetVersionId?: number | null;
  packVersionId?: number | null;
  createdAt: string;
  updatedAt: string;
}

export interface NodeRelationRecord {
  id: number;
  fromNodeId: string;
  toNodeId: string;
  type: RelationType;
  createdAt: string;
  updatedAt: string;
}

export interface BatchUpsertNodeRelationsRequest {
  relations: Array<{
    fromNodeId: string;
    toNodeId: string;
    type: RelationType;
  }>;
}

export interface BatchUpsertNodeRelationsResponse {
  relations: NodeRelationRecord[];
}

export type AppVersionRef = {
  kind: 'app';
  creatorUsername: string;
  name: string;
  version: string;
};

export type AssetVersionRef = {
  kind: 'asset';
  creatorUsername: string;
  name: string;
  revision: number;
};

export type PackVersionRef = {
  kind: 'pack';
  creatorUsername: string;
  name: string;
  version: string;
};

export type ContentVersionRef = AppVersionRef | AssetVersionRef | PackVersionRef;

const SEMVER_VERSION_REF_REGEX = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$/;

export function parseContentVersionRef(raw: string): ContentVersionRef | null {
  if (typeof raw !== 'string') {
    return null;
  }
  const trimmed = raw.trim();
  if (!trimmed.length) {
    return null;
  }
  const match = /^(app|asset|pack):([^/]+)\/([^@]+)@(.+)$/i.exec(trimmed);
  if (!match) {
    return null;
  }
  const kind = match[1].toLowerCase();
  const creatorUsername = match[2].trim();
  const name = match[3].trim();
  const rawVersion = match[4].trim();
  if (!creatorUsername.length || !name.length || !rawVersion.length) {
    return null;
  }
  if (kind === 'asset') {
    const revisionMatch = /^r(\d+)$/i.exec(rawVersion);
    if (!revisionMatch) {
      return null;
    }
    const revision = Number.parseInt(revisionMatch[1], 10);
    if (!Number.isInteger(revision) || revision <= 0) {
      return null;
    }
    return {
      kind: 'asset',
      creatorUsername,
      name,
      revision,
    };
  }
  if (!SEMVER_VERSION_REF_REGEX.test(rawVersion)) {
    return null;
  }
  if (kind === 'app') {
    return {
      kind: 'app',
      creatorUsername,
      name,
      version: rawVersion,
    };
  }
  if (kind === 'pack') {
    return {
      kind: 'pack',
      creatorUsername,
      name,
      version: rawVersion,
    };
  }
  return null;
}

export function formatContentVersionRef(ref: ContentVersionRef): string {
  if (ref.kind === 'asset') {
    return `asset:${ref.creatorUsername}/${ref.name}@r${ref.revision}`;
  }
  if (ref.kind === 'app') {
    return `app:${ref.creatorUsername}/${ref.name}@${ref.version}`;
  }
  return `pack:${ref.creatorUsername}/${ref.name}@${ref.version}`;
}

export function isVersionNodeKind(value: unknown): value is VersionNodeKind {
  return typeof value === 'string' && (VERSION_NODE_KIND_VALUES as readonly string[]).includes(value);
}

export function isRelationType(value: unknown): value is RelationType {
  return typeof value === 'string' && (RELATION_TYPE_VALUES as readonly string[]).includes(value);
}
