import type { AssetCategory, AssetRef } from './asset.js';
import type { AppHostingMode } from './version.js';

export const VERSION_VISIBILITY_VALUES = ['PRIVATE', 'PUBLIC'] as const;
export type VersionVisibility = (typeof VERSION_VISIBILITY_VALUES)[number];
export type AssetCategoryBreakdown = Partial<Record<AssetCategory, number>>;
export type AssetSubcategoryBreakdown = Partial<Record<string, number>>;

export interface AssetPackVersionResponse {
  id: number;
  version: string;
  major: number;
  minor: number;
  patch: number;
  visibility: VersionVisibility;
  hostingMode: AppHostingMode;
  externalUrl?: string | null;
  downloadUrl?: string | null;
  releaseNotes?: string | null;
  assets: AssetRef[];
  assetCategoryBreakdown?: AssetCategoryBreakdown;
  assetSubcategoryBreakdown?: AssetSubcategoryBreakdown;
  iconUrl?: string | null;
  heroPortraitUrl?: string | null;
  heroLandscapeUrl?: string | null;
  screenshotPortraitUrls?: string[];
  screenshotLandscapeUrls?: string[];
  videoPortraitUrls?: string[];
  videoLandscapeUrls?: string[];
  createdAt: string;
  updatedAt: string;
}

export interface AssetPackResponse {
  id: number;
  name: string;
  displayName: string;
  description?: string | null;
  creatorId: number;
  creatorUsername: string;
  previewAppVersionId?: number | null;
  createdAt: string;
  updatedAt: string;
  currentVersion?: AssetPackVersionResponse | null;
  viewerSaved?: boolean;
  viewerLiked?: boolean;
  likeCount?: number;
  viewCount?: number;
}

export interface CreateAssetPackVersionRequest {
  version: string;
  visibility?: VersionVisibility;
  remixRef?: string;
  hostingMode?: AppHostingMode;
  externalUrl?: string;
  downloadUrl?: string;
  releaseNotes?: string;
  displayName?: string;
  description?: string;
  previewAppVersionId?: number;
  assets?: Array<{ assetRef: string; role?: string }>;
}

export interface UpdateAssetPackRequest {
  name?: string;
  displayName?: string;
  description?: string | null;
  previewAppVersionId?: number | null;
}

export interface UpdateAssetPackVersionRequest {
  visibility?: VersionVisibility;
  releaseNotes?: string | null;
  setAsCurrent?: boolean;
}

export interface AssetPackListResponse {
  packs: AssetPackResponse[];
  pagination: {
    limit: number;
    offset: number;
    count: number;
    hasMore: boolean;
  };
}

export interface AssetPackDetailResponse {
  pack: AssetPackResponse;
}

export interface AssetPackVersionsListResponse {
  versions: AssetPackVersionResponse[];
  pagination?: {
    limit: number;
    offset: number;
    count: number;
    hasMore: boolean;
  };
}

export interface CreateAssetPackVersionResponse {
  pack: AssetPackResponse;
  version: AssetPackVersionResponse;
  versionNodeId: string;
}

export interface UpdateAssetPackResponse {
  pack: AssetPackResponse;
}

export interface UpdateAssetPackVersionResponse {
  version: AssetPackVersionResponse;
}

export interface DeleteAssetPackVersionResponse {
  success: boolean;
}

export interface DeleteAssetPackResponse {
  success: boolean;
}

export interface AssetPackSourceBundleResponse {
  filename: string;
  sizeBytes: number;
  checksum?: string | null;
}

export function isVersionVisibility(value: unknown): value is VersionVisibility {
  return typeof value === 'string' && (VERSION_VISIBILITY_VALUES as readonly string[]).includes(value);
}
