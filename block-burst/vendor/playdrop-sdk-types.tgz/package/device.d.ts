import type { DeviceAPI, DeviceCategory, DeviceOrientation, DeviceInputs } from './types.js';
interface DeviceState {
    category: DeviceCategory;
    orientation: DeviceOrientation;
    inputs: DeviceInputs;
}
export declare function setDeviceInfo(info: DeviceState): void;
export declare const device: DeviceAPI;
export {};
