import type { SearchAPI } from './types.js';
export declare const search: SearchAPI;
