import type { AssetsCatalogAPI, AssetPacksCatalogAPI, AssetsGraphAPI, ModelsAPI } from './types.js';
import { type ApiClient } from '@playdrop/api-client';
export declare function resetAssetsApiClientForTests(): void;
export declare function ensureAssetsApiClient(): ApiClient;
export declare function createModelsApi(): ModelsAPI;
export declare function createAssetsCatalogApi(): AssetsCatalogAPI;
export declare function createAssetPacksCatalogApi(): AssetPacksCatalogAPI;
export declare function createAssetsGraphApi(): AssetsGraphAPI;
