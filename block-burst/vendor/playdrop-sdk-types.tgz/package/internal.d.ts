export { setInitConfig, getInitConfig, getAppId, resetInitState, setInitResponse, getInitResponse, } from './init.js';
export { initBridge, getBridge, resetBridge, } from './bridge.js';
