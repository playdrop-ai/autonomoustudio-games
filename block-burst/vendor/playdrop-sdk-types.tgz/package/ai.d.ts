import { createAiClient } from '@playdrop/ai-client';
import type { AiAPI } from './types.js';
type AiClientFactory = typeof createAiClient;
export declare const ai: AiAPI;
export declare const __test__: {
    setAiClientFactory(fn: AiClientFactory): void;
    resetAiClientFactory(): void;
    setBaseUrlResolver(fn: () => string): void;
    resetBaseUrlResolver(): void;
    resetState(): void;
};
export {};
