import type { AssetsAPI } from './types.js';
export declare const assets: AssetsAPI;
export declare function resetAssetCache(): void;
