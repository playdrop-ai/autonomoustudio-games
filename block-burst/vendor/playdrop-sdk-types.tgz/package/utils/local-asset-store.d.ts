export declare function mapToLocalAssetStore(originalUrl: string, localBase: string | null | undefined, onError?: (error: unknown) => void): string;
