import type { AppMetadata } from './types.js';
export declare const app: AppMetadata;
export declare function applyAppMetadata(snapshot: Partial<AppMetadata>): void;
export declare function resetAppMetadata(): void;
