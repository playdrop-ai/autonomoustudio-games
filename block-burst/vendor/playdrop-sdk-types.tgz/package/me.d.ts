import type { MeAPI } from './types.js';
export declare const me: MeAPI;
export declare function resetMe(): void;
