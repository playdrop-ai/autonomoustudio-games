import type { LibrariesAPI } from './types.js';
declare function normalizeAddonName(raw: string): string;
export declare const libs: LibrariesAPI;
export declare function resetLibCache(): void;
export declare const __test__: {
    resetState(): void;
    setImportModule(fn: (url: string) => Promise<any>): void;
    normalizeAddonName: typeof normalizeAddonName;
    availableThreeAddons(): ReadonlyArray<string>;
};
export {};
