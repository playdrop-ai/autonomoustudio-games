import type { AppData, Room } from './types.js';
export declare function joinRoom(): Promise<Room>;
export declare function getActiveRoom(): Room | null;
export declare function applySelfAppDataSnapshotToActiveRoom(snapshot: AppData | null): void;
