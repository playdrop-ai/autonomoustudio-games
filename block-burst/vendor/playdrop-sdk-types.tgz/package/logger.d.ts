export declare const logDebug: (message: string, ...args: unknown[]) => void;
export declare const logInfo: (message: string, ...args: unknown[]) => void;
export declare const logWarn: (message: string, ...args: unknown[]) => void;
export declare const logError: (message: string, ...args: unknown[]) => void;
