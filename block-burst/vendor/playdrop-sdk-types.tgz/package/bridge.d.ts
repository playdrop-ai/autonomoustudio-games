import { type ClientBridge } from '@playdrop/web-bridge';
export declare function initBridge(): ClientBridge | null;
export declare function getBridge(): ClientBridge | null;
export declare function resetBridge(): void;
