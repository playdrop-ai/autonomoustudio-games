import type { HostAPI, SessionMode } from './types.js';
export declare function setSessionMode(mode: SessionMode): void;
export declare const host: HostAPI;
