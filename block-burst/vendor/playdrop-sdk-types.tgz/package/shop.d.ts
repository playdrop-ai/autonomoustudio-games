import { createApiClient } from '@playdrop/api-client';
import { type ClientBridge } from '@playdrop/web-bridge';
import type { ShopAPI } from './types.js';
export declare const shop: ShopAPI;
export declare const __test__: {
    setBridgeResolver(fn: () => ClientBridge | null): void;
    resetBridgeResolver(): void;
    setApiClientFactory(fn: typeof createApiClient): void;
    resetApiClientFactory(): void;
    resetState(): void;
};
