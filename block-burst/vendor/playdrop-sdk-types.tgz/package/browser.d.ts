import * as entityCore from '@playdrop/boxel-core';
import * as entityThree from '@playdrop/boxel-three';
import type { PlaydropSDK } from './types.js';
export type PlaydropBoxelNamespace = {
    core: typeof entityCore;
    three: typeof entityThree;
};
export type PlaydropNamespace = PlaydropSDK & {
    init: () => Promise<PlaydropSDK>;
    __hostInitPromise?: Promise<void>;
    boxel?: PlaydropBoxelNamespace;
};
declare global {
    interface Window {
        playdrop?: PlaydropNamespace;
        __playdrop_internal?: Record<string, unknown>;
    }
}
