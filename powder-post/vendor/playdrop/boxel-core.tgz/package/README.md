# @playdrop/boxel-core

Shared domain logic for normalized Playdrop entities. This module is framework-neutral and exposes:

- TypeScript entity schemas, type guards, and parsing/formatting helpers.
- Validation, voxel, material, texture, and primitive utilities reused by both the editor web app and the CLI.

It has zero browser, Playwright, or Three.js dependencies so it can run in Node, Deno, or the browser. Downstream code should import directly from the package entry point, for example:

```ts
import { parseBoxel } from '@playdrop/boxel-core';
```

## Humanoid helpers

The core package now owns the Minecraft → Playdrop humanoid builders so they can be reused without the explorer bundle. Key exports include:

- `scanHumanoidSource` — walks a Bedrock geometry entry + texture pixels and returns a normalized R6 scan.
- `buildHumanoidR6Entity` — fills the shared R6 template with textured primitives based on the scan output.
- `buildHumanoidR15Entity` / `buildHumanoidR15TexturedEntity` — generate voxel or textured R15 rigs from an R6 entity.
- `applyLayerMode` — converts textured boxes to base-only, flat, overlay-only, or voxel representations.
- `getHumanoidTemplate` — loads the baked R6/R15 template JSON (`HUMANOID_R6_TEMPLATE_ID`, `HUMANOID_R15_TEMPLATE_ID`).

These helpers are the building blocks behind the CLI command added in `@playdrop/boxel-cli`. See the package README for usage examples.
