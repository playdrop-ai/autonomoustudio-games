import type { VoxelBox } from './types';

export type VoxelSize = [number, number, number];

export interface VoxelIndex {
  x: number;
  y: number;
  z: number;
  index: number;
}

export const clampSizeAxis = (value: number): number => {
  if (!Number.isFinite(value)) return 1;
  const rounded = Math.floor(Math.max(1, Math.min(64, value)));
  return rounded;
};

export const createFilledVoxelData = (size: VoxelSize, materialIndex = 0): number[] => {
  const [sx, sy, sz] = size;
  const total = sx * sy * sz;
  return new Array(total).fill(materialIndex);
};

export const validateVoxelData = (voxels: number[], size: VoxelSize): boolean => {
  const expected = size[0] * size[1] * size[2];
  if (voxels.length !== expected) return false;
  return voxels.every(value => Number.isInteger(value) && value >= -1);
};

export const cloneVoxelData = (voxels: number[]): number[] => voxels.slice();

export const forEachVoxel = (voxel: VoxelBox, callback: (info: VoxelIndex, material: number) => void) => {
  const [sx, sy, sz] = voxel.size;
  const { voxels } = voxel;
  for (let z = 0; z < sz; z += 1) {
    for (let y = 0; y < sy; y += 1) {
      for (let x = 0; x < sx; x += 1) {
        const index = x + y * sx + z * sx * sy;
        callback({ x, y, z, index }, voxels[index] ?? -1);
      }
    }
  }
};

export const setVoxelAt = (voxels: number[], size: VoxelSize, coord: { x: number; y: number; z: number }, value: number) => {
  const [sx, sy, sz] = size;
  if (
    coord.x < 0 ||
    coord.x >= sx ||
    coord.y < 0 ||
    coord.y >= sy ||
    coord.z < 0 ||
    coord.z >= sz
  ) {
    return;
  }
  const index = coord.x + coord.y * sx + coord.z * sx * sy;
  voxels[index] = value;
};

export const getVoxelIndex = (size: VoxelSize, coord: { x: number; y: number; z: number }): number => {
  return coord.x + coord.y * size[0] + coord.z * size[0] * size[1];
};
