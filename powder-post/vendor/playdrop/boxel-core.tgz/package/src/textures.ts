import type { BoxelDefinition, Material, Pattern, TexturedBox, Texture } from './types';

export type FaceKey = 'top' | 'bottom' | 'north' | 'south' | 'east' | 'west';
type OverlayFaceKey =
  | 'topOverlay'
  | 'bottomOverlay'
  | 'northOverlay'
  | 'southOverlay'
  | 'eastOverlay'
  | 'westOverlay'
  | 'sidesOverlay'
  | 'allOverlay';

const FACE_FALLBACKS: Record<FaceKey, Array<keyof TexturedBox>> = {
  top: ['top', 'all', 'sides'],
  bottom: ['bottom', 'all', 'sides'],
  north: ['north', 'sides', 'all'],
  south: ['south', 'sides', 'all'],
  east: ['east', 'sides', 'all'],
  west: ['west', 'sides', 'all'],
};

const FACE_KEYS: FaceKey[] = ['top', 'bottom', 'north', 'south', 'east', 'west'];
const OVERLAY_FACE_FALLBACKS: Record<FaceKey, OverlayFaceKey[]> = {
  top: ['topOverlay', 'allOverlay', 'sidesOverlay'],
  bottom: ['bottomOverlay', 'allOverlay', 'sidesOverlay'],
  north: ['northOverlay', 'sidesOverlay', 'allOverlay'],
  south: ['southOverlay', 'sidesOverlay', 'allOverlay'],
  east: ['eastOverlay', 'sidesOverlay', 'allOverlay'],
  west: ['westOverlay', 'sidesOverlay', 'allOverlay'],
};

const EPSILON = 1e-6;

const clamp = (value: number, min: number, max: number): number => {
  if (!Number.isFinite(value)) return min;
  if (value < min) return min;
  if (value > max) return max;
  return value;
};

const toDimension = (value: number): number => {
  if (!Number.isFinite(value) || value < 1) {
    throw new Error('texture_dimension_invalid');
  }
  return Math.floor(value);
};

export function uvToCanvasPixel(
  u: number,
  v: number,
  width: number,
  height: number
): { x: number; y: number } {
  const w = toDimension(width);
  const h = toDimension(height);

  const clampedU = clamp(u, 0, 1);
  const clampedV = clamp(v, 0, 1);

  const x = Math.min(w - 1, Math.max(0, Math.round(clampedU * (w - 1 + EPSILON))));
  const y = Math.min(h - 1, Math.max(0, Math.round(clampedV * (h - 1 + EPSILON))));

  return { x, y };
}

const toAsciiSymbol = (value: number): string => {
  if (value >= 0 && value <= 9) return value.toString();
  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  const index = value - 10;
  if (index >= 0 && index < alphabet.length) return alphabet[index];
  return '?';
};

export const buildPatternAscii = (pattern: { size: [number, number]; data: number[] }): string[] => {
  const [width, height] = pattern.size;
  const lines: string[] = [];
  for (let y = 0; y < height; y += 1) {
    const start = y * width;
    const line = pattern.data.slice(start, start + width).map(toAsciiSymbol).join('');
    lines.push(line);
  }
  return lines;
};

export function resolveFaceTextureId(box: TexturedBox, face: FaceKey): string | undefined {
  const order = FACE_FALLBACKS[face];
  for (const key of order) {
    const candidate = box[key];
    if (typeof candidate === 'string' && candidate.trim().length > 0) {
      return candidate;
    }
  }
  return undefined;
}

export function resolveOverlayFaceTextureId(box: TexturedBox, face: FaceKey): string | undefined {
  const order = OVERLAY_FACE_FALLBACKS[face];
  for (const key of order) {
    const candidate = box[key];
    if (typeof candidate === 'string' && candidate.trim().length > 0) {
      return candidate;
    }
  }
  return undefined;
}

export function collectFaceTextureIds(box: TexturedBox): string[] {
  const ids = new Set<string>();
  FACE_KEYS.forEach(face => {
    const textureId = resolveFaceTextureId(box, face);
    if (textureId) {
      ids.add(textureId);
    }
  });
  return Array.from(ids);
}

export function collectOverlayFaceTextureIds(box: TexturedBox): string[] {
  const ids = new Set<string>();
  FACE_KEYS.forEach(face => {
    const textureId = resolveOverlayFaceTextureId(box, face);
    if (textureId) {
      ids.add(textureId);
    }
  });
  return Array.from(ids);
}

export function getFaceKeys(): FaceKey[] {
  return [...FACE_KEYS];
}

export function getTextureMaterialIds(texture: Texture): string[] {
  return Array.isArray(texture.materials) ? [...texture.materials] : [];
}

export function collectTexturedBoxTextures(box: TexturedBox): Set<string> {
  const textures = new Set<string>();
  collectFaceTextureIds(box).forEach(id => textures.add(id));
  collectOverlayFaceTextureIds(box).forEach(id => textures.add(id));
  return textures;
}

export function collectTexturedBoxMaterials(
  box: TexturedBox,
  textureLookup: Map<string, Texture>
): Set<string> {
  const materialIds = new Set<string>();
  const textureIds = [
    ...collectFaceTextureIds(box),
    ...collectOverlayFaceTextureIds(box),
  ];
  textureIds.forEach(textureId => {
    const texture = textureLookup.get(textureId);
    if (!texture) return;
    texture.materials.forEach(materialId => materialIds.add(materialId));
  });
  return materialIds;
}

export function collectTexturedBoxPatterns(
  box: TexturedBox,
  textureLookup: Map<string, Texture>
): Set<string> {
  const patternIds = new Set<string>();
  const textureIds = [
    ...collectFaceTextureIds(box),
    ...collectOverlayFaceTextureIds(box),
  ];
  textureIds.forEach(textureId => {
    const texture = textureLookup.get(textureId);
    if (!texture) return;
    patternIds.add(texture.pattern);
  });
  return patternIds;
}

function buildTextureLookup(entity: BoxelDefinition): Map<string, Texture> {
  return new Map(entity.textures.map(texture => [texture.id, texture] as const));
}

function buildMaterialLookup(entity: BoxelDefinition): Map<string, Material> {
  return new Map(entity.materials.map(material => [material.id, material] as const));
}

export function determineTexturedBoxRenderMode(entity: BoxelDefinition, box: TexturedBox): 'plain' | 'cutout' {
  const textureLookup = buildTextureLookup(entity);
  const materialLookup = buildMaterialLookup(entity);
  const textureIds = new Set<string>([
    ...collectFaceTextureIds(box),
    ...collectOverlayFaceTextureIds(box),
  ]);
  for (const textureId of textureIds) {
    const texture = textureLookup.get(textureId);
    if (!texture) {
      continue;
    }
    for (const materialId of texture.materials) {
      const material = materialLookup.get(materialId);
      if (!material) {
        continue;
      }
      const opacity = material.opacity;
      if (opacity !== undefined && Number(opacity) < 1) {
        return 'cutout';
      }
    }
  }
  return 'plain';
}

export interface TexturedBoxDependencySummary {
  textures: Set<string>;
  materials: Set<string>;
  patterns: Set<string>;
}

export function collectTexturedBoxDependencies(
  box: TexturedBox,
  textureLookup: Map<string, Texture>
): TexturedBoxDependencySummary {
  const textures = collectTexturedBoxTextures(box);
  const materials = new Set<string>();
  const patterns = new Set<string>();

  textures.forEach(textureId => {
    const texture = textureLookup.get(textureId);
    if (!texture) return;
    patterns.add(texture.pattern);
    texture.materials.forEach(materialId => materials.add(materialId));
  });

  return { textures, materials, patterns };
}

export function collectEntityTextureLookup(entity: BoxelDefinition): Map<string, Texture> {
  return buildTextureLookup(entity);
}

export function collectEntityMaterialLookup(entity: BoxelDefinition): Map<string, Material> {
  return buildMaterialLookup(entity);
}

export function collectEntityPatternLookup(entity: BoxelDefinition): Map<string, Pattern> {
  return new Map(entity.patterns.map(pattern => [pattern.id, pattern] as const));
}
