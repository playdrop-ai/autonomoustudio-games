export const formatNumber = (value: number): string => {
  if (!Number.isFinite(value)) return '-';
  const abs = Math.abs(value);
  const fixed = abs >= 100
    ? value.toFixed(0)
    : abs >= 10
      ? value.toFixed(2)
      : abs >= 1
        ? value.toFixed(3)
        : value.toFixed(4);
  let normalized = fixed;
  if (normalized.includes('.')) {
    normalized = normalized.replace(/0+$/, '').replace(/\.$/, '');
  }
  if (normalized === '-0') normalized = '0';
  return normalized;
};

export const formatVec = (vec?: number[]): string => {
  if (!vec) return '-';
  return vec.map(formatNumber).join(', ');
};

export const formatColor = (vec?: number[]): string => {
  if (!vec) return '-';
  const clamped = vec.map(value => Math.max(0, Math.min(255, Math.round(value))));
  const hex = '#' + clamped.map(value => value.toString(16).padStart(2, '0')).join('').toUpperCase();
  return `${hex} · rgb(${clamped.join(', ')})`;
};
