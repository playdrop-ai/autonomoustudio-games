import type { BoxelDefinition, VoxelBox } from '../../types';

export type SplitAxis = 'x' | 'y' | 'z';

const axisIndex: Record<SplitAxis, number> = { x: 0, y: 1, z: 2 };

export interface SplitVoxelBoxResult {
  first: VoxelBox;
  second: VoxelBox;
}

function splitVoxelBoxInternal(
  primitive: VoxelBox,
  axis: SplitAxis,
  plane: number
): { result: SplitVoxelBoxResult; splitIndex: number; extent: number } {
  const axisIdx = axisIndex[axis];
  const extent = Math.round(primitive.size[axisIdx]);
  const splitIndex = Math.round(plane);
  if (splitIndex <= 0 || splitIndex >= extent) {
    throw new Error(`Split plane ${splitIndex} must be within (0, ${extent}) for axis ${axis}`);
  }

  const leftSize: [number, number, number] = [...primitive.size] as [number, number, number];
  const rightSize: [number, number, number] = [...primitive.size] as [number, number, number];
  leftSize[axisIdx] = splitIndex;
  rightSize[axisIdx] = extent - splitIndex;

  const leftVoxels = new Array<number>(leftSize[0] * leftSize[1] * leftSize[2]).fill(0);
  const rightVoxels = new Array<number>(rightSize[0] * rightSize[1] * rightSize[2]).fill(0);

  const voxels = primitive.voxels ?? [];
  const [sx, sy, sz] = primitive.size;

  const stride = (x: number, y: number, z: number): number => x + sx * (y + sy * z);

  for (let z = 0; z < sz; z += 1) {
    for (let y = 0; y < sy; y += 1) {
      for (let x = 0; x < sx; x += 1) {
        const value = voxels[stride(x, y, z)] ?? 0;
        if (value === 0) {
          continue;
        }
        if ((axis === 'x' && x < splitIndex) || (axis === 'y' && y < splitIndex) || (axis === 'z' && z < splitIndex)) {
          const li = x + leftSize[0] * (y + leftSize[1] * z);
          leftVoxels[li] = value;
        } else {
          const rx = axis === 'x' ? x - splitIndex : x;
          const ry = axis === 'y' ? y - splitIndex : y;
          const rz = axis === 'z' ? z - splitIndex : z;
          const ri = rx + rightSize[0] * (ry + rightSize[1] * rz);
          rightVoxels[ri] = value;
        }
      }
    }
  }

  const paletteClone = primitive.palette ? primitive.palette.slice() : [];

  const left: VoxelBox = {
    id: `${primitive.id}_part_a`,
    kind: 'voxel_box',
    size: leftSize,
    voxels: leftVoxels,
    palette: paletteClone,
  };

  const right: VoxelBox = {
    id: `${primitive.id}_part_b`,
    kind: 'voxel_box',
    size: rightSize,
    voxels: rightVoxels,
    palette: paletteClone,
  };

  return { result: { first: left, second: right }, splitIndex, extent };
}

export interface SplitVoxelResult {
  firstId: string;
  secondId: string;
}

export function splitVoxelPrimitive(entity: BoxelDefinition, primitiveId: string, axis: SplitAxis, plane: number): SplitVoxelResult {
  const primitiveIndex = entity.primitives.findIndex(primitive => primitive.id === primitiveId);
  if (primitiveIndex === -1) {
    throw new Error(`Primitive ${primitiveId} not found`);
  }
  const primitive = entity.primitives[primitiveIndex];
  if (primitive.kind !== 'voxel_box') {
    throw new Error(`Primitive ${primitiveId} is not a voxel box`);
  }

  const { result } = splitVoxelBoxInternal(primitive, axis, plane);

  entity.primitives.splice(primitiveIndex, 1, result.first, result.second);

  return { firstId: result.first.id, secondId: result.second.id };
}

export function splitVoxelBoxClone(primitive: VoxelBox, axis: SplitAxis, plane: number): SplitVoxelBoxResult {
  const copy = JSON.parse(JSON.stringify(primitive)) as VoxelBox;
  const { result } = splitVoxelBoxInternal(copy, axis, plane);
  return {
    first: { ...result.first, id: result.first.id },
    second: { ...result.second, id: result.second.id },
  };
}
