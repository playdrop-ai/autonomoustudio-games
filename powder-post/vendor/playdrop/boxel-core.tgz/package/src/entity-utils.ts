import type {
  ComboBox,
  BoxelDefinition,
  Material,
  Node,
  Pattern,
  Primitive,
  TexturedBox,
  Texture,
  VoxelBox,
} from './types';
import { collectTexturedBoxDependencies, collectEntityTextureLookup } from './textures';
import { mergeMaterials } from './materials';

export interface PrimitiveDependencySets {
  primitives: Set<string>;
  materials: Set<string>;
  textures: Set<string>;
  patterns: Set<string>;
}

export const buildPrimitiveLookup = (entity: BoxelDefinition): Map<string, Primitive> => {
  const lookup = new Map<string, Primitive>();
  entity.primitives.forEach(primitive => lookup.set(primitive.id, primitive));
  return lookup;
};

export const buildMaterialLookup = (entity: BoxelDefinition): Map<string, Material> => {
  const lookup = new Map<string, Material>();
  entity.materials.forEach(material => lookup.set(material.id, material));
  return lookup;
};

export const buildTextureLookup = (entity: BoxelDefinition): Map<string, Texture> => collectEntityTextureLookup(entity);

export const buildPatternLookup = (entity: BoxelDefinition): Map<string, Pattern> => {
  const lookup = new Map<string, Pattern>();
  entity.patterns.forEach(pattern => lookup.set(pattern.id, pattern));
  return lookup;
};

export function findNodeById(root: Node, targetId: string): Node | null {
  if (root.id === targetId) {
    return root;
  }
  for (const child of root.children ?? []) {
    const found = findNodeById(child, targetId);
    if (found) {
      return found;
    }
  }
  return null;
}

export function findNode(root: Node, targetId: string): Node | undefined {
  const result = findNodeById(root, targetId);
  return result === null ? undefined : result;
}

export function applyNodeDimensions(
  node: Node,
  primitive: { size: [number, number, number] },
  originalSize: [number, number, number],
  originalCenter: [number, number, number]
): void {
  node.size = [primitive.size[0], primitive.size[1], primitive.size[2]] as [number, number, number];
  const center: [number, number, number] = [
    Number(originalCenter[0]),
    (Number(originalCenter[1]) - Number(originalSize[1]) / 2) + primitive.size[1] / 2,
    Number(originalCenter[2]),
  ];
  node.center = center;
}

export function applyNodeDimensionsAxis(
  node: Node,
  primitive: { size: [number, number, number] },
  originalSize: [number, number, number],
  originalCenter: [number, number, number],
  axis: 'x' | 'y'
): void {
  node.size = [primitive.size[0], primitive.size[1], primitive.size[2]] as [number, number, number];
  const center: [number, number, number] = [
    Number(originalCenter[0]),
    Number(originalCenter[1]),
    Number(originalCenter[2]),
  ];
  const axisIdx = axis === 'x' ? 0 : 1;
  center[axisIdx] =
    (Number(originalCenter[axisIdx]) - Number(originalSize[axisIdx]) / 2) + primitive.size[axisIdx] / 2;
  node.center = center;
}

export function updateChildPosition(parent: Node, childId: string, offsetY: number): void {
  if (!Array.isArray(parent.children)) {
    return;
  }
  parent.children.forEach(child => {
    if (child.id !== childId || !Array.isArray(child.position)) {
      return;
    }
    const updated = [...child.position] as [number, number, number];
    updated[1] = offsetY;
    child.position = updated;
  });
}

export function updateChildPositionAxis(parent: Node, childId: string, axis: 'x' | 'y', value: number): void {
  if (!Array.isArray(parent.children)) {
    return;
  }
  const axisIdx = axis === 'x' ? 0 : 1;
  parent.children.forEach(child => {
    if (child.id !== childId) {
      return;
    }
    const current = Array.isArray(child.position)
      ? ([...child.position] as [number, number, number])
      : ([0, 0, 0] as [number, number, number]);
    current[axisIdx] = value;
    child.position = current;
  });
}

export function anchorCenter(
  originalCenter: number,
  originalSize: number,
  newSize: number,
  orientation: 1 | -1
): number {
  const innerBoundary =
    orientation > 0 ? originalCenter - originalSize / 2 : originalCenter + originalSize / 2;
  return orientation > 0 ? innerBoundary + newSize / 2 : innerBoundary - newSize / 2;
}

export function collectPrimitiveUsage(entity: BoxelDefinition, primitiveId: string): { nodeIds: string[]; comboIds: string[] } {
  const nodeIds: string[] = [];
  const comboIds: string[] = [];

  const visitNode = (node: Node) => {
    if (node.mesh === primitiveId) {
      nodeIds.push(node.id);
    }
    node.children?.forEach(visitNode);
  };

  visitNode(entity.geometry.root);

  entity.primitives.forEach(primitive => {
    if (primitive.kind !== 'combo_box') return;
    const combo = primitive as ComboBox;
    combo.slots.forEach(slot => {
      if (slot.primitive === primitiveId) {
        comboIds.push(combo.id);
      }
    });
  });

  return { nodeIds, comboIds };
}

export function computeComboBoundingSize(combo: ComboBox, primitiveLookup: Map<string, Primitive>): [number, number, number] {
  if (!combo.slots || combo.slots.length === 0) {
    return [
      combo.size?.[0] ?? 1,
      combo.size?.[1] ?? 1,
      combo.size?.[2] ?? 1,
    ];
  }

  let minX = Infinity;
  let minY = Infinity;
  let minZ = Infinity;
  let maxX = -Infinity;
  let maxY = -Infinity;
  let maxZ = -Infinity;
  let tracked = 0;

  combo.slots.forEach(slot => {
    const child = primitiveLookup.get(slot.primitive);
    if (!child) {
      return;
    }
    const size = child.size ?? [0, 0, 0];
    const halfSize: [number, number, number] = [size[0] / 2, size[1] / 2, size[2] / 2];
    minX = Math.min(minX, slot.offset[0] - halfSize[0]);
    minY = Math.min(minY, slot.offset[1] - halfSize[1]);
    minZ = Math.min(minZ, slot.offset[2] - halfSize[2]);
    maxX = Math.max(maxX, slot.offset[0] + halfSize[0]);
    maxY = Math.max(maxY, slot.offset[1] + halfSize[1]);
    maxZ = Math.max(maxZ, slot.offset[2] + halfSize[2]);
    tracked += 1;
  });

  if (tracked === 0 || !Number.isFinite(minX)) {
    return [
      combo.size?.[0] ?? 1,
      combo.size?.[1] ?? 1,
      combo.size?.[2] ?? 1,
    ];
  }

  const derived: [number, number, number] = [
    Math.max(0, maxX - minX),
    Math.max(0, maxY - minY),
    Math.max(0, maxZ - minZ),
  ];

  return [
    combo.size?.[0] ?? derived[0],
    combo.size?.[1] ?? derived[1],
    combo.size?.[2] ?? derived[2],
  ];
}

/**
 * Estimate the pixel-per-meter scale of an entity using its root scale vector.
 * Returns an integer value (e.g. 16 for classic avatars, 32 for HD avatars) or null when it cannot be derived.
 */
export function computeEntityPixelsPerMeter(entity: BoxelDefinition): number | null {
  const rootScale = entity.geometry?.root?.scale;
  if (Array.isArray(rootScale) && rootScale.length > 0) {
    const positive = rootScale
      .map(value => Number(value))
      .filter(value => Number.isFinite(value) && value > 0);
    if (positive.length > 0) {
      const averageScale = positive.reduce((sum, value) => sum + value, 0) / positive.length;
      if (averageScale > 0) {
        const pixelsPerMeter = Math.round(1 / averageScale);
        if (pixelsPerMeter > 0) {
          return pixelsPerMeter;
        }
      }
    }
  }
  return null;
}

export function collectPrimitiveDependencies(entity: BoxelDefinition, rootPrimitiveId: string): PrimitiveDependencySets {
  const primitiveLookup = buildPrimitiveLookup(entity);
  if (!primitiveLookup.has(rootPrimitiveId)) {
    throw new Error(`Primitive "${rootPrimitiveId}" not found in source entity`);
  }

  const pending: string[] = [rootPrimitiveId];
  const visited = new Set<string>();
  const primitives = new Set<string>();
  const materials = new Set<string>();
  const textures = new Set<string>();
  const patterns = new Set<string>();

  const textureLookup = buildTextureLookup(entity);
  const patternLookup = buildPatternLookup(entity);
  const materialLookup = buildMaterialLookup(entity);

  while (pending.length > 0) {
    const primitiveId = pending.pop()!;
    if (visited.has(primitiveId)) {
      continue;
    }
    visited.add(primitiveId);

    const primitive = primitiveLookup.get(primitiveId);
    if (!primitive) {
      throw new Error(`Primitive "${primitiveId}" references missing definition in source entity`);
    }

    primitives.add(primitive.id);

    switch (primitive.kind) {
      case 'plain_box': {
        const box = primitive as Primitive & { material: string };
        if (!materialLookup.has(box.material)) {
          throw new Error(`Primitive "${primitive.id}" references unknown material "${box.material}"`);
        }
        materials.add(box.material);
        break;
      }
      case 'textured_box': {
        const textured = primitive as TexturedBox;
        const summary = collectTexturedBoxDependencies(textured, textureLookup);
        summary.textures.forEach(textureId => {
          const texture = textureLookup.get(textureId);
          if (!texture) {
            throw new Error(`Primitive "${textured.id}" references unknown texture "${textureId}"`);
          }
          textures.add(textureId);
          if (!patternLookup.has(texture.pattern)) {
            throw new Error(`Texture "${textureId}" references missing pattern "${texture.pattern}"`);
          }
        });
        summary.patterns.forEach(patternId => patterns.add(patternId));
        summary.materials.forEach(materialId => {
          if (!materialLookup.has(materialId)) {
            throw new Error(`Texture dependency references unknown material "${materialId}"`);
          }
          materials.add(materialId);
        });
        break;
      }
      case 'voxel_box': {
        const voxel = primitive as VoxelBox;
        (voxel.palette ?? []).forEach(materialId => {
          if (!materialLookup.has(materialId)) {
            throw new Error(`Voxel primitive "${voxel.id}" references unknown material "${materialId}"`);
          }
          materials.add(materialId);
        });
        break;
      }
      case 'combo_box': {
        const combo = primitive as ComboBox;
        combo.slots.forEach(slot => {
          pending.push(slot.primitive);
        });
        break;
      }
      default:
        throw new Error(`Unsupported primitive kind "${(primitive as Primitive).kind}"`);
    }
  }

  return { primitives, materials, textures, patterns };
}

export function ensureNoIdCollisions<T extends { id: string }>(
  existing: readonly T[],
  incomingIds: Set<string>,
  entitySection: string
): void {
  for (const item of existing) {
    if (incomingIds.has(item.id)) {
      throw new Error(
        `Target entity already contains ${entitySection} with id "${item.id}". Rename it before importing or choose a different primitive.`
      );
    }
  }
}

export function selectByIdOrder<T extends { id: string }>(items: readonly T[], ids: Set<string>): T[] {
  return items.filter(item => ids.has(item.id)).map(item => ({ ...item }));
}

export interface MaterialMergeOutcome {
  additions: Material[];
  rewrites: Map<string, string>;
}

export function mergeIncomingMaterials(
  existingMaterials: readonly Material[],
  incomingMaterials: readonly Material[]
): MaterialMergeOutcome {
  const { additions, rewrites } = mergeMaterials(existingMaterials, incomingMaterials);
  return { additions, rewrites };
}

export function applyMaterialRewriteToPrimitive(primitive: Primitive, rewrite: (id: string) => string): Primitive {
  switch (primitive.kind) {
    case 'plain_box':
      return {
        ...primitive,
        material: rewrite(primitive.material),
      };
    case 'voxel_box':
      return {
        ...primitive,
        palette: Array.isArray(primitive.palette) ? primitive.palette.map(rewrite) : [],
      };
    case 'textured_box':
    case 'combo_box':
    default:
      return { ...primitive };
  }
}

export function applyMaterialRewriteToTexture(texture: Texture, rewrite: (id: string) => string): Texture {
  return {
    ...texture,
    materials: Array.isArray(texture.materials) ? texture.materials.map(rewrite) : [],
  };
}

export function cloneEntity<T>(value: T): T {
  if (typeof structuredClone === 'function') {
    return structuredClone(value);
  }
  return JSON.parse(JSON.stringify(value));
}
