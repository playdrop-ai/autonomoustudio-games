import humanoidR6Template from './humanoid_r6.json';
import humanoidR15Template from './humanoid_r15.json';
import type { BoxelDefinition } from '../../types';

const TEMPLATE_REGISTRY = {
  humanoid_r6: humanoidR6Template as unknown as BoxelDefinition,
  humanoid_r15: humanoidR15Template as unknown as BoxelDefinition,
} as const;

export type HumanoidTemplateId = keyof typeof TEMPLATE_REGISTRY;

export const getHumanoidTemplate = (id: HumanoidTemplateId): BoxelDefinition => {
  const template = TEMPLATE_REGISTRY[id];
  if (!template) {
    throw new Error(`Unknown humanoid template: ${id}`);
  }
  return JSON.parse(JSON.stringify(template)) as BoxelDefinition;
};

export const HUMANOID_R6_TEMPLATE_ID: HumanoidTemplateId = 'humanoid_r6';
export const HUMANOID_R15_TEMPLATE_ID: HumanoidTemplateId = 'humanoid_r15';
