import type { BoxelDefinition, Node } from '../../types';
import { cloneEntity } from '../../entity-utils';

export const roundSize = (value: number): number => Math.max(1, Math.round(value));

export function collectNodes(root: Node, mutate?: (node: Node) => void): Map<string, Node> {
  const nodes = new Map<string, Node>();
  (function traverse(node: Node) {
    mutate?.(node);
    nodes.set(node.id, node);
    node.children.forEach((child: Node) => traverse(child));
  })(root);
  return nodes;
}

export function cloneTemplate(template: BoxelDefinition, outputId: string): BoxelDefinition {
  const templateClone = cloneEntity(template);
  templateClone.id = outputId;
  templateClone.geometry.id = `${outputId}_geometry`;
  return templateClone;
}
