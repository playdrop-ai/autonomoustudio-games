import type { BoxelDefinition } from '../../types';

export interface BuildHumanoidR15Options {
  template: BoxelDefinition;
  source: BoxelDefinition;
  outputId: string;
}
