export {
  scanHumanoidSource,
  type HumanoidSourceScan,
  type HumanoidSourceCube,
  type HumanoidOverlayCube,
  type HumanoidPartKey,
  type FaceUVRect as HumanoidFaceUVRect,
} from './scanner';

export { buildHumanoidR6Entity, type BuildHumanoidR6Options } from './builder';

export {
  IDENTITY_FACE_MAP,
  RIGHT_ARM_FACE_MAP,
  LEFT_ARM_FACE_MAP,
  PART_FACE_TRANSFORMS,
  getFaceDimensions,
  extractSourceFacePixels,
  transformFacePixels,
  type FaceName as HumanoidFaceName,
  type FaceTransform,
  type FaceSource,
} from './textures/face-map';

export {
  createFaceArtifacts,
  type CreateFaceArtifactsParams,
  type FaceArtifactsResult,
} from './textures/artifacts';
