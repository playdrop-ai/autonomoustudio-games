import type { Pattern, Texture } from '../../../types';
import type { FaceSource, FaceTransform, FaceName } from './face-map';
import { transformFacePixels } from './face-map';

export interface CreateFaceArtifactsParams {
  baseId: string;
  face: FaceName;
  source: FaceSource;
  transform: FaceTransform;
  expectedSize: [number, number];
  textureWidth: number;
  textureHeight: number;
  texturePixels: Uint8Array;
  ensureMaterial: (color: { r: number; g: number; b: number; a: number }) => string;
  variant?: 'base' | 'overlay';
}

export interface FaceArtifactsResult {
  pattern: Pattern | null;
  texture: Texture | null;
  hasTransparency: boolean;
  hasVisiblePixels: boolean;
}

export function createFaceArtifacts(params: CreateFaceArtifactsParams): FaceArtifactsResult {
  const {
    baseId,
    face,
    source,
    transform,
    expectedSize,
    textureWidth,
    textureHeight,
    texturePixels,
    ensureMaterial,
    variant = 'base',
  } = params;

  const transformed = transformFacePixels(source, transform, textureWidth, textureHeight, texturePixels);
  const width = transformed.width;
  const height = transformed.height;

  if (width !== expectedSize[0] || height !== expectedSize[1]) {
    throw new Error(
      `Transformed face for "${baseId}" (${face}) has size ${width}x${height} but expected ${expectedSize[0]}x${expectedSize[1]}`
    );
  }

  const textureMaterials: string[] = [];
  const localMaterialIndex = new Map<string, number>();
  const patternData: number[] = [];
  let hasTransparency = false;
  let hasVisiblePixels = false;

  for (let row = 0; row < height; row += 1) {
    for (let col = 0; col < width; col += 1) {
      const idx = (row * width + col) * 4;
      const color = {
        r: transformed.data[idx],
        g: transformed.data[idx + 1],
        b: transformed.data[idx + 2],
        a: transformed.data[idx + 3],
      };
      if (color.a < 255) {
        hasTransparency = true;
      }
      if (color.a > 0) {
        hasVisiblePixels = true;
      }
      const materialId = ensureMaterial(color);
      let localIndex = localMaterialIndex.get(materialId);
      if (localIndex === undefined) {
        localIndex = textureMaterials.length;
        textureMaterials.push(materialId);
        localMaterialIndex.set(materialId, localIndex);
      }
      patternData.push(localIndex);
    }
  }

  if (variant === 'overlay' && !hasVisiblePixels) {
    return { pattern: null, texture: null, hasTransparency, hasVisiblePixels: false };
  }

  const suffix = variant === 'overlay' ? '_overlay' : '';
  const patternId = `${baseId}${suffix}`;
  const pattern: Pattern = {
    id: patternId,
    size: [width, height],
    data: patternData,
  };
  const texture: Texture = {
    id: patternId,
    pattern: patternId,
    materials: textureMaterials,
  };

  return {
    pattern,
    texture,
    hasTransparency,
    hasVisiblePixels: true,
  };
}
