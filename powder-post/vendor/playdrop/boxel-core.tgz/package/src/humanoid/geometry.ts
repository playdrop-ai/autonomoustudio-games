import type { Vec3 } from '../types';

export type GeometryVec3 = [number, number, number];
export type GeometryFaceName = 'north' | 'south' | 'east' | 'west' | 'up' | 'down';

export interface GeometryCube {
  origin: GeometryVec3;
  size: GeometryVec3;
  uv: [number, number] | Record<GeometryFaceName, [number, number, number?, number?]>;
  inflate?: number;
  mirror?: boolean;
}

export interface GeometryBone {
  name: string;
  parent?: string;
  pivot?: GeometryVec3;
  mirror?: boolean;
  cubes?: GeometryCube[];
}

export interface GeometryEntry {
  texturewidth?: number;
  textureheight?: number;
  bones?: GeometryBone[];
}

export const toGeometryVec3 = (input?: GeometryVec3 | Vec3): GeometryVec3 => {
  if (!input) {
    return [0, 0, 0];
  }
  return [Number(input[0]) || 0, Number(input[1]) || 0, Number(input[2]) || 0];
};
