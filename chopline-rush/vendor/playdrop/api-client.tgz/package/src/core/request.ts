export type ApiRequestLike = {
  method: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
  path: string;
  body?: unknown;
  headers?: Record<string, string>;
};

export type ApiResponseLike<T> = {
  status: number;
  body: T;
  headers: Headers;
};

export type RequestExecutor = <T>(request: ApiRequestLike) => Promise<ApiResponseLike<T>>;

export const DEFAULT_REQUEST_TIMEOUT_MS = 15000;

export function resolveRequestTimeoutMs(value: number | undefined): number {
  if (value === undefined) {
    return DEFAULT_REQUEST_TIMEOUT_MS;
  }
  const parsed = Number(value);
  if (!Number.isFinite(parsed) || parsed <= 0) {
    throw new Error('invalid_api_request_timeout_ms');
  }
  return Math.floor(parsed);
}

export function createBaseUrlResolver(baseUrl: string | undefined): () => string {
  return () => {
    if (baseUrl) {
      return baseUrl;
    }
    if (typeof process !== 'undefined' && process.env["NEXT_PUBLIC_API_BASE"]) {
      return process.env["NEXT_PUBLIC_API_BASE"];
    }
    if (typeof window !== 'undefined') {
      const { protocol, hostname } = window.location;
      if (hostname.includes('www.') && hostname.includes('.')) {
        return `${protocol}//api.${hostname.replace('www.', '')}`;
      }
      if (hostname === 'play.local' || hostname === 'www.localhost') {
        const apiDomain = hostname.includes('localhost') ? 'api.localhost' : 'api.local';
        return `${protocol}//${apiDomain}`;
      }
      return `${protocol}//${hostname}:4000`;
    }
    return 'http://localhost:4000';
  };
}

export function resolveUrl(base: string, path: string): string {
  if (/^https?:/i.test(path)) {
    return path;
  }
  const normalizedBase = base.endsWith('/') ? base : `${base}/`;
  const trimmedPath = path.startsWith('/') ? path.slice(1) : path;
  return new URL(trimmedPath, normalizedBase).toString();
}

export function buildBrowserCredentialsInit(
  includeBrowserCredentials: boolean,
): Partial<Pick<RequestInit, 'credentials'>> {
  if (!includeBrowserCredentials || typeof window === 'undefined') {
    return {};
  }
  return { credentials: 'include' };
}

export async function parseResponseBody<T>(response: Response): Promise<T> {
  if (response.status === 204 || response.status === 205 || response.status === 304) {
    return undefined as T;
  }
  const contentType = response.headers.get('content-type') || '';
  if (contentType.includes('application/json')) {
    try {
      return (await response.clone().json()) as T;
    } catch {
      // fall through to text if parsing fails
    }
  }
  try {
    const text = await response.clone().text();
    return text as unknown as T;
  } catch {
    return undefined as T;
  }
}

export function createRequestExecutor(input: {
  fetchImpl: typeof fetch;
  resolveBaseUrl: () => string;
  resolveUrl: (base: string, path: string) => string;
  parseResponseBody: <T>(response: Response) => Promise<T>;
  resolveToken: () => Promise<string | null>;
  getClientHeaders: () => Record<string, string>;
  requestTimeoutMs: number;
  includeBrowserCredentials: boolean;
}): RequestExecutor {
  const {
    fetchImpl,
    resolveBaseUrl,
    resolveUrl: resolveUrlInput,
    parseResponseBody: parseResponseBodyInput,
    resolveToken,
    getClientHeaders,
    requestTimeoutMs,
    includeBrowserCredentials,
  } = input;

  return async function request<T>(req: ApiRequestLike): Promise<ApiResponseLike<T>> {
    const base = resolveBaseUrl();
    const targetUrl = resolveUrlInput(base, req.path);
    const headers = new Headers();

    for (const [key, value] of Object.entries(getClientHeaders())) {
      headers.set(key, value);
    }

    headers.set('accept', 'application/json');
    if (req.body !== undefined && req.body !== null && req.method !== 'GET') {
      headers.set('content-type', 'application/json');
    }

    if (req.headers) {
      for (const [key, value] of Object.entries(req.headers)) {
        headers.set(key, value);
      }
    }

    const token = await resolveToken();
    if (token) {
      headers.set('authorization', `Bearer ${token}`);
    }

    const init: RequestInit = {
      method: req.method,
      headers,
      ...buildBrowserCredentialsInit(includeBrowserCredentials),
    };
    if (req.body !== undefined && req.body !== null && req.method !== 'GET') {
      init.body = typeof req.body === 'string' ? req.body : JSON.stringify(req.body);
    }

    let timeoutHandle: ReturnType<typeof setTimeout> | null = null;
    let controller: AbortController | null = null;
    if (typeof AbortController !== 'undefined') {
      controller = new AbortController();
      init.signal = controller.signal;
      timeoutHandle = setTimeout(() => {
        controller?.abort();
      }, requestTimeoutMs);
    }

    try {
      const response = await fetchImpl(targetUrl, init);
      const parsed = await parseResponseBodyInput<T>(response);
      return {
        status: response.status,
        body: parsed,
        headers: response.headers,
      };
    } catch (error) {
      if (controller?.signal.aborted) {
        throw new Error(`api_request_timeout:${req.method}:${req.path}`);
      }
      throw error;
    } finally {
      if (timeoutHandle) {
        clearTimeout(timeoutHandle);
      }
    }
  };
}
