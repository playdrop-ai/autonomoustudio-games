import type {
  ContentCommentsResponse,
  CreateContentCommentRequest,
  CreateContentCommentResponse,
  DeleteContentCommentResponse,
  LikedItemMutationResponse,
  SavedItemKind,
} from '@playdrop/types';

type ApiResponseLike<T> = {
  status: number;
  body: T;
  headers: Headers;
};

type RequestExecutor = <T>(input: {
  method: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
  path: string;
  body?: unknown;
  headers?: Record<string, string>;
  signal?: AbortSignal;
}) => Promise<ApiResponseLike<T>>;

type ErrorHandler = (response: ApiResponseLike<unknown>, defaultMessage: string) => never;

export function buildCommentsApiClientMethods(input: {
  request: RequestExecutor;
  handleApiError: ErrorHandler;
  normalizeSavedItemKindInput: (kind: SavedItemKind) => SavedItemKind;
  normalizeCreatorItemSlug: (value: string, field: 'creator' | 'name') => string;
  normalizePositiveIntegerInput: (value: number, errorCode: string) => number;
}) {
  const {
    request,
    handleApiError,
    normalizeSavedItemKindInput,
    normalizeCreatorItemSlug,
    normalizePositiveIntegerInput,
  } = input;

  return {
    async fetchContentComments(kind: SavedItemKind, creatorUsername: string, itemName: string): Promise<ContentCommentsResponse> {
      const normalizedKind = normalizeSavedItemKindInput(kind);
      const creator = normalizeCreatorItemSlug(creatorUsername, 'creator');
      const name = normalizeCreatorItemSlug(itemName, 'name');
      const response = await request<ContentCommentsResponse>({
        method: 'GET',
        path: `/comments/${encodeURIComponent(normalizedKind)}/${encodeURIComponent(creator)}/${encodeURIComponent(name)}`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'fetch_content_comments');
      }
      return response.body;
    },

    async createContentComment(
      kind: SavedItemKind,
      creatorUsername: string,
      itemName: string,
      requestBody: CreateContentCommentRequest,
    ): Promise<CreateContentCommentResponse> {
      const normalizedKind = normalizeSavedItemKindInput(kind);
      const creator = normalizeCreatorItemSlug(creatorUsername, 'creator');
      const name = normalizeCreatorItemSlug(itemName, 'name');
      const response = await request<CreateContentCommentResponse>({
        method: 'POST',
        path: `/me/comments/${encodeURIComponent(normalizedKind)}/${encodeURIComponent(creator)}/${encodeURIComponent(name)}`,
        body: requestBody,
      });
      if (response.status !== 200) {
        handleApiError(response, 'create_content_comment');
      }
      return response.body;
    },

    async likeContentComment(commentId: number): Promise<LikedItemMutationResponse> {
      const normalizedCommentId = normalizePositiveIntegerInput(commentId, 'invalid_comment_id');
      const response = await request<LikedItemMutationResponse>({
        method: 'PUT',
        path: `/me/comments/${encodeURIComponent(String(normalizedCommentId))}/likes`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'like_content_comment');
      }
      return response.body;
    },

    async unlikeContentComment(commentId: number): Promise<LikedItemMutationResponse> {
      const normalizedCommentId = normalizePositiveIntegerInput(commentId, 'invalid_comment_id');
      const response = await request<LikedItemMutationResponse>({
        method: 'DELETE',
        path: `/me/comments/${encodeURIComponent(String(normalizedCommentId))}/likes`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'unlike_content_comment');
      }
      return response.body;
    },

    async deleteContentComment(commentId: number): Promise<DeleteContentCommentResponse> {
      const normalizedCommentId = normalizePositiveIntegerInput(commentId, 'invalid_comment_id');
      const response = await request<DeleteContentCommentResponse>({
        method: 'DELETE',
        path: `/me/comments/${encodeURIComponent(String(normalizedCommentId))}`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'delete_content_comment');
      }
      return response.body;
    },
  };
}
