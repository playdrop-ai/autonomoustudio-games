import type {
  SearchAssetType,
  SearchKind,
  SearchMode,
  SearchRequest,
  SearchResponse,
  SearchSuggestRequest,
  SearchSuggestResponse,
} from '@playdrop/types';

type ApiResponseLike<T> = {
  status: number;
  body: T;
  headers: Headers;
};

type RequestExecutor = <T>(input: {
  method: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
  path: string;
  body?: unknown;
  headers?: Record<string, string>;
  signal?: AbortSignal;
}) => Promise<ApiResponseLike<T>>;

type ErrorHandler = (response: ApiResponseLike<unknown>, defaultMessage: string) => never;

export function buildSearchApiClientMethods(input: {
  request: RequestExecutor;
  handleApiError: ErrorHandler;
  normalizeSearchModeInput: (mode: SearchMode) => SearchMode;
  normalizeSearchKindInput: (kind: SearchKind) => SearchKind;
  normalizeSearchAssetTypeInput: (assetType: SearchAssetType) => SearchAssetType;
  normalizePositiveIntegerInput: (value: number, errorCode: string) => number;
}) {
  const {
    request,
    handleApiError,
    normalizeSearchModeInput,
    normalizeSearchKindInput,
    normalizeSearchAssetTypeInput,
    normalizePositiveIntegerInput,
  } = input;

  return {
    async search(searchRequest: SearchRequest): Promise<SearchResponse> {
      const query = typeof searchRequest.q === 'string' ? searchRequest.q.trim() : '';
      if (!query) {
        throw new Error('invalid_search_query');
      }

      const params = new URLSearchParams();
      params.set('q', query);
      if (searchRequest.mode) {
        params.set('mode', normalizeSearchModeInput(searchRequest.mode));
      }
      if (searchRequest.kind) {
        params.set('kind', normalizeSearchKindInput(searchRequest.kind));
      }
      if (searchRequest.page !== undefined) {
        params.set('page', String(normalizePositiveIntegerInput(searchRequest.page, 'invalid_search_page')));
      }
      if (searchRequest.pageSize !== undefined) {
        params.set('pageSize', String(normalizePositiveIntegerInput(searchRequest.pageSize, 'invalid_search_page_size')));
      }
      if (searchRequest.appType) {
        params.set('appType', searchRequest.appType);
      }
      if (searchRequest.assetType) {
        params.set('assetType', normalizeSearchAssetTypeInput(searchRequest.assetType));
      }
      if (searchRequest.assetCategory) {
        params.set('assetCategory', searchRequest.assetCategory);
      }
      if (typeof searchRequest.assetSubcategory === 'string' && searchRequest.assetSubcategory.trim().length > 0) {
        params.set('assetSubcategory', searchRequest.assetSubcategory.trim());
      }
      if (searchRequest.packContainsCategory) {
        params.set('packContainsCategory', searchRequest.packContainsCategory);
      }
      if (typeof searchRequest.packContainsSubcategory === 'string' && searchRequest.packContainsSubcategory.trim().length > 0) {
        params.set('packContainsSubcategory', searchRequest.packContainsSubcategory.trim());
      }

      const response = await request<SearchResponse>({
        method: 'GET',
        path: `/search?${params.toString()}`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'search');
      }

      return response.body;
    },

    async suggestSearch(searchRequest: SearchSuggestRequest): Promise<SearchSuggestResponse> {
      const query = typeof searchRequest.q === 'string' ? searchRequest.q.trim() : '';
      if (!query) {
        throw new Error('invalid_search_query');
      }

      const response = await request<SearchSuggestResponse>({
        method: 'GET',
        path: `/search/suggest?q=${encodeURIComponent(query)}`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'suggest_search');
      }

      return response.body;
    },
  };
}
