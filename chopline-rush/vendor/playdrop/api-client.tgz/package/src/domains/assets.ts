import type {
  AssetBrowseKind,
  AssetCategoriesResponse,
  AssetCategory,
  AssetDetailResponse,
  AssetListResponse,
  AssetSourceBundleResponse,
  AssetVersionResponse,
  AssetVersionsListResponse,
  ContentRemixRelationsResponse,
  CreateAssetVersionResponse,
  DeleteAssetResponse,
  DeleteAssetVersionResponse,
  UpdateAssetRequest,
  UpdateAssetResponse,
  UpdateAssetVersionRequest,
  UpdateAssetVersionResponse,
} from '@playdrop/types';
import type { UploadAssetVersionOptions } from '../client.js';
import { buildBrowserCredentialsInit } from '../core/request.js';

type ApiResponseLike<T> = {
  status: number;
  body: T;
  headers: Headers;
};

type RequestExecutor = <T>(input: {
  method: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
  path: string;
  body?: unknown;
  headers?: Record<string, string>;
  signal?: AbortSignal;
}) => Promise<ApiResponseLike<T>>;

type ErrorHandler = (response: ApiResponseLike<unknown>, defaultMessage: string) => never;

type ParseResponseBody = <T>(response: Response) => Promise<T>;

async function buildAuthorizedHeaders(
  getClientHeaders: () => Record<string, string>,
  resolveToken: () => Promise<string | null>,
): Promise<Headers> {
  const headers = new Headers();
  for (const [key, value] of Object.entries(getClientHeaders())) {
    headers.set(key, value);
  }
  const token = await resolveToken();
  if (token) {
    headers.set('authorization', `Bearer ${token}`);
  }
  return headers;
}

function buildPublicAssetPath(
  normalizeCreatorItemSlug: (value: string, field: 'creator' | 'name') => string,
  creatorUsername: string,
  assetName: string,
  suffix = '',
): string {
  const creator = normalizeCreatorItemSlug(creatorUsername, 'creator');
  const name = normalizeCreatorItemSlug(assetName, 'name');
  return `/assets/${encodeURIComponent(creator)}/${encodeURIComponent(name)}${suffix}`;
}

function buildAssetVersionUploadForm(options: UploadAssetVersionOptions): FormData {
  if (!Array.isArray(options.files) || options.files.length === 0) {
    throw new Error('missing_asset_files');
  }
  const form = new FormData();
  form.set('category', options.category);
  form.set('subcategory', options.subcategory);
  form.set('format', options.format);
  appendAssetVersionOptionalFields(form, options);
  appendAssetVersionFiles(form, options);
  return form;
}

function appendAssetVersionOptionalFields(form: FormData, options: UploadAssetVersionOptions): void {
  if (options.visibility) form.set('visibility', options.visibility);
  if (options.sourceKind) form.set('sourceKind', options.sourceKind);
  if (typeof options.sourceAppVersionId === 'number') {
    form.set('sourceAppVersionId', String(options.sourceAppVersionId));
  }
  if (typeof options.sourceGenerationId === 'string' && options.sourceGenerationId.trim().length > 0) {
    form.set('sourceGenerationId', options.sourceGenerationId.trim());
  }
  if (typeof options.remixRef === 'string' && options.remixRef.trim().length > 0) {
    form.set('remixRef', options.remixRef.trim());
  }
  if (typeof options.shopListed === 'boolean') {
    form.set('shopListed', options.shopListed ? 'true' : 'false');
  }
  if (typeof options.shopPriceCredits === 'number') {
    form.set('shopPriceCredits', String(options.shopPriceCredits));
  }
  if (typeof options.displayName === 'string' && options.displayName.trim().length > 0) {
    form.set('displayName', options.displayName.trim());
  }
  if (typeof options.description === 'string') {
    form.set('description', options.description);
  }
}

function appendAssetVersionFiles(form: FormData, options: UploadAssetVersionOptions): void {
  for (const item of options.files) {
    if (!item) {
      throw new Error('missing_asset_upload_file');
    }
    const fieldName = typeof item.fieldName === 'string' && item.fieldName.trim().length > 0
      ? item.fieldName.trim()
      : 'file';
    if (typeof item.filename === 'string' && item.filename.trim().length > 0) {
      form.append(fieldName, item.file, item.filename.trim());
    } else {
      form.append(fieldName, item.file);
    }
  }
}

async function fetchAssetRelatedRequest(
  request: RequestExecutor,
  handleApiError: ErrorHandler,
  normalizeCreatorItemSlug: (value: string, field: 'creator' | 'name') => string,
  creatorUsername: string,
  assetName: string,
): Promise<ContentRemixRelationsResponse> {
  const response = await request<ContentRemixRelationsResponse>({
    method: 'GET',
    path: buildPublicAssetPath(normalizeCreatorItemSlug, creatorUsername, assetName, '/related'),
  });
  if (response.status !== 200) {
    handleApiError(response, 'get_asset_related');
  }
  return response.body;
}

async function listAssetsRequest(
  request: RequestExecutor,
  handleApiError: ErrorHandler,
  options: { limit?: number; offset?: number; category?: AssetCategory; subcategory?: string; kind?: AssetBrowseKind } = {},
): Promise<AssetListResponse> {
  const params = new URLSearchParams();
  if (typeof options.limit === 'number') params.set('limit', String(options.limit));
  if (typeof options.offset === 'number') params.set('offset', String(options.offset));
  if (typeof options.category === 'string' && options.category.trim().length > 0) {
    params.set('category', options.category.trim());
  }
  if (typeof options.subcategory === 'string' && options.subcategory.trim().length > 0) {
    params.set('subcategory', options.subcategory.trim());
  }
  if (typeof options.kind === 'string' && options.kind.trim().length > 0) {
    params.set('kind', options.kind.trim());
  }
  const query = params.toString();
  const path = `/assets${query ? `?${query}` : ''}`;
  const response = await request<AssetListResponse>({ method: 'GET', path });
  if (response.status !== 200) {
    handleApiError(response, 'list_assets');
  }
  return response.body;
}

async function listAssetCategoriesRequest(
  request: RequestExecutor,
  handleApiError: ErrorHandler,
): Promise<AssetCategoriesResponse> {
  const response = await request<AssetCategoriesResponse>({
    method: 'GET',
    path: '/asset-categories',
  });
  if (response.status !== 200) {
    handleApiError(response, 'list_asset_categories');
  }
  return response.body;
}

async function createAssetVersionRequest(
  input: {
    fetchImpl: typeof fetch;
    includeBrowserCredentials: boolean;
    resolveBaseUrl: () => string;
    resolveUrl: (base: string, path: string) => string;
    parseResponseBody: ParseResponseBody;
    resolveToken: () => Promise<string | null>;
    getClientHeaders: () => Record<string, string>;
    buildCreatorAssetMutationPath: (creatorUsername: string, assetName?: string, suffix?: string) => string;
    handleApiError: ErrorHandler;
  },
  creatorUsername: string,
  assetName: string,
  options: UploadAssetVersionOptions,
): Promise<CreateAssetVersionResponse> {
  const form = buildAssetVersionUploadForm(options);
  const base = input.resolveBaseUrl();
  const path = `${input.buildCreatorAssetMutationPath(creatorUsername, assetName)}/versions`;
  const headers = await buildAuthorizedHeaders(input.getClientHeaders, input.resolveToken);
  const response = await input.fetchImpl(input.resolveUrl(base, path), {
    method: 'POST',
    headers,
    body: form,
    ...buildBrowserCredentialsInit(input.includeBrowserCredentials),
  });
  const parsed = await input.parseResponseBody<CreateAssetVersionResponse>(response);
  const apiResponse = { status: response.status, body: parsed, headers: response.headers };
  if (response.status !== 201 && response.status !== 200) {
    input.handleApiError(apiResponse, 'create_asset_version');
  }
  return parsed;
}

export function buildAssetsApiClientMethods(input: {
  request: RequestExecutor;
  handleApiError: ErrorHandler;
  fetchImpl: typeof fetch;
  includeBrowserCredentials: boolean;
  resolveBaseUrl: () => string;
  resolveUrl: (base: string, path: string) => string;
  parseResponseBody: ParseResponseBody;
  resolveToken: () => Promise<string | null>;
  getClientHeaders: () => Record<string, string>;
  buildCreatorAssetMutationPath: (creatorUsername: string, assetName?: string, suffix?: string) => string;
  normalizeCreatorItemSlug: (value: string, field: 'creator' | 'name') => string;
  normalizeAssetRevisionInput: (revision: string | number) => string;
  parseContentDispositionFilename: (headerValue: string | null) => string | null;
}) {
  const {
    request,
    handleApiError,
    fetchImpl,
    includeBrowserCredentials,
    resolveBaseUrl,
    resolveUrl,
    parseResponseBody,
    resolveToken,
    getClientHeaders,
    buildCreatorAssetMutationPath,
    normalizeCreatorItemSlug,
    normalizeAssetRevisionInput,
    parseContentDispositionFilename,
  } = input;

  return {
    async createAssetVersion(
      creatorUsername: string,
      name: string,
      options: UploadAssetVersionOptions,
    ): Promise<CreateAssetVersionResponse> {
      const assetName = typeof name === 'string' ? name.trim() : '';
      if (!assetName) {
        throw new Error('invalid_asset_name');
      }
      return createAssetVersionRequest(
        {
          fetchImpl,
          includeBrowserCredentials,
          resolveBaseUrl,
          resolveUrl,
          parseResponseBody,
          resolveToken,
          getClientHeaders,
          buildCreatorAssetMutationPath,
          handleApiError,
        },
        creatorUsername,
        assetName,
        options,
      );
    },

    async fetchAssetRelated(
      creatorUsername: string,
      assetName: string,
    ): Promise<ContentRemixRelationsResponse> {
      return fetchAssetRelatedRequest(request, handleApiError, normalizeCreatorItemSlug, creatorUsername, assetName);
    },

    async listAssetCategories(): Promise<AssetCategoriesResponse> {
      return listAssetCategoriesRequest(request, handleApiError);
    },

    async listAssets(
      options: { limit?: number; offset?: number; category?: AssetCategory; subcategory?: string; kind?: AssetBrowseKind } = {},
    ): Promise<AssetListResponse> {
      return listAssetsRequest(request, handleApiError, options);
    },

    async listAssetsForCreator(
      creatorUsername: string,
      options: { limit?: number; offset?: number; category?: AssetCategory; subcategory?: string; kind?: AssetBrowseKind } = {},
    ): Promise<AssetListResponse> {
      const params = new URLSearchParams();
      if (typeof options.limit === 'number') {
        params.set('limit', String(options.limit));
      }
      if (typeof options.offset === 'number') {
        params.set('offset', String(options.offset));
      }
      if (typeof options.category === 'string' && options.category.trim().length > 0) {
        params.set('category', options.category.trim());
      }
      if (typeof options.subcategory === 'string' && options.subcategory.trim().length > 0) {
        params.set('subcategory', options.subcategory.trim());
      }
      if (typeof options.kind === 'string' && options.kind.trim().length > 0) {
        params.set('kind', options.kind.trim());
      }
      const query = params.toString();
      const path = `/creators/${encodeURIComponent(creatorUsername)}/assets${query ? `?${query}` : ''}`;
      const response = await request<AssetListResponse>({
        method: 'GET',
        path,
      });
      if (response.status !== 200) {
        handleApiError(response, 'list_assets_for_creator');
      }
      return response.body;
    },

    async fetchAssetBySlug(creatorUsername: string, assetName: string): Promise<AssetDetailResponse> {
      const path = `/assets/${encodeURIComponent(creatorUsername)}/${encodeURIComponent(assetName)}`;
      const response = await request<AssetDetailResponse>({
        method: 'GET',
        path,
      });
      if (response.status !== 200) {
        handleApiError(response, 'fetch_asset_by_slug');
      }
      return response.body;
    },

    async listAssetVersions(
      creatorUsername: string,
      assetName: string,
      options: { limit?: number; offset?: number } = {},
    ): Promise<AssetVersionsListResponse> {
      const params = new URLSearchParams();
      if (typeof options.limit === 'number') {
        params.set('limit', String(options.limit));
      }
      if (typeof options.offset === 'number') {
        params.set('offset', String(options.offset));
      }
      const query = params.toString();
      const path = `/assets/${encodeURIComponent(creatorUsername)}/${encodeURIComponent(assetName)}/versions${query ? `?${query}` : ''}`;
      const response = await request<AssetVersionsListResponse>({
        method: 'GET',
        path,
      });
      if (response.status !== 200) {
        handleApiError(response, 'list_asset_versions');
      }
      return response.body;
    },

    async updateAsset(
      creatorUsername: string,
      name: string,
      requestBody: UpdateAssetRequest,
    ): Promise<UpdateAssetResponse> {
      const assetName = typeof name === 'string' ? name.trim() : '';
      if (!assetName) {
        throw new Error('invalid_asset_name');
      }
      const response = await request<UpdateAssetResponse>({
        method: 'PATCH',
        path: buildCreatorAssetMutationPath(creatorUsername, assetName),
        body: requestBody,
      });
      if (response.status !== 200) {
        handleApiError(response, 'update_asset');
      }
      return response.body;
    },

    async updateAssetVersion(
      creatorUsername: string,
      name: string,
      revision: string | number,
      requestBody: UpdateAssetVersionRequest,
    ): Promise<UpdateAssetVersionResponse> {
      const assetName = typeof name === 'string' ? name.trim() : '';
      if (!assetName) {
        throw new Error('invalid_asset_name');
      }
      const normalizedRevision = normalizeAssetRevisionInput(revision);
      const response = await request<UpdateAssetVersionResponse>({
        method: 'PATCH',
        path: `${buildCreatorAssetMutationPath(creatorUsername, assetName)}/versions/${encodeURIComponent(normalizedRevision)}`,
        body: requestBody,
      });
      if (response.status !== 200) {
        handleApiError(response, 'update_asset_version');
      }
      return response.body;
    },

    async deleteAssetVersion(
      creatorUsername: string,
      name: string,
      revision: string | number,
    ): Promise<DeleteAssetVersionResponse> {
      const assetName = typeof name === 'string' ? name.trim() : '';
      if (!assetName) {
        throw new Error('invalid_asset_name');
      }
      const normalizedRevision = normalizeAssetRevisionInput(revision);
      const response = await request<DeleteAssetVersionResponse>({
        method: 'DELETE',
        path: `${buildCreatorAssetMutationPath(creatorUsername, assetName)}/versions/${encodeURIComponent(normalizedRevision)}`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'delete_asset_version');
      }
      return response.body;
    },

    async deleteAsset(
      creatorUsername: string,
      name: string,
    ): Promise<DeleteAssetResponse> {
      const assetName = typeof name === 'string' ? name.trim() : '';
      if (!assetName) {
        throw new Error('invalid_asset_name');
      }
      const response = await request<DeleteAssetResponse>({
        method: 'DELETE',
        path: buildCreatorAssetMutationPath(creatorUsername, assetName),
      });
      if (response.status !== 200) {
        handleApiError(response, 'delete_asset');
      }
      return response.body;
    },

    async downloadAssetFile(
      creatorUsername: string,
      assetName: string,
      revision: string | number,
      options: { role?: string } = {},
    ): Promise<Blob> {
      const creator = typeof creatorUsername === 'string' ? creatorUsername.trim() : '';
      const name = typeof assetName === 'string' ? assetName.trim() : '';
      if (!creator || !name) {
        throw new Error('invalid_asset_key');
      }
      const normalizedRevision = normalizeAssetRevisionInput(revision);
      const params = new URLSearchParams();
      if (typeof options.role === 'string' && options.role.trim().length > 0) {
        params.set('role', options.role.trim());
      }
      const query = params.toString();
      const path = `/assets/${encodeURIComponent(creator)}/${encodeURIComponent(name)}/versions/${encodeURIComponent(normalizedRevision)}/file${query ? `?${query}` : ''}`;
      const base = resolveBaseUrl();
      const headers = new Headers();
      for (const [key, value] of Object.entries(getClientHeaders())) {
        headers.set(key, value);
      }
      const token = await resolveToken();
      if (token) {
        headers.set('authorization', `Bearer ${token}`);
      }
      const response = await fetchImpl(resolveUrl(base, path), {
        method: 'GET',
        headers,
        ...buildBrowserCredentialsInit(includeBrowserCredentials),
      });
      if (!response.ok) {
        const parsed = await parseResponseBody<any>(response);
        handleApiError({ status: response.status, body: parsed, headers: response.headers }, 'download_asset_file');
      }
      return response.blob();
    },

    async downloadAssetSource(
      creatorUsername: string,
      assetName: string,
      revision: string | number,
    ): Promise<{ blob: Blob; metadata: AssetSourceBundleResponse }> {
      const creator = typeof creatorUsername === 'string' ? creatorUsername.trim() : '';
      const name = typeof assetName === 'string' ? assetName.trim() : '';
      if (!creator || !name) {
        throw new Error('invalid_asset_key');
      }
      const normalizedRevision = normalizeAssetRevisionInput(revision);
      const path = `/assets/${encodeURIComponent(creator)}/${encodeURIComponent(name)}/versions/${encodeURIComponent(normalizedRevision)}/source`;
      const base = resolveBaseUrl();
      const headers = new Headers();
      for (const [key, value] of Object.entries(getClientHeaders())) {
        headers.set(key, value);
      }
      const token = await resolveToken();
      if (token) {
        headers.set('authorization', `Bearer ${token}`);
      }
      const response = await fetchImpl(resolveUrl(base, path), {
        method: 'GET',
        headers,
        ...buildBrowserCredentialsInit(includeBrowserCredentials),
      });
      if (!response.ok) {
        const parsed = await parseResponseBody<any>(response);
        handleApiError({ status: response.status, body: parsed, headers: response.headers }, 'download_asset_source');
      }

      const blob = await response.blob();
      const filename = parseContentDispositionFilename(response.headers.get('content-disposition'))
        ?? `${name}-r${normalizedRevision}-source.zip`;
      const headerSize = response.headers.get('content-length');
      const parsedSize = headerSize ? Number.parseInt(headerSize, 10) : Number.NaN;
      const checksumHeader = response.headers.get('x-asset-source-checksum');
      return {
        blob,
        metadata: {
          filename,
          sizeBytes: Number.isFinite(parsedSize) && parsedSize >= 0 ? parsedSize : blob.size,
          checksum: checksumHeader ?? null,
        },
      };
    },
  };
}
