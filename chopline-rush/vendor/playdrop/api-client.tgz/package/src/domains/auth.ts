import type {
  AppleOAuthHandoffExchangeRequest,
  AppleOAuthHandoffExchangeResponse,
  AppleOAuthLinkStartRequest,
  AppleOAuthLinkStartResponse,
  ApiKeyLoginRequest,
  CliApiKeyStatusResponse,
  CliLoginApproveRequest,
  CliLoginApproveResponse,
  CliLoginPollRequest,
  CliLoginPollResponse,
  CliLoginStartResponse,
  CliLoginStatusResponse,
  CompleteXSignupRequest,
  CompleteXSignupResponse,
  CompleteGoogleSignupRequest,
  CompleteGoogleSignupResponse,
  GoogleAppleLinkRequest,
  GoogleAppleLinkResponse,
  GoogleAppleSignInRequest,
  GoogleAppleSignInResponse,
  GoogleOneTapExchangeRequest,
  GoogleOneTapExchangeResponse,
  GooglePendingSignupResponse,
  LoginRequest,
  LoginResponse,
  LogoutResponse,
  RegisterRequest,
  RegisterResponse,
  UnlinkGoogleResponse,
  UnlinkXResponse,
  UsernameAvailableResponse,
  XPendingSignupResponse,
  CreateCliApiKeyResponse,
} from '@playdrop/types';

type ApiResponseLike<T> = {
  status: number;
  body: T;
  headers: Headers;
};

type RequestExecutor = <T>(input: {
  method: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
  path: string;
  body?: unknown;
  headers?: Record<string, string>;
  signal?: AbortSignal;
}) => Promise<ApiResponseLike<T>>;

type ErrorHandler = (response: ApiResponseLike<unknown>, defaultMessage: string) => never;

export function buildAuthApiClientMethods(input: {
  request: RequestExecutor;
  handleApiError: ErrorHandler;
}) {
  const { request, handleApiError } = input;

  return {
    async login(loginRequest: LoginRequest): Promise<LoginResponse> {
      const response = await request<LoginResponse>({
        method: 'POST',
        path: '/auth/login',
        body: loginRequest,
      });

      if (response.status !== 200) {
        handleApiError(response, 'login');
      }

      return response.body;
    },

    async loginWithApiKey(loginRequest: ApiKeyLoginRequest): Promise<LoginResponse> {
      const response = await request<LoginResponse>({
        method: 'POST',
        path: '/auth/api-key/login',
        body: loginRequest,
      });

      if (response.status !== 200) {
        handleApiError(response, 'login_with_api_key');
      }

      return response.body;
    },

    async startCliLogin(): Promise<CliLoginStartResponse> {
      const response = await request<CliLoginStartResponse>({
        method: 'POST',
        path: '/auth/cli/start',
      });

      if (response.status !== 200) {
        handleApiError(response, 'start_cli_login');
      }

      return response.body;
    },

    async pollCliLogin(pollRequest: CliLoginPollRequest): Promise<CliLoginPollResponse> {
      const response = await request<CliLoginPollResponse>({
        method: 'POST',
        path: '/auth/cli/poll',
        body: pollRequest,
      });

      if (response.status !== 200 && response.status !== 202) {
        handleApiError(response, 'poll_cli_login');
      }

      return response.body;
    },

    async fetchCliLoginStatus(requestId: string): Promise<CliLoginStatusResponse> {
      const response = await request<CliLoginStatusResponse>({
        method: 'GET',
        path: `/auth/cli/status/${encodeURIComponent(requestId)}`,
      });

      if (response.status !== 200 && response.status !== 410) {
        handleApiError(response, 'fetch_cli_login_status');
      }

      return response.body;
    },

    async approveCliLogin(approveRequest: CliLoginApproveRequest): Promise<CliLoginApproveResponse> {
      const response = await request<CliLoginApproveResponse>({
        method: 'POST',
        path: '/auth/cli/approve',
        body: approveRequest,
      });

      if (response.status !== 200) {
        handleApiError(response, 'approve_cli_login');
      }

      return response.body;
    },

    async register(registerRequest: RegisterRequest): Promise<RegisterResponse> {
      const response = await request<RegisterResponse>({
        method: 'POST',
        path: '/auth/register',
        body: registerRequest,
      });

      if (response.status !== 201) {
        handleApiError(response, 'register');
      }

      return response.body;
    },

    async logout(): Promise<LogoutResponse> {
      const response = await request<LogoutResponse>({
        method: 'POST',
        path: '/auth/logout',
      });

      if (response.status !== 200) {
        handleApiError(response, 'logout');
      }

      return response.body;
    },

    async unlinkX(): Promise<UnlinkXResponse> {
      const response = await request<UnlinkXResponse>({
        method: 'POST',
        path: '/auth/x/unlink',
      });

      if (response.status !== 200) {
        handleApiError(response, 'unlink_x');
      }

      return response.body;
    },

    async unlinkGoogle(): Promise<UnlinkGoogleResponse> {
      const response = await request<UnlinkGoogleResponse>({
        method: 'POST',
        path: '/auth/google/unlink',
      });

      if (response.status !== 200) {
        handleApiError(response, 'unlink_google');
      }

      return response.body;
    },

    async createAppleOAuthLinkStart(
      startRequest: AppleOAuthLinkStartRequest,
    ): Promise<AppleOAuthLinkStartResponse> {
      const response = await request<AppleOAuthLinkStartResponse>({
        method: 'POST',
        path: '/auth/oauth/apple-link-start',
        body: startRequest,
      });

      if (response.status !== 200) {
        handleApiError(response, 'create_apple_oauth_link_start');
      }

      return response.body;
    },

    async exchangeAppleOAuthHandoff(
      exchangeRequest: AppleOAuthHandoffExchangeRequest,
    ): Promise<AppleOAuthHandoffExchangeResponse> {
      const response = await request<AppleOAuthHandoffExchangeResponse>({
        method: 'POST',
        path: '/auth/oauth/apple-handoff-exchange',
        body: exchangeRequest,
      });

      if (response.status !== 200) {
        handleApiError(response, 'exchange_apple_oauth_handoff');
      }

      return response.body;
    },

    async signInWithGoogleApple(
      signInRequest: GoogleAppleSignInRequest,
    ): Promise<GoogleAppleSignInResponse> {
      const response = await request<GoogleAppleSignInResponse>({
        method: 'POST',
        path: '/auth/google/apple/sign-in',
        body: signInRequest,
      });

      if (response.status !== 200) {
        handleApiError(response, 'sign_in_with_google_apple');
      }

      return response.body;
    },

    async linkGoogleApple(
      linkRequest: GoogleAppleLinkRequest,
    ): Promise<GoogleAppleLinkResponse> {
      const response = await request<GoogleAppleLinkResponse>({
        method: 'POST',
        path: '/auth/google/apple/link',
        body: linkRequest,
      });

      if (response.status !== 200) {
        handleApiError(response, 'link_google_apple');
      }

      return response.body;
    },

    async fetchGooglePendingSignup(token: string): Promise<GooglePendingSignupResponse> {
      const response = await request<GooglePendingSignupResponse>({
        method: 'GET',
        path: `/auth/google/pending/${encodeURIComponent(token)}`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'fetch_google_pending_signup');
      }

      return response.body;
    },

    async checkUsernameAvailable(username: string): Promise<UsernameAvailableResponse> {
      const response = await request<UsernameAvailableResponse>({
        method: 'GET',
        path: `/auth/username-available/${encodeURIComponent(username)}`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'check_username_available');
      }

      return response.body;
    },

    async completeGoogleSignup(signupRequest: CompleteGoogleSignupRequest): Promise<CompleteGoogleSignupResponse> {
      const response = await request<CompleteGoogleSignupResponse>({
        method: 'POST',
        path: '/auth/google/complete-signup',
        body: signupRequest,
      });

      if (response.status !== 201) {
        handleApiError(response, 'complete_google_signup');
      }

      return response.body;
    },

    async fetchXPendingSignup(token: string): Promise<XPendingSignupResponse> {
      const response = await request<XPendingSignupResponse>({
        method: 'GET',
        path: `/auth/x/pending/${encodeURIComponent(token)}`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'fetch_x_pending_signup');
      }

      return response.body;
    },

    async completeXSignup(signupRequest: CompleteXSignupRequest): Promise<CompleteXSignupResponse> {
      const response = await request<CompleteXSignupResponse>({
        method: 'POST',
        path: '/auth/x/complete-signup',
        body: signupRequest,
      });

      if (response.status !== 201) {
        handleApiError(response, 'complete_x_signup');
      }

      return response.body;
    },

    async exchangeGoogleOneTapCredential(
      oneTapRequest: GoogleOneTapExchangeRequest,
    ): Promise<GoogleOneTapExchangeResponse> {
      const response = await request<GoogleOneTapExchangeResponse>({
        method: 'POST',
        path: '/auth/google/one-tap',
        body: oneTapRequest,
      });

      if (response.status !== 200) {
        handleApiError(response, 'exchange_google_one_tap_credential');
      }

      return response.body;
    },

    async fetchCliApiKeyStatus(): Promise<CliApiKeyStatusResponse> {
      const response = await request<CliApiKeyStatusResponse>({
        method: 'GET',
        path: '/me/api-key',
      });

      if (response.status !== 200) {
        handleApiError(response, 'fetch_cli_api_key_status');
      }

      return response.body;
    },

    async createCliApiKey(): Promise<CreateCliApiKeyResponse> {
      const response = await request<CreateCliApiKeyResponse>({
        method: 'POST',
        path: '/me/api-key',
      });

      if (response.status !== 200) {
        handleApiError(response, 'create_cli_api_key');
      }

      return response.body;
    },
  };
}
