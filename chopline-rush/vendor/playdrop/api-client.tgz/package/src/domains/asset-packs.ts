import type {
  AbortAssetPackUploadResponse,
  AssetCategory,
  AssetPackDetailResponse,
  AssetPackListResponse,
  AssetPackSourceBundleResponse,
  AssetPackVersionsListResponse,
  ContentRemixRelationsResponse,
  DeleteAssetPackResponse,
  DeleteAssetPackVersionResponse,
  FinalizeAssetPackUploadResponse,
  InitializeAssetPackUploadRequest,
  InitializeAssetPackUploadResponse,
  UploadAssetPackSessionAssetResponse,
  UploadAssetPackSessionMediaResponse,
  UpdateAssetPackRequest,
  UpdateAssetPackResponse,
  UpdateAssetPackVersionRequest,
  UpdateAssetPackVersionResponse,
} from '@playdrop/types';
import type {
  UploadAssetPackSessionAssetOptions,
  UploadAssetPackSessionMediaOptions,
} from '../client.js';
import { buildBrowserCredentialsInit } from '../core/request.js';

type ApiResponseLike<T> = {
  status: number;
  body: T;
  headers: Headers;
};

type RequestExecutor = <T>(input: {
  method: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
  path: string;
  body?: unknown;
  headers?: Record<string, string>;
  signal?: AbortSignal;
}) => Promise<ApiResponseLike<T>>;

type ErrorHandler = (response: ApiResponseLike<unknown>, defaultMessage: string) => never;

type ParseResponseBody = <T>(response: Response) => Promise<T>;

type AssetPacksApiClientInput = {
  request: RequestExecutor;
  handleApiError: ErrorHandler;
  fetchImpl: typeof fetch;
  includeBrowserCredentials: boolean;
  resolveBaseUrl: () => string;
  resolveUrl: (base: string, path: string) => string;
  parseResponseBody: ParseResponseBody;
  resolveToken: () => Promise<string | null>;
  getClientHeaders: () => Record<string, string>;
  buildCreatorAssetPackMutationPath: (creatorUsername: string, packName?: string, suffix?: string) => string;
  normalizeCreatorItemSlug: (value: string, field: 'creator' | 'name') => string;
  normalizeSemverInput: (version: string) => string;
  parseContentDispositionFilename: (headerValue: string | null) => string | null;
};

function buildPublicAssetPackPath(
  normalizeCreatorItemSlug: (value: string, field: 'creator' | 'name') => string,
  creatorUsername: string,
  packName: string,
  suffix = '',
): string {
  const creator = normalizeCreatorItemSlug(creatorUsername, 'creator');
  const name = normalizeCreatorItemSlug(packName, 'name');
  return `/asset-packs/${encodeURIComponent(creator)}/${encodeURIComponent(name)}${suffix}`;
}

function buildAssetPackVersionPath(
  normalizeCreatorItemSlug: (value: string, field: 'creator' | 'name') => string,
  normalizeSemverInput: (version: string) => string,
  creatorUsername: string,
  packName: string,
  version: string,
  suffix: string,
): string {
  const creator = normalizeCreatorItemSlug(creatorUsername, 'creator');
  const name = normalizeCreatorItemSlug(packName, 'name');
  const normalizedVersion = normalizeSemverInput(version);
  return `/asset-packs/${encodeURIComponent(creator)}/${encodeURIComponent(name)}/versions/${encodeURIComponent(normalizedVersion)}${suffix}`;
}

async function buildAuthorizedHeaders(
  getClientHeaders: () => Record<string, string>,
  resolveToken: () => Promise<string | null>,
): Promise<Headers> {
  const headers = new Headers();
  for (const [key, value] of Object.entries(getClientHeaders())) {
    headers.set(key, value);
  }
  const token = await resolveToken();
  if (token) {
    headers.set('authorization', `Bearer ${token}`);
  }
  return headers;
}

function buildAssetPackSessionAssetUploadForm(options: UploadAssetPackSessionAssetOptions): FormData {
  if (!Array.isArray(options.files) || options.files.length === 0) {
    throw new Error('missing_asset_files');
  }
  const form = new FormData();
  for (const item of options.files) {
    if (!item) {
      throw new Error('missing_asset_upload_file');
    }
    const fieldName = typeof item.fieldName === 'string' && item.fieldName.trim().length > 0
      ? item.fieldName.trim()
      : 'file';
    if (typeof item.filename === 'string' && item.filename.trim().length > 0) {
      form.append(fieldName, item.file, item.filename.trim());
    } else {
      form.append(fieldName, item.file);
    }
  }
  return form;
}

function buildAssetPackSessionMediaUploadForm(options: UploadAssetPackSessionMediaOptions): FormData {
  if (!options?.file) {
    throw new Error('missing_media_file');
  }
  const form = new FormData();
  if (typeof options.filename === 'string' && options.filename.trim().length > 0) {
    form.append('file', options.file, options.filename.trim());
  } else {
    form.append('file', options.file);
  }
  return form;
}

async function fetchAssetPackRelatedRequest(
  request: RequestExecutor,
  handleApiError: ErrorHandler,
  normalizeCreatorItemSlug: (value: string, field: 'creator' | 'name') => string,
  creatorUsername: string,
  packName: string,
): Promise<ContentRemixRelationsResponse> {
  const response = await request<ContentRemixRelationsResponse>({
    method: 'GET',
    path: buildPublicAssetPackPath(normalizeCreatorItemSlug, creatorUsername, packName, '/related'),
  });
  if (response.status !== 200) {
    handleApiError(response, 'get_pack_related');
  }
  return response.body;
}

export function buildAssetPacksApiClientMethods(input: {
  request: RequestExecutor;
  handleApiError: ErrorHandler;
  fetchImpl: typeof fetch;
  includeBrowserCredentials: boolean;
  resolveBaseUrl: () => string;
  resolveUrl: (base: string, path: string) => string;
  parseResponseBody: ParseResponseBody;
  resolveToken: () => Promise<string | null>;
  getClientHeaders: () => Record<string, string>;
  buildCreatorAssetPackMutationPath: (creatorUsername: string, packName?: string, suffix?: string) => string;
  normalizeCreatorItemSlug: (value: string, field: 'creator' | 'name') => string;
  normalizeSemverInput: (version: string) => string;
  parseContentDispositionFilename: (headerValue: string | null) => string | null;
}) {
  return {
    ...buildAssetPackUploadSessionMethods(input),
    ...buildAssetPackReadWriteMethods(input),
  };
}

function buildAssetPackUploadSessionMethods(input: AssetPacksApiClientInput) {
  const {
    request,
    handleApiError,
    fetchImpl,
    includeBrowserCredentials,
    resolveBaseUrl,
    resolveUrl,
    parseResponseBody,
    resolveToken,
    getClientHeaders,
    buildCreatorAssetPackMutationPath,
    normalizeCreatorItemSlug,
  } = input;

  return {
    async initializeAssetPackUpload(
      creatorUsername: string,
      name: string,
      requestBody: InitializeAssetPackUploadRequest,
    ): Promise<InitializeAssetPackUploadResponse> {
      const packName = typeof name === 'string' ? name.trim() : '';
      if (!packName) {
        throw new Error('invalid_pack_name');
      }
      const response = await request<InitializeAssetPackUploadResponse>({
        method: 'POST',
        path: `${buildCreatorAssetPackMutationPath(creatorUsername, packName)}/upload-sessions`,
        body: requestBody,
      });
      if (response.status !== 200 && response.status !== 201) {
        handleApiError(response, 'initialize_asset_pack_upload');
      }
      return response.body;
    },

    async uploadAssetPackSessionAsset(
      creatorUsername: string,
      name: string,
      sessionId: string,
      uploadKey: string,
      options: UploadAssetPackSessionAssetOptions,
    ): Promise<UploadAssetPackSessionAssetResponse> {
      const packName = typeof name === 'string' ? name.trim() : '';
      if (!packName) {
        throw new Error('invalid_pack_name');
      }
      const normalizedSessionId = typeof sessionId === 'string' ? sessionId.trim() : '';
      const normalizedUploadKey = typeof uploadKey === 'string' ? uploadKey.trim() : '';
      if (!normalizedSessionId) {
        throw new Error('invalid_pack_upload_session_id');
      }
      if (!normalizedUploadKey) {
        throw new Error('invalid_pack_upload_asset_key');
      }
      const form = buildAssetPackSessionAssetUploadForm(options);
      const base = resolveBaseUrl();
      const path = `${buildCreatorAssetPackMutationPath(creatorUsername, packName)}/upload-sessions/${encodeURIComponent(normalizedSessionId)}/assets/${encodeURIComponent(normalizedUploadKey)}`;
      const headers = await buildAuthorizedHeaders(getClientHeaders, resolveToken);
      const response = await fetchImpl(resolveUrl(base, path), {
        method: 'POST',
        headers,
        body: form,
        ...buildBrowserCredentialsInit(includeBrowserCredentials),
      });
      const parsed = await parseResponseBody<UploadAssetPackSessionAssetResponse>(response);
      const apiResponse = { status: response.status, body: parsed, headers: response.headers };
      if (response.status !== 200 && response.status !== 201) {
        handleApiError(apiResponse, 'upload_asset_pack_session_asset');
      }
      return parsed;
    },

    async uploadAssetPackSessionMedia(
      creatorUsername: string,
      name: string,
      sessionId: string,
      mediaKey: string,
      options: UploadAssetPackSessionMediaOptions,
    ): Promise<UploadAssetPackSessionMediaResponse> {
      const packName = typeof name === 'string' ? name.trim() : '';
      if (!packName) {
        throw new Error('invalid_pack_name');
      }
      const normalizedSessionId = typeof sessionId === 'string' ? sessionId.trim() : '';
      const normalizedMediaKey = typeof mediaKey === 'string' ? mediaKey.trim() : '';
      if (!normalizedSessionId) {
        throw new Error('invalid_pack_upload_session_id');
      }
      if (!normalizedMediaKey) {
        throw new Error('invalid_pack_upload_media_key');
      }
      const form = buildAssetPackSessionMediaUploadForm(options);
      const base = resolveBaseUrl();
      const path = `${buildCreatorAssetPackMutationPath(creatorUsername, packName)}/upload-sessions/${encodeURIComponent(normalizedSessionId)}/media/${encodeURIComponent(normalizedMediaKey)}`;
      const headers = await buildAuthorizedHeaders(getClientHeaders, resolveToken);
      const response = await fetchImpl(resolveUrl(base, path), {
        method: 'POST',
        headers,
        body: form,
        ...buildBrowserCredentialsInit(includeBrowserCredentials),
      });
      const parsed = await parseResponseBody<UploadAssetPackSessionMediaResponse>(response);
      const apiResponse = { status: response.status, body: parsed, headers: response.headers };
      if (response.status !== 200 && response.status !== 201) {
        handleApiError(apiResponse, 'upload_asset_pack_session_media');
      }
      return parsed;
    },

    async finalizeAssetPackUpload(
      creatorUsername: string,
      name: string,
      sessionId: string,
    ): Promise<FinalizeAssetPackUploadResponse> {
      const packName = typeof name === 'string' ? name.trim() : '';
      if (!packName) {
        throw new Error('invalid_pack_name');
      }
      const normalizedSessionId = typeof sessionId === 'string' ? sessionId.trim() : '';
      if (!normalizedSessionId) {
        throw new Error('invalid_pack_upload_session_id');
      }
      const response = await request<FinalizeAssetPackUploadResponse>({
        method: 'POST',
        path: `${buildCreatorAssetPackMutationPath(creatorUsername, packName)}/upload-sessions/${encodeURIComponent(normalizedSessionId)}/finalize`,
      });
      if (response.status !== 200 && response.status !== 201) {
        handleApiError(response, 'finalize_asset_pack_upload');
      }
      return response.body;
    },

    async abortAssetPackUpload(
      creatorUsername: string,
      name: string,
      sessionId: string,
    ): Promise<AbortAssetPackUploadResponse> {
      const packName = typeof name === 'string' ? name.trim() : '';
      if (!packName) {
        throw new Error('invalid_pack_name');
      }
      const normalizedSessionId = typeof sessionId === 'string' ? sessionId.trim() : '';
      if (!normalizedSessionId) {
        throw new Error('invalid_pack_upload_session_id');
      }
      const response = await request<AbortAssetPackUploadResponse>({
        method: 'POST',
        path: `${buildCreatorAssetPackMutationPath(creatorUsername, packName)}/upload-sessions/${encodeURIComponent(normalizedSessionId)}/abort`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'abort_asset_pack_upload');
      }
      return response.body;
    },

    async fetchAssetPackRelated(
      creatorUsername: string,
      packName: string,
    ): Promise<ContentRemixRelationsResponse> {
      return fetchAssetPackRelatedRequest(request, handleApiError, normalizeCreatorItemSlug, creatorUsername, packName);
    },
  };
}

function buildAssetPackReadWriteMethods(input: AssetPacksApiClientInput) {
  const {
    request,
    handleApiError,
    fetchImpl,
    includeBrowserCredentials,
    resolveBaseUrl,
    resolveUrl,
    parseResponseBody,
    resolveToken,
    getClientHeaders,
    buildCreatorAssetPackMutationPath,
    normalizeCreatorItemSlug,
    normalizeSemverInput,
    parseContentDispositionFilename,
  } = input;

  return {
    async listAssetPacks(
      options: { limit?: number; offset?: number; containsCategory?: AssetCategory; containsSubcategory?: string } = {},
    ): Promise<AssetPackListResponse> {
      const params = new URLSearchParams();
      if (typeof options.limit === 'number') {
        params.set('limit', String(options.limit));
      }
      if (typeof options.offset === 'number') {
        params.set('offset', String(options.offset));
      }
      if (typeof options.containsCategory === 'string' && options.containsCategory.trim().length > 0) {
        params.set('containsCategory', options.containsCategory.trim());
      }
      if (typeof options.containsSubcategory === 'string' && options.containsSubcategory.trim().length > 0) {
        params.set('containsSubcategory', options.containsSubcategory.trim());
      }
      const query = params.toString();
      const path = `/asset-packs${query ? `?${query}` : ''}`;
      const response = await request<AssetPackListResponse>({
        method: 'GET',
        path,
      });
      if (response.status !== 200) {
        handleApiError(response, 'list_asset_packs');
      }
      return response.body;
    },

    async listAssetPacksForCreator(
      creatorUsername: string,
      options: { limit?: number; offset?: number; containsCategory?: AssetCategory; containsSubcategory?: string } = {},
    ): Promise<AssetPackListResponse> {
      const params = new URLSearchParams();
      if (typeof options.limit === 'number') {
        params.set('limit', String(options.limit));
      }
      if (typeof options.offset === 'number') {
        params.set('offset', String(options.offset));
      }
      if (typeof options.containsCategory === 'string' && options.containsCategory.trim().length > 0) {
        params.set('containsCategory', options.containsCategory.trim());
      }
      if (typeof options.containsSubcategory === 'string' && options.containsSubcategory.trim().length > 0) {
        params.set('containsSubcategory', options.containsSubcategory.trim());
      }
      const query = params.toString();
      const path = `/creators/${encodeURIComponent(creatorUsername)}/asset-packs${query ? `?${query}` : ''}`;
      const response = await request<AssetPackListResponse>({
        method: 'GET',
        path,
      });
      if (response.status !== 200) {
        handleApiError(response, 'list_asset_packs_for_creator');
      }
      return response.body;
    },

    async fetchAssetPackBySlug(creatorUsername: string, packName: string): Promise<AssetPackDetailResponse> {
      const path = `/asset-packs/${encodeURIComponent(creatorUsername)}/${encodeURIComponent(packName)}`;
      const response = await request<AssetPackDetailResponse>({
        method: 'GET',
        path,
      });
      if (response.status !== 200) {
        handleApiError(response, 'fetch_asset_pack_by_slug');
      }
      return response.body;
    },

    async downloadAssetPackSource(
      creatorUsername: string,
      packName: string,
      version: string,
    ): Promise<{ blob: Blob; metadata: AssetPackSourceBundleResponse }> {
      const creator = typeof creatorUsername === 'string' ? creatorUsername.trim() : '';
      const name = typeof packName === 'string' ? packName.trim() : '';
      if (!creator || !name) {
        throw new Error('invalid_pack_key');
      }
      const normalizedVersion = normalizeSemverInput(version);
      const path = buildAssetPackVersionPath(
        normalizeCreatorItemSlug,
        normalizeSemverInput,
        creator,
        name,
        normalizedVersion,
        '/source',
      );
      const base = resolveBaseUrl();
      const headers = new Headers();
      for (const [key, value] of Object.entries(getClientHeaders())) {
        headers.set(key, value);
      }
      const token = await resolveToken();
      if (token) {
        headers.set('authorization', `Bearer ${token}`);
      }
      const response = await fetchImpl(resolveUrl(base, path), {
        method: 'GET',
        headers,
        ...buildBrowserCredentialsInit(includeBrowserCredentials),
      });
      if (!response.ok) {
        const parsed = await parseResponseBody<any>(response);
        handleApiError({ status: response.status, body: parsed, headers: response.headers }, 'download_asset_pack_source');
      }

      const blob = await response.blob();
      const filename = parseContentDispositionFilename(response.headers.get('content-disposition'))
        ?? `${name}-${normalizedVersion}-source.zip`;
      const headerSize = response.headers.get('content-length');
      const parsedSize = headerSize ? Number.parseInt(headerSize, 10) : Number.NaN;
      const checksumHeader = response.headers.get('x-pack-source-checksum');
      return {
        blob,
        metadata: {
          filename,
          sizeBytes: Number.isFinite(parsedSize) && parsedSize >= 0 ? parsedSize : blob.size,
          checksum: checksumHeader ?? null,
        },
      };
    },

    async downloadAssetPack(
      creatorUsername: string,
      packName: string,
      version: string,
    ): Promise<{ blob: Blob; metadata: AssetPackSourceBundleResponse }> {
      const creator = typeof creatorUsername === 'string' ? creatorUsername.trim() : '';
      const name = typeof packName === 'string' ? packName.trim() : '';
      if (!creator || !name) {
        throw new Error('invalid_pack_key');
      }
      const normalizedVersion = normalizeSemverInput(version);
      const path = buildAssetPackVersionPath(
        normalizeCreatorItemSlug,
        normalizeSemverInput,
        creator,
        name,
        normalizedVersion,
        '/download',
      );
      const base = resolveBaseUrl();
      const headers = new Headers();
      for (const [key, value] of Object.entries(getClientHeaders())) {
        headers.set(key, value);
      }
      const token = await resolveToken();
      if (token) {
        headers.set('authorization', `Bearer ${token}`);
      }
      const response = await fetchImpl(resolveUrl(base, path), {
        method: 'GET',
        headers,
        ...buildBrowserCredentialsInit(includeBrowserCredentials),
      });
      if (!response.ok) {
        const parsed = await parseResponseBody<any>(response);
        handleApiError({ status: response.status, body: parsed, headers: response.headers }, 'download_asset_pack');
      }

      const blob = await response.blob();
      const filename = parseContentDispositionFilename(response.headers.get('content-disposition'))
        ?? `${name}-${normalizedVersion}.zip`;
      const headerSize = response.headers.get('content-length');
      const parsedSize = headerSize ? Number.parseInt(headerSize, 10) : Number.NaN;
      const checksumHeader = response.headers.get('x-pack-source-checksum');
      return {
        blob,
        metadata: {
          filename,
          sizeBytes: Number.isFinite(parsedSize) && parsedSize >= 0 ? parsedSize : blob.size,
          checksum: checksumHeader ?? null,
        },
      };
    },

    async listAssetPackVersions(
      creatorUsername: string,
      packName: string,
      options: { limit?: number; offset?: number } = {},
    ): Promise<AssetPackVersionsListResponse> {
      const params = new URLSearchParams();
      if (typeof options.limit === 'number') {
        params.set('limit', String(options.limit));
      }
      if (typeof options.offset === 'number') {
        params.set('offset', String(options.offset));
      }
      const query = params.toString();
      const path = `/asset-packs/${encodeURIComponent(creatorUsername)}/${encodeURIComponent(packName)}/versions${query ? `?${query}` : ''}`;
      const response = await request<AssetPackVersionsListResponse>({
        method: 'GET',
        path,
      });
      if (response.status !== 200) {
        handleApiError(response, 'list_asset_pack_versions');
      }
      return response.body;
    },

    async updateAssetPack(
      creatorUsername: string,
      name: string,
      requestBody: UpdateAssetPackRequest,
    ): Promise<UpdateAssetPackResponse> {
      const packName = typeof name === 'string' ? name.trim() : '';
      if (!packName) {
        throw new Error('invalid_pack_name');
      }
      const response = await request<UpdateAssetPackResponse>({
        method: 'PATCH',
        path: buildCreatorAssetPackMutationPath(creatorUsername, packName),
        body: requestBody,
      });
      if (response.status !== 200) {
        handleApiError(response, 'update_asset_pack');
      }
      return response.body;
    },

    async updateAssetPackVersion(
      creatorUsername: string,
      name: string,
      version: string,
      requestBody: UpdateAssetPackVersionRequest,
    ): Promise<UpdateAssetPackVersionResponse> {
      const packName = typeof name === 'string' ? name.trim() : '';
      const versionValue = typeof version === 'string' ? version.trim() : '';
      if (!packName) {
        throw new Error('invalid_pack_name');
      }
      if (!versionValue) {
        throw new Error('invalid_pack_version');
      }
      const response = await request<UpdateAssetPackVersionResponse>({
        method: 'PATCH',
        path: `${buildCreatorAssetPackMutationPath(creatorUsername, packName)}/versions/${encodeURIComponent(versionValue)}`,
        body: requestBody,
      });
      if (response.status !== 200) {
        handleApiError(response, 'update_asset_pack_version');
      }
      return response.body;
    },

    async deleteAssetPackVersion(
      creatorUsername: string,
      name: string,
      version: string,
    ): Promise<DeleteAssetPackVersionResponse> {
      const packName = typeof name === 'string' ? name.trim() : '';
      const versionValue = typeof version === 'string' ? version.trim() : '';
      if (!packName) {
        throw new Error('invalid_pack_name');
      }
      if (!versionValue) {
        throw new Error('invalid_pack_version');
      }
      const response = await request<DeleteAssetPackVersionResponse>({
        method: 'DELETE',
        path: `${buildCreatorAssetPackMutationPath(creatorUsername, packName)}/versions/${encodeURIComponent(versionValue)}`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'delete_asset_pack_version');
      }
      return response.body;
    },

    async deleteAssetPack(
      creatorUsername: string,
      name: string,
    ): Promise<DeleteAssetPackResponse> {
      const packName = typeof name === 'string' ? name.trim() : '';
      if (!packName) {
        throw new Error('invalid_pack_name');
      }
      const response = await request<DeleteAssetPackResponse>({
        method: 'DELETE',
        path: buildCreatorAssetPackMutationPath(creatorUsername, packName),
      });
      if (response.status !== 200) {
        handleApiError(response, 'delete_asset_pack');
      }
      return response.body;
    },
  };
}
