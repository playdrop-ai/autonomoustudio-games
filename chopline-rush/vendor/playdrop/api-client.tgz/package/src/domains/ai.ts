import type { AiGenerationDetailResponse } from '@playdrop/types';

type ApiResponseLike<T> = {
  status: number;
  body: T;
  headers: Headers;
};

type RequestExecutor = <T>(input: {
  method: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
  path: string;
  body?: unknown;
  headers?: Record<string, string>;
  signal?: AbortSignal;
}) => Promise<ApiResponseLike<T>>;

type ErrorHandler = (response: ApiResponseLike<unknown>, defaultMessage: string) => never;

export function buildAiApiClientMethods(input: {
  request: RequestExecutor;
  handleApiError: ErrorHandler;
}) {
  const { request, handleApiError } = input;

  return {
    async fetchAiGeneration(id: string): Promise<AiGenerationDetailResponse> {
      const response = await request<AiGenerationDetailResponse>({
        method: 'GET',
        path: `/ai-generations/${encodeURIComponent(id)}`,
      });
      if (response.status !== 200) {
        handleApiError(response, 'fetch_ai_generation');
      }
      return response.body;
    },
  };
}
