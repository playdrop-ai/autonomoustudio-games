import type {
  AppAccessTokenResponse,
  AppDetailResponse,
  AppLogEntryRequest,
  AppLogEntryResponse,
  AppSourceBundleResponse,
  AppType,
  AppsListResponse,
  AppVersionDetailResponse,
  AppVersionVisibility,
  AppVersionsListResponse,
  CreateAppRequest,
  CreateAppResponse,
  CreateVersionResponse,
  ContentRemixRelationsResponse,
  DeleteAppResponse,
  DeleteVersionResponse,
  RemixScaffoldResponse,
  UpdateAppRequest,
  UpdateAppResponse,
  UpdateVersionResponse,
} from '@playdrop/types';
import type { UploadAppVersionOptions } from '../client.js';
import { buildBrowserCredentialsInit } from '../core/request.js';

type ApiResponseLike<T> = {
  status: number;
  body: T;
  headers: Headers;
};

type RequestExecutor = <T>(input: {
  method: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
  path: string;
  body?: unknown;
  headers?: Record<string, string>;
  signal?: AbortSignal;
}) => Promise<ApiResponseLike<T>>;

type ErrorHandler = (response: ApiResponseLike<unknown>, defaultMessage: string) => never;

type ParseResponseBody = <T>(response: Response) => Promise<T>;

function buildPublicAppPath(
  normalizeCreatorItemSlug: (value: string, field: 'creator' | 'name') => string,
  creatorUsername: string,
  appName: string,
  suffix = '',
): string {
  const creator = normalizeCreatorItemSlug(creatorUsername, 'creator');
  const name = normalizeCreatorItemSlug(appName, 'name');
  return `/apps/${encodeURIComponent(creator)}/${encodeURIComponent(name)}${suffix}`;
}

async function buildAuthorizedHeaders(
  getClientHeaders: () => Record<string, string>,
  resolveToken: () => Promise<string | null>,
): Promise<Headers> {
  const headers = new Headers();
  for (const [key, value] of Object.entries(getClientHeaders())) {
    headers.set(key, value);
  }
  const token = await resolveToken();
  if (token) {
    headers.set('authorization', `Bearer ${token}`);
  }
  return headers;
}

function buildAppVersionUploadForm(options: UploadAppVersionOptions): FormData {
  const form = new FormData();
  form.append('version', options.version);
  if (options.releaseNotes !== undefined) form.append('releaseNotes', options.releaseNotes);
  if (options.visibility !== undefined) form.append('visibility', options.visibility);
  if (options.surfaceTargets && options.surfaceTargets.length > 0) {
    form.append('surfaceTargets', JSON.stringify(options.surfaceTargets));
  }
  appendAppVersionMetadataFields(form, options);
  appendAppVersionMediaFiles(form, options);
  return form;
}

function appendAppVersionMetadataFields(form: FormData, options: UploadAppVersionOptions): void {
  if (options.entryPoint !== undefined) form.append('entryPoint', options.entryPoint);
  if (options.setAsCurrent !== undefined) form.append('setAsCurrent', String(options.setAsCurrent));
  if (options.remixRef !== undefined) form.append('remixRef', options.remixRef);
  if (options.externalUrl !== undefined) form.append('externalUrl', options.externalUrl);
  if (options.displayName !== undefined) form.append('displayName', options.displayName);
  if (options.description !== undefined) form.append('description', options.description);
  if (options.type !== undefined) form.append('type', options.type);
  if (options.emoji !== undefined) form.append('emoji', options.emoji);
  if (options.color !== undefined) form.append('color', options.color);
  if (options.bundle) form.append('bundle', options.bundle);
  if (options.source) form.append('source', options.source);
  if (options.ecs) form.append('ecs', options.ecs);
  if (options.server) form.append('server', options.server);
}

function appendAppVersionMediaFiles(form: FormData, options: UploadAppVersionOptions): void {
  if (options.icon) form.append('icon', options.icon);
  if (options.heroPortrait) form.append('heroPortrait', options.heroPortrait);
  if (options.heroLandscape) form.append('heroLandscape', options.heroLandscape);
  options.screenshotsPortrait?.forEach((screenshot) => form.append('screenshotsPortrait', screenshot));
  options.screenshotsLandscape?.forEach((screenshot) => form.append('screenshotsLandscape', screenshot));
  options.videosPortrait?.forEach((video) => form.append('videosPortrait', video));
  options.videosLandscape?.forEach((video) => form.append('videosLandscape', video));
}

async function fetchAppsByCreatorRequest(
  request: RequestExecutor,
  handleApiError: ErrorHandler,
  creatorUsername: string,
  options: { limit?: number; offset?: number; type?: AppType } = {},
): Promise<AppsListResponse> {
  const normalizedCreator = creatorUsername.trim();
  const params = new URLSearchParams();
  if (typeof options.limit === 'number' && Number.isFinite(options.limit)) {
    params.set('limit', String(options.limit));
  }
  if (typeof options.offset === 'number' && Number.isFinite(options.offset)) {
    params.set('offset', String(options.offset));
  }
  if (typeof options.type === 'string' && options.type.trim().length > 0) {
    params.set('type', options.type.trim());
  }
  const query = params.toString();
  const response = await request<AppsListResponse>({
    method: 'GET',
    path: `/creators/${encodeURIComponent(normalizedCreator)}/apps` + (query ? `?${query}` : ''),
  });
  if (response.status !== 200) {
    handleApiError(response, 'fetch_apps_by_creator');
  }
  return response.body;
}

async function uploadAppVersionRequest(
  input: {
    fetchImpl: typeof fetch;
    includeBrowserCredentials: boolean;
    resolveBaseUrl: () => string;
    resolveUrl: (base: string, path: string) => string;
    parseResponseBody: ParseResponseBody;
    resolveToken: () => Promise<string | null>;
    getClientHeaders: () => Record<string, string>;
    buildCreatorAppMutationPath: (creatorUsername: string, name?: string) => string;
    handleApiError: ErrorHandler;
  },
  creatorUsername: string,
  appName: string,
  options: UploadAppVersionOptions,
): Promise<CreateVersionResponse> {
  const form = buildAppVersionUploadForm(options);
  const base = input.resolveBaseUrl();
  const path = `${input.buildCreatorAppMutationPath(creatorUsername, appName)}/versions`;
  const headers = await buildAuthorizedHeaders(input.getClientHeaders, input.resolveToken);
  const response = await input.fetchImpl(input.resolveUrl(base, path), {
    method: 'POST',
    headers,
    body: form,
    ...buildBrowserCredentialsInit(input.includeBrowserCredentials),
  });
  const parsed = await input.parseResponseBody<CreateVersionResponse>(response);
  const apiResponse = { status: response.status, body: parsed, headers: response.headers };
  if (response.status !== 201) {
    input.handleApiError(apiResponse, 'upload_app_version');
  }
  return parsed;
}

export function buildAppsApiClientMethods(input: {
  request: RequestExecutor;
  handleApiError: ErrorHandler;
  fetchImpl: typeof fetch;
  includeBrowserCredentials: boolean;
  resolveBaseUrl: () => string;
  resolveUrl: (base: string, path: string) => string;
  parseResponseBody: ParseResponseBody;
  resolveToken: () => Promise<string | null>;
  getClientHeaders: () => Record<string, string>;
  buildCreatorAppMutationPath: (creatorUsername: string, name?: string) => string;
  normalizeCreatorItemSlug: (value: string, field: 'creator' | 'name') => string;
  normalizeSemverInput: (version: string) => string;
  parseContentDispositionFilename: (headerValue: string | null) => string | null;
}) {
  const {
    request,
    handleApiError,
    fetchImpl,
    includeBrowserCredentials,
    resolveBaseUrl,
    resolveUrl,
    parseResponseBody,
    resolveToken,
    getClientHeaders,
    buildCreatorAppMutationPath,
    normalizeCreatorItemSlug,
    normalizeSemverInput,
    parseContentDispositionFilename,
  } = input;

  return {
    async fetchApps(options: { limit?: number; offset?: number } = {}): Promise<AppsListResponse> {
      const params = new URLSearchParams();
      if (typeof options.limit === 'number' && Number.isFinite(options.limit)) {
        params.set('limit', String(options.limit));
      }
      if (typeof options.offset === 'number' && Number.isFinite(options.offset)) {
        params.set('offset', String(options.offset));
      }
      const query = params.toString();
      const response = await request<AppsListResponse>({
        method: 'GET',
        path: '/apps' + (query ? `?${query}` : ''),
      });

      if (response.status !== 200) {
        handleApiError(response, 'fetch_apps');
      }

      return response.body;
    },

    async fetchAppsByType(type: AppType, options: { limit?: number; offset?: number } = {}): Promise<AppsListResponse> {
      const params = new URLSearchParams();
      if (typeof options.limit === 'number' && Number.isFinite(options.limit)) {
        params.set('limit', String(options.limit));
      }
      if (typeof options.offset === 'number' && Number.isFinite(options.offset)) {
        params.set('offset', String(options.offset));
      }
      const query = params.toString();
      const response = await request<AppsListResponse>({
        method: 'GET',
        path: `/apps/types/${encodeURIComponent(type)}` + (query ? `?${query}` : ''),
      });

      if (response.status !== 200) {
        handleApiError(response, 'fetch_apps_by_type');
      }

      return response.body;
    },

    async fetchAppsByCreator(
      creatorUsername: string,
      options: { limit?: number; offset?: number; type?: AppType } = {},
    ): Promise<AppsListResponse> {
      return fetchAppsByCreatorRequest(request, handleApiError, creatorUsername, options);
    },

    async fetchAppBySlug(creatorUsername: string, appName: string): Promise<AppDetailResponse> {
      const response = await request<AppDetailResponse>({
        method: 'GET',
        path: `/apps/${encodeURIComponent(creatorUsername)}/${encodeURIComponent(appName)}`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'fetch_app');
      }

      return response.body;
    },

    async requestAppAccessToken(appId: number): Promise<AppAccessTokenResponse> {
      const response = await request<AppAccessTokenResponse>({
        method: 'POST',
        path: `/apps/${encodeURIComponent(String(appId))}/token`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'request_app_access_token');
      }

      return response.body;
    },

    async sendAppLog(appId: number, entry: AppLogEntryRequest): Promise<AppLogEntryResponse> {
      const response = await request<AppLogEntryResponse>({
        method: 'POST',
        path: `/apps/${encodeURIComponent(String(appId))}/logs`,
        body: entry,
      });

      if (response.status !== 200) {
        handleApiError(response, 'send_app_log');
      }

      return response.body;
    },

    async createApp(creatorUsername: string, createRequest: CreateAppRequest): Promise<CreateAppResponse> {
      const response = await request<CreateAppResponse>({
        method: 'POST',
        path: buildCreatorAppMutationPath(creatorUsername),
        body: createRequest,
      });

      if (response.status !== 200) {
        handleApiError(response, 'create_app');
      }

      return response.body;
    },

    async updateApp(
      creatorUsername: string,
      name: string,
      updateRequest: UpdateAppRequest,
    ): Promise<UpdateAppResponse> {
      const response = await request<UpdateAppResponse>({
        method: 'PATCH',
        path: buildCreatorAppMutationPath(creatorUsername, name),
        body: updateRequest,
      });

      if (response.status !== 200) {
        handleApiError(response, 'update_app');
      }

      return response.body;
    },

    async uploadAppVersion(
      creatorUsername: string,
      appName: string,
      options: UploadAppVersionOptions,
    ): Promise<CreateVersionResponse> {
      return uploadAppVersionRequest(
        {
          fetchImpl,
          includeBrowserCredentials,
          resolveBaseUrl,
          resolveUrl,
          parseResponseBody,
          resolveToken,
          getClientHeaders,
          buildCreatorAppMutationPath,
          handleApiError,
        },
        creatorUsername,
        appName,
        options,
      );
    },

    async fetchAppRelated(
      creatorUsername: string,
      appName: string,
    ): Promise<ContentRemixRelationsResponse> {
      const response = await request<ContentRemixRelationsResponse>({
        method: 'GET',
        path: buildPublicAppPath(normalizeCreatorItemSlug, creatorUsername, appName, '/related'),
      });
      if (response.status !== 200) {
        handleApiError(response, 'get_app_related');
      }
      return response.body;
    },

    async listAppVersions(
      creatorUsername: string,
      appName: string,
    ): Promise<AppVersionsListResponse> {
      const path = `/apps/${encodeURIComponent(creatorUsername)}/${encodeURIComponent(appName)}/versions`;
      const response = await request<AppVersionsListResponse>({
        method: 'GET',
        path,
      });

      if (response.status !== 200) {
        handleApiError(response, 'list_app_versions');
      }

      return response.body;
    },

    async getAppVersion(
      creatorUsername: string,
      appName: string,
      version: string,
    ): Promise<AppVersionDetailResponse> {
      const normalizedVersion = normalizeSemverInput(version);
      const path = `/apps/${encodeURIComponent(creatorUsername)}/${encodeURIComponent(appName)}/versions/${encodeURIComponent(normalizedVersion)}`;
      const response = await request<AppVersionDetailResponse>({
        method: 'GET',
        path,
      });

      if (response.status !== 200) {
        handleApiError(response, 'get_app_version');
      }

      return response.body;
    },

    async downloadAppSource(
      creatorUsername: string,
      appName: string,
      version: string,
    ): Promise<{ blob: Blob; metadata: AppSourceBundleResponse }> {
      const creator = normalizeCreatorItemSlug(creatorUsername, 'creator');
      const name = normalizeCreatorItemSlug(appName, 'name');
      const normalizedVersion = normalizeSemverInput(version);
      const path = `/apps/${encodeURIComponent(creator)}/${encodeURIComponent(name)}/versions/${encodeURIComponent(normalizedVersion)}/source`;
      const base = resolveBaseUrl();
      const headers = new Headers();
      for (const [key, value] of Object.entries(getClientHeaders())) {
        headers.set(key, value);
      }
      const token = await resolveToken();
      if (token) {
        headers.set('authorization', `Bearer ${token}`);
      }
      const response = await fetchImpl(resolveUrl(base, path), {
        method: 'GET',
        headers,
        ...buildBrowserCredentialsInit(includeBrowserCredentials),
      });
      if (!response.ok) {
        const parsed = await parseResponseBody<any>(response);
        handleApiError({ status: response.status, body: parsed, headers: response.headers }, 'download_app_source');
      }

      const blob = await response.blob();
      const filename = parseContentDispositionFilename(response.headers.get('content-disposition'))
        ?? `${name}-${normalizedVersion}-source.zip`;
      const headerSize = response.headers.get('content-length');
      const parsedSize = headerSize ? Number.parseInt(headerSize, 10) : Number.NaN;
      const checksumHeader = response.headers.get('x-app-source-checksum');
      return {
        blob,
        metadata: {
          filename,
          sizeBytes: Number.isFinite(parsedSize) && parsedSize >= 0 ? parsedSize : blob.size,
          checksum: checksumHeader ?? null,
        },
      };
    },

    async updateAppVersion(
      creatorUsername: string,
      appName: string,
      version: string,
      updates: { releaseNotes?: string | null; visibility?: AppVersionVisibility; setAsCurrent?: boolean },
    ): Promise<UpdateVersionResponse> {
      const path = `${buildCreatorAppMutationPath(creatorUsername, appName)}/versions/${encodeURIComponent(version)}`;
      const response = await request<UpdateVersionResponse>({
        method: 'PATCH',
        path,
        body: updates,
      });

      if (response.status !== 200) {
        handleApiError(response, 'update_app_version');
      }

      return response.body;
    },

    async deleteAppVersion(
      creatorUsername: string,
      appName: string,
      version: string,
    ): Promise<DeleteVersionResponse> {
      const path = `${buildCreatorAppMutationPath(creatorUsername, appName)}/versions/${encodeURIComponent(version)}`;
      const response = await request<DeleteVersionResponse>({
        method: 'DELETE',
        path,
      });

      if (response.status !== 200) {
        handleApiError(response, 'delete_app_version');
      }

      return response.body;
    },

    async deleteApp(creatorUsername: string, name: string): Promise<DeleteAppResponse> {
      const response = await request<DeleteAppResponse>({
        method: 'DELETE',
        path: buildCreatorAppMutationPath(creatorUsername, name),
      });

      if (response.status !== 200) {
        handleApiError(response, 'delete_app');
      }

      return response.body;
    },

    async fetchRemixScaffold(creatorUsername: string, appName: string, version?: string): Promise<RemixScaffoldResponse> {
      const params = new URLSearchParams();
      if (typeof version === 'string' && version.trim().length > 0) {
        params.set('version', version.trim());
      }
      const response = await request<RemixScaffoldResponse>({
        method: 'GET',
        path: `${buildPublicAppPath(normalizeCreatorItemSlug, creatorUsername, appName)}/remix${params.size > 0 ? `?${params.toString()}` : ''}`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'fetch_remix_scaffold');
      }

      return response.body;
    },
  };
}
