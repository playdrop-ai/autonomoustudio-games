import type {
  AppleOAuthHandoffExchangeRequest,
  AppleOAuthHandoffExchangeResponse,
  AppleOAuthLinkStartRequest,
  AppleOAuthLinkStartResponse,
  ApplePushDeviceRequest,
  ApplePushDeviceStatusResponse,
  ApiKeyLoginRequest,
  CliApiKeyStatusResponse,
  CliLoginApproveRequest,
  CliLoginApproveResponse,
  CliLoginPollRequest,
  CliLoginPollResponse,
  CliLoginStartResponse,
  CliLoginStatusResponse,
  CompleteXSignupRequest,
  CompleteXSignupResponse,
  DeleteMyAccountRequest,
  DeleteMyAccountResponse,
  LoginRequest,
  LoginResponse,
  LogoutResponse,
  PrivacyExportResponse,
  RegisterRequest,
  RegisterResponse,
  CreateAppRequest,
  CreateAppResponse,
  UpdateAppRequest,
  AdminUpdateAppRequest,
  UpdateAppResponse,
  AppsListResponse,
  AppDetailResponse,
  MyAppsResponse,
  BootstrapResponse,
  SetProfileAssetRequest,
  SetProfileAssetResponse,
  MeResponse,
  UserDetailResponse,
  UsersListResponse,
  CreateUserRequest,
  CreateUserResponse,
  UpdateAdminUserRequest,
  RemixScaffoldResponse,
  TemplateScaffoldResponse,
  HomeResponse,
  FetchHomeOptions,
  DeleteAppResponse,
  AppType,
  AppAccessTokenResponse,
  AppLogEntryRequest,
  AppLogEntryResponse,
  SubmitFeedbackRequest,
  SubmitFeedbackResponse,
  FeedbackListResponse,
  DeleteFeedbackResponse,
  ShopResponse,
  AssetPurchaseRequest,
  CreditPackCheckoutSessionRequest,
  PurchaseResponse,
  CreditPackCheckoutSessionResponse,
  CreditPackCheckoutStatusResponse,
  TransactionsResponse,
  CreditPacksResponse,
  CreditPackResponse,
  PaymentProvider,
  PaymentStatus,
  AdminPaymentsListResponse,
  AdminPaymentDetailResponse,
  AdminRefundPaymentRequest,
  IapPurchaseRequest,
  IapPurchaseResponse,
  IapReceiptsResponse,
  IapReceiptListParams,
  IapReceiptResponse,
  AdminCreditTransactionsResponse,
  AiGenerationsResponse,
  AiGenerationDetailResponse,
  OwnedProfileAssetsResponse,
  SavedItemKind,
  LikedItemMutationResponse,
  SavedItemMutationResponse,
  LibraryCategory,
  LibrarySort,
  LibraryResponse,
  EngagementEventType,
  EngagementTargetKind,
  TrackEngagementEventRequest,
  TrackEngagementEventResponse,
  CreatorFollowMutationResponse,
  ContentCommentsResponse,
  CreateContentCommentRequest,
  CreateContentCommentResponse,
  FollowingSort,
  FollowingCreatorsResponse,
  FollowingFeedSection,
  FollowingFeedResponse,
  DeleteContentCommentResponse,
  NotificationStatus,
  NotificationsResponse,
  NotificationReadResponse,
  PushSubscriptionMutationResponse,
  AdminUserResponse,
  DeleteAdminUserResponse,
  BatchCreateUsersResponse,
  UpsertWebPushSubscriptionRequest,
  UpdateProfileRequest,
  UpdateProfileResponse,
  WebPushConfigResponse,
  WebPushSubscriptionStatusResponse,
  ChangePasswordRequest,
  ChangePasswordResponse,
  UpgradeToCreatorResponse,
  UnlinkXResponse,
  UnlinkGoogleResponse,
  GooglePendingSignupResponse,
  XPendingSignupResponse,
  GoogleOneTapExchangeRequest,
  GoogleOneTapExchangeResponse,
  UsernameAvailableResponse,
  CompleteGoogleSignupRequest,
  CompleteGoogleSignupResponse,
  GoogleAppleLinkRequest,
  GoogleAppleLinkResponse,
  GoogleAppleSignInRequest,
  GoogleAppleSignInResponse,
  CreateCliApiKeyResponse,
  AppVersionVisibility,
  AppVersionsListResponse,
  AppVersionDetailResponse,
  AppSourceBundleResponse,
  CreateVersionResponse,
  UpdateVersionResponse,
  DeleteVersionResponse,
  AppSurface,
  AdminAppsListResponse,
  AdminUpdateAppResponse,
  AssetBrowseKind,
  AssetCategory,
  AssetFormat,
  AssetVisibility,
  AssetSourceKind,
  AssetResponse,
  AssetListResponse,
  AssetCategoriesResponse,
  AssetVersionResponse,
  AssetDetailResponse,
  AssetVersionsListResponse,
  CreateAssetVersionResponse,
  UpdateAssetRequest,
  UpdateAssetResponse,
  UpdateAssetVersionRequest,
  UpdateAssetVersionResponse,
  DeleteAssetVersionResponse,
  DeleteAssetResponse,
  AssetSourceBundleResponse,
  AssetPackResponse,
  AssetPackSourceBundleResponse,
  AssetPackListResponse,
  AssetPackVersionResponse,
  AssetPackDetailResponse,
  AssetPackVersionsListResponse,
  InitializeAssetPackUploadRequest,
  InitializeAssetPackUploadResponse,
  UploadAssetPackSessionAssetResponse,
  UploadAssetPackSessionMediaResponse,
  FinalizeAssetPackUploadResponse,
  AbortAssetPackUploadResponse,
  UpdateAssetPackRequest,
  UpdateAssetPackResponse,
  UpdateAssetPackVersionRequest,
  UpdateAssetPackVersionResponse,
  DeleteAssetPackVersionResponse,
  DeleteAssetPackResponse,
  BatchUpsertNodeRelationsRequest,
  BatchUpsertNodeRelationsResponse,
  ContentRemixRelationsResponse,
  SearchRequest,
  SearchResponse,
  SearchSuggestRequest,
  SearchSuggestResponse,
  SearchAssetType,
  SearchKind,
  SearchMode,
} from '@playdrop/types';
import {
  FOLLOWING_FEED_SECTION_VALUES,
  FOLLOWING_SORT_VALUES,
  ENGAGEMENT_EVENT_TYPE_VALUES,
  ENGAGEMENT_TARGET_KIND_VALUES,
  LIBRARY_CATEGORY_VALUES,
  LIBRARY_SORT_VALUES,
  NOTIFICATION_STATUS_VALUES,
  SAVED_ITEM_KIND_VALUES,
  SEARCH_ASSET_TYPE_VALUES,
  SEARCH_KIND_VALUES,
  SEARCH_MODE_VALUES,
} from '@playdrop/types';
import { buildMeApiClientMethods } from './domains/me.js';
import { buildSearchApiClientMethods } from './domains/search.js';
import { buildAppsApiClientMethods } from './domains/apps.js';
import { buildAssetsApiClientMethods } from './domains/assets.js';
import { buildAssetPacksApiClientMethods } from './domains/asset-packs.js';
import { buildAuthApiClientMethods } from './domains/auth.js';
import { buildCommentsApiClientMethods } from './domains/comments.js';
import { buildPaymentsApiClientMethods } from './domains/payments.js';
import { buildAdminApiClientMethods } from './domains/admin.js';
import { buildAiApiClientMethods } from './domains/ai.js';
import {
  createBaseUrlResolver,
  createRequestExecutor,
  parseResponseBody,
  resolveRequestTimeoutMs,
  resolveUrl,
} from './core/request.js';
import { handleApiError } from './core/errors.js';

export interface HttpMethod {
  GET: 'GET';
  POST: 'POST';
  PUT: 'PUT';
  PATCH: 'PATCH';
  DELETE: 'DELETE';
}

export interface ApiRequest {
  method: keyof HttpMethod;
  path: string;
  body?: unknown;
  headers?: Record<string, string>;
}

export interface ApiResponse<T = unknown> {
  status: number;
  body: T;
  headers: Headers;
}

export interface ApiClientConfig {
  baseUrl?: string;
  tokenProvider?: () => string | null | Promise<string | null>;
  fetchImpl?: typeof fetch;
  clientHeaders?: () => Record<string, string>;
  requestTimeoutMs?: number;
  includeBrowserCredentials?: boolean;
}

/**
 * Options for uploading a new app version.
 *
 * @remarks
 * **Content-Type requirements for listing assets:**
 * - Image assets (icon, hero, screenshots) must have `type: 'image/png'`
 * - Video assets must have `type: 'video/mp4'`
 *
 * When using `File` objects from file inputs, the browser sets the type automatically.
 * When using `Blob`, you must explicitly set the type:
 * ```ts
 * const icon = new Blob([pngData], { type: 'image/png' });
 * const video = new Blob([mp4Data], { type: 'video/mp4' });
 * ```
 */
export interface UploadAppVersionOptions {
  /** Version string in semver format (e.g., "1.0.0") */
  version: string;
  /** Release notes for this version */
  releaseNotes?: string;
  /** Visibility: PUBLIC or PRIVATE (default: PUBLIC) */
  visibility?: AppVersionVisibility;
  /** Surface targets for this version */
  surfaceTargets?: AppSurface[];
  /** Entry point file within the bundle (default: "index.html") */
  entryPoint?: string;
  /** Set this version as the current version (default: true for PUBLIC) */
  setAsCurrent?: boolean;
  /** Canonical version ref this version remixes */
  remixRef?: string;
  // App metadata (used when creating app if it doesn't exist)
  /** Display name for the app */
  displayName?: string;
  /** Description of the app */
  description?: string;
  /** App type: GAME, DEMO, TOOL, TEMPLATE */
  type?: AppType;
  /** Emoji for the app card */
  emoji?: string;
  /** Background color for the app card (hex) */
  color?: string;
  // For hosted mode
  /** Bundle zip file containing the app files */
  bundle?: File | Blob;
  /** Source archive for remix functionality */
  source?: File | Blob;
  /** ECS definition file */
  ecs?: File | Blob;
  /** Server-side game code */
  server?: File | Blob;
  // For external mode
  /** External URL for EXTERNAL hosting mode (must be https) */
  externalUrl?: string;
  // Listing assets - IMPORTANT: Must have correct Content-Type
  /** App icon (must be image/png) */
  icon?: File | Blob;
  /** Hero image portrait (must be image/png) */
  heroPortrait?: File | Blob;
  /** Hero image landscape (must be image/png) */
  heroLandscape?: File | Blob;
  /** Screenshot images portrait (must be image/png) */
  screenshotsPortrait?: (File | Blob)[];
  /** Screenshot images landscape (must be image/png) */
  screenshotsLandscape?: (File | Blob)[];
  /** Video previews portrait (must be video/mp4) */
  videosPortrait?: (File | Blob)[];
  /** Video previews landscape (must be video/mp4) */
  videosLandscape?: (File | Blob)[];
}

export interface UploadAssetVersionOptions {
  category: AssetCategory;
  subcategory: string;
  format: AssetFormat;
  visibility?: AssetVisibility;
  sourceKind?: AssetSourceKind;
  sourceAppVersionId?: number;
  sourceGenerationId?: string;
  remixRef?: string;
  shopListed?: boolean;
  shopPriceCredits?: number;
  displayName?: string;
  description?: string;
  files: Array<{
    file: File | Blob;
    fieldName?: string;
    filename?: string;
  }>;
}

export interface UploadAssetPackSessionAssetOptions {
  files: Array<{
    file: File | Blob;
    fieldName?: string;
    filename?: string;
  }>;
}

export interface UploadAssetPackSessionMediaOptions {
  file: File | Blob;
  filename?: string;
}

export interface ApiClient {
  // Core methods
  request<T = unknown>(request: ApiRequest): Promise<ApiResponse<T>>;

  // Authentication
  login(request: LoginRequest): Promise<LoginResponse>;
  loginWithApiKey(request: ApiKeyLoginRequest): Promise<LoginResponse>;
  startCliLogin(): Promise<CliLoginStartResponse>;
  pollCliLogin(request: CliLoginPollRequest): Promise<CliLoginPollResponse>;
  fetchCliLoginStatus(requestId: string): Promise<CliLoginStatusResponse>;
  approveCliLogin(request: CliLoginApproveRequest): Promise<CliLoginApproveResponse>;
  register(request: RegisterRequest): Promise<RegisterResponse>;
  logout(): Promise<LogoutResponse>;
  me(): Promise<MeResponse>;
  updateProfile(request: UpdateProfileRequest): Promise<UpdateProfileResponse>;
  changePassword(request: ChangePasswordRequest): Promise<ChangePasswordResponse>;
  exportPrivacyData(): Promise<PrivacyExportResponse>;
  deleteAccount(request: DeleteMyAccountRequest): Promise<DeleteMyAccountResponse>;
  upgradeToCreator(): Promise<UpgradeToCreatorResponse>;
  unlinkX(): Promise<UnlinkXResponse>;
  unlinkGoogle(): Promise<UnlinkGoogleResponse>;
  createAppleOAuthLinkStart(request: AppleOAuthLinkStartRequest): Promise<AppleOAuthLinkStartResponse>;
  exchangeAppleOAuthHandoff(request: AppleOAuthHandoffExchangeRequest): Promise<AppleOAuthHandoffExchangeResponse>;
  signInWithGoogleApple(request: GoogleAppleSignInRequest): Promise<GoogleAppleSignInResponse>;
  linkGoogleApple(request: GoogleAppleLinkRequest): Promise<GoogleAppleLinkResponse>;
  fetchGooglePendingSignup(token: string): Promise<GooglePendingSignupResponse>;
  fetchXPendingSignup(token: string): Promise<XPendingSignupResponse>;
  checkUsernameAvailable(username: string): Promise<UsernameAvailableResponse>;
  completeGoogleSignup(request: CompleteGoogleSignupRequest): Promise<CompleteGoogleSignupResponse>;
  completeXSignup(request: CompleteXSignupRequest): Promise<CompleteXSignupResponse>;
  exchangeGoogleOneTapCredential(request: GoogleOneTapExchangeRequest): Promise<GoogleOneTapExchangeResponse>;
  fetchCliApiKeyStatus(): Promise<CliApiKeyStatusResponse>;
  createCliApiKey(): Promise<CreateCliApiKeyResponse>;
  fetchUserById(userId: number): Promise<UserDetailResponse>;
  fetchUserByUsername(username: string): Promise<UserDetailResponse>;
  fetchOwnedProfileAssets(): Promise<OwnedProfileAssetsResponse>;
  saveItem(kind: SavedItemKind, creatorUsername: string, itemName: string): Promise<SavedItemMutationResponse>;
  unsaveItem(kind: SavedItemKind, creatorUsername: string, itemName: string): Promise<SavedItemMutationResponse>;
  likeItem(kind: SavedItemKind, creatorUsername: string, itemName: string): Promise<LikedItemMutationResponse>;
  unlikeItem(kind: SavedItemKind, creatorUsername: string, itemName: string): Promise<LikedItemMutationResponse>;
  fetchContentComments(kind: SavedItemKind, creatorUsername: string, itemName: string): Promise<ContentCommentsResponse>;
  fetchAppRelated(creatorUsername: string, appName: string): Promise<ContentRemixRelationsResponse>;
  fetchAssetRelated(creatorUsername: string, assetName: string): Promise<ContentRemixRelationsResponse>;
  fetchAssetPackRelated(creatorUsername: string, packName: string): Promise<ContentRemixRelationsResponse>;
  createContentComment(
    kind: SavedItemKind,
    creatorUsername: string,
    itemName: string,
    request: CreateContentCommentRequest,
  ): Promise<CreateContentCommentResponse>;
  likeContentComment(commentId: number): Promise<LikedItemMutationResponse>;
  unlikeContentComment(commentId: number): Promise<LikedItemMutationResponse>;
  deleteContentComment(commentId: number): Promise<DeleteContentCommentResponse>;
  trackEngagementEvent(request: TrackEngagementEventRequest): Promise<TrackEngagementEventResponse>;
  fetchLibrary(options?: { category?: LibraryCategory; sort?: LibrarySort }): Promise<LibraryResponse>;
  followCreator(creatorUsername: string): Promise<CreatorFollowMutationResponse>;
  unfollowCreator(creatorUsername: string): Promise<CreatorFollowMutationResponse>;
  fetchFollowingCreators(options?: { sort?: FollowingSort }): Promise<FollowingCreatorsResponse>;
  fetchFollowingFeed(options: { section: FollowingFeedSection; limit?: number }): Promise<FollowingFeedResponse>;
  fetchNotifications(options?: { status?: NotificationStatus; limit?: number; offset?: number }): Promise<NotificationsResponse>;
  markNotificationRead(notificationId: number): Promise<NotificationReadResponse>;
  markAllNotificationsRead(): Promise<NotificationReadResponse>;
  fetchWebPushConfig(): Promise<WebPushConfigResponse>;
  fetchWebPushSubscriptionStatus(request: UpsertWebPushSubscriptionRequest): Promise<WebPushSubscriptionStatusResponse>;
  upsertWebPushSubscription(request: UpsertWebPushSubscriptionRequest): Promise<PushSubscriptionMutationResponse>;
  deleteWebPushSubscription(request: UpsertWebPushSubscriptionRequest): Promise<PushSubscriptionMutationResponse>;
  fetchApplePushDeviceStatus(request: ApplePushDeviceRequest): Promise<ApplePushDeviceStatusResponse>;
  upsertApplePushDevice(request: ApplePushDeviceRequest): Promise<PushSubscriptionMutationResponse>;
  deleteApplePushDevice(request: ApplePushDeviceRequest): Promise<PushSubscriptionMutationResponse>;
  search(request: SearchRequest): Promise<SearchResponse>;
  suggestSearch(request: SearchSuggestRequest): Promise<SearchSuggestResponse>;

  // Apps
  fetchApps(options?: { limit?: number; offset?: number }): Promise<AppsListResponse>;
  fetchAppsByType(type: AppType, options?: { limit?: number; offset?: number }): Promise<AppsListResponse>;
  fetchAppsByCreator(creatorUsername: string, options?: { limit?: number; offset?: number; type?: AppType }): Promise<AppsListResponse>;
  fetchAppBySlug(creatorUsername: string, appName: string): Promise<AppDetailResponse>;
  requestAppAccessToken(appId: number): Promise<AppAccessTokenResponse>;
  sendAppLog(appId: number, entry: AppLogEntryRequest): Promise<AppLogEntryResponse>;
  fetchMyApps(options?: { limit?: number; offset?: number; type?: AppType }): Promise<MyAppsResponse>;
  createApp(creatorUsername: string, request: CreateAppRequest): Promise<CreateAppResponse>;
  updateApp(creatorUsername: string, name: string, request: UpdateAppRequest): Promise<UpdateAppResponse>;
  createAssetVersion(
    creatorUsername: string,
    name: string,
    options: UploadAssetVersionOptions,
  ): Promise<CreateAssetVersionResponse>;
  listAssetCategories(): Promise<AssetCategoriesResponse>;
  listAssets(options?: { limit?: number; offset?: number; category?: AssetCategory; subcategory?: string; kind?: AssetBrowseKind }): Promise<AssetListResponse>;
  listAssetsForCreator(
    creatorUsername: string,
    options?: { limit?: number; offset?: number; category?: AssetCategory; subcategory?: string; kind?: AssetBrowseKind }
  ): Promise<AssetListResponse>;
  fetchAssetBySlug(creatorUsername: string, assetName: string): Promise<AssetDetailResponse>;
  listAssetVersions(
    creatorUsername: string,
    assetName: string,
    options?: { limit?: number; offset?: number }
  ): Promise<AssetVersionsListResponse>;
  updateAsset(creatorUsername: string, name: string, request: UpdateAssetRequest): Promise<UpdateAssetResponse>;
  updateAssetVersion(
    creatorUsername: string,
    name: string,
    revision: string | number,
    request: UpdateAssetVersionRequest,
  ): Promise<UpdateAssetVersionResponse>;
  deleteAssetVersion(
    creatorUsername: string,
    name: string,
    revision: string | number,
  ): Promise<DeleteAssetVersionResponse>;
  deleteAsset(creatorUsername: string, name: string): Promise<DeleteAssetResponse>;
  downloadAssetFile(
    creatorUsername: string,
    assetName: string,
    revision: string | number,
    options?: { role?: string },
  ): Promise<Blob>;
  downloadAssetSource(
    creatorUsername: string,
    assetName: string,
    revision: string | number,
  ): Promise<{ blob: Blob; metadata: AssetSourceBundleResponse }>;
  initializeAssetPackUpload(
    creatorUsername: string,
    name: string,
    request: InitializeAssetPackUploadRequest,
  ): Promise<InitializeAssetPackUploadResponse>;
  uploadAssetPackSessionAsset(
    creatorUsername: string,
    name: string,
    sessionId: string,
    uploadKey: string,
    options: UploadAssetPackSessionAssetOptions,
  ): Promise<UploadAssetPackSessionAssetResponse>;
  uploadAssetPackSessionMedia(
    creatorUsername: string,
    name: string,
    sessionId: string,
    mediaKey: string,
    options: UploadAssetPackSessionMediaOptions,
  ): Promise<UploadAssetPackSessionMediaResponse>;
  finalizeAssetPackUpload(
    creatorUsername: string,
    name: string,
    sessionId: string,
  ): Promise<FinalizeAssetPackUploadResponse>;
  abortAssetPackUpload(
    creatorUsername: string,
    name: string,
    sessionId: string,
  ): Promise<AbortAssetPackUploadResponse>;
  listAssetPacks(
    options?: { limit?: number; offset?: number; containsCategory?: AssetCategory; containsSubcategory?: string }
  ): Promise<AssetPackListResponse>;
  listAssetPacksForCreator(
    creatorUsername: string,
    options?: { limit?: number; offset?: number; containsCategory?: AssetCategory; containsSubcategory?: string }
  ): Promise<AssetPackListResponse>;
  fetchAssetPackBySlug(creatorUsername: string, packName: string): Promise<AssetPackDetailResponse>;
  downloadAssetPackSource(
    creatorUsername: string,
    packName: string,
    version: string,
  ): Promise<{ blob: Blob; metadata: AssetPackSourceBundleResponse }>;
  downloadAssetPack(
    creatorUsername: string,
    packName: string,
    version: string,
  ): Promise<{ blob: Blob; metadata: AssetPackSourceBundleResponse }>;
  listAssetPackVersions(
    creatorUsername: string,
    packName: string,
    options?: { limit?: number; offset?: number }
  ): Promise<AssetPackVersionsListResponse>;
  updateAssetPack(creatorUsername: string, name: string, request: UpdateAssetPackRequest): Promise<UpdateAssetPackResponse>;
  updateAssetPackVersion(
    creatorUsername: string,
    name: string,
    version: string,
    request: UpdateAssetPackVersionRequest,
  ): Promise<UpdateAssetPackVersionResponse>;
  deleteAssetPackVersion(
    creatorUsername: string,
    name: string,
    version: string,
  ): Promise<DeleteAssetPackVersionResponse>;
  deleteAssetPack(creatorUsername: string, name: string): Promise<DeleteAssetPackResponse>;
  batchUpsertGraphRelations(request: BatchUpsertNodeRelationsRequest): Promise<BatchUpsertNodeRelationsResponse>;
  deleteApp(creatorUsername: string, name: string): Promise<DeleteAppResponse>;
  submitFeedback(request: SubmitFeedbackRequest): Promise<SubmitFeedbackResponse>;
  listFeedback(options?: { limit?: number; offset?: number; source?: string; userId?: number }): Promise<FeedbackListResponse>;
  deleteFeedback(id: number): Promise<DeleteFeedbackResponse>;

  // App Versions
  uploadAppVersion(
    creatorUsername: string,
    appName: string,
    options: UploadAppVersionOptions
  ): Promise<CreateVersionResponse>;
  listAppVersions(creatorUsername: string, appName: string): Promise<AppVersionsListResponse>;
  getAppVersion(creatorUsername: string, appName: string, version: string): Promise<AppVersionDetailResponse>;
  downloadAppSource(
    creatorUsername: string,
    appName: string,
    version: string,
  ): Promise<{ blob: Blob; metadata: AppSourceBundleResponse }>;
  updateAppVersion(
    creatorUsername: string,
    appName: string,
    version: string,
    updates: { releaseNotes?: string | null; visibility?: AppVersionVisibility; setAsCurrent?: boolean },
  ): Promise<UpdateVersionResponse>;
  deleteAppVersion(creatorUsername: string, appName: string, version: string): Promise<DeleteVersionResponse>;

  // Credit + shop
  fetchPublicCreditShop(): Promise<ShopResponse>;
  fetchCreditShop(): Promise<ShopResponse>;
  createCreditPackCheckoutSession(
    sku: string,
    request?: CreditPackCheckoutSessionRequest,
  ): Promise<CreditPackCheckoutSessionResponse>;
  fetchCreditPackCheckoutStatus(sessionId: string): Promise<CreditPackCheckoutStatusResponse>;
  purchaseAsset(request: AssetPurchaseRequest): Promise<PurchaseResponse>;
  purchaseIap(request: IapPurchaseRequest): Promise<IapPurchaseResponse>;
  fetchIapReceipts(params?: IapReceiptListParams): Promise<IapReceiptsResponse>;
  cancelIapReceipt(receiptId: number): Promise<IapReceiptResponse>;
  fetchAppIapReceipts(params?: Omit<IapReceiptListParams, 'appId'>): Promise<IapReceiptsResponse>;
  consumeAppIapReceipt(receiptId: number): Promise<IapReceiptResponse>;
  grantAppIapReceipt(receiptId: number): Promise<IapReceiptResponse>;
  cancelAppIapReceipt(receiptId: number): Promise<IapReceiptResponse>;
  fetchCreditTransactions(options?: { limit?: number; offset?: number }): Promise<TransactionsResponse>;
  fetchAiGeneration(id: string): Promise<AiGenerationDetailResponse>;

  setSelectedProfileAsset(request: SetProfileAssetRequest): Promise<SetProfileAssetResponse>;

  // Home
  fetchHome(options?: FetchHomeOptions): Promise<HomeResponse>;

  // Admin
  fetchUsers(): Promise<UsersListResponse>;
  createUser(request: CreateUserRequest): Promise<CreateUserResponse>;
  batchCreateUsersFromCsv(formData: FormData): Promise<BatchCreateUsersResponse>;
  fetchAdminUser(userId: number): Promise<AdminUserResponse>;
  updateAdminUser(userId: number, request: UpdateAdminUserRequest): Promise<AdminUserResponse>;
  deleteAdminUser(userId: number): Promise<DeleteAdminUserResponse>;
  fetchAdminApps(): Promise<AdminAppsListResponse>;
  updateAdminApp(id: number, request: AdminUpdateAppRequest): Promise<AdminUpdateAppResponse>;
  deleteAdminApp(id: number): Promise<DeleteAppResponse>;
  fetchAdminCreditPacks(): Promise<CreditPacksResponse>;
  createAdminCreditPack(request: { sku: string; displayName: string; amount: number; costCents: number }): Promise<CreditPackResponse>;
  updateAdminCreditPack(sku: string, request: { displayName?: string; amount?: number; costCents?: number }): Promise<CreditPackResponse>;
  deleteAdminCreditPack(sku: string): Promise<{ success: boolean }>;
  syncAdminCreditPacksStripe(): Promise<CreditPacksResponse>;
  fetchAdminPayments(options?: {
    provider?: PaymentProvider;
    status?: PaymentStatus | PaymentStatus[];
    userId?: number;
    creditPackSku?: string;
    from?: string | Date;
    to?: string | Date;
    limit?: number;
    offset?: number;
  }): Promise<AdminPaymentsListResponse>;
  fetchAdminPayment(paymentId: number): Promise<AdminPaymentDetailResponse>;
  refundAdminPayment(paymentId: number, request: AdminRefundPaymentRequest): Promise<AdminPaymentDetailResponse>;
  reconcileAdminPayment(paymentId: number): Promise<AdminPaymentDetailResponse>;
  fetchAdminCreditTransactions(options?: { limit?: number; offset?: number }): Promise<AdminCreditTransactionsResponse>;
  fetchAdminAiGenerations(options?: { limit?: number; offset?: number }): Promise<AiGenerationsResponse>;
  fetchAdminAiGeneration(id: string): Promise<AiGenerationDetailResponse>;

  // Creator bootstrap & scaffolds
  fetchBootstrap(): Promise<BootstrapResponse>;
  fetchRemixScaffold(creatorUsername: string, appName: string, version?: string): Promise<RemixScaffoldResponse>;
  fetchTemplateScaffold(namespace: string, slug: string): Promise<TemplateScaffoldResponse>;
}

export function createApiClient(config: ApiClientConfig = {}): ApiClient {
  const fetchImpl = config.fetchImpl ?? globalThis.fetch?.bind(globalThis);
  if (!fetchImpl) {
    throw new Error('api_client_missing_fetch');
  }
  const requestTimeoutMs = resolveRequestTimeoutMs(config.requestTimeoutMs);
  const includeBrowserCredentials = config.includeBrowserCredentials ?? true;
  const resolveBaseUrl = createBaseUrlResolver(config.baseUrl);
  const getClientHeaders = () => (config.clientHeaders ? config.clientHeaders() : {});

  async function resolveToken(): Promise<string | null> {
    if (config.tokenProvider) {
      const token = await config.tokenProvider();
      return token ?? null;
    }
    return null;
  }

  function buildIapQuery(params?: IapReceiptListParams): string {
    if (!params) {
      return '';
    }
    const search = new URLSearchParams();
    if (params.kind) {
      search.set('kind', params.kind);
    }
    if (params.status) {
      const statuses = Array.isArray(params.status) ? params.status : [params.status];
      if (statuses.length > 0) {
        search.set('status', statuses.join(','));
      }
    }
    if (params.from) {
      const fromValue = params.from instanceof Date ? params.from.toISOString() : params.from;
      search.set('from', fromValue);
    }
    if (params.to) {
      const toValue = params.to instanceof Date ? params.to.toISOString() : params.to;
      search.set('to', toValue);
    }
    if (typeof params.appId === 'number') {
      search.set('appId', String(params.appId));
    }
    if (typeof params.limit === 'number') {
      search.set('limit', String(params.limit));
    }
    if (typeof params.offset === 'number') {
      search.set('offset', String(params.offset));
    }
    const query = search.toString();
    return query;
  }

  function normalizeAssetRevisionInput(revision: string | number): string {
    if (typeof revision === 'number') {
      if (!Number.isInteger(revision) || revision <= 0) {
        throw new Error('invalid_asset_revision');
      }
      return String(revision);
    }
    const trimmed = revision.trim().toLowerCase();
    if (!trimmed) {
      throw new Error('invalid_asset_revision');
    }
    const numeric = trimmed.startsWith('r') ? trimmed.slice(1) : trimmed;
    const parsed = Number.parseInt(numeric, 10);
    if (!Number.isInteger(parsed) || parsed <= 0) {
      throw new Error('invalid_asset_revision');
    }
    return String(parsed);
  }

  function normalizeSemverInput(version: string): string {
    const trimmed = typeof version === 'string' ? version.trim() : '';
    if (!trimmed) {
      throw new Error('invalid_version_format');
    }
    const semverRegex = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$/;
    if (!semverRegex.test(trimmed)) {
      throw new Error('invalid_version_format');
    }
    return trimmed;
  }

  function normalizeEnumInput<T extends string>(value: string, allowed: readonly T[], errorCode: string): T {
    if (!allowed.includes(value as T)) {
      throw new Error(errorCode);
    }
    return value as T;
  }

  function normalizeSavedItemKindInput(kind: SavedItemKind): SavedItemKind {
    return normalizeEnumInput(kind, SAVED_ITEM_KIND_VALUES, 'invalid_saved_item_kind');
  }

  function normalizeEngagementEventTypeInput(eventType: EngagementEventType): EngagementEventType {
    return normalizeEnumInput(eventType, ENGAGEMENT_EVENT_TYPE_VALUES, 'invalid_engagement_event_type');
  }

  function normalizeEngagementTargetKindInput(targetKind: EngagementTargetKind): EngagementTargetKind {
    return normalizeEnumInput(targetKind, ENGAGEMENT_TARGET_KIND_VALUES, 'invalid_engagement_target_kind');
  }

  function normalizeLibraryCategoryInput(category: LibraryCategory): LibraryCategory {
    return normalizeEnumInput(category, LIBRARY_CATEGORY_VALUES, 'invalid_library_category');
  }

  function normalizeLibrarySortInput(sort: LibrarySort): LibrarySort {
    return normalizeEnumInput(sort, LIBRARY_SORT_VALUES, 'invalid_library_sort');
  }

  function normalizeFollowingSortInput(sort: FollowingSort): FollowingSort {
    return normalizeEnumInput(sort, FOLLOWING_SORT_VALUES, 'invalid_following_sort');
  }

  function normalizeFollowingFeedSectionInput(section: FollowingFeedSection): FollowingFeedSection {
    return normalizeEnumInput(section, FOLLOWING_FEED_SECTION_VALUES, 'invalid_following_feed_section');
  }

  function normalizeNotificationStatusInput(status: NotificationStatus): NotificationStatus {
    return normalizeEnumInput(status, NOTIFICATION_STATUS_VALUES, 'invalid_notification_status');
  }

  function normalizeSearchKindInput(kind: SearchKind): SearchKind {
    return normalizeEnumInput(kind, SEARCH_KIND_VALUES, 'invalid_search_kind');
  }

  function normalizeSearchModeInput(mode: SearchMode): SearchMode {
    return normalizeEnumInput(mode, SEARCH_MODE_VALUES, 'invalid_search_mode');
  }

  function normalizeSearchAssetTypeInput(assetType: SearchAssetType): SearchAssetType {
    return normalizeEnumInput(assetType, SEARCH_ASSET_TYPE_VALUES, 'invalid_search_asset_type');
  }

  function normalizePositiveIntegerInput(value: number, errorCode: string): number {
    if (!Number.isInteger(value) || value <= 0) {
      throw new Error(errorCode);
    }
    return value;
  }

  function normalizeNonNegativeIntegerInput(value: number, errorCode: string): number {
    if (!Number.isInteger(value) || value < 0) {
      throw new Error(errorCode);
    }
    return value;
  }

  function normalizeCreatorItemSlug(value: string, field: 'creator' | 'name'): string {
    const trimmed = typeof value === 'string' ? value.trim() : '';
    if (!trimmed) {
      throw new Error(field === 'creator' ? 'invalid_creator_username' : 'invalid_item_name');
    }
    return trimmed;
  }

  function normalizeWebPushSubscriptionRequest(
    requestBody: UpsertWebPushSubscriptionRequest,
  ): UpsertWebPushSubscriptionRequest {
    const subscription = requestBody?.subscription;
    const endpoint = typeof subscription?.endpoint === 'string' ? subscription.endpoint.trim() : '';
    const expirationTime = subscription?.expirationTime;
    const p256dh = typeof subscription?.keys?.p256dh === 'string' ? subscription.keys.p256dh.trim() : '';
    const auth = typeof subscription?.keys?.auth === 'string' ? subscription.keys.auth.trim() : '';

    if (!endpoint || !endpoint.startsWith('https://')) {
      throw new Error('invalid_web_push_subscription');
    }
    if (expirationTime !== null && expirationTime !== undefined && !Number.isFinite(expirationTime)) {
      throw new Error('invalid_web_push_subscription');
    }
    if (!p256dh || !auth) {
      throw new Error('invalid_web_push_subscription');
    }

    return {
      subscription: {
        endpoint,
        expirationTime: expirationTime === undefined ? null : expirationTime,
        keys: {
          p256dh,
          auth,
        },
      },
    };
  }

  function normalizeApplePushDeviceRequest(
    requestBody: ApplePushDeviceRequest,
  ): ApplePushDeviceRequest {
    const deviceToken = typeof requestBody?.deviceToken === 'string' ? requestBody.deviceToken.trim().toLowerCase() : '';
    const apnsEnvironment = requestBody?.apnsEnvironment;

    if (!/^[0-9a-f]+$/.test(deviceToken) || deviceToken.length < 16) {
      throw new Error('invalid_apple_push_device_token');
    }
    if (apnsEnvironment !== 'development' && apnsEnvironment !== 'production') {
      throw new Error('invalid_apple_push_environment');
    }

    return {
      deviceToken,
      apnsEnvironment,
    };
  }

  function buildCreatorAppMutationPath(
    creatorUsername: string,
    appName?: string,
    suffix = '',
  ): string {
    const creator = normalizeCreatorItemSlug(creatorUsername, 'creator');
    if (!appName) {
      return `/creators/${encodeURIComponent(creator)}/apps${suffix}`;
    }
    const name = normalizeCreatorItemSlug(appName, 'name');
    return `/creators/${encodeURIComponent(creator)}/apps/${encodeURIComponent(name)}${suffix}`;
  }

  function buildCreatorAssetMutationPath(
    creatorUsername: string,
    assetName?: string,
    suffix = '',
  ): string {
    const creator = normalizeCreatorItemSlug(creatorUsername, 'creator');
    if (!assetName) {
      return `/creators/${encodeURIComponent(creator)}/assets${suffix}`;
    }
    const name = normalizeCreatorItemSlug(assetName, 'name');
    return `/creators/${encodeURIComponent(creator)}/assets/${encodeURIComponent(name)}${suffix}`;
  }

  function buildCreatorAssetPackMutationPath(
    creatorUsername: string,
    packName?: string,
    suffix = '',
  ): string {
    const creator = normalizeCreatorItemSlug(creatorUsername, 'creator');
    if (!packName) {
      return `/creators/${encodeURIComponent(creator)}/asset-packs${suffix}`;
    }
    const name = normalizeCreatorItemSlug(packName, 'name');
    return `/creators/${encodeURIComponent(creator)}/asset-packs/${encodeURIComponent(name)}${suffix}`;
  }

  function parseContentDispositionFilename(headerValue: string | null): string | null {
    if (!headerValue) {
      return null;
    }
    const utf8Match = /filename\*=UTF-8''([^;]+)/i.exec(headerValue);
    if (utf8Match && utf8Match[1]) {
      try {
        return decodeURIComponent(utf8Match[1]);
      } catch {
        return utf8Match[1];
      }
    }
    const plainMatch = /filename="?([^";]+)"?/i.exec(headerValue);
    return plainMatch?.[1] ?? null;
  }

  const request = createRequestExecutor({
    fetchImpl,
    resolveBaseUrl,
    resolveUrl,
    parseResponseBody,
    resolveToken,
    getClientHeaders,
    requestTimeoutMs,
    includeBrowserCredentials,
  });

  // Implementation of all API methods
  return {
    request,
    ...buildAuthApiClientMethods({
      request,
      handleApiError,
    }),

    async me(): Promise<MeResponse> {
      const response = await request<MeResponse>({
        method: 'GET',
        path: '/me',
      });

      if (response.status !== 200) {
        handleApiError(response, 'me');
      }

      return response.body;
    },

    async updateProfile(updateRequest: UpdateProfileRequest): Promise<UpdateProfileResponse> {
      const response = await request<UpdateProfileResponse>({
        method: 'PATCH',
        path: '/me',
        body: updateRequest,
      });

      if (response.status !== 200) {
        handleApiError(response, 'update_profile');
      }

      return response.body;
    },

    async changePassword(changeRequest: ChangePasswordRequest): Promise<ChangePasswordResponse> {
      const response = await request<ChangePasswordResponse>({
        method: 'POST',
        path: '/me/password',
        body: changeRequest,
      });

      if (response.status !== 200) {
        handleApiError(response, 'change_password');
      }

      return response.body;
    },

    async exportPrivacyData(): Promise<PrivacyExportResponse> {
      const response = await request<PrivacyExportResponse>({
        method: 'GET',
        path: '/me/privacy-export',
      });

      if (response.status !== 200) {
        handleApiError(response, 'export_privacy_data');
      }

      return response.body;
    },

    async deleteAccount(deleteRequest: DeleteMyAccountRequest): Promise<DeleteMyAccountResponse> {
      const response = await request<DeleteMyAccountResponse>({
        method: 'DELETE',
        path: '/me',
        body: deleteRequest,
      });

      if (response.status !== 200) {
        handleApiError(response, 'delete_account');
      }

      return response.body;
    },

    async upgradeToCreator(): Promise<UpgradeToCreatorResponse> {
      const response = await request<UpgradeToCreatorResponse>({
        method: 'POST',
        path: '/me/upgrade-to-creator',
      });

      if (response.status !== 200) {
        handleApiError(response, 'upgrade_to_creator');
      }

      return response.body;
    },

    async fetchUserById(userId: number): Promise<UserDetailResponse> {
      if (!Number.isFinite(userId) || userId <= 0) {
        throw new Error('invalid_user_id');
      }
      const response = await request<UserDetailResponse>({
        method: 'GET',
        path: `/users/${encodeURIComponent(String(userId))}`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'fetch_user_by_id');
      }

      return response.body;
    },

    async fetchUserByUsername(username: string): Promise<UserDetailResponse> {
      const trimmed = typeof username === 'string' ? username.trim() : '';
      if (!trimmed) {
        throw new Error('invalid_username');
      }
      const response = await request<UserDetailResponse>({
        method: 'GET',
        path: `/users/by-username/${encodeURIComponent(trimmed)}`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'fetch_user_by_username');
      }

      return response.body;
    },

    async fetchOwnedProfileAssets(): Promise<OwnedProfileAssetsResponse> {
      const response = await request<OwnedProfileAssetsResponse>({
        method: 'GET',
        path: '/me/profile-assets',
      });

      if (response.status !== 200) {
        handleApiError(response, 'fetch_owned_profile_assets');
      }

      return response.body;
    },

    async saveItem(kind: SavedItemKind, creatorUsername: string, itemName: string): Promise<SavedItemMutationResponse> {
      const normalizedKind = normalizeSavedItemKindInput(kind);
      const creator = normalizeCreatorItemSlug(creatorUsername, 'creator');
      const name = normalizeCreatorItemSlug(itemName, 'name');
      const response = await request<SavedItemMutationResponse>({
        method: 'PUT',
        path: `/me/saved-items/${encodeURIComponent(normalizedKind)}/${encodeURIComponent(creator)}/${encodeURIComponent(name)}`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'save_item');
      }

      return response.body;
    },

    async unsaveItem(kind: SavedItemKind, creatorUsername: string, itemName: string): Promise<SavedItemMutationResponse> {
      const normalizedKind = normalizeSavedItemKindInput(kind);
      const creator = normalizeCreatorItemSlug(creatorUsername, 'creator');
      const name = normalizeCreatorItemSlug(itemName, 'name');
      const response = await request<SavedItemMutationResponse>({
        method: 'DELETE',
        path: `/me/saved-items/${encodeURIComponent(normalizedKind)}/${encodeURIComponent(creator)}/${encodeURIComponent(name)}`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'unsave_item');
      }

      return response.body;
    },

    async likeItem(kind: SavedItemKind, creatorUsername: string, itemName: string): Promise<LikedItemMutationResponse> {
      const normalizedKind = normalizeSavedItemKindInput(kind);
      const creator = normalizeCreatorItemSlug(creatorUsername, 'creator');
      const name = normalizeCreatorItemSlug(itemName, 'name');
      const response = await request<LikedItemMutationResponse>({
        method: 'PUT',
        path: `/me/likes/${encodeURIComponent(normalizedKind)}/${encodeURIComponent(creator)}/${encodeURIComponent(name)}`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'like_item');
      }

      return response.body;
    },

    async unlikeItem(kind: SavedItemKind, creatorUsername: string, itemName: string): Promise<LikedItemMutationResponse> {
      const normalizedKind = normalizeSavedItemKindInput(kind);
      const creator = normalizeCreatorItemSlug(creatorUsername, 'creator');
      const name = normalizeCreatorItemSlug(itemName, 'name');
      const response = await request<LikedItemMutationResponse>({
        method: 'DELETE',
        path: `/me/likes/${encodeURIComponent(normalizedKind)}/${encodeURIComponent(creator)}/${encodeURIComponent(name)}`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'unlike_item');
      }

      return response.body;
    },

    async trackEngagementEvent(payload: TrackEngagementEventRequest): Promise<TrackEngagementEventResponse> {
      const eventType = normalizeEngagementEventTypeInput(payload.eventType);
      const targetKind = normalizeEngagementTargetKindInput(payload.targetKind);
      const creatorUsername = normalizeCreatorItemSlug(payload.creatorUsername, 'creator');
      const itemName = payload.itemName === undefined ? undefined : normalizeCreatorItemSlug(payload.itemName, 'name');
      const response = await request<TrackEngagementEventResponse>({
        method: 'POST',
        path: '/engagement-events',
        body: {
          eventType,
          targetKind,
          creatorUsername,
          ...(itemName !== undefined ? { itemName } : {}),
        },
      });

      if (response.status !== 200) {
        handleApiError(response, 'track_engagement_event');
      }

      return response.body;
    },

    async fetchLibrary(options: { category?: LibraryCategory; sort?: LibrarySort } = {}): Promise<LibraryResponse> {
      const params = new URLSearchParams();
      if (options.category) {
        params.set('category', normalizeLibraryCategoryInput(options.category));
      }
      if (options.sort) {
        params.set('sort', normalizeLibrarySortInput(options.sort));
      }
      const query = params.toString();
      const response = await request<LibraryResponse>({
        method: 'GET',
        path: `/me/library${query ? `?${query}` : ''}`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'fetch_library');
      }

      return response.body;
    },

    async followCreator(creatorUsername: string): Promise<CreatorFollowMutationResponse> {
      const creator = normalizeCreatorItemSlug(creatorUsername, 'creator');
      const response = await request<CreatorFollowMutationResponse>({
        method: 'PUT',
        path: `/me/following/${encodeURIComponent(creator)}`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'follow_creator');
      }

      return response.body;
    },

    async unfollowCreator(creatorUsername: string): Promise<CreatorFollowMutationResponse> {
      const creator = normalizeCreatorItemSlug(creatorUsername, 'creator');
      const response = await request<CreatorFollowMutationResponse>({
        method: 'DELETE',
        path: `/me/following/${encodeURIComponent(creator)}`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'unfollow_creator');
      }

      return response.body;
    },

    async fetchFollowingCreators(options: { sort?: FollowingSort } = {}): Promise<FollowingCreatorsResponse> {
      const params = new URLSearchParams();
      if (options.sort) {
        params.set('sort', normalizeFollowingSortInput(options.sort));
      }
      const query = params.toString();
      const response = await request<FollowingCreatorsResponse>({
        method: 'GET',
        path: `/me/following${query ? `?${query}` : ''}`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'fetch_following_creators');
      }

      return response.body;
    },

    async fetchFollowingFeed(options: { section: FollowingFeedSection; limit?: number }): Promise<FollowingFeedResponse> {
      const params = new URLSearchParams();
      params.set('section', normalizeFollowingFeedSectionInput(options.section));
      if (options.limit !== undefined) {
        params.set('limit', String(normalizePositiveIntegerInput(options.limit, 'invalid_following_feed_limit')));
      }
      const response = await request<FollowingFeedResponse>({
        method: 'GET',
        path: `/me/following/feed?${params.toString()}`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'fetch_following_feed');
      }

      return response.body;
    },

    async fetchNotifications(options: { status?: NotificationStatus; limit?: number; offset?: number } = {}): Promise<NotificationsResponse> {
      const params = new URLSearchParams();
      if (options.status) {
        params.set('status', normalizeNotificationStatusInput(options.status));
      }
      if (options.limit !== undefined) {
        params.set('limit', String(normalizePositiveIntegerInput(options.limit, 'invalid_notification_limit')));
      }
      if (options.offset !== undefined) {
        params.set('offset', String(normalizeNonNegativeIntegerInput(options.offset, 'invalid_notification_offset')));
      }
      const query = params.toString();
      const response = await request<NotificationsResponse>({
        method: 'GET',
        path: `/me/notifications${query ? `?${query}` : ''}`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'fetch_notifications');
      }

      return response.body;
    },

    async markNotificationRead(notificationId: number): Promise<NotificationReadResponse> {
      if (!Number.isInteger(notificationId) || notificationId <= 0) {
        throw new Error('invalid_notification_id');
      }
      const response = await request<NotificationReadResponse>({
        method: 'POST',
        path: `/me/notifications/${encodeURIComponent(String(notificationId))}/read`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'mark_notification_read');
      }

      return response.body;
    },

    async markAllNotificationsRead(): Promise<NotificationReadResponse> {
      const response = await request<NotificationReadResponse>({
        method: 'POST',
        path: '/me/notifications/read-all',
      });

      if (response.status !== 200) {
        handleApiError(response, 'mark_all_notifications_read');
      }

      return response.body;
    },

    async fetchWebPushConfig(): Promise<WebPushConfigResponse> {
      const response = await request<WebPushConfigResponse>({
        method: 'GET',
        path: '/me/push/web/config',
      });

      if (response.status !== 200) {
        handleApiError(response, 'fetch_web_push_config');
      }

      return response.body;
    },

    async fetchWebPushSubscriptionStatus(
      requestBody: UpsertWebPushSubscriptionRequest,
    ): Promise<WebPushSubscriptionStatusResponse> {
      const response = await request<WebPushSubscriptionStatusResponse>({
        method: 'POST',
        path: '/me/push/web/subscription/status',
        body: normalizeWebPushSubscriptionRequest(requestBody),
      });

      if (response.status !== 200) {
        handleApiError(response, 'fetch_web_push_subscription_status');
      }

      return response.body;
    },

    async upsertWebPushSubscription(requestBody: UpsertWebPushSubscriptionRequest): Promise<PushSubscriptionMutationResponse> {
      const response = await request<PushSubscriptionMutationResponse>({
        method: 'PUT',
        path: '/me/push/web/subscription',
        body: normalizeWebPushSubscriptionRequest(requestBody),
      });

      if (response.status !== 200) {
        handleApiError(response, 'upsert_web_push_subscription');
      }

      return response.body;
    },

    async deleteWebPushSubscription(requestBody: UpsertWebPushSubscriptionRequest): Promise<PushSubscriptionMutationResponse> {
      const response = await request<PushSubscriptionMutationResponse>({
        method: 'DELETE',
        path: '/me/push/web/subscription',
        body: normalizeWebPushSubscriptionRequest(requestBody),
      });

      if (response.status !== 200) {
        handleApiError(response, 'delete_web_push_subscription');
      }

      return response.body;
    },

    async fetchApplePushDeviceStatus(
      requestBody: ApplePushDeviceRequest,
    ): Promise<ApplePushDeviceStatusResponse> {
      const response = await request<ApplePushDeviceStatusResponse>({
        method: 'POST',
        path: '/me/push/apple/device/status',
        body: normalizeApplePushDeviceRequest(requestBody),
      });

      if (response.status !== 200) {
        handleApiError(response, 'fetch_apple_push_device_status');
      }

      return response.body;
    },

    async upsertApplePushDevice(requestBody: ApplePushDeviceRequest): Promise<PushSubscriptionMutationResponse> {
      const response = await request<PushSubscriptionMutationResponse>({
        method: 'PUT',
        path: '/me/push/apple/device',
        body: normalizeApplePushDeviceRequest(requestBody),
      });

      if (response.status !== 200) {
        handleApiError(response, 'upsert_apple_push_device');
      }

      return response.body;
    },

    async deleteApplePushDevice(requestBody: ApplePushDeviceRequest): Promise<PushSubscriptionMutationResponse> {
      const response = await request<PushSubscriptionMutationResponse>({
        method: 'DELETE',
        path: '/me/push/apple/device',
        body: normalizeApplePushDeviceRequest(requestBody),
      });

      if (response.status !== 200) {
        handleApiError(response, 'delete_apple_push_device');
      }

      return response.body;
    },

    ...buildSearchApiClientMethods({
      request,
      handleApiError,
      normalizeSearchModeInput,
      normalizeSearchKindInput,
      normalizeSearchAssetTypeInput,
      normalizePositiveIntegerInput,
    }),
    ...buildCommentsApiClientMethods({
      request,
      handleApiError,
      normalizeSavedItemKindInput,
      normalizeCreatorItemSlug,
      normalizePositiveIntegerInput,
    }),
    ...buildAppsApiClientMethods({
      request,
      handleApiError,
      fetchImpl,
      includeBrowserCredentials,
      resolveBaseUrl,
      resolveUrl,
      parseResponseBody,
      resolveToken,
      getClientHeaders: () => config.clientHeaders ? config.clientHeaders() : {},
      buildCreatorAppMutationPath,
      normalizeCreatorItemSlug,
      normalizeSemverInput,
      parseContentDispositionFilename,
    }),
    ...buildAssetsApiClientMethods({
      request,
      handleApiError,
      fetchImpl,
      includeBrowserCredentials,
      resolveBaseUrl,
      resolveUrl,
      parseResponseBody,
      resolveToken,
      getClientHeaders: () => config.clientHeaders ? config.clientHeaders() : {},
      buildCreatorAssetMutationPath,
      normalizeCreatorItemSlug,
      normalizeAssetRevisionInput,
      parseContentDispositionFilename,
    }),
    ...buildAssetPacksApiClientMethods({
      request,
      handleApiError,
      fetchImpl,
      includeBrowserCredentials,
      resolveBaseUrl,
      resolveUrl,
      parseResponseBody,
      resolveToken,
      getClientHeaders: () => config.clientHeaders ? config.clientHeaders() : {},
      buildCreatorAssetPackMutationPath,
      normalizeCreatorItemSlug,
      normalizeSemverInput,
      parseContentDispositionFilename,
    }),
    ...buildMeApiClientMethods({ request, handleApiError }),

    async batchUpsertGraphRelations(body: BatchUpsertNodeRelationsRequest): Promise<BatchUpsertNodeRelationsResponse> {
      const response = await request<BatchUpsertNodeRelationsResponse>({
        method: 'POST',
        path: '/me/graph/relations:batchUpsert',
        body,
      });
      if (response.status !== 200) {
        handleApiError(response, 'batch_upsert_graph_relations');
      }
      return response.body;
    },

    async submitFeedback(feedbackRequest: SubmitFeedbackRequest): Promise<SubmitFeedbackResponse> {
      const response = await request<SubmitFeedbackResponse>({
        method: 'POST',
        path: '/feedback',
        body: feedbackRequest,
      });

      if (response.status !== 201 && response.status !== 200) {
        handleApiError(response, 'submit_feedback');
      }

      return response.body;
    },

    async listFeedback(options: { limit?: number; offset?: number; source?: string; userId?: number } = {}): Promise<FeedbackListResponse> {
      const params = new URLSearchParams();
      if (options.limit !== undefined) {
        params.set('limit', String(options.limit));
      }
      if (options.offset !== undefined) {
        params.set('offset', String(options.offset));
      }
      if (typeof options.source === 'string' && options.source.trim().length > 0) {
        params.set('source', options.source.trim());
      }
      if (options.userId !== undefined) {
        params.set('userId', String(options.userId));
      }
      const query = params.toString();
      const path = `/feedback${query ? `?${query}` : ''}`;

      const response = await request<FeedbackListResponse>({
        method: 'GET',
        path,
      });

      if (response.status !== 200) {
        handleApiError(response, 'list_feedback');
      }

      return response.body;
    },

    async deleteFeedback(id: number): Promise<DeleteFeedbackResponse> {
      const response = await request<DeleteFeedbackResponse>({
        method: 'DELETE',
        path: `/feedback/${encodeURIComponent(String(id))}`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'delete_feedback');
      }

      return response.body;
    },

    async setSelectedProfileAsset(profileAssetRequest: SetProfileAssetRequest): Promise<SetProfileAssetResponse> {
      const response = await request<SetProfileAssetResponse>({
        method: 'POST',
        path: '/me/profile-asset',
        body: profileAssetRequest,
      });

      if (response.status !== 200) {
        handleApiError(response, 'set_profile_asset');
      }

      return response.body;
    },

    async fetchHome(options: FetchHomeOptions = {}): Promise<HomeResponse> {
      const params = new URLSearchParams();
      if (typeof options.section === 'string' && options.section.trim().length > 0) {
        params.set('section', options.section.trim());
      }
      if (typeof options.limit === 'number') {
        params.set('limit', String(options.limit));
      }
      if (typeof options.offset === 'number') {
        params.set('offset', String(options.offset));
      }
      const query = params.toString();
      const response = await request<HomeResponse>({
        method: 'GET',
        path: `/home${query ? `?${query}` : ''}`,
      });

      if (response.status !== 200) {
        handleApiError(response, 'fetch_home');
      }

      return response.body;
    },
    ...buildAdminApiClientMethods({
      request,
      handleApiError,
      fetchImpl,
      includeBrowserCredentials,
      resolveBaseUrl,
      resolveUrl,
      parseResponseBody,
      resolveToken,
      getClientHeaders: () => config.clientHeaders ? config.clientHeaders() : {},
    }),
    ...buildPaymentsApiClientMethods({
      request,
      handleApiError,
      buildIapQuery,
    }),
    ...buildAiApiClientMethods({
      request,
      handleApiError,
    }),
  };
}
