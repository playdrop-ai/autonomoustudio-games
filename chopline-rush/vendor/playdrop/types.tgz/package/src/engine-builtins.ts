import type { EcsFieldType } from "./ecs.js";

export type EngineBuiltinComponentKind = "static" | "versioned" | "tick" | "signal";

export type EngineBuiltinComponent = {
  id: number;
  name: string;
  kind: EngineBuiltinComponentKind;
  networked: boolean;
  input: boolean;
  fields: { name: string; type: EcsFieldType }[];
};

export const ENGINE_BUILTIN_COMPONENTS: EngineBuiltinComponent[] = [
  {
    "fields": [
      {
        "name": "userId",
        "type": "u64"
      }
    ],
    "id": 10,
    "input": false,
    "kind": "static",
    "name": "userId",
    "networked": true
  },
  {
    "fields": [
      {
        "name": "avatarId",
        "type": "u64"
      }
    ],
    "id": 11,
    "input": false,
    "kind": "static",
    "name": "avatarId",
    "networked": true
  },
  {
    "fields": [
      {
        "name": "x",
        "type": "f32"
      },
      {
        "name": "y",
        "type": "f32"
      },
      {
        "name": "z",
        "type": "f32"
      }
    ],
    "id": 20,
    "input": false,
    "kind": "versioned",
    "name": "positionSim",
    "networked": false
  },
  {
    "fields": [
      {
        "name": "x",
        "type": "f32"
      },
      {
        "name": "y",
        "type": "f32"
      },
      {
        "name": "z",
        "type": "f32"
      }
    ],
    "id": 21,
    "input": false,
    "kind": "tick",
    "name": "positionBuffer",
    "networked": true
  },
  {
    "fields": [
      {
        "name": "yaw",
        "type": "f32"
      },
      {
        "name": "pitch",
        "type": "f32"
      }
    ],
    "id": 22,
    "input": false,
    "kind": "tick",
    "name": "yawPitchBuffer",
    "networked": true
  },
  {
    "fields": [
      {
        "name": "yaw",
        "type": "f32"
      },
      {
        "name": "pitch",
        "type": "f32"
      }
    ],
    "id": 23,
    "input": false,
    "kind": "versioned",
    "name": "yawPitchSim",
    "networked": false
  },
  {
    "fields": [
      {
        "name": "x",
        "type": "f32"
      },
      {
        "name": "y",
        "type": "f32"
      },
      {
        "name": "z",
        "type": "f32"
      }
    ],
    "id": 24,
    "input": false,
    "kind": "tick",
    "name": "positionPrediction",
    "networked": false
  },
  {
    "fields": [
      {
        "name": "yaw",
        "type": "f32"
      },
      {
        "name": "pitch",
        "type": "f32"
      }
    ],
    "id": 25,
    "input": false,
    "kind": "tick",
    "name": "yawPitchPrediction",
    "networked": false
  },
  {
    "fields": [
      {
        "name": "x",
        "type": "f32"
      },
      {
        "name": "y",
        "type": "f32"
      },
      {
        "name": "z",
        "type": "f32"
      }
    ],
    "id": 26,
    "input": false,
    "kind": "versioned",
    "name": "velocity",
    "networked": false
  },
  {
    "fields": [
      {
        "name": "grounded",
        "type": "bool"
      }
    ],
    "id": 27,
    "input": false,
    "kind": "versioned",
    "name": "grounded",
    "networked": false
  },
  {
    "fields": [
      {
        "name": "current",
        "type": "f32"
      },
      {
        "name": "max",
        "type": "f32"
      }
    ],
    "id": 28,
    "input": false,
    "kind": "versioned",
    "name": "health",
    "networked": true
  },
  {
    "fields": [
      {
        "name": "origin",
        "type": "vec3"
      },
      {
        "name": "direction",
        "type": "vec3"
      },
      {
        "name": "hitEntity",
        "type": "u64"
      },
      {
        "name": "impactPoint",
        "type": "vec3"
      }
    ],
    "id": 29,
    "input": false,
    "kind": "tick",
    "name": "bulletBuffer",
    "networked": true
  },
  {
    "fields": [
      {
        "name": "isDead",
        "type": "bool"
      },
      {
        "name": "respawnAtTick",
        "type": "u64"
      }
    ],
    "id": 30,
    "input": false,
    "kind": "versioned",
    "name": "dead",
    "networked": true
  },
  {
    "fields": [
      {
        "name": "x",
        "type": "f32"
      },
      {
        "name": "y",
        "type": "f32"
      },
      {
        "name": "z",
        "type": "f32"
      }
    ],
    "id": 1020,
    "input": false,
    "kind": "versioned",
    "name": "positionRender",
    "networked": false
  },
  {
    "fields": [
      {
        "name": "yaw",
        "type": "f32"
      },
      {
        "name": "pitch",
        "type": "f32"
      }
    ],
    "id": 1030,
    "input": false,
    "kind": "versioned",
    "name": "yawPitchRender",
    "networked": false
  },
  {
    "fields": [
      {
        "name": "moveX",
        "type": "f32"
      },
      {
        "name": "moveZ",
        "type": "f32"
      },
      {
        "name": "yaw",
        "type": "f32"
      },
      {
        "name": "pitch",
        "type": "f32"
      },
      {
        "name": "jump",
        "type": "bool"
      },
      {
        "name": "crouch",
        "type": "bool"
      },
      {
        "name": "sprint",
        "type": "bool"
      },
      {
        "name": "interact",
        "type": "bool"
      },
      {
        "name": "use",
        "type": "bool"
      },
      {
        "name": "confirm",
        "type": "bool"
      },
      {
        "name": "cancel",
        "type": "bool"
      },
      {
        "name": "attack",
        "type": "bool"
      },
      {
        "name": "aim",
        "type": "bool"
      },
      {
        "name": "place",
        "type": "bool"
      },
      {
        "name": "remove",
        "type": "bool"
      },
      {
        "name": "slot",
        "type": "u8"
      }
    ],
    "id": 2001,
    "input": true,
    "kind": "tick",
    "name": "input",
    "networked": true
  },
  {
    "fields": [],
    "id": 5001,
    "input": false,
    "kind": "static",
    "name": "player",
    "networked": false
  },
  {
    "fields": [],
    "id": 5002,
    "input": false,
    "kind": "static",
    "name": "room",
    "networked": false
  },
  {
    "fields": [
      {
        "name": "gravity",
        "type": "f32"
      },
      {
        "name": "jumpVelocity",
        "type": "f32"
      },
      {
        "name": "playerHeight",
        "type": "f32"
      },
      {
        "name": "playerRadius",
        "type": "f32"
      },
      {
        "name": "stepHeight",
        "type": "f32"
      },
      {
        "name": "pushbackDamping",
        "type": "f32"
      }
    ],
    "id": 6001,
    "input": false,
    "kind": "static",
    "name": "physicsConfig",
    "networked": false
  },
  {
    "fields": [
      {
        "name": "moveSpeed",
        "type": "f32"
      }
    ],
    "id": 6002,
    "input": false,
    "kind": "static",
    "name": "movementConfig",
    "networked": false
  },
  {
    "fields": [
      {
        "name": "fireCooldownMs",
        "type": "f32"
      },
      {
        "name": "bulletRange",
        "type": "f32"
      },
      {
        "name": "bulletDamage",
        "type": "f32"
      },
      {
        "name": "gunOffsetX",
        "type": "f32"
      },
      {
        "name": "gunOffsetY",
        "type": "f32"
      },
      {
        "name": "gunOffsetZ",
        "type": "f32"
      },
      {
        "name": "respawnDelayMs",
        "type": "f32"
      },
      {
        "name": "maxHealth",
        "type": "f32"
      }
    ],
    "id": 6003,
    "input": false,
    "kind": "static",
    "name": "shooterConfig",
    "networked": false
  },
  {
    "fields": [
      {
        "name": "editCooldownTicks",
        "type": "u64"
      }
    ],
    "id": 6004,
    "input": false,
    "kind": "static",
    "name": "craftConfig",
    "networked": false
  },
  {
    "fields": [
      {
        "name": "lastEditTick",
        "type": "u64"
      }
    ],
    "id": 6005,
    "input": false,
    "kind": "versioned",
    "name": "voxelEditState",
    "networked": false
  },
  {
    "fields": [
      {
        "name": "x",
        "type": "i32"
      },
      {
        "name": "y",
        "type": "i32"
      },
      {
        "name": "z",
        "type": "i32"
      }
    ],
    "id": 6010,
    "input": false,
    "kind": "static",
    "name": "chunkPosition",
    "networked": true
  },
  {
    "fields": [
      {
        "name": "cells",
        "type": "bytes"
      }
    ],
    "id": 6011,
    "input": false,
    "kind": "versioned",
    "name": "voxelChunk",
    "networked": true
  },
  {
    "fields": [],
    "id": 7001,
    "input": false,
    "kind": "signal",
    "name": "shootBulletIntent",
    "networked": false
  },
  {
    "fields": [
      {
        "name": "tool",
        "type": "u8"
      },
      {
        "name": "palette",
        "type": "u8"
      }
    ],
    "id": 7002,
    "input": false,
    "kind": "signal",
    "name": "editVoxelChunkIntent",
    "networked": false
  },
  {
    "fields": [
      {
        "name": "moveX",
        "type": "f32"
      },
      {
        "name": "moveZ",
        "type": "f32"
      },
      {
        "name": "yaw",
        "type": "f32"
      },
      {
        "name": "pitch",
        "type": "f32"
      },
      {
        "name": "jump",
        "type": "bool"
      },
      {
        "name": "crouch",
        "type": "bool"
      },
      {
        "name": "sprint",
        "type": "bool"
      },
      {
        "name": "aim",
        "type": "bool"
      }
    ],
    "id": 7003,
    "input": false,
    "kind": "signal",
    "name": "moveIntent",
    "networked": false
  }
];

export const ENGINE_BUILTIN_COMPONENT_NAMES = ENGINE_BUILTIN_COMPONENTS.map((component) => component.name);

export const ENGINE_BUILTIN_COMPONENT_IDS = ENGINE_BUILTIN_COMPONENTS.map((component) => component.id);
