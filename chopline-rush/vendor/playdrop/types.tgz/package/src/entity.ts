export const ENTITY_TYPE_VALUES = ['AVATAR', 'HUMANOID', 'CREATURE', 'BLOCK'] as const;
export type EntityType = (typeof ENTITY_TYPE_VALUES)[number];

export const AVATAR_VISIBILITY_VALUES = ['DEFAULT', 'SHOP', 'HIDDEN'] as const;
export type AvatarVisibility = (typeof AVATAR_VISIBILITY_VALUES)[number];

export interface EntityMetadataBase {
  id: number;
  name: string;
  displayName: string;
  description: string;
  creatorId: number;
  creatorUsername: string;
  createdAt: string;
  updatedAt: string;
  meshUrl: string;
  previewUrl: string;
  boxelUrl: string;
  meshSizeBytes?: number | null;
  previewSizeBytes?: number | null;
  definitionSizeBytes?: number | null;
  type: EntityType;
  priceCredits?: number | null;
  avatarVisibility?: AvatarVisibility | null;
}

export type EntityMetadata = EntityMetadataBase;

export type CreatureMetadata = EntityMetadata;

export type HumanoidMetadata = CreatureMetadata;

export type AvatarMetadata = HumanoidMetadata;

export type BlockMetadata = EntityMetadata;

function isNullableNumber(value: unknown): value is number | null | undefined {
  return value === null || value === undefined || (typeof value === 'number' && Number.isFinite(value));
}

export function isEntityType(value: unknown): value is EntityType {
  if (typeof value !== 'string') {
    return false;
  }
  return (ENTITY_TYPE_VALUES as readonly string[]).includes(value);
}

export function isEntityMetadata(value: unknown): value is EntityMetadata {
  if (typeof value !== 'object' || value === null) {
    return false;
  }
  const metadata = value as Record<string, unknown>;
  const id = metadata['id'];
  const name = metadata['name'];
  const displayName = metadata['displayName'];
  const description = metadata['description'];
  const creatorId = metadata['creatorId'];
  const creatorUsername = metadata['creatorUsername'];
  const createdAt = metadata['createdAt'];
  const updatedAt = metadata['updatedAt'];
  const meshUrl = metadata['meshUrl'];
  const previewUrl = metadata['previewUrl'];
  const boxelUrl = metadata['boxelUrl'];
  const meshSizeBytes = metadata['meshSizeBytes'];
  const previewSizeBytes = metadata['previewSizeBytes'];
  const definitionSizeBytes = metadata['definitionSizeBytes'];
  const type = metadata['type'];
  const priceCredits = metadata['priceCredits'];
  const avatarVisibility = metadata['avatarVisibility'];
  return (
    typeof id === 'number'
    && Number.isInteger(id)
    && typeof name === 'string'
    && name.length > 0
    && typeof displayName === 'string'
    && typeof description === 'string'
    && typeof creatorId === 'number'
    && Number.isInteger(creatorId)
    && typeof creatorUsername === 'string'
    && typeof createdAt === 'string'
    && typeof updatedAt === 'string'
    && typeof meshUrl === 'string'
    && typeof previewUrl === 'string'
    && typeof boxelUrl === 'string'
    && isNullableNumber(meshSizeBytes)
    && isNullableNumber(previewSizeBytes)
    && isNullableNumber(definitionSizeBytes)
    && isEntityType(type)
    && (priceCredits === undefined || priceCredits === null || typeof priceCredits === 'number')
    && (avatarVisibility === undefined
      || avatarVisibility === null
      || (typeof avatarVisibility === 'string'
        && (AVATAR_VISIBILITY_VALUES as readonly string[]).includes(avatarVisibility)))
  );
}
