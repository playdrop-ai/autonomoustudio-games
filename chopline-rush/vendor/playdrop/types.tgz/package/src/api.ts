import type { AppType, AppSurface } from './app.js';
import type { AppHostingMode, AppVersionVisibility } from './version.js';
import type { AssetCategory, AssetResponse } from './asset.js';
import type { AssetPackResponse } from './asset-pack.js';

// ============================================================================
// API Request Types
// ============================================================================

// Note: description, emoji, color are now per-version (set via version upload)
export interface CreateAppRequest {
  name: string;
  displayName?: string;
}

// Note: description, emoji, color are now per-version (set via version upload)
export interface UpdateAppRequest {
  displayName?: string;
  type?: AppType;
}

export interface AdminUpdateAppRequest {
  type?: AppType;
}

export interface LoginRequest {
  username: string;
  password: string;
}

export interface RegisterRequest {
  username: string;
  password: string;
  displayName: string;
}

export interface RegisterResponse {
  accessToken?: string;
  user: PublicUser;
}

export interface ApiKeyLoginRequest {
  apiKey: string;
}

export interface CliLoginStartResponse {
  requestId: string;
  pollToken: string;
  loginUrl: string;
  expiresAt: string;
  pollIntervalMs: number;
}

export interface CliLoginPollRequest {
  requestId: string;
  pollToken: string;
}

export interface CliLoginPendingResponse {
  status: 'pending';
  expiresAt: string;
}

export type CliLoginPollResponse = LoginResponse | CliLoginPendingResponse;

export interface CliLoginStatusResponse {
  status: 'pending' | 'approved' | 'expired';
  expiresAt: string;
}

export interface CliLoginApproveRequest {
  requestId: string;
}

export interface CliLoginApproveResponse {
  success: boolean;
}

export interface CliApiKeyStatusResponse {
  hasKey: boolean;
  prefix?: string;
  createdAt?: string;
  lastUsedAt?: string | null;
}

export interface CreateCliApiKeyResponse {
  apiKey: string;
  prefix: string;
  createdAt: string;
}

export interface CreateUserRequest {
  username: string;
  password: string;
  role: 'USER' | 'CREATOR' | 'ADMIN';
}

export interface SetProfileAssetRequest {
  assetRef: string;
}

export interface SetProfileAssetResponse {
  selectedProfileAssetRef: string;
}

// ============================================================================
// API Response Types
// ============================================================================

export interface ApiErrorResponse {
  error: string;
  message?: string;
}

export interface AppResponse {
  id?: number;
  name: string;
  displayName: string;
  description: string;
  creatorId?: number;
  creatorUsername: string;
  createdAt: string;
  updatedAt: string;
  type: AppType;
  emoji?: string | null;
  color?: string | null;
  lastPlayedAt?: string;

  // Version info (from currentVersion)
  /** Current version string (e.g., "1.2.3"), null if no versions exist */
  currentVersion?: string | null;
  /** Hosting mode of current version */
  hostingMode?: AppHostingMode;
  /** Visibility of current version */
  visibility?: AppVersionVisibility;
  /** Base URL for loading the app (from current version) */
  assetUrl: string | null;
  /** Entry point file within assetUrl */
  entryPoint?: string | null;
  /** Surface targets from current version (undefined for draft apps with no version) */
  surfaceTargets?: AppSurface[];

  // HOSTED mode fields (from current version)
  bundleSize?: number | null;
  sourceUrl?: string | null;
  hasEcs?: boolean;
  hasServer?: boolean;

  // Listing URLs (from current version)
  iconUrl?: string | null;
  heroPortraitUrl?: string | null;
  heroLandscapeUrl?: string | null;
  screenshotPortraitUrls?: string[];
  screenshotLandscapeUrls?: string[];
  videoPortraitUrls?: string[];
  videoLandscapeUrls?: string[];
  viewerSaved?: boolean;
  viewerLiked?: boolean;
  likeCount?: number;
  viewCount?: number;
  playCount?: number;
  commentCount?: number;
  remixCount?: number;
}

export type AdminAppResponse = AppResponse;

export interface AdminAppsListResponse {
  apps: AdminAppResponse[];
}

export interface PublicUser {
  id: number;
  username: string;
  displayName: string;
  role: 'USER' | 'CREATOR' | 'ADMIN';
  selectedProfileAssetRef: string;
  profileAssetPreviewUrl: string;
  bio: string | null;
  youtubeUsername: string | null;
  githubUsername: string | null;
  websiteUrl: string | null;
  xUsername: string | null;
  xProfileImageUrl: string | null;
  googleEmail: string | null;
  googleProfileImageUrl: string | null;
  followerCount: number;
  followingCount: number;
  viewerFollowing?: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface MeUser extends PublicUser {
  creditBalance: number;
  ownedAssetsCount: number;
  hasPassword: boolean;
  followingCreatorsCount: number;
  unreadNotificationsCount: number;
  creatorQuota?: CreatorQuotaResponse | null;
}

export interface CreatorQuotaLimitsResponse {
  maxAppsPerCreator: number;
  maxAssetPacksPerCreator: number;
  maxAssetsPerCreator: number;
  maxStoredContentBytes: number;
  maxVersionsPerApp: number;
  maxVersionsPerAsset: number;
  maxVersionsPerAssetPack: number;
}

export interface CreatorQuotaUsageResponse {
  appCount: number;
  assetPackCount: number;
  assetCount: number;
  storedContentBytes: number;
}

export interface CreatorQuotaResponse {
  tier: 'CREATOR' | 'ADMIN';
  limits: CreatorQuotaLimitsResponse;
  usage: CreatorQuotaUsageResponse;
}

export type AdminUserDetail = MeUser;

export interface UpdateProfileRequest {
  displayName?: string;
  bio?: string | null;
  youtubeUsername?: string | null;
  githubUsername?: string | null;
  websiteUrl?: string | null;
}

export interface UpdateProfileResponse {
  user: MeUser;
}

export interface ChangePasswordRequest {
  currentPassword?: string;  // Optional: not required when user has no password (OAuth-only)
  newPassword: string;
}

export interface ChangePasswordResponse {
  success: boolean;
}

export interface DeleteMyAccountRequest {
  username: string;
  currentPassword?: string;
}

export interface DeleteMyAccountResponse {
  success: boolean;
}

export interface PrivacyExportLinkedAccount {
  provider: 'PASSWORD' | 'GOOGLE' | 'X';
  identifier: string | null;
}

export interface PrivacyExportFollowedCreator {
  username: string;
  displayName: string;
  followedAt: string;
  latestPublishedAt: string | null;
}

export interface PrivacyExportSavedItem {
  kind: SavedItemKind;
  creatorUsername: string;
  itemName: string;
  displayName: string;
  savedAt: string;
}

export interface PrivacyExportComment {
  id: number;
  kind: SavedItemKind;
  creatorUsername: string;
  itemName: string;
  parentCommentId: number | null;
  body: string;
  deletedAt: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface PrivacyExportPublishedApp {
  name: string;
  displayName: string;
  type: AppType;
  createdAt: string;
  updatedAt: string;
}

export interface PrivacyExportPublishedAsset {
  name: string;
  displayName: string;
  category: AssetCategory;
  createdAt: string;
  updatedAt: string;
}

export interface PrivacyExportPublishedPack {
  name: string;
  displayName: string;
  createdAt: string;
  updatedAt: string;
}

export interface PrivacyExportAiGenerationJob {
  id: string;
  modality: AiGenerationType;
  status: 'PENDING' | 'RUNNING' | 'SUCCESS' | 'FAILURE';
  requestPrompt: string;
  requestPayload: unknown;
  resultData: unknown;
  errorCode: string | null;
  errorMessage: string | null;
  linkedGenerationId: string | null;
  createdAt: string;
  updatedAt: string;
  startedAt: string | null;
  completedAt: string | null;
  failedAt: string | null;
}

export interface PrivacyExportResponse {
  exportedAt: string;
  account: MeUser;
  linkedAccounts: PrivacyExportLinkedAccount[];
  followedCreators: PrivacyExportFollowedCreator[];
  savedItems: PrivacyExportSavedItem[];
  comments: PrivacyExportComment[];
  notifications: UserNotificationResponse[];
  creditTransactions: CreditTransaction[];
  iapReceipts: IapReceipt[];
  aiActivity: {
    generations: AiGenerationDetail[];
    jobs: PrivacyExportAiGenerationJob[];
  };
  publishedContent: {
    apps: PrivacyExportPublishedApp[];
    assets: PrivacyExportPublishedAsset[];
    packs: PrivacyExportPublishedPack[];
  };
}

export interface UnlinkXResponse {
  success: boolean;
}

export interface UnlinkGoogleResponse {
  success: boolean;
}

export type AppleOAuthProvider = 'google' | 'x';

export interface AppleOAuthLinkStartRequest {
  provider: AppleOAuthProvider;
}

export interface AppleOAuthLinkStartResponse {
  startUrl: string;
}

export interface AppleOAuthHandoffExchangeRequest {
  token: string;
}

export type AppleOAuthHandoffExchangeResponse = LoginResponse;

export interface GoogleAppleSignInRequest {
  idToken: string;
}

export interface GoogleAppleLoginResponse {
  result: 'login';
  accessToken: string;
  user: PublicUser;
}

export interface GoogleAppleSignupResponse {
  result: 'signup';
  pendingToken: string;
}

export type GoogleAppleSignInResponse =
  | GoogleAppleLoginResponse
  | GoogleAppleSignupResponse;

export interface GoogleAppleLinkRequest {
  idToken: string;
}

export interface GoogleAppleLinkResponse {
  success: boolean;
}

export interface GooglePendingSignupResponse {
  googleEmail: string;
  googleName: string | null;
  googlePicture: string | null;
  suggestedUsername: string;
  suggestedDisplayName: string;
  usernameAvailable: boolean;
}

export interface UsernameAvailableResponse {
  available: boolean;
}

export interface CompleteGoogleSignupRequest {
  pendingToken: string;
  username: string;
  displayName: string;
}

export interface CompleteGoogleSignupResponse {
  accessToken?: string;
  user: PublicUser;
}

export interface XPendingSignupResponse {
  xUsername: string;
  xName: string | null;
  xProfileImageUrl: string | null;
  suggestedUsername: string;
  suggestedDisplayName: string;
  usernameAvailable: boolean;
}

export interface CompleteXSignupRequest {
  pendingToken: string;
  username: string;
  displayName: string;
}

export interface CompleteXSignupResponse {
  accessToken?: string;
  user: PublicUser;
}

export interface GoogleOneTapExchangeRequest {
  credential: string;
  nextPath?: string | null;
}

export interface GoogleOneTapLoginResponse {
  result: 'login';
  accessToken?: string;
  user: PublicUser;
}

export interface GoogleOneTapSignupResponse {
  result: 'signup';
  pendingToken: string;
}

export type GoogleOneTapExchangeResponse =
  | GoogleOneTapLoginResponse
  | GoogleOneTapSignupResponse;

export interface UpgradeToCreatorResponse {
  user: MeUser;
}

export type UserResponse = PublicUser;

// ============================================================================
// API Response Wrappers
// ============================================================================

export interface AppsListResponse {
  apps: AppResponse[];
  pagination?: PaginationMeta;
}

export interface AppDetailResponse {
  app: AppResponse;
}

type RemixRelatedItemSummaryBase = {
  creatorUsername: string;
  name: string;
  displayName: string | null;
  linkedVersionRef: string | null;
};

export type RemixRelatedItemSummary =
  | ({
      kind: 'APP';
      appType: AppType;
    } & RemixRelatedItemSummaryBase)
  | ({
      kind: 'ASSET';
    } & RemixRelatedItemSummaryBase)
  | ({
      kind: 'PACK';
    } & RemixRelatedItemSummaryBase);

export interface ContentRemixRelationsResponse {
  remixedFrom: RemixRelatedItemSummary[];
  remixedBy: RemixRelatedItemSummary[];
}

export interface AppAccessTokenResponse {
  appAccessToken: string;
  appId: number;
}

export type LogSeverity = 'debug' | 'info' | 'warn' | 'error';

export interface AppLogEntryContext {
  appName?: string | null;
  creatorUsername?: string | null;
  viewerId?: number | null;
  viewerUsername?: string | null;
}

export interface AppLogEntryRequest {
  severity: LogSeverity;
  message: string;
  payload?: unknown;
  context?: AppLogEntryContext;
}

export interface AppLogEntryResponse {
  success: boolean;
}

export interface CreateAppResponse {
  app: AppResponse;
  templateUrl: string;
  sourceArchiveUrl?: string;
}

export type RemixScaffoldMode = 'archive' | 'inline-html' | 'external-metadata-only';

export interface ExternalRemixScaffoldMetadata {
  name: string;
  displayName: string;
  description: string;
  creatorUsername: string;
  type: AppType;
  emoji: string | null;
  color: string | null;
  surfaceTargets: AppSurface[];
}

export interface ArchiveRemixScaffoldResponse {
  remixMode: 'archive';
  html?: string | null;
  metadata?: Record<string, unknown>;
  archiveUrl: string;
  externalListingUrl?: string;
}

export interface InlineHtmlRemixScaffoldResponse {
  remixMode: 'inline-html';
  html: string;
  metadata?: Record<string, unknown>;
  archiveUrl?: string;
  externalListingUrl?: string;
}

export interface ExternalMetadataOnlyRemixScaffoldResponse {
  remixMode: 'external-metadata-only';
  html?: string | null;
  metadata: ExternalRemixScaffoldMetadata;
  archiveUrl?: string;
  externalListingUrl: string;
}

export type RemixScaffoldResponse =
  | ArchiveRemixScaffoldResponse
  | InlineHtmlRemixScaffoldResponse
  | ExternalMetadataOnlyRemixScaffoldResponse;

export interface TemplateScaffoldResponse {
  html: string;
  metadata?: Record<string, unknown>;
  archiveUrl?: string;
}

export interface UploadAppResponse {
  app: AppResponse;
}

export interface UpdateAppResponse {
  app: AppResponse;
  fileUnchanged?: boolean;
  metadataUnchanged?: boolean;
  sourceUnchanged?: boolean;
}

export interface AdminUpdateAppResponse {
  app: AdminAppResponse;
}

export interface ProfileAssetSummary {
  assetRef: string;
  assetId: number;
  name: string;
  displayName: string;
  previewUrl: string;
  meshUrl: string;
  boxelUrl: string;
}

export interface OwnedProfileAssetsResponse {
  assets: ProfileAssetSummary[];
}

export interface PaginationMeta {
  limit: number;
  offset: number;
  count: number;
  hasMore: boolean;
}

// ============================================================================
// Feedback
// ============================================================================

export interface FeedbackEntry {
  id: number;
  userId: number;
  username: string;
  source: string;
  version: string | null;
  build: string | null;
  title: string;
  comment: string;
  createdAt: string;
}

export interface SubmitFeedbackRequest {
  title: string;
  comment: string;
  source: string;
  version?: string | null;
  build?: string | null;
}

export interface SubmitFeedbackResponse {
  feedback: FeedbackEntry;
}

export interface FeedbackListResponse {
  feedback: FeedbackEntry[];
  pagination: PaginationMeta;
}

export interface DeleteFeedbackResponse {
  success: boolean;
}

export interface LoginResponse {
  accessToken?: string;
  user: PublicUser;
}

export interface LogoutResponse {
  success: boolean;
}

export interface PublicUserResponse {
  user: PublicUser;
}

export interface MeResponse {
  user: MeUser;
}

export interface AdminUserResponse {
  user: AdminUserDetail;
}

export type UserDetailResponse = PublicUserResponse;

export const SEARCH_RESULT_KIND_VALUES = ['creator', 'app', 'asset', 'pack'] as const;
export type SearchResultKind = typeof SEARCH_RESULT_KIND_VALUES[number];

export const SEARCH_KIND_VALUES = ['all', ...SEARCH_RESULT_KIND_VALUES] as const;
export type SearchKind = typeof SEARCH_KIND_VALUES[number];

export const SEARCH_MODE_VALUES = ['grouped', 'flat'] as const;
export type SearchMode = typeof SEARCH_MODE_VALUES[number];

export const SEARCH_ASSET_TYPE_VALUES = ['image', 'video', 'audio', 'song', 'sfx', '3d'] as const;
export type SearchAssetType = typeof SEARCH_ASSET_TYPE_VALUES[number];

export interface SearchRequest {
  q: string;
  mode?: SearchMode;
  kind?: SearchKind;
  page?: number;
  pageSize?: number;
  appType?: AppType;
  assetType?: SearchAssetType;
  assetCategory?: AssetCategory;
  assetSubcategory?: string;
  packContainsCategory?: AssetCategory;
  packContainsSubcategory?: string;
}

export interface SearchSuggestRequest {
  q: string;
}

export interface SearchCountsByKind {
  creator: number;
  app: number;
  asset: number;
  pack: number;
  total: number;
}

export interface SearchTabCounts {
  topResults: number;
  creators: number;
  apps: number;
  demos: number;
  tools: number;
  templates: number;
  images: number;
  videos: number;
  audio: number;
  songs: number;
  sfx: number;
  models3d: number;
  packs: number;
}

// Creator info for home page collections
export interface HomeCreatorResponse {
  id: number;
  username: string;
  displayName: string;
  profileAssetPreviewUrl: string | null;
  xProfileImageUrl: string | null;
  googleProfileImageUrl: string | null;
  createdAt?: string;
  viewerFollowing?: boolean;
}

export const SAVED_ITEM_KIND_VALUES = ['APP', 'ASSET', 'PACK'] as const;
export type SavedItemKind = typeof SAVED_ITEM_KIND_VALUES[number];

export const ENGAGEMENT_EVENT_TYPE_VALUES = [
  'VIEW',
  'LAUNCH',
  'PLAY',
  'DOWNLOAD',
  'LIKE',
  'UNLIKE',
  'SAVE',
  'UNSAVE',
  'FOLLOW',
  'UNFOLLOW',
] as const;
export type EngagementEventType = typeof ENGAGEMENT_EVENT_TYPE_VALUES[number];

export const ENGAGEMENT_TARGET_KIND_VALUES = ['CREATOR', 'APP', 'ASSET', 'PACK'] as const;
export type EngagementTargetKind = typeof ENGAGEMENT_TARGET_KIND_VALUES[number];

export const NOTIFICATION_EVENT_TYPE_VALUES = [
  'NEW_CONTENT',
  'UPDATED',
  'CONTENT_COMMENT',
  'CONTENT_REPLY',
  'CONTENT_LIKE',
  'NEW_FOLLOWER',
  'ASSET_PURCHASED',
  'PAYMENT_SUCCEEDED',
  'PAYMENT_REFUNDED',
  'ADMIN_ACTION',
  'AI_JOB_SUCCEEDED',
  'AI_JOB_FAILED',
] as const;
export type NotificationEventType = typeof NOTIFICATION_EVENT_TYPE_VALUES[number];

export const LIBRARY_CATEGORY_VALUES = [
  'games',
  'demos',
  'tools',
  'templates',
  'images',
  'music',
  'sfx',
  'videos',
  '3d',
  'packs',
] as const;
export type LibraryCategory = typeof LIBRARY_CATEGORY_VALUES[number];

export const LIBRARY_SORT_VALUES = ['saved_desc', 'alpha_asc'] as const;
export type LibrarySort = typeof LIBRARY_SORT_VALUES[number];

export const FOLLOWING_SORT_VALUES = ['activity_desc', 'alpha_asc'] as const;
export type FollowingSort = typeof FOLLOWING_SORT_VALUES[number];

export const NOTIFICATION_STATUS_VALUES = ['all', 'unread'] as const;
export type NotificationStatus = typeof NOTIFICATION_STATUS_VALUES[number];

export const NOTIFICATION_PREVIEW_KIND_VALUES = ['item', 'person', 'credit', 'account'] as const;
export type NotificationPreviewKind = typeof NOTIFICATION_PREVIEW_KIND_VALUES[number];

export const FOLLOWING_APP_SECTION_VALUES = ['games', 'demos', 'tools', 'templates'] as const;
export type FollowingAppSection = typeof FOLLOWING_APP_SECTION_VALUES[number];

export const FOLLOWING_FEED_SECTION_VALUES = [
  ...FOLLOWING_APP_SECTION_VALUES,
  'images',
  'music',
  'sfx',
  'videos',
  '3d',
  'packs',
] as const;
export type FollowingFeedSection = typeof FOLLOWING_FEED_SECTION_VALUES[number];

export interface SavedAppItem {
  kind: 'APP';
  savedAt: string;
  app: AppResponse;
}

export interface SavedAssetItem {
  kind: 'ASSET';
  savedAt: string;
  asset: AssetResponse;
}

export interface SavedPackItem {
  kind: 'PACK';
  savedAt: string;
  pack: AssetPackResponse;
}

export type LibraryItem = SavedAppItem | SavedAssetItem | SavedPackItem;

export type LibraryCounts = Record<LibraryCategory, number>;

export interface LibraryResponse {
  category: LibraryCategory;
  sort: LibrarySort;
  counts: LibraryCounts;
  items: LibraryItem[];
}

export interface TrackEngagementEventRequest {
  eventType: EngagementEventType;
  targetKind: EngagementTargetKind;
  creatorUsername: string;
  itemName?: string;
}

export interface TrackEngagementEventResponse {
  recorded: boolean;
}

export interface FollowedCreatorResponse extends HomeCreatorResponse {
  followedAt: string;
  latestPublishedAt: string | null;
}

export interface FollowingCreatorsResponse {
  creators: FollowedCreatorResponse[];
}

export interface FollowingAppsFeedResponse {
  section: FollowingAppSection;
  apps: AppResponse[];
}

export interface FollowingAssetsFeedResponse {
  section: HomeAssetSectionKey;
  assets: AssetResponse[];
}

export interface FollowingPacksFeedResponse {
  section: 'packs';
  packs: AssetPackResponse[];
}

export type FollowingFeedResponse =
  | FollowingAppsFeedResponse
  | FollowingAssetsFeedResponse
  | FollowingPacksFeedResponse;

export interface CreatorSearchResult {
  kind: 'creator';
  targetPath: string;
  creator: HomeCreatorResponse;
}

export interface AppSearchResult {
  kind: 'app';
  targetPath: string;
  app: AppResponse;
}

export interface AssetSearchResult {
  kind: 'asset';
  targetPath: string;
  asset: AssetResponse;
}

export interface AssetPackSearchResult {
  kind: 'pack';
  targetPath: string;
  pack: AssetPackResponse;
}

export type SearchResult =
  | CreatorSearchResult
  | AppSearchResult
  | AssetSearchResult
  | AssetPackSearchResult;

export interface SearchGroupedResults {
  creators: CreatorSearchResult[];
  apps: AppSearchResult[];
  assets: AssetSearchResult[];
  packs: AssetPackSearchResult[];
}

export interface SearchResponse {
  q: string;
  mode: SearchMode;
  kind: SearchKind;
  countsByKind: SearchCountsByKind;
  tabCounts: SearchTabCounts;
  groups?: SearchGroupedResults;
  results?: SearchResult[];
  pagination?: PaginationMeta;
}

export interface SearchSuggestResponse {
  q: string;
  countsByKind: SearchCountsByKind;
  groups: SearchGroupedResults;
}

export interface SavedItemMutationResponse {
  saved: boolean;
}

export interface LikedItemMutationResponse {
  liked: boolean;
}

export interface ContentCommentAuthor {
  id: number;
  username: string;
  displayName: string;
}

export interface ContentCommentNode {
  id: number;
  kind: SavedItemKind;
  parentCommentId: number | null;
  body: string;
  isDeleted: boolean;
  authorIsCreator: boolean;
  canDelete: boolean;
  createdAt: string;
  updatedAt: string;
  likeCount: number;
  viewerLiked?: boolean;
  author: ContentCommentAuthor;
  replies: ContentCommentNode[];
}

export interface ContentCommentsResponse {
  comments: ContentCommentNode[];
}

export interface CreateContentCommentRequest {
  body: string;
  parentCommentId?: number | null;
}

export interface CreateContentCommentResponse {
  comment: ContentCommentNode;
}

export interface DeleteContentCommentResponse {
  success: boolean;
}

export interface CreatorFollowMutationResponse {
  following: boolean;
}

export type NotificationMetadata = Record<string, unknown>;

export interface UserNotificationResponse {
  id: number;
  eventType: NotificationEventType;
  title: string;
  body: string;
  targetPath: string;
  previewImageUrl?: string | null;
  previewKind?: NotificationPreviewKind | null;
  itemKind?: SavedItemKind | null;
  creator?: HomeCreatorResponse | null;
  actor?: HomeCreatorResponse | null;
  itemCreatorUsername?: string | null;
  itemName?: string | null;
  itemDisplayName?: string | null;
  appType?: AppType | null;
  assetCategory?: AssetCategory | null;
  assetSubcategory?: string | null;
  metadata?: NotificationMetadata | null;
  createdAt: string;
  readAt: string | null;
}

export interface NotificationsResponse {
  notifications: UserNotificationResponse[];
  unreadCount: number;
  pagination: PaginationMeta;
}

export interface NotificationReadResponse {
  success: boolean;
  unreadCount: number;
}

export interface WebPushSubscriptionKeys {
  p256dh: string;
  auth: string;
}

export interface WebPushSubscriptionObject {
  endpoint: string;
  expirationTime: number | null;
  keys: WebPushSubscriptionKeys;
}

export interface WebPushConfigResponse {
  vapidPublicKey: string;
}

export interface UpsertWebPushSubscriptionRequest {
  subscription: WebPushSubscriptionObject;
}

export interface WebPushSubscriptionStatusResponse {
  subscribed: boolean;
}

export interface PushSubscriptionMutationResponse {
  success: boolean;
  subscribed: boolean;
}

export type ApplePushEnvironment = 'development' | 'production';

export interface ApplePushDeviceRequest {
  deviceToken: string;
  apnsEnvironment: ApplePushEnvironment;
}

export interface ApplePushDeviceStatusResponse {
  subscribed: boolean;
}

// Base fields shared by all home collection types
interface HomeCollectionBase {
  id: string;
  title: string;
  description?: string | null;
  metadata?: Record<string, unknown> | null;
}

// Collection of apps
export interface AppsHomeCollection extends HomeCollectionBase {
  type: 'apps';
  apps: AppResponse[];
}

// Collection of creators
export interface CreatorsHomeCollection extends HomeCollectionBase {
  type: 'creators';
  creators: HomeCreatorResponse[];
}

// Discriminated union of all collection types
export type HomeCollection = AppsHomeCollection | CreatorsHomeCollection;

export interface HomeCollectionsResponse {
  section: 'games';
  collections: HomeCollection[];
}

export type HomeAssetSectionKey = 'images' | 'music' | 'sfx' | 'videos' | '3d';
export type HomeSectionKey = 'games' | HomeAssetSectionKey | 'packs';

export interface HomeAssetsSectionResponse {
  section: HomeAssetSectionKey;
  assets: AssetResponse[];
  pagination: PaginationMeta;
}

export interface HomePacksSectionResponse {
  section: 'packs';
  packs: AssetPackResponse[];
  pagination: PaginationMeta;
}

export type HomeResponse = HomeCollectionsResponse | HomeAssetsSectionResponse | HomePacksSectionResponse;

export interface FetchHomeOptions {
  section?: HomeSectionKey;
  limit?: number;
  offset?: number;
}

export interface MyAppsResponse {
  apps: AppResponse[];
  pagination?: PaginationMeta;
}

export interface DeleteAppResponse {
  success: boolean;
}

export interface UsersListResponse {
  users: AdminUserDetail[];
}

export interface CreateUserResponse {
  user: AdminUserDetail;
}

export interface UpdateAdminUserRequest {
  role?: 'USER' | 'CREATOR' | 'ADMIN';
  displayName?: string;
  creditDelta?: number;
  bio?: string | null;
  youtubeUsername?: string | null;
  githubUsername?: string | null;
  websiteUrl?: string | null;
  // X OAuth credentials (admin can set/update these)
  xUserId?: string | null;
  xUsername?: string | null;
  xProfileImageUrl?: string | null;
}

export interface DeleteAdminUserResponse {
  success: boolean;
}

export interface BatchCreateUsersResponse {
  created: number;
  skipped: number;
  errors: number;
  details: Array<{
    xUsername: string;
    status: 'created' | 'skipped' | 'error';
    message?: string;
  }>;
}

export interface BootstrapResponse {
  readmeUri: string;
  agentsUri: string;
  catalogue?: string;
}

// ============================================================================
// Validation Helpers
// ============================================================================

export function isPaginationMeta(value: unknown): value is PaginationMeta {
  if (typeof value !== 'object' || value === null) {
    return false;
  }
  const meta = value as Record<string, unknown>;
  const limit = meta['limit'];
  const offset = meta['offset'];
  const count = meta['count'];
  const hasMore = meta['hasMore'];
  return (
    Number.isInteger(limit)
    && Number.isInteger(offset)
    && Number.isInteger(count)
    && (limit as number) >= 0
    && (offset as number) >= 0
    && (count as number) >= 0
    && typeof hasMore === 'boolean'
  );
}

// ============================================================================
// Client Error Types
// ============================================================================

export class UnsupportedClientError extends Error {
  code: string;
  details: Record<string, unknown> | null;

  constructor(code: string, message: string, details: Record<string, unknown> | null = null) {
    super(message);
    this.name = 'UnsupportedClientError';
    this.code = code;
    this.details = details;
  }
}

// Shop and Credit types
export interface CreditPack {
  sku: string;
  name: string;
  amount: number;
  cost: number;
}

export interface ShopCollection {
  id: string;
  title: string;
  items: ShopItem[];
}

export type ShopItem =
  | {
      type: 'credit_pack';
      id: string;
      sku: string;
      name: string;
      amount: number;
      costCents: number;
    }
  | {
      type: 'asset';
      id: string;
      assetId: number;
      assetRef: string;
      name: string;
      displayName: string;
      category: string;
      subcategory: string;
      previewUrl: string | null;
      priceCredits: number;
      owned: boolean;
      creatorUsername: string;
    };

export interface ShopResponse {
  collections: ShopCollection[];
}

export interface AdminCreditPack {
  sku: string;
  displayName: string;
  amount: number;
  costCents: number;
  stripeProductId: string | null;
  stripePriceId: string | null;
  createdAt: string;
  updatedAt: string;
}

export type PaymentProvider = 'STRIPE' | 'APPLE_IAP';
export type PaymentStatus = 'PENDING' | 'AUTHORIZED' | 'SUCCEEDED' | 'FULFILLED' | 'FAILED' | 'CANCELLED' | 'REFUNDED';
export type PaymentEventProcessStatus = 'PENDING' | 'PROCESSED' | 'FAILED';
export type PaymentRefundStatus = 'PENDING' | 'SUCCEEDED' | 'FAILED' | 'CANCELLED';

export interface CreditPacksResponse {
  creditPacks: AdminCreditPack[];
}

export interface CreditPackResponse {
  creditPack: AdminCreditPack;
}

export type CreditTransactionDirection = 'IN' | 'OUT';
export type CreditTransactionKind = 'CONSUMABLE' | 'ENTITLEMENT';
export type CreditTransactionStatus = 'PENDING' | 'AUTHORIZED' | 'CONSUMED' | 'GRANTED' | 'CANCELLED';
export type CreditTransactionType = 'CREDIT_PACK' | 'ASSET' | 'IN_APP' | 'AI_SERVICE' | 'ADMIN_GRANT';

export interface CreditTransaction {
  id: number;
  sourceId: number;
  sourceName: string;
  paymentId?: number | null;
  type: string;
  kind: CreditTransactionKind;
  status: CreditTransactionStatus;
  displayName: string;
  sku: string | null;
  amount: number;
  direction: CreditTransactionDirection;
  netAmount: number;
  buyer: string;
  seller: string;
  createdAt: string;
  updatedAt: string;
}

export interface TransactionsResponse {
  transactions: CreditTransaction[];
}

export interface AdminCreditTransaction {
  id: number;
  sourceId: number;
  sourceName: string;
  paymentId?: number | null;
  type: CreditTransactionType;
  kind: CreditTransactionKind;
  status: CreditTransactionStatus;
  displayName: string;
  sku: string | null;
  amount: number;
  buyerId: number;
  buyer: string;
  sellerId: number;
  seller: string;
  createdAt: string;
  updatedAt: string;
}

export interface AdminCreditTransactionsResponse {
  transactions: AdminCreditTransaction[];
  pagination: PaginationMeta;
}

export interface IapReceipt {
  id: number;
  type: string;
  kind: CreditTransactionKind;
  status: CreditTransactionStatus;
  displayName: string;
  sku: string | null;
  amount: number;
  sourceId: number;
  sourceName: string;
  buyerId: number;
  buyer: string;
  sellerId: number;
  seller: string;
  createdAt: string;
  updatedAt: string;
}

export interface IapReceiptsResponse {
  receipts: IapReceipt[];
  pagination: PaginationMeta;
}

export interface IapPurchaseRequest {
  appId: number;
  kind: 'consumable' | 'entitlement';
  sku: string;
  displayName: string;
  priceCredits: number;
}

export type AiGenerationType = 'TEXT' | 'JSON' | 'IMAGE' | 'MUSIC' | 'SFX' | 'VIDEO' | 'MODEL_3D';
export type AiGenerationStatus = 'SUCCESS' | 'FAILURE';
export type AiGenerationPaidBy = 'USER' | 'CREATOR';

export interface AiGenerationSummary {
  id: string;
  createdAt: string;
  userId: number | null;
  username: string | null;
  creatorId: number | null;
  creatorUsername: string | null;
  sourceId: number | null;
  sourceName: string | null;
  type: AiGenerationType;
  status: AiGenerationStatus;
  provider: string;
  model: string;
  amount: number;
  paidBy: AiGenerationPaidBy;
  transactionId: number | null;
}

export interface AiGenerationDetail extends AiGenerationSummary {
  inputData: unknown;
  inputAssets: string[];
  outputData: unknown;
  outputAssets: string[];
  errorCode: string | null;
  errorMessage: string | null;
  transaction: AdminCreditTransaction | null;
}

export interface AiGenerationsResponse {
  generations: AiGenerationSummary[];
  pagination: PaginationMeta;
}

export interface AiGenerationDetailResponse {
  generation: AiGenerationDetail;
}

export interface IapPurchaseResponse {
  receipt: IapReceipt;
  creditBalance: number;
}

export interface IapReceiptResponse {
  receipt: IapReceipt;
}

export interface IapReceiptListParams {
  kind?: 'consumable' | 'entitlement';
  status?: CreditTransactionStatus | CreditTransactionStatus[];
  from?: string | Date;
  to?: string | Date;
  appId?: number;
  limit?: number;
  offset?: number;
}

export interface AssetPurchaseRequest {
  type: 'asset';
  assetRef: string;
}

export type PurchaseRequest = AssetPurchaseRequest;

export interface CreditPackCheckoutSessionRequest {
  nextPath?: string;
}

export interface CreditPackCheckoutSessionResponse {
  checkoutSessionId: string;
  checkoutUrl: string;
  expiresAt: string | null;
  paymentId?: number;
  provider?: PaymentProvider;
  isReturningCustomer?: boolean;
}

export interface CreditPackCheckoutStatusResponse {
  checkoutSessionId: string;
  fulfilled: boolean;
  paymentStatus: string;
  transactionId: number | null;
  creditBalance: number | null;
  paymentId?: number | null;
  provider?: PaymentProvider;
  providerPaymentId?: string | null;
}

export interface AdminPaymentSummary {
  id: number;
  provider: PaymentProvider;
  status: PaymentStatus;
  userId: number;
  username: string;
  userCreditBalance: number;
  creditPackSku: string | null;
  creditPackDisplayName: string | null;
  currency: string;
  amountCents: number;
  providerPaymentId: string | null;
  providerIntentId: string | null;
  providerChargeId: string | null;
  providerPaymentDashboardUrl: string | null;
  providerIntentDashboardUrl: string | null;
  providerChargeDashboardUrl: string | null;
  fulfilledCreditTransactionId: number | null;
  failureCode: string | null;
  failureMessage: string | null;
  refundCount: number;
  refundedAmountCents: number;
  createdAt: string;
  updatedAt: string;
}

export interface AdminPaymentEvent {
  id: number;
  provider: PaymentProvider;
  providerEventId: string;
  eventType: string;
  signatureVerified: boolean;
  processStatus: PaymentEventProcessStatus;
  processError: string | null;
  processedAt: string | null;
  createdAt: string;
}

export interface AdminPaymentRefund {
  id: number;
  paymentId: number;
  provider: PaymentProvider;
  providerRefundId: string | null;
  providerRefundDashboardUrl: string | null;
  amountCents: number;
  status: PaymentRefundStatus;
  reason: string | null;
  initiatedByAdminUserId: number;
  initiatedByAdminUsername: string;
  reversalCreditTransactionId: number | null;
  postRefundCreditBalance: number | null;
  debtAmount: number | null;
  createdAt: string;
  updatedAt: string;
}

export interface AdminPaymentDetail extends AdminPaymentSummary {
  events: AdminPaymentEvent[];
  refunds: AdminPaymentRefund[];
}

export interface AdminPaymentsListResponse {
  payments: AdminPaymentSummary[];
  pagination: PaginationMeta;
}

export interface AdminPaymentDetailResponse {
  payment: AdminPaymentDetail;
}

export interface AdminRefundPaymentRequest {
  reason?: string | null;
}

export interface PurchaseResponse {
  success: boolean;
  transaction: {
    id: number;
    amount: number;
    type: string;
    sku: string | null;
    createdAt: string;
  };
  creditBalance?: number;
  grantedAssetRef?: string | null;
}

export class ApiError extends Error {
  status: number;
  code?: string;

  constructor(message: string, status: number, code?: string) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    if (code !== undefined) {
      this.code = code;
    }
  }
}
