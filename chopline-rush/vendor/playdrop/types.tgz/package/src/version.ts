import type { AppSurface } from './app.js';

// ============================================================================
// Versioning Enums
// ============================================================================

export const APP_HOSTING_MODE_VALUES = ['HOSTED', 'EXTERNAL'] as const;

export type AppHostingMode = (typeof APP_HOSTING_MODE_VALUES)[number];

export const DEFAULT_APP_HOSTING_MODE: AppHostingMode = 'HOSTED';

export function isAppHostingMode(value: unknown): value is AppHostingMode {
  if (typeof value !== 'string') {
    return false;
  }
  return (APP_HOSTING_MODE_VALUES as readonly string[]).includes(value.trim().toUpperCase());
}

export function parseAppHostingMode(value: unknown): AppHostingMode | null {
  if (typeof value !== 'string') {
    return null;
  }
  const normalized = value.trim().toUpperCase();
  return isAppHostingMode(normalized) ? (normalized as AppHostingMode) : null;
}

export const APP_VERSION_VISIBILITY_VALUES = ['PRIVATE', 'PUBLIC'] as const;

export type AppVersionVisibility = (typeof APP_VERSION_VISIBILITY_VALUES)[number];

export const DEFAULT_APP_VERSION_VISIBILITY: AppVersionVisibility = 'PUBLIC';

export function isAppVersionVisibility(value: unknown): value is AppVersionVisibility {
  if (typeof value !== 'string') {
    return false;
  }
  return (APP_VERSION_VISIBILITY_VALUES as readonly string[]).includes(value.trim().toUpperCase());
}

export function parseAppVersionVisibility(value: unknown): AppVersionVisibility | null {
  if (typeof value !== 'string') {
    return null;
  }
  const normalized = value.trim().toUpperCase();
  return isAppVersionVisibility(normalized) ? (normalized as AppVersionVisibility) : null;
}

// ============================================================================
// Semantic Versioning
// ============================================================================

export interface SemVer {
  major: number;
  minor: number;
  patch: number;
}

/**
 * Regex for validating semantic version strings.
 * Format: Major.Minor.Patch where each is a non-negative integer.
 * Leading zeros are not allowed except for 0 itself.
 */
export const SEMVER_REGEX = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$/;

/**
 * Format a SemVer object as a string (e.g., "1.2.3").
 */
export function formatVersion(v: SemVer): string {
  return `${v.major}.${v.minor}.${v.patch}`;
}

/**
 * Parse a version string into a SemVer object.
 * Returns null if the string is not a valid semantic version.
 */
export function parseVersion(s: string): SemVer | null {
  const match = s.match(SEMVER_REGEX);
  if (!match) return null;
  const [, major, minor, patch] = match;
  if (!major || !minor || !patch) {
    return null;
  }
  return {
    major: parseInt(major, 10),
    minor: parseInt(minor, 10),
    patch: parseInt(patch, 10),
  };
}

/**
 * Check if a string is a valid semantic version.
 */
export function isValidVersion(s: string): boolean {
  return SEMVER_REGEX.test(s);
}

/**
 * Compare two SemVer objects.
 * Returns negative if a < b, positive if a > b, zero if equal.
 */
export function compareVersions(a: SemVer, b: SemVer): number {
  if (a.major !== b.major) return a.major - b.major;
  if (a.minor !== b.minor) return a.minor - b.minor;
  return a.patch - b.patch;
}

// ============================================================================
// Version API Types
// ============================================================================

/**
 * Response type for an app version.
 */
export interface AppVersionResponse {
  id: number;
  /** Formatted version string (e.g., "1.2.3") */
  version: string;
  major: number;
  minor: number;
  patch: number;
  /** Version-specific description */
  description?: string | null;
  /** Version-specific emoji */
  emoji?: string | null;
  /** Version-specific color */
  color?: string | null;
  releaseNotes?: string | null;
  visibility: AppVersionVisibility;
  hostingMode: AppHostingMode;
  createdAt: string;
  updatedAt: string;
  /** Base URL for the version (folder URL for HOSTED, externalUrl for EXTERNAL) */
  assetUrl: string;
  /** Entry point file within assetUrl (HOSTED only) */
  entryPoint: string;
  surfaceTargets: AppSurface[];

  // HOSTED mode only
  bundleSize?: number | null;
  sourceUrl?: string | null;
  hasEcs?: boolean;
  hasServer?: boolean;

  // Listing asset URLs (computed from paths)
  iconUrl?: string | null;
  heroPortraitUrl?: string | null;
  heroLandscapeUrl?: string | null;
  screenshotPortraitUrls?: string[];
  screenshotLandscapeUrls?: string[];
  videoPortraitUrls?: string[];
  videoLandscapeUrls?: string[];
}

/**
 * Minimal version info for list views.
 */
export interface AppVersionSummary {
  id: number;
  version: string;
  major: number;
  minor: number;
  patch: number;
  visibility: AppVersionVisibility;
  hostingMode: AppHostingMode;
  releaseNotes?: string | null;
  createdAt: string;
  /** Whether this is the current (live) version */
  isCurrent?: boolean;
}

/**
 * Request type for creating a new version.
 */
export interface CreateVersionRequest {
  /** Version string in Major.Minor.Patch format */
  version: string;
  releaseNotes?: string | null;
  visibility?: AppVersionVisibility;
  remixRef?: string;
  surfaceTargets?: AppSurface[];
  entryPoint?: string;
  /** Set this version as the current version (default: true) */
  setAsCurrent?: boolean;

  // HOSTED mode (default)
  // bundle, source, ecs, server are sent as multipart files

  // EXTERNAL mode
  externalUrl?: string;
}

/**
 * Request type for updating a version.
 */
export interface UpdateVersionRequest {
  releaseNotes?: string | null;
  visibility?: AppVersionVisibility;
  /** Set this version as the current version (requires visibility: PUBLIC) */
  setAsCurrent?: boolean;
}

/**
 * Response wrapper for version list.
 */
export interface AppVersionsListResponse {
  versions: AppVersionSummary[];
}

/**
 * Response wrapper for version detail.
 */
export interface AppVersionDetailResponse {
  version: AppVersionResponse;
}

export interface AppSourceBundleResponse {
  filename: string;
  sizeBytes: number;
  checksum?: string | null;
}

/**
 * Response wrapper for version creation.
 */
export interface CreateVersionResponse {
  version: AppVersionResponse;
  versionNodeId: string;
}

/**
 * Response wrapper for version update.
 */
export interface UpdateVersionResponse {
  version: AppVersionResponse;
}

/**
 * Response for version deletion.
 */
export interface DeleteVersionResponse {
  success: boolean;
}
