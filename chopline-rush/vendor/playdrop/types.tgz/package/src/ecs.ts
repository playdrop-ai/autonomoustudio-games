export type EcsFieldType = 'u8' | 'u16' | 'u32' | 'u64' | 'i8' | 'i16' | 'i32' | 'i64' | 'f32' | 'f64' | 'bool' | 'vec2' | 'vec3' | 'bytes';

export type EcsComponentField = {
  name: string;
  type: EcsFieldType;
};

/**
 * Component kind determines storage and synchronization behavior:
 * - static: Configuration that never changes after initial spawn
 * - versioned: Data that changes occasionally (not every tick), auto-increments version on mutation
 * - tick: Data that changes every tick, stored as tick buffer with history
 * - signal: Server-only components that auto-clear each tick, used for intents
 */
export type EcsComponentKind = 'static' | 'versioned' | 'tick' | 'signal';

export type EcsComponentConfig = {
  id: number;
  name: string;
  kind: EcsComponentKind;
  networked: boolean;
  input: boolean;
  fields: EcsComponentField[];
};

export type EcsSystemModule = {
  name: string;
  module: string;
};

export type EcsSystemEntry = string | EcsSystemModule;

export type EcsSystemsConfig = {
  serverStartup?: EcsSystemEntry[];
  serverSimulation: EcsSystemEntry[];
  clientStartup?: EcsSystemEntry[];
  clientSimulation: EcsSystemEntry[];
  clientPresentation: EcsSystemEntry[];
};

export type EcsConfig = {
  components: EcsComponentConfig[];
  systems: EcsSystemsConfig;
};

type PlainRecord = Record<string, unknown>;

function isPlainRecord(value: unknown): value is PlainRecord {
  return !!value && typeof value === 'object' && !Array.isArray(value);
}

function assert(condition: boolean, message: string): asserts condition {
  if (!condition) {
    throw new Error(message);
  }
}

function validateField(input: unknown, idx: number, componentName: string): EcsComponentField {
  assert(isPlainRecord(input), `component "${componentName}" field[${idx}] must be an object`);
  const { name, type } = input;
  assert(typeof name === 'string' && name.length > 0, `component "${componentName}" field[${idx}] must have a non-empty name`);
  assert(
    typeof type === 'string' &&
      (['u8', 'u16', 'u32', 'u64', 'i8', 'i16', 'i32', 'i64', 'f32', 'f64', 'bool', 'vec2', 'vec3', 'bytes'] as const).includes(type as EcsFieldType),
    `component "${componentName}" field "${name}" has invalid type "${String(type)}"`,
  );
  return { name, type: type as EcsFieldType };
}

function validateComponent(input: unknown, idx: number): EcsComponentConfig {
  assert(isPlainRecord(input), `component[${idx}] must be an object`);
  const { id, name, kind, networked, input: isInput, fields } = input;
  assert(Number.isInteger(id) && (id as number) > 0, `component[${idx}] id must be a positive integer`);
  assert(typeof name === 'string' && name.length > 0, `component[${idx}] must have a non-empty name`);
  assert(
    kind === 'static' || kind === 'versioned' || kind === 'tick' || kind === 'signal',
    `component "${name}" has invalid kind "${String(kind)}" (must be static, versioned, tick, or signal)`,
  );
  assert(typeof networked === 'boolean', `component "${name}" networked must be a boolean`);
  assert(typeof isInput === 'boolean', `component "${name}" input must be a boolean`);
  assert(Array.isArray(fields), `component "${name}" fields must be an array`);
  const validatedFields = fields.map((field, fieldIdx) => validateField(field, fieldIdx, name));
  return {
    id: id as number,
    name,
    kind: kind as EcsComponentKind,
    networked: networked as boolean,
    input: isInput as boolean,
    fields: validatedFields,
  };
}

function validateSystemEntry(entry: unknown, listName: string, idx: number): EcsSystemEntry {
  if (typeof entry === 'string') {
    assert(entry.length > 0, `${listName}[${idx}] must not be an empty string`);
    return entry;
  }
  assert(isPlainRecord(entry), `${listName}[${idx}] must be a string or an object`);
  const { name, module } = entry;
  assert(typeof name === 'string' && name.length > 0, `${listName}[${idx}] object must have a non-empty name`);
  assert(typeof module === 'string' && module.length > 0, `${listName}[${idx}] object must have a non-empty module`);
  return { name, module };
}

function validateSystems(systems: unknown): EcsSystemsConfig {
  assert(isPlainRecord(systems), 'systems must be an object');
  const { serverStartup, serverSimulation, clientStartup, clientSimulation, clientPresentation } = systems;
  // serverStartup and clientStartup are optional
  if (serverStartup !== undefined) {
    assert(Array.isArray(serverStartup), 'systems.serverStartup must be an array');
  }
  assert(Array.isArray(serverSimulation), 'systems.serverSimulation must be an array');
  if (clientStartup !== undefined) {
    assert(Array.isArray(clientStartup), 'systems.clientStartup must be an array');
  }
  assert(Array.isArray(clientSimulation), 'systems.clientSimulation must be an array');
  assert(Array.isArray(clientPresentation), 'systems.clientPresentation must be an array');
  return {
    ...(serverStartup
      ? {
          serverStartup: (serverStartup as unknown[]).map((entry, idx) =>
            validateSystemEntry(entry, 'systems.serverStartup', idx)
          )
        }
      : {}),
    serverSimulation: serverSimulation.map((entry, idx) => validateSystemEntry(entry, 'systems.serverSimulation', idx)),
    ...(clientStartup
      ? {
          clientStartup: (clientStartup as unknown[]).map((entry, idx) =>
            validateSystemEntry(entry, 'systems.clientStartup', idx)
          )
        }
      : {}),
    clientSimulation: clientSimulation.map((entry, idx) => validateSystemEntry(entry, 'systems.clientSimulation', idx)),
    clientPresentation: clientPresentation.map((entry, idx) => validateSystemEntry(entry, 'systems.clientPresentation', idx)),
  };
}

function ensureUniqueComponents(components: EcsComponentConfig[]) {
  const ids = new Set<number>();
  const names = new Set<string>();
  for (const component of components) {
    assert(!ids.has(component.id), `duplicate component id ${component.id}`);
    ids.add(component.id);
    assert(!names.has(component.name), `duplicate component name "${component.name}"`);
    names.add(component.name);
  }
}

export function validateEcsConfig(config: unknown): EcsConfig {
  assert(isPlainRecord(config), 'config must be an object');
  const { components, systems } = config;
  assert(Array.isArray(components), 'components must be an array');
  const validatedComponents = components.map((component, idx) => validateComponent(component, idx));
  ensureUniqueComponents(validatedComponents);
  const validatedSystems = validateSystems(systems);
  return {
    components: validatedComponents,
    systems: validatedSystems,
  };
}
