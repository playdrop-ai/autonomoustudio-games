# @playdrop/types

Shared TypeScript types and helpers for API payloads, app metadata, and realtime protocol frames.

## Responsibilities
- Defines request/response contracts for the REST API (apps, avatars, users, logs, scaffolds, home collections).
- Provides app metadata helpers (`APP_TYPE_VALUES`, `parseAppType`, `normalizeAppType`, default emoji/color mappings).
- Includes realtime protocol enums and frame shapes consumed by both the server and WebSocket clients.
- Exports the canonical `UnsupportedClientError` used by the API client when version guards fail.

## Usage
```ts
import type { AppResponse, AppType } from '@playdrop/types';
import { normalizeAppType } from '@playdrop/types';
```

## Implementation Notes
- All exports are ESM-first; the build emits `dist` artifacts referenced by package `exports`.
- Reused across server, client, and CLI workspaces to eliminate ad-hoc typings.

## Related Workspaces
- Consumed by nearly every workspace: API/realtime servers, web/admin apps, CLI, SDK, and storage helpers.
